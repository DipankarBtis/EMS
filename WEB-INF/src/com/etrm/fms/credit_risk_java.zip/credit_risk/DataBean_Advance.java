package com.etrm.fms.credit_risk;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Vector;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.etrm.fms.util.RuntimeConf;
import com.etrm.fms.util.SystemErrorLogger;
import com.etrm.fms.util.UtilBean;

//Coded By          : Harsh Patel
//Code Reviewed by	:
//CR Date			: 10/12/2024
//Status	  		: Developing
public class DataBean_Advance 
{
	String db_src_file_name="DataBean_Advance.java";
	
	Connection conn;
	PreparedStatement stmt;
	PreparedStatement stmt1;
	PreparedStatement stmt2;
	PreparedStatement stmt3;
	PreparedStatement stmt4;
	PreparedStatement stmt5;
	PreparedStatement stmt6;
	PreparedStatement stmt_temp;
	PreparedStatement stmt_temp1;
	ResultSet rset;
	ResultSet rset1;
	ResultSet rset2;
	ResultSet rset3;
	ResultSet rset4;
	ResultSet rset5;
	ResultSet rset6;
	ResultSet rset_temp;
	ResultSet rset_temp1;
	String queryString="";
	String queryString1="";
	String queryString2="";
	String queryString3="";
	String queryString4="";
	String queryString5="";
	String queryString6="";
	String queryString_temp1="";
	
	UtilBean utilBean = new UtilBean();
	
	NumberFormat nf = new DecimalFormat("###########0.00");
	NumberFormat nf2 = new DecimalFormat("###########0.0000");
	
	public void init()
	{
		String function_nm="init()";
		try
		{
			Context initContext = new InitialContext();
	    	Context envContext  = (Context)initContext.lookup("java:/comp/env");
	    	DataSource ds = (DataSource)envContext.lookup(RuntimeConf.security_database);
	    	if(ds != null)
	    	{
	    		conn = ds.getConnection(); 
	    		if(conn != null)
	    		{
	    			if(callFlag.equalsIgnoreCase("CASH_COLLATERAL_MANAGEMENT"))
	    			{
	    				getCounterpartyDetails();
	    				if(clearance.equals("I") && VMST_COUNTERPARTY_CD.size()==1)
	    				{
	    					counterparty_cd=""+VMST_COUNTERPARTY_CD.elementAt(0);
	    				}
	    				getContractDetail();
	    				getAdvanceSecurityDetails();
	    			}
	    		}
	    		conn.close();
				conn = null;
	    	}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
		finally
	    {
	    	if(rset != null){try{rset.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(rset1 != null){try{rset1.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(rset2 != null){try{rset2.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(rset3 != null){try{rset3.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(rset4 != null){try{rset4.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(rset5 != null){try{rset5.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(rset6 != null){try{rset6.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(rset_temp != null){try{rset_temp.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(rset_temp1 != null){try{rset_temp1.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt != null){try{stmt.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt1 != null){try{stmt1.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt2 != null){try{stmt2.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt3 != null){try{stmt3.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt4 != null){try{stmt4.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt5 != null){try{stmt5.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt6 != null){try{stmt6.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt_temp != null){try{stmt_temp.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt_temp1 != null){try{stmt_temp1.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(conn != null){try{conn.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    }
	}
	
	public void getCounterpartyDetails() 
	{
		String function_nm="getCounterpartyDetails()";
		try
		{
			if(clearance.equals("I"))
			{
				queryString = "SELECT COUNTERPARTY_CD,COUNTERPARTY_NM,COUNTERPARTY_ABBR "
						+ "FROM FMS_COMPANY_EXCHG_MST A "
						+ "WHERE EFF_DT=(SELECT MAX(EFF_DT) FROM FMS_COMPANY_EXCHG_MST B WHERE A.COUNTERPARTY_CD=B.COUNTERPARTY_CD) "
						+ "ORDER BY COUNTERPARTY_NM";
			}
			else
			{
				queryString = "SELECT COUNTERPARTY_CD,COUNTERPARTY_NM,COUNTERPARTY_ABBR "
						+ "FROM FMS_COUNTERPARTY_MST A "
						+ "WHERE EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_COUNTERPARTY_MST B "
						+ "WHERE A.COUNTERPARTY_CD=B.COUNTERPARTY_CD) "
						+ "AND STATUS=? AND KYC=? "
						+ "ORDER BY COUNTERPARTY_NM";
			}
			stmt = conn.prepareStatement(queryString);
			if(clearance.equals("I"))
			{
			}
			else
			{
				stmt.setString(1, "Y");
				stmt.setString(2, "Y");
			}
			rset = stmt.executeQuery();
			while(rset.next())
			{
				String counterpty_cd = rset.getString(1)==null?"":rset.getString(1);
				VMST_COUNTERPARTY_CD.add(counterpty_cd);
				VMST_COUNTERPARTY_NM.add(rset.getString(2)==null?"":rset.getString(2));
				VMST_COUNTERPARTY_ABBR.add(rset.getString(3)==null?"":rset.getString(3));
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getContractDetail()
	{
		String function_nm="getContractDetail()";
		try
		{
			int cont1=0;
			queryString2 = "SELECT AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,CONTRACT_TYPE,TO_CHAR(START_DT,'DD/MM/YYYY'),TO_CHAR(END_DT,'DD/MM/YYYY'),COUNTERPARTY_CD,"
					+ "CONT_REF_NO,TRADE_REF_NO,'GAS' "
					+ "FROM FMS_SUPPLY_CONT_MST A "
					+ "WHERE COMPANY_CD=? "
					+ "AND A.CONT_REV=(SELECT MAX(B.CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD "
					+ "AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV AND A.CONT_NO=B.CONT_NO AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) "
					+ "AND END_DT>=TO_DATE(TO_CHAR(SYSDATE,'DD/MM/YYYY'),'DD/MM/YYYY') ";
			queryString2+=clearance.equals("I")? "AND CONTRACT_TYPE=? ":"AND COUNTERPARTY_CD=? AND CONTRACT_TYPE NOT IN (?) ";
			queryString2+=" UNION ALL ";
			queryString2+="SELECT AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,CONTRACT_TYPE,TO_CHAR(START_DT,'DD/MM/YYYY'),TO_CHAR(END_DT,'DD/MM/YYYY'),COUNTERPARTY_CD,"
					+ "CONT_REF_NO,TRADE_REF_NO,'GAS' "
					+ "FROM FMS_TRADER_CONT_MST A "
					+ "WHERE COMPANY_CD=? "
					+ "AND A.CONT_REV=(SELECT MAX(B.CONT_REV) FROM FMS_TRADER_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD "
					+ "AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV AND A.CONT_NO=B.CONT_NO AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) "
					+ "AND END_DT>=TO_DATE(TO_CHAR(SYSDATE,'DD/MM/YYYY'),'DD/MM/YYYY') ";
			queryString2+=clearance.equals("I")?"AND CONTRACT_TYPE=? ":"AND COUNTERPARTY_CD=? AND CONTRACT_TYPE NOT IN (?) ";
			queryString2+=" UNION ALL ";
			queryString2+="SELECT AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,CONTRACT_TYPE,TO_CHAR(START_DT,'DD/MM/YYYY'),TO_CHAR(END_DT,'DD/MM/YYYY'),COUNTERPARTY_CD,"
					+ "CONT_REF_NO,NULL,'GAS' "
					+ "FROM FMS_TRADER_CN_MST A  "
					+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE=? AND COUNTERPARTY_CD=? "
					+ "AND A.CONT_REV=(SELECT MAX(B.CONT_REV) FROM FMS_TRADER_CN_MST B WHERE A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD  "
					+ "AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV AND A.CONT_NO=B.CONT_NO AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) "
					+ "AND END_DT>=TO_DATE(TO_CHAR(SYSDATE,'DD/MM/YYYY'),'DD/MM/YYYY') AND 'K'=? ";
			queryString2+=" UNION ALL ";
			queryString2+="SELECT AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,CONTRACT_TYPE,TO_CHAR(START_DT,'DD/MM/YYYY'),TO_CHAR(END_DT,'DD/MM/YYYY'),COUNTERPARTY_CD,"
					+ "CONT_REF_NO,NULL,'LTCORA' "
					+ "FROM FMS_LTCORA_CONT_MST A   "
					+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE IN (?,?) AND COUNTERPARTY_CD=? "
					+ "AND A.CONT_REV=(SELECT MAX(B.CONT_REV) FROM FMS_LTCORA_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD   "
					+ "AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV AND A.CONT_NO=B.CONT_NO AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) "
					+ "AND END_DT>=TO_DATE(TO_CHAR(SYSDATE,'DD/MM/YYYY'),'DD/MM/YYYY') AND 'K'=? ";
			stmt2 = conn.prepareStatement(queryString2);
			stmt2.setString(++cont1, comp_cd);
			if(clearance.equals("I"))
			{
				stmt2.setString(++cont1, "X");
			}
			else
			{
				stmt2.setString(++cont1, counterparty_cd);
				stmt2.setString(++cont1, "X");
			}
			stmt2.setString(++cont1, comp_cd);
			if(clearance.equals("I"))
			{
				stmt2.setString(++cont1, "I");
			}
			else
			{
				stmt2.setString(++cont1, counterparty_cd);
				stmt2.setString(++cont1, "I");
			}
			stmt2.setString(++cont1,comp_cd);
			stmt2.setString(++cont1,"N");
			stmt2.setString(++cont1, counterparty_cd);
			stmt2.setString(++cont1,clearance);
			stmt2.setString(++cont1, comp_cd);
			stmt2.setString(++cont1, "G");
			stmt2.setString(++cont1, "P");
			stmt2.setString(++cont1, counterparty_cd);
			stmt2.setString(++cont1,clearance);
			rset2 = stmt2.executeQuery();
			while(rset2.next())
			{
				String agmt = rset2.getString(1)==null?"0":rset2.getString(1);
				String agmt_rev = "0";//rset2.getString(2)==null?"0":rset2.getString(2);
				String cont = rset2.getString(3)==null?"0":rset2.getString(3);
				String cont_rev = "0";//rset2.getString(4)==null?"0":rset2.getString(4);
				String cont_type = rset2.getString(5)==null?"":rset2.getString(5);
				String start_dt = rset2.getString(6)==null?"":rset2.getString(6);
				String to_dt = rset2.getString(7)==null?"":rset2.getString(7);
				String countpty_cd = rset2.getString(8)==null?"":rset2.getString(8);
				String cont_ref = rset2.getString(9)==null?"":rset2.getString(9);
				if(clearance.equals("I"))
				{
					cont_ref= rset2.getString(10)==null?"":rset2.getString(10);
				}
				String dealType = rset2.getString(11)==null?"":rset2.getString(11);
				
				String abbr=""+utilBean.getCounterpartyABBR(countpty_cd);
				String dealno=utilBean.NewDealMappingId(comp_cd, countpty_cd, agmt, agmt_rev, cont, cont_rev, cont_type,"");
				
				VAGMT_NO.add(agmt);
				VAGMT_REV_NO.add(agmt_rev);
				VCONT_NO.add(cont);
				VCONT_REV_NO.add(cont_rev);
				VCONTRACT_TYPE.add(cont_type);

				VCONTRACT_MAPPING.add(countpty_cd+"-"+cont_type+"-"+agmt+"-"+agmt_rev+"-"+cont+"-"+cont_rev);
				VCONTRACT_MAPPING_DIS.add(abbr+" - "+dealno+" ["+cont_ref+"] <label style='color:blue;'>("+start_dt+" - "+to_dt+")</label>");
				VCONTRACT_MAPPING_DIS_1.add(abbr+" - "+dealno+" ["+cont_ref+"]");
				VCONTRACT_EXPIRED.add("N");
				VCONTRACT_DEAL_TYPE.add(dealType);
			}
			rset2.close();
			stmt2.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getAdvanceSecurityDetails()
	{
		String function_nm="getAdvanceSecurityDetails()";
		try
		{
			int st_count=0;
			queryString = "SELECT COUNTERPARTY_CD,SEC_TYPE,SEC_REF_NO,STATUS,CURRENCY,VALUE,TO_CHAR(RECEIPT_DT,'DD/MM/YYYY'),SEQ_NO,"
					+ "DEAL_TYPE,REMARKS,SEQ_REV_NO,PG_REF,SAP_APPROVAL,CR_DR,TDS_AMT,TDS_STRUCT_CD,TO_CHAR(TDS_EFF_DT,'DD/MM/YYYY') "
					+ "FROM FMS_SECURITY_MST "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND SEC_TYPE IN (?,?) AND GX=? "
					+ "ORDER BY ENT_DT DESC ";
			stmt = conn.prepareStatement(queryString);
			stmt.setString(++st_count, comp_cd);
			stmt.setString(++st_count, counterparty_cd);
			stmt.setString(++st_count, "ADV");
			stmt.setString(++st_count, "DPT");
			stmt.setString(++st_count, clearance);
			rset = stmt.executeQuery();
			while(rset.next())
			{
				String counterPartyCd = rset.getString(1)==null?"":rset.getString(1);
				String sec_ref_no =  rset.getString(3)==null?"":rset.getString(3);
				String currency= rset.getString(5)==null?"":rset.getString(5);
				double value = rset.getDouble(6); 
				String seq_no = rset.getString(8)==null?"":rset.getString(8);
				String seq_rev_no = rset.getString(11)==null?"":rset.getString(11);
				double tds_amt = rset.getDouble(15);
				double total_value = value + tds_amt;
				
				VCOUNTERPARTY_CD.add(counterPartyCd);
				if(clearance.equals("I"))
				{
					VCOUNTERPARTY_NAME.add(""+utilBean.getGasExchangeName(counterPartyCd));
					VCOUNTERPARTY_ABBR.add(""+utilBean.getGasExchangeAbbr(counterPartyCd));
				}
				else
				{
					VCOUNTERPARTY_NAME.add(""+utilBean.getCounterpartyName(counterPartyCd));
					VCOUNTERPARTY_ABBR.add(""+utilBean.getCounterpartyABBR(counterPartyCd));
				}
				VSEC_TYPE.add(rset.getString(2)==null?"":rset.getString(2));
				VSEC_REF_NO.add(comp_cd+"-"+sec_ref_no);
				VTEMP_SEC_REF_NO.add(sec_ref_no);
				VSTATUS.add(rset.getString(4)==null?"":rset.getString(4));
				VCURRENCY.add(currency);
				VCURRENCY_NM.add(utilBean.getRateUnitNm(currency));
				VVALUE.add(rset.getString(6)==null?"":nf.format(rset.getDouble(6)));
				VRECEIVED_DATE.add(rset.getString(7)==null?"":rset.getString(7));
				VSEQ_NO.add(seq_no);
				VDEAL_TYPE.add(rset.getString(9)==null?"":rset.getString(9));
				VREMARK.add(rset.getString(10)==null?"":rset.getString(10));
				VSEQ_REV_NO.add(seq_rev_no);
				VADV_PG_REF.add(rset.getString(12)==null?"":rset.getString(12));
				VSAP_APPROVAL_FLAG.add(rset.getString(13)==null?"":rset.getString(13));
				String cr_dr=rset.getString(14)==null?"":rset.getString(14);
				String cr_dr_nm=cr_dr.equals("CR")?"Credit":cr_dr.equals("DR")?"Debit":"";
				VCRDR.add(cr_dr);
				VCRDR_NM.add(cr_dr_nm);
				VTDS_AMT.add(rset.getString(15)==null?"":nf.format(rset.getDouble(15)));
				String tds_struct_cd=rset.getString(16)==null?"":rset.getString(16);
				String tds_eff_dt=rset.getString(17)==null?"":rset.getString(17);
				VTDS_STRUCT_CD.add(tds_struct_cd);
				VTDS_EFF_DT.add(tds_eff_dt);
				VTDS_STRUCT_INFO.add(utilBean.getTaxDescr(tds_struct_cd, tds_eff_dt));
				VTOTAL_VALUE.add(nf.format(total_value));
				
				String dealNo = "";
				String deal_mapping = "";
				st_count=0;
				queryString1 = "SELECT A.AGMT_NO,A.AGMT_REV,A.CONT_NO,A.CONT_REV,A.CONTRACT_TYPE,TO_CHAR(A.START_DT,'DD/MM/YYYY'),TO_CHAR(A.END_DT,'DD/MM/YYYY'),A.COUNTERPARTY_CD,"
						+ "A.CONT_REF_NO,A.TRADE_REF_NO,'GAS' "
						+ "FROM FMS_SUPPLY_CONT_MST A, FMS_SECURITY_DEAL_MAP B "
						+ "WHERE A.COMPANY_CD=? AND B.COUNTERPARTY_CD=? AND B.GX=? AND B.SEQ_NO=? AND B.SEQ_REV_NO=? "
						+ "AND A.CONT_REV=(SELECT MAX(B.CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD "
						+ "AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV AND A.CONT_NO=B.CONT_NO AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) "
						+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.AGMT_NO=B.AGMT_NO AND A.CONT_NO=B.CONT_NO AND A.CONTRACT_TYPE=B.CONTRACT_TYPE ";
				queryString1+=clearance.equals("I")?"AND A.COUNTERPARTY_CD=B.ENTITY_CD ":"AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD ";
				queryString1+=" UNION ALL ";
				queryString1+= "SELECT A.AGMT_NO,A.AGMT_REV,A.CONT_NO,A.CONT_REV,A.CONTRACT_TYPE,TO_CHAR(A.START_DT,'DD/MM/YYYY'),TO_CHAR(A.END_DT,'DD/MM/YYYY'),A.COUNTERPARTY_CD,"
						+ "A.CONT_REF_NO,A.TRADE_REF_NO,'GAS' "
						+ "FROM FMS_TRADER_CONT_MST A, FMS_SECURITY_DEAL_MAP B "
						+ "WHERE A.COMPANY_CD=? AND B.COUNTERPARTY_CD=? AND B.GX=? AND B.SEQ_NO=? AND B.SEQ_REV_NO=? "
						+ "AND A.CONT_REV=(SELECT MAX(B.CONT_REV) FROM FMS_TRADER_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD "
						+ "AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV AND A.CONT_NO=B.CONT_NO AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) "
						+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.AGMT_NO=B.AGMT_NO AND A.CONT_NO=B.CONT_NO AND A.CONTRACT_TYPE=B.CONTRACT_TYPE ";
				queryString1+=clearance.equals("I")?"AND A.COUNTERPARTY_CD=B.ENTITY_CD ":"AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD ";
				queryString1+=" UNION ALL ";
				queryString1+= "SELECT A.AGMT_NO,A.AGMT_REV,A.CONT_NO,A.CONT_REV,A.CONTRACT_TYPE,TO_CHAR(A.START_DT,'DD/MM/YYYY'),TO_CHAR(A.END_DT,'DD/MM/YYYY'),A.COUNTERPARTY_CD,"
						+ "A.CONT_REF_NO,NULL,'GAS' "
						+ "FROM FMS_TRADER_CN_MST A, FMS_SECURITY_DEAL_MAP B  "
						+ "WHERE A.COMPANY_CD=? AND B.COUNTERPARTY_CD=? AND B.GX=? AND B.SEQ_NO=? AND B.SEQ_REV_NO=? "
						+ "AND A.CONT_REV=(SELECT MAX(B.CONT_REV) FROM FMS_TRADER_CN_MST B WHERE A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD  "
						+ "AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV AND A.CONT_NO=B.CONT_NO AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) "
						+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.AGMT_NO=B.AGMT_NO AND A.CONT_NO=B.CONT_NO AND A.CONTRACT_TYPE=B.CONTRACT_TYPE ";
				queryString1+=clearance.equals("I")?"AND A.COUNTERPARTY_CD=B.ENTITY_CD ":"AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD ";
				queryString1+=" UNION ALL ";
				queryString1+= "SELECT A.AGMT_NO,A.AGMT_REV,A.CONT_NO,A.CONT_REV,A.CONTRACT_TYPE,TO_CHAR(A.START_DT,'DD/MM/YYYY'),TO_CHAR(A.END_DT,'DD/MM/YYYY'),A.COUNTERPARTY_CD,"
						+ "A.CONT_REF_NO,NULL,'LTCORA' "
						+ "FROM FMS_LTCORA_CONT_MST A, FMS_SECURITY_DEAL_MAP B "
						+ "WHERE A.COMPANY_CD=? AND B.COUNTERPARTY_CD=? AND B.GX=? AND B.SEQ_NO=? AND B.SEQ_REV_NO=? "
						+ "AND A.CONT_REV=(SELECT MAX(B.CONT_REV) FROM FMS_LTCORA_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD   "
						+ "AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV AND A.CONT_NO=B.CONT_NO AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) "
						+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.AGMT_NO=B.AGMT_NO AND A.CONT_NO=B.CONT_NO AND A.CONTRACT_TYPE=B.CONTRACT_TYPE ";
				queryString1+=clearance.equals("I")?"AND A.COUNTERPARTY_CD=B.ENTITY_CD ":"AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD ";
				stmt1 = conn.prepareStatement(queryString1);
				stmt1.setString(++st_count, comp_cd);
				stmt1.setString(++st_count, counterPartyCd);
				stmt1.setString(++st_count, clearance);
				stmt1.setString(++st_count, seq_no);
				stmt1.setString(++st_count, seq_rev_no);
				stmt1.setString(++st_count, comp_cd);
				stmt1.setString(++st_count, counterPartyCd);
				stmt1.setString(++st_count, clearance);
				stmt1.setString(++st_count, seq_no);
				stmt1.setString(++st_count, seq_rev_no);
				stmt1.setString(++st_count, comp_cd);
				stmt1.setString(++st_count, counterPartyCd);
				stmt1.setString(++st_count, clearance);
				stmt1.setString(++st_count, seq_no);
				stmt1.setString(++st_count, seq_rev_no);
				stmt1.setString(++st_count, comp_cd);
				stmt1.setString(++st_count, counterPartyCd);
				stmt1.setString(++st_count, clearance);
				stmt1.setString(++st_count, seq_no);
				stmt1.setString(++st_count, seq_rev_no);
				rset1 = stmt1.executeQuery();
				while(rset1.next())
				{
					String agmt = rset1.getString(1)==null?"0":rset1.getString(1);
					String agmt_rev = "0";//rset1.getString(2)==null?"":rset1.getString(2);
					String cont = rset1.getString(3)==null?"":rset1.getString(3);
					String cont_rev = "0";//rset1.getString(4)==null?"":rset1.getString(4);
					String cont_type = rset1.getString(5)==null?"":rset1.getString(5);
					String start_dt = rset1.getString(6)==null?"":rset1.getString(6);
					String to_dt = rset1.getString(7)==null?"":rset1.getString(7);
					String counterparty_cd = rset1.getString(8)==null?"":rset1.getString(8);
					String cont_ref = rset1.getString(9)==null?"":rset1.getString(9);
					if(clearance.equals("I"))
					{
						cont_ref= rset1.getString(10)==null?"":rset1.getString(10);
					}
					String dealType = rset1.getString(11)==null?"":rset1.getString(11);
					
					String abbr=""+utilBean.getCounterpartyABBR(counterparty_cd);
					String tempDealNo=utilBean.NewDealMappingId(comp_cd,counterparty_cd, agmt, agmt_rev, cont, cont_rev, cont_type, "");
					dealNo=dealNo.equals("")?tempDealNo:dealNo+","+tempDealNo;
					
					deal_mapping=counterparty_cd+"-"+cont_type+"-"+agmt+"-"+agmt_rev+"-"+cont+"-"+cont_rev;
					if(!VCONTRACT_MAPPING.contains(deal_mapping))
					{
						VAGMT_NO.add(agmt);
						VAGMT_REV_NO.add(agmt_rev);
						VCONT_NO.add(cont);
						VCONT_REV_NO.add(cont_rev);
						VCONTRACT_TYPE.add(cont_type);
	
						VCONTRACT_MAPPING.add(counterparty_cd+"-"+cont_type+"-"+agmt+"-"+agmt_rev+"-"+cont+"-"+cont_rev);
						VCONTRACT_MAPPING_DIS.add(abbr+" - "+tempDealNo+" ["+cont_ref+"] <label style='color:blue;'>("+start_dt+" - "+to_dt+")</label>");
						VCONTRACT_MAPPING_DIS_1.add(abbr+" - "+tempDealNo+" ["+cont_ref+"]");
						VCONTRACT_EXPIRED.add("Y");
						VCONTRACT_DEAL_TYPE.add(dealType);
					}
				}
				rset1.close();
				stmt1.close();
				
				VDEAL_NO.add(dealNo);
				VDEAL_MAPPING.add(deal_mapping);
				
				String pdf_generated = "N";
				String pdf_name="";
				queryString5 = "SELECT FILE_NAME "
						+ "FROM FMS_SECURITY_FILE_DTL "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND SEQ_NO=? "
						+ "AND SEQ_REV_NO=? AND GX=? AND FILE_TYPE=?";
				stmt5 = conn.prepareStatement(queryString5);
				stmt5.setString(1, comp_cd);
				stmt5.setString(2, counterPartyCd);
				stmt5.setString(3, seq_no);
				stmt5.setString(4, seq_rev_no);
				stmt5.setString(5, clearance);
				stmt5.setString(6, "PDF");
				rset5 = stmt5.executeQuery();
				if(rset5.next())
				{
					pdf_generated = "Y";
					pdf_name = rset5.getString(1)==null?"":rset5.getString(1);
				}
				VPDF_GENERATED.add(pdf_generated);
				VPDF_FILE_NAME.add(pdf_name);

				rset5.close();
				stmt5.close();

				/*String pdf_rev_generated = "N";
				String rev_pdf_name="";
				queryString6 = "SELECT FILE_NAME "
						+ "FROM FMS_SECURITY_FILE_DTL "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND SEQ_NO=? "
						+ "AND SEQ_REV_NO=? AND GX=? AND FILE_TYPE=?";
				stmt6 = conn.prepareStatement(queryString6);
				stmt6.setString(1, comp_cd);
				stmt6.setString(2, counterPartyCd);
				stmt6.setString(3, seq_no);
				stmt6.setString(4, seq_rev_no);
				stmt6.setString(5, clearance);
				stmt6.setString(6, "PDF_REV");
				rset6 = stmt6.executeQuery();
				if(rset6.next())
				{
					pdf_rev_generated = "Y";
					rev_pdf_name = rset6.getString(1)==null?"":rset6.getString(1);
				}
				VPDF_REV_GENERATED.add(pdf_rev_generated);
				VPDF_REV_FILE_NAME.add(rev_pdf_name);

				rset6.close();
				stmt6.close();*/
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	String callFlag = "";
	public void setCallFlag(String callFlag) {this.callFlag = callFlag;}
	String comp_cd = "";
	public void setComp_cd(String comp_cd) {this.comp_cd = comp_cd;}
	
	String counterparty_cd = "";
	String cont_no = "";
	String cont_rev_no = "";
	String agmt_no = "";
	String agmt_rev_no = "";
	String contract_type = "";
	String clearance = "";
	String adv_flag = "";
	String gx = "";
	String seq_no = "";
	String seq_rev_no = "";
	String sec_ref_no = "";
	String emp_cd = "";
	
	public void setCounterparty_cd(String counterparty_cd) {this.counterparty_cd = counterparty_cd;}
	public void setCont_no(String cont_no) {this.cont_no = cont_no;}
	public void setCont_rev_no(String cont_rev_no) {this.cont_rev_no = cont_rev_no;}
	public void setAgmt_no(String agmt_no) {this.agmt_no = agmt_no;}
	public void setAgmt_rev_no(String agmt_rev_no) {this.agmt_rev_no = agmt_rev_no;}
	public void setContract_type(String contract_type) {this.contract_type = contract_type;}
	public void setClearance(String clearance) {this.clearance = clearance;}
	public void setAdv_flag(String adv_flag) {this.adv_flag = adv_flag;}
	public void setGx(String gx) {this.gx = gx;}
	public void setSeq_no(String seq_no) {this.seq_no = seq_no;}
	public void setSeq_rev_no(String seq_rev_no) {this.seq_rev_no = seq_rev_no;}
	public void setSec_ref_no(String sec_ref_no) {this.sec_ref_no = sec_ref_no;}
	public void setEmp_cd(String emp_cd) {this.emp_cd = emp_cd;}
	
	public String getCounterparty_cd() {return counterparty_cd;}
	
	Vector VMST_COUNTERPARTY_CD = new Vector();
	Vector VMST_COUNTERPARTY_NM = new Vector();
	Vector VMST_COUNTERPARTY_ABBR = new Vector();
	Vector VCOUNTERPARTY_CD = new Vector();
	Vector VCOUNTERPARTY_NAME = new Vector();
	Vector VCOUNTERPARTY_ABBR = new Vector();
	Vector VCONT_NO = new Vector();
	Vector VCONT_REV_NO = new Vector();
	Vector VAGMT_NO = new Vector();
	Vector VAGMT_REV_NO = new Vector();
	Vector VCONTRACT_TYPE = new Vector();
	Vector VSTATUS = new Vector();
	Vector VSTATUS_NM = new Vector();
	Vector VCURRENCY = new Vector();
	Vector VCURRENCY_NM = new Vector();
	Vector VSEC_TYPE = new Vector();
	Vector VSEC_REF_NO = new Vector();
	Vector VVALUE = new Vector();
	Vector VTOTAL_VALUE = new Vector();
	Vector VRECEIVED_DATE = new Vector();
	Vector VDEAL_TYPE = new Vector();
	Vector VSEQ_NO = new Vector();
	Vector VSEQ_REV_NO = new Vector();
	Vector VREMARK = new Vector();
	Vector VADV_PG_REF = new Vector();
	Vector VDEAL_NO = new Vector();
	Vector VPDF_GENERATED = new Vector();
	Vector VPDF_FILE_NAME = new Vector();
	Vector VSAP_APPROVAL_FLAG = new Vector();
	Vector VCONTRACT_MAPPING = new Vector();
	Vector VCONTRACT_MAPPING_DIS = new Vector();
	Vector VCONTRACT_MAPPING_DIS_1 = new Vector();
	Vector VCRDR = new Vector();
	Vector VCRDR_NM = new Vector();
	Vector VTDS_AMT = new Vector();
	Vector VTDS_STRUCT_CD = new Vector();
	Vector VTDS_STRUCT_INFO = new Vector();
	Vector VTDS_EFF_DT = new Vector();
	Vector VTEMP_SEC_REF_NO = new Vector();
	Vector VDEAL_MAPPING = new Vector();
	Vector VCONTRACT_EXPIRED = new Vector();
	Vector VCONTRACT_DEAL_TYPE = new Vector();
	
	public Vector getVMST_COUNTERPARTY_CD() {return VMST_COUNTERPARTY_CD;}
	public Vector getVMST_COUNTERPARTY_NM() {return VMST_COUNTERPARTY_NM;}
	public Vector getVMST_COUNTERPARTY_ABBR() {return VMST_COUNTERPARTY_ABBR;}
	public Vector getVCOUNTERPARTY_CD() {return VCOUNTERPARTY_CD;}
	public Vector getVCOUNTERPARTY_NAME() {return VCOUNTERPARTY_NAME;}
	public Vector getVCOUNTERPARTY_ABBR() {return VCOUNTERPARTY_ABBR;}
	public Vector getVCONT_NO() {return VCONT_NO;}
	public Vector getVCONT_REV_NO() {return VCONT_REV_NO;}
	public Vector getVAGMT_NO() {return VAGMT_NO;}
	public Vector getVAGMT_REV_NO() {return VAGMT_REV_NO;}
	public Vector getVCONTRACT_TYPE() {return VCONTRACT_TYPE;}
	public Vector getVSTATUS() {return VSTATUS;}
	public Vector getVSTATUS_NM() {return VSTATUS_NM;}
	public Vector getVCURRENCY() {return VCURRENCY;}
	public Vector getVCURRENCY_NM() {return VCURRENCY_NM;}
	public Vector getVSEC_TYPE() {return VSEC_TYPE;}
	public Vector getVSEC_REF_NO() {return VSEC_REF_NO;}
	public Vector getVVALUE() {return VVALUE;}
	public Vector getVTOTAL_VALUE() {return VTOTAL_VALUE;}
	public Vector getVRECEIVED_DATE() {return VRECEIVED_DATE;}
	public Vector getVDEAL_TYPE() {return VDEAL_TYPE;}
	public Vector getVSEQ_NO() {return VSEQ_NO;}
	public Vector getVSEQ_REV_NO() {return VSEQ_REV_NO;}
	public Vector getVREMARK() {return VREMARK;}
	public Vector getVADV_PG_REF() {return VADV_PG_REF;}
	public Vector getVDEAL_NO() {return VDEAL_NO;}
	public Vector getVPDF_GENERATED() {return VPDF_GENERATED;}
	public Vector getVPDF_FILE_NAME() {return VPDF_FILE_NAME;}
	public Vector getVSAP_APPROVAL_FLAG() {return VSAP_APPROVAL_FLAG;}
	public Vector getVCONTRACT_MAPPING() {return VCONTRACT_MAPPING;}
	public Vector getVCONTRACT_MAPPING_DIS() {return VCONTRACT_MAPPING_DIS;}
	public Vector getVCONTRACT_MAPPING_DIS_1() {return VCONTRACT_MAPPING_DIS_1;}
	public Vector getVCRDR() {return VCRDR;}
	public Vector getVCRDR_NM() {return VCRDR_NM;}
	public Vector getVTDS_AMT() {return VTDS_AMT;}
	public Vector getVTDS_STRUCT_CD() {return VTDS_STRUCT_CD;}
	public Vector getVTDS_STRUCT_INFO() {return VTDS_STRUCT_INFO;}
	public Vector getVTDS_EFF_DT() {return VTDS_EFF_DT;}
	public Vector getVTEMP_SEC_REF_NO() {return VTEMP_SEC_REF_NO;}
	public Vector getVDEAL_MAPPING() {return VDEAL_MAPPING;}
	public Vector getVCONTRACT_EXPIRED() {return VCONTRACT_EXPIRED;}
	public Vector getVCONTRACT_DEAL_TYPE() {return VCONTRACT_DEAL_TYPE;}
}