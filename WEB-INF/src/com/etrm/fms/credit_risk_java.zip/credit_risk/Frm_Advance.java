package com.etrm.fms.credit_risk;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.etrm.fms.util.CommonVariable;
import com.etrm.fms.util.RuntimeConf;
import com.etrm.fms.util.SystemErrorLogger;
import com.etrm.fms.util.UtilBean;
import com.etrm.fms.util.escapeSingleQuotes;

@WebServlet("/servlet/Frm_Advance")
public class Frm_Advance extends HttpServlet
{
	static String frm_src_file_name="Frm_Advance.java";
	public static Connection dbcon;
	
	public static String option = "";
	public static String url = "";
	public static String msg = "";
	public static String msg_type = "";
	public static String err_msg = "";
	
	private static String queryString = null;
	private static String query = null;
	private static String query1 = null;
	private static String query2 = null;
	private static PreparedStatement stmt = null;
	private static PreparedStatement stmt1 = null;
	private static PreparedStatement stmt2 = null;
	private static PreparedStatement stmt3 = null;
	private static PreparedStatement stmt4 = null;
	
	private static ResultSet rset = null;
	private static ResultSet rset1 = null;
	private static ResultSet rset2 = null;
	private static ResultSet rset3 = null;
	private static ResultSet rset4 = null;
	
	public static String form_id = "0";
	public static String form_nm = "";
	public static String mod_cd = "0";
	public static String mod_nm = "";
	public static String u = "";
	
	public static String old_value="";
	public static String new_value="";
	
	public static String emp_cd="";
	public static String comp_cd="";
	public static String comp_abbr="";
	public static String emp_nm="";
	public static String ip="";
	
	public static String commonUrl_pra="";
	
	public static escapeSingleQuotes escObj = new escapeSingleQuotes();
	
	static UtilBean utilBean = new UtilBean();
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
	{
		String function_nm="doPost()";
		HttpSession session = request.getSession();
		if(session.getAttribute("emp_uid")==null || session.getAttribute("emp_uid")=="")
		{
			url="../sess/Expire.jsp";
		}
		else
		{
			try
			{
				Context Context = new InitialContext();
				Context envContext  = (Context)Context.lookup("java:/comp/env");
				DataSource ds = (DataSource)envContext.lookup(RuntimeConf.security_database);
				
				if(ds != null)
				{
					dbcon = ds.getConnection();	
					if(dbcon != null)
					{
						dbcon.setAutoCommit(false);
						
						form_id=request.getParameter("form_cd")==null?"0":request.getParameter("form_cd");
						form_nm=request.getParameter("form_nm")==null?"":request.getParameter("form_nm");
						mod_cd=request.getParameter("mod_cd")==null?"0":request.getParameter("mod_cd");
						mod_nm=request.getParameter("mod_nm")==null?"":request.getParameter("mod_nm");
						
						emp_cd = (String)session.getAttribute("emp_cd")==null?"":(String)session.getAttribute("emp_cd");
						comp_cd = (String)session.getAttribute("comp_cd")==null?"":(String)session.getAttribute("comp_cd");
						comp_abbr = (String)session.getAttribute("comp_abbr")==null?"":(String)session.getAttribute("comp_abbr");
						emp_nm = (String)session.getAttribute("emp_nm")==null?"":(String)session.getAttribute("emp_nm");
						ip = (String)session.getAttribute("ip")==null?"":(String)session.getAttribute("ip");
						u=request.getParameter("u")==null?"":request.getParameter("u");
						
						new_value="";
						old_value="";
						
						option=request.getParameter("option")==null?"":request.getParameter("option");
						
						commonUrl_pra = "&u="+u;
						
						if(option.equalsIgnoreCase("CASH_COLLATERAL_MST"))
						{
							InsertUpdateCashCollateral(request);
						}
					}
				}
			}
			catch(Exception e)
			{
				new SystemErrorLogger().InsertErrorLogger(frm_src_file_name, function_nm, e);
				url=CommonVariable.errorpage_url;
			}
			finally
			{
				if(rset != null){try {rset.close();}catch(SQLException e){System.out.println("rset is not close " + e);}}
				if(rset1 != null){try {rset1.close();}catch(SQLException e){System.out.println("rset1 is not close " + e);}}
				if(rset2 != null){try {rset2.close();}catch(SQLException e){System.out.println("rset2 is not close " + e);}}
				if(rset3 != null){try {rset3.close();}catch(SQLException e){System.out.println("rset3 is not close " + e);}}
				if(rset4 != null){try {rset4.close();}catch(SQLException e){System.out.println("rset4 is not close " + e);}}
				if(stmt != null){try {stmt.close();}catch(SQLException e){System.out.println("stmt is not close " + e);}}
				if(stmt1 != null){try {stmt1.close();}catch(SQLException e){System.out.println("stmt1 is not close " + e);}}
				if(stmt2 != null){try {stmt2.close();}catch(SQLException e){System.out.println("stmt2 is not close " + e);}}
				if(stmt3 != null){try {stmt3.close();}catch(SQLException e){System.out.println("stmt3 is not close " + e);}}
				if(stmt4 != null){try {stmt4.close();}catch(SQLException e){System.out.println("stmt4 is not close " + e);}}
				if(dbcon != null){try {dbcon.close();}catch(SQLException e){System.out.println("conn is not close " + e);}}
			}
		}
		
		try 
		{
			response.sendRedirect(url);
		}
		catch(IOException e) 
		{
			new SystemErrorLogger().InsertErrorLogger(frm_src_file_name, function_nm, e);
		}
	}
	
	private void InsertUpdateCashCollateral(HttpServletRequest request)throws SQLException 
	{
		String function_nm="InsertUpdateCashCollateral()";
		msg="";
		msg_type="";
		url="";
		try
		{
			String operation = request.getParameter("opration")==null?"":request.getParameter("opration");
			String clearance = request.getParameter("clearance")==null?"":request.getParameter("clearance");
			
			String counterparty = request.getParameter("counterparty")==null?"":request.getParameter("counterparty");
			String sec_type = request.getParameter("sec_type")==null?"":request.getParameter("sec_type");
			String crdr = request.getParameter("crdr")==null?"":request.getParameter("crdr");
			String value = request.getParameter("value")==null?"":request.getParameter("value");
			String currency = request.getParameter("currency")==null?"":request.getParameter("currency");
			String tds_cd = request.getParameter("tds_cd")==null?"":request.getParameter("tds_cd");
			String tds_dt = request.getParameter("tds_dt")==null?"":request.getParameter("tds_dt");
			String tds_amt = request.getParameter("tds_amt")==null?"":request.getParameter("tds_amt");
			String received_dt = request.getParameter("received_dt")==null?"":request.getParameter("received_dt");
			String pg_ref = request.getParameter("pg_ref")==null?"":request.getParameter("pg_ref");
			String deal_type = request.getParameter("deal_type")==null?"":request.getParameter("deal_type");
			String status = request.getParameter("status")==null?"":request.getParameter("status");
			String remark = request.getParameter("remark")==null?"":request.getParameter("remark");
			remark=escObj.replaceSingleQuotes(remark);
			
			String[] deal_dtl = request.getParameterValues("deal_dtl");
			
			String seq_no="1";
			String seq_rev_no="0";
			String ref_no="";
			String counterparty_abbr = "";
			String counterparty_nm = "";
			if(clearance.equals("I"))
			{
				counterparty_abbr = ""+utilBean.getGasExchangeAbbr(counterparty);
				counterparty_nm = ""+utilBean.getGasExchangeName(counterparty);
			}
			else
			{
				counterparty_abbr = ""+utilBean.getCounterpartyABBR(counterparty);
				counterparty_nm = ""+utilBean.getCounterpartyName(counterparty);
			}
			
			boolean isOperation=false;
			if(operation.equals("MODIFY"))
			{
				seq_no = request.getParameter("seq_no")==null?"":request.getParameter("seq_no");
				seq_rev_no = request.getParameter("seq_rev_no")==null?"":request.getParameter("seq_rev_no");
				ref_no = request.getParameter("ref_no")==null?"":request.getParameter("ref_no");
				
				int num=0;
				query="UPDATE FMS_SECURITY_MST SET CR_DR=?,VALUE=?,CURRENCY=?,SEC_TYPE=?,"
						+ "RECEIPT_DT=TO_DATE(?,'DD/MM/YYYY'),PG_REF=?, "
						+ "MODIFY_DT=SYSDATE , MODIFY_BY=? ,REMARKS=?,STATUS=?,"
						+ "TDS_AMT=?,TDS_STRUCT_CD=?,TDS_EFF_DT=TO_DATE(?,'DD/MM/YYYY'),DEAL_TYPE=? ";
				if(status.equals("C"))
				{
					query+=",CANCEL_DT=SYSDATE ";
				}
				if(status.equals("O"))
				{
					query+=",INORDER_HIST=?,APRV_DT=SYSDATE,APRV_BY=? ";
				}
				query+= "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND GX=? "
						+ "AND SEQ_NO=? AND SEQ_REV_NO=? ";
				stmt=dbcon.prepareStatement(query);
				stmt.setString(++num, crdr);
				stmt.setString(++num, value);
				stmt.setString(++num, currency);
				stmt.setString(++num, sec_type);
				stmt.setString(++num, received_dt);
				stmt.setString(++num, pg_ref);
				stmt.setString(++num, emp_cd);
				stmt.setString(++num, remark);
				stmt.setString(++num, status);
				stmt.setString(++num, tds_amt);
				stmt.setString(++num, tds_cd);
				stmt.setString(++num, tds_dt);
				stmt.setString(++num, deal_type);
				if(status.equals("O"))
				{
					stmt.setString(++num, "Y");
					stmt.setString(++num, emp_cd);
				}
				stmt.setString(++num, comp_cd);
				stmt.setString(++num, counterparty);
				stmt.setString(++num, clearance);
				stmt.setString(++num, seq_no);
				stmt.setString(++num, seq_rev_no);
				stmt.executeUpdate();
				stmt.close();
				
				query = "DELETE FROM FMS_SECURITY_DEAL_MAP "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND GX=? "
					+ "AND SEQ_NO=? AND SEQ_REV_NO=? ";
				stmt=dbcon.prepareStatement(query);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty);
				stmt.setString(3, clearance);
				stmt.setString(4, seq_no);
				stmt.setString(5, seq_rev_no);
				stmt.executeUpdate();
				stmt.close();
				
				isOperation=true;
				
				msg = "Successful! - "+sec_type+" Cash Collateral "+comp_cd+"-"+ref_no+" Modified for "+counterparty_nm+"!";
				msg_type="S";
			}
			else if(operation.equals("INSERT"))
			{
				query="SELECT MAX(SEQ_NO)"
						+ "FROM FMS_SECURITY_MST "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND GX=?";
				stmt=dbcon.prepareStatement(query);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty);
				stmt.setString(3, clearance);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					seq_no=""+(rset.getInt(1)+1);
				}
				rset.close();
				stmt.close();
				
				ref_no=counterparty_abbr+"-S-"+seq_no;
				query="INSERT INTO FMS_SECURITY_MST(COMPANY_CD,COUNTERPARTY_CD,SEQ_NO,SEC_REF_NO,CR_DR,SEC_TYPE,CURRENCY,VALUE,"
						+ "RECEIPT_DT,REMARKS,STATUS,ENT_BY,ENT_DT,SEQ_REV_NO,GX,TDS_AMT,TDS_STRUCT_CD,TDS_EFF_DT,PG_REF,DEAL_TYPE) "
						+ "VALUES(?,?,?,?,?,?,?,?,TO_DATE(?,'DD/MM/YYYY'),?,?,?,SYSDATE,?,?,?,?,TO_DATE(?,'DD/MM/YYYY'),?,?)";
				stmt=dbcon.prepareStatement(query);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty);
				stmt.setString(3, seq_no);
				stmt.setString(4, ref_no);
				stmt.setString(5, crdr);
				stmt.setString(6, sec_type);
				stmt.setString(7, currency);
				stmt.setString(8, value);
				stmt.setString(9, received_dt);
				stmt.setString(10, remark);
				stmt.setString(11, status);
				stmt.setString(12, emp_cd);
				stmt.setString(13, seq_rev_no);
				stmt.setString(14, clearance);
				stmt.setString(15, tds_amt);
				stmt.setString(16, tds_cd);
				stmt.setString(17, tds_dt);
				stmt.setString(18, pg_ref);
				stmt.setString(19, deal_type);
				stmt.executeUpdate();
				
				stmt.close();
				
				isOperation=true;
				
				msg = "Successful! - "+sec_type+" Cash Collateral "+comp_cd+"-"+ref_no+" Added for "+counterparty_nm+"!";
				msg_type="S";
			}
			
			if(isOperation)
			{
				if(deal_dtl != null)
				{
					for(int i=0;i<deal_dtl.length;i++)
					{
						String map_seq_no="1";
						query="SELECT MAX(MAP_SEQ_NO) "
								+ "FROM FMS_SECURITY_DEAL_MAP "
								+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
								+ "AND SEQ_NO=? AND SEQ_REV_NO=? AND GX=?";
						stmt=dbcon.prepareStatement(query);
						stmt.setString(1, comp_cd);
						stmt.setString(2, counterparty);
						stmt.setString(3, seq_no);
						stmt.setString(4, seq_rev_no);
						stmt.setString(5, clearance);
						rset=stmt.executeQuery();
						if(rset.next())
						{
							map_seq_no=""+(rset.getInt(1)+1);
						}
						rset.close();
						stmt.close();
						
						String[] new_deal_info = deal_dtl[i].split("-");
						String entity_cd="";
						if(clearance.equals("I"))
						{
							entity_cd=new_deal_info[0];
						}
						String cont_type =  new_deal_info[1];
						String agmt = new_deal_info[2];
						String agmt_rev = new_deal_info[3];
						String cont = new_deal_info[4];
						String cont_rev = new_deal_info[5];
						
						query="INSERT INTO FMS_SECURITY_DEAL_MAP(COMPANY_CD,COUNTERPARTY_CD,AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,SEQ_NO,"
								+ "MAP_SEQ_NO,SEC_REF_NO,CONTRACT_TYPE,ENT_BY,ENT_DT,SEQ_REV_NO,GX,ENTITY_CD) "
								+ "VALUES(?,?,?,?,?,?,?,?,?,?,?,SYSDATE,?,?,?)";
						stmt=dbcon.prepareStatement(query);
						stmt.setString(1, comp_cd);
						stmt.setString(2, counterparty);
						stmt.setString(3, agmt);
						stmt.setString(4, agmt_rev);
						stmt.setString(5, cont);
						stmt.setString(6, cont_rev);
						stmt.setString(7, seq_no);
						stmt.setString(8, map_seq_no);
						stmt.setString(9, ref_no);
						stmt.setString(10, cont_type);
						stmt.setString(11, emp_cd);
						stmt.setString(12, seq_rev_no);
						stmt.setString(13, clearance);
						stmt.setString(14, entity_cd);
						stmt.executeQuery();
						stmt.close();
					}
				}
				
				String dtl_seqNo = "";
				query1 = "SELECT MAX(NVL(LOG_SEQ_NO,1)+1) "
						+ "FROM LOG_FMS_SECURITY_MST "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND SEQ_NO=? "
						+ "AND SEQ_REV_NO=? AND GX=?";
				stmt1=dbcon.prepareStatement(query1);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, counterparty);
				stmt1.setString(3, seq_no);
				stmt1.setString(4, seq_rev_no);
				stmt1.setString(5, clearance);
				rset1 = stmt1.executeQuery();
				if(rset1.next()) 
				{
					dtl_seqNo = rset1.getString(1)==null?"1":rset1.getString(1);
				}
				rset1.close();
				stmt1.close();
				
				query2 = "INSERT INTO LOG_FMS_SECURITY_MST(COMPANY_CD, COUNTERPARTY_CD, SEQ_NO, LOG_SEQ_NO, LOG_ENT_DT, SEC_REF_NO, SEC_CATEGORY, "
						+ "SEC_TYPE, DEAL_TYPE, GUARANTOR_CD, CURRENCY, VARIATION_VALUE, VALUE, VALUE_FLUC, ISS_BANK_CD, ISS_BANK_REF, ADV_BANK_CD, "
						+ "ADV_BANK_REF, CONFIRM_BANK_CD, CONFIRM_BANK_REF, RECEIPT_DT, ISSUE_DT, EXPIRE_DT, RENEW_DT, CANCEL_DT, TENOR, REVIEW_DT, "
						+ "STATUS, REMARKS, FLAG, INORDER_HIST, ENT_BY, ENT_DT, MODIFY_DT, MODIFY_BY, APRV_DT, APRV_BY, GX, SEQ_REV_NO, SAP_APPROVAL, "
						+ "SAP_APPROVED_BY, SAP_APPROVED_DT, SAP_REVERSAL, SAP_REVERSAL_BY, SAP_REVERSAL_DT,PG_REF,CR_DR,TDS_AMT,TDS_STRUCT_CD,TDS_EFF_DT) "
						+ "SELECT COMPANY_CD, COUNTERPARTY_CD, SEQ_NO, ?, SYSDATE, SEC_REF_NO, SEC_CATEGORY, "
						+ "SEC_TYPE, DEAL_TYPE, GUARANTOR_CD, CURRENCY, VARIATION_VALUE, VALUE, VALUE_FLUC, ISS_BANK_CD, ISS_BANK_REF, ADV_BANK_CD, "
						+ "ADV_BANK_REF, CONFIRM_BANK_CD, CONFIRM_BANK_REF, RECEIPT_DT, ISSUE_DT, EXPIRE_DT, RENEW_DT, CANCEL_DT, TENOR, REVIEW_DT, "
						+ "STATUS, REMARKS, FLAG, INORDER_HIST, ENT_BY, ENT_DT, MODIFY_DT, MODIFY_BY, APRV_DT, APRV_BY, GX, SEQ_REV_NO, SAP_APPROVAL, "
						+ "SAP_APPROVED_BY, SAP_APPROVED_DT, SAP_REVERSAL, SAP_REVERSAL_BY, SAP_REVERSAL_DT,PG_REF,CR_DR,TDS_AMT,TDS_STRUCT_CD,TDS_EFF_DT "
						+ "FROM FMS_SECURITY_MST "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
						+ "AND SEQ_NO=? AND SEQ_REV_NO=? AND GX=?";
				stmt2=dbcon.prepareStatement(query2);
				stmt2.setString(1, dtl_seqNo);
				stmt2.setString(2, comp_cd);
				stmt2.setString(3, counterparty);
				stmt2.setString(4, seq_no);
				stmt2.setString(5, seq_rev_no);
				stmt2.setString(6, clearance);
				stmt2.executeQuery();
				stmt2.close();
			}
			
			url = "../credit_risk/frm_cash_collateral.jsp?msg="+msg+"&msg_type="+msg_type+"&counterparty_cd="+counterparty+"&clearance="+clearance+commonUrl_pra;
			dbcon.commit();
		}
		catch(Exception e)
		{
			dbcon.rollback();
			new SystemErrorLogger().InsertErrorLogger(frm_src_file_name, function_nm, e);
			url=CommonVariable.errorpage_url;
			msg = "Error in Exception! - Cash Collateral Insert/Update Failed!";
		}
		
		try
		{
			new com.etrm.fms.util.InfoLogger().InsertInfoLogger(emp_cd, comp_cd,emp_nm, ip, form_id, form_nm,mod_cd,mod_nm, old_value, new_value, msg);  	
		}
		catch(Exception infoLogger)
		{
			new SystemErrorLogger().InsertErrorLogger(frm_src_file_name, function_nm, infoLogger);
		}
	}
}
