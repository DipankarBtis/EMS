package com.etrm.fms.util;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.etrm.fms.dlng.UtilBean_DLNG;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfAnnotation;
import com.itextpdf.text.pdf.PdfFormField;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.events.FieldPositioningEvents;

public class DB_Pdf_Generation1
{
	String db_src_file_name="DB_Pdf_Generation1.java";
	
	Connection conn;
	PreparedStatement stmt;
	PreparedStatement stmt1;
	PreparedStatement stmt2;
	PreparedStatement stmt3;
	PreparedStatement stmt4;
	PreparedStatement stmt_tmp;
	ResultSet rset;
	ResultSet rset1;
	ResultSet rset2;
	ResultSet rset3;
	ResultSet rset4;
	ResultSet rset_tmp;
	String queryString="";
	String queryString1="";
	String queryString2="";
	String queryString3="";
	String queryString4="";
	String queryString5="";
	
	public static final String SIGNAME = "Signature1";

	UtilBean utilBean = new UtilBean();
	DateUtil dateUtil = new DateUtil();
	DB_AllocationUtil utilAlloc = new DB_AllocationUtil();
	static UtilBean_DLNG dlng_util = new UtilBean_DLNG();

	public HttpServletRequest request = null;
	public void setRequest(HttpServletRequest request) {this.request = request;}

	NumberFormat nf = new DecimalFormat("###########0.00");
	NumberFormat nf2 = new DecimalFormat("###########0.0000");
	NumberFormat nf3 = new DecimalFormat("###########0.000");
	NumberFormat nf0 = new DecimalFormat("###########0.0");
	
	NumberFormat df3 = new DecimalFormat("###########0.000");
	
	double mmbtuToMtConv=51.5;

	public void init()
	{
		synchronized(this)
		{
			String function_nm="init()";
			try
			{
				Context initContext = new InitialContext();
		    	Context envContext  = (Context)initContext.lookup("java:/comp/env");
		    	DataSource ds = (DataSource)envContext.lookup(RuntimeConf.security_database);
		    	if(ds != null) 
		    	{
		    		conn = ds.getConnection();
		    		if(conn != null)
		    		{
		    			conn.setAutoCommit(false);
		    			
		    			if(callFlag.equalsIgnoreCase("DLNG_PDF_SELLER_NOMINATION_TO_CUSTOMER"))
		    			{
		    				printDlngPdfNominationToCustomer();
		    			}
		    			else if(callFlag.equalsIgnoreCase("DLNG_PDF_SELLER_NOMINATION_TO_TRANSPORTER"))
		    			{
		    				printDlngPdfNominationToTransporter();
		    			}
		    			else if(callFlag.equalsIgnoreCase("DLNG_PDF_JOINT_TICKET"))
		    			{
		    				printPdfJoinTicket();
		    			}
		    			else if(callFlag.equalsIgnoreCase("PDF_HEDGE_COMPLIANCE"))
		    			{
		    				printPdfHedgeCompliance();
		    			}
		    			else if(callFlag.equalsIgnoreCase("PDF_DLNG_INVOICE"))
		    			{
		    				printPdfFileForDLNGInvoice();
		    			}
		    			else if(callFlag.equalsIgnoreCase("PDF_DLNG_CRDR_INVOICE"))
		    			{
		    				printPdfFileForDLNG_CRDRInvoice();
		    			}
		    			else if(callFlag.equalsIgnoreCase("PDF_DERV_INVOICE"))
		    			{
		    				printPdfFileForDervInvoice();
		    			}
		    			else if(callFlag.equalsIgnoreCase("DLNG_F_FLOW_INVOICE"))
		    			{
		    				printPdfFileForDLNG_F_FlowInvoice();
		    			}
		    			else if(callFlag.equalsIgnoreCase("PDF_DLNG_SVC_INVOICE"))
		    			{
		    				printPdfFileForDlngServiceInvoice();
		    			}
		    			else if(callFlag.equalsIgnoreCase("PDF_DLNG_LP_INVOICE"))
		    			{
		    				printPdfFileForLpDLNGInvoice();
		    			}
		    			else if(callFlag.equalsIgnoreCase("PDF_DERV_CRDR_INVOICE"))
		    			{
		    				printPdfFileForDervCRDRInvoice();
		    				doClear();
		    			}
			    	}
		    		conn.close();
					conn = null;
		    	}
			}
			catch(Exception e)
			{
				new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
			}
			finally
		    {
		    	if(rset != null){try{rset.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
		    	if(rset1 != null){try{rset1.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
		    	if(rset2 != null){try{rset2.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
		    	if(rset3 != null){try{rset3.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
		    	if(rset4 != null){try{rset4.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
		    	if(rset_tmp != null){try{rset_tmp.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
		    	if(stmt != null){try{stmt.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
		    	if(stmt1 != null){try{stmt1.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
		    	if(stmt2 != null){try{stmt2.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
		    	if(stmt3 != null){try{stmt3.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
		    	if(stmt4 != null){try{stmt4.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
		    	if(stmt_tmp != null){try{stmt_tmp.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
		    	if(conn != null){try{conn.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
		    }
		}
	}
	
	public String getCounterpartyPlantTaxInfo(String comp_cd, String entity, String counterparty_cd, String plant_seq) throws Exception
	{
		String function_nm="getCounterpartyPlantTaxInfo()";
		String tax_info="";
		try
		{
			String queryString3 = "SELECT A.STAT_NO, TO_CHAR(A.EFF_DT,'DD/MM/YYYY'), B.STAT_NM "
					+ "FROM FMS_COUNTERPARTY_PLANT_TAX A, FMS_GOVT_STAT_TAX B "
					+ "WHERE A.COUNTERPARTY_CD=? AND A.ENTITY=? "
					+ "AND A.PLANT_SEQ_NO=? AND A.COMPANY_CD=? "
					+ "AND A.STAT_CD=B.STAT_CD AND A.STAT_NO IS NOT NULL AND B.STAT_NM NOT IN ('VAT TIN','CST TIN')";
			stmt3 = conn.prepareStatement(queryString3);
			stmt3.setString(1, counterparty_cd);
			stmt3.setString(2, entity);
			stmt3.setString(3, plant_seq);
			stmt3.setString(4, comp_cd);
			rset3 = stmt3.executeQuery();
			while(rset3.next())
			{
				String no = rset3.getString(1)==null?"":rset3.getString(1);
				String nm = rset3.getString(3)==null?"":rset3.getString(3);

				tax_info+="\n"+nm+" : "+no;
			}
			stmt3.close();
			rset3.close();
				
		}
		catch(Exception e)
		{
			throw e;
		}
		
		return tax_info;
	}
	
	public void printPdfFileForDervInvoice() throws SQLException
	{
		String function_nm="printPdfFileForDervInvoice()";
		
		String emp_nm ="";
		String ip = "";
		msg="";
		//String msg_content="";
		String path ="";
		String counterparty_abbr="";
		String invdtl="Sales";
		
		Rectangle pageSize = new Rectangle(595, 842);
		Rectangle pageSize1=new Rectangle(842,595);
		
		pageSize.setBackgroundColor(new BaseColor(0xffffff));
		pageSize1.setBackgroundColor(new BaseColor(0xffffff));
		
		Document document = new Document(pageSize);
		try
		{
			HttpSession session = request.getSession();
			emp_nm = (String)session.getAttribute("emp_nm")==null?"":(String)session.getAttribute("emp_nm");
			ip = (String)session.getAttribute("ip")==null?"":(String)session.getAttribute("ip");
			
			String company_nm = ""+session.getAttribute("comp_nm")==null?"":""+session.getAttribute("comp_nm");
			String company_abbr = ""+session.getAttribute("comp_abbr")==null?"":""+session.getAttribute("comp_abbr");
			String counterparty_nm=""+utilBean.getCounterpartyName(conn,counterparty_cd);
			counterparty_abbr=""+utilBean.getCounterpartyABBR(conn,counterparty_cd);
			
			invdtl="Derivatives";
			
			String contRef="";
			String trade_dt="";
			
			String appPath = request.getServletContext().getRealPath("");

			String main_folder="";
			if(!comp_cd.equals(""))
			{
				main_folder=CommonVariable.work_dir+comp_cd;
			}
			
			String sub_folder="unsigned_pdf";
			String sub_folder2="derivatives_invoice";
			if(inv_type.equals("R"))
			{
				sub_folder="derivatives";
				sub_folder2="remittance";
			}
			String temp_path=appPath+File.separator+main_folder+File.separator+sub_folder+File.separator+sub_folder2;
			File main_folderDir = new File(temp_path);
	        if(!main_folderDir.exists())
	        {
	        	main_folderDir.mkdirs();
	        }
			
			String[] contNo = cont_no.split(", ");
			String[] agmtNo = agmt_no.split(", ");;
			//String[] agmtRev = agmt_rev_no.split(", ");
			//String[] contRev = cont_rev_no.split(", ");
			String[] contType = contract_type.split(", ");
			String[] instruNo =  instrument_no.split(", ");
			String[] perd_start_dt =  period_start_dt.split(", ");
			String[] perd_end_dt =  period_end_dt.split(", ");
			String total_inv_amt="";
			double temp_tot_inv_amt = 0;
			
			String invoice_seq = "";
			String invoice_no = "";
			String inv_dt = "";
			String inv_due_dt = "";
			String alloc_qty = "";
			String sell_price = "";
			String sell_price_unit = "";
			String sell_amt = "";
			String buy_price = "";
			String buy_price_unit = "";
			String buy_amt = "";
			String inv_raised_in = "";
			String invoice_amt = "";
			String net_payable_amt = "";
			String remark1 = "";
			String remark2 = "";
			String inv_ref = "";
			String invoice_id_seq = "";
			String instrument_volume_unit = "";
			String temp_period_start_dt="";
			String temp_period_end_dt="";
			String instrument_type="";
			String curve_nm="";
			String instru_duration="";
			
			for(int i=0; i<contNo.length; i++)
			{
				queryString="SELECT A.COMPANY_CD,A.COUNTERPARTY_CD,A.AGMT_TYPE,A.AGMT_NO,A.AGMT_REV,A.CONTRACT_TYPE,A.CONT_NO,A.CONT_REV,A.CONT_NAME,A.CONT_REF_NO,"
						+ "B.INSTRUMENT_NO,B.INSTRUMENT_TYPE,B.BUY_SELL,B.STATUS,B.QTY,B.QTY_UNIT,B.RATE,B.RATE_UNIT,"
						+ "B.PRODUCT_NM,B.CURVE_NM,B.PROJ_METHOD,TO_CHAR(B.CONT_DD_MM_YR,'DD/MM/YYYY'),"
						+ "TO_CHAR(B.PRICE_START_DT,'DD/MM/YYYY'),TO_CHAR(B.PRICE_END_DT,'DD/MM/YYYY'),B.CONV_FACTOR,TO_CHAR(A.TRADE_DT,'DD/MM/YYYY') "
						+ "FROM FMS_DERV_CONT_MST A,FMS_DERV_INSTRUMENT_MST B "
						+ "WHERE A.COMPANY_CD=? AND A.COUNTERPARTY_CD=? AND A.AGMT_NO=? AND A.CONT_NO=? AND A.CONTRACT_TYPE=? "
						+ "AND B.STATUS='Y' AND B.INSTRUMENT_NO=? "
						+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_TYPE=B.AGMT_TYPE AND A.AGMT_NO=B.AGMT_NO "
						+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE AND A.CONT_NO=B.CONT_NO";
				stmt = conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty_cd);
				stmt.setString(3, agmtNo[i]);
				stmt.setString(4, contNo[i]);
				stmt.setString(5, contType[i]);
				stmt.setString(6, instruNo[i]);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					contRef=rset.getString(10)==null?"":rset.getString(10);
					trade_dt=rset.getString(26)==null?"":rset.getString(26);
					instrument_volume_unit = rset.getString(16)==null?"":rset.getString(16);
					instrument_type = rset.getString(12)==null?"":rset.getString(12);
					curve_nm = rset.getString(20)==null?"":rset.getString(20);
					String start_dt = rset.getString(23)==null?"":rset.getString(23);
					String end_dt = rset.getString(24)==null?"":rset.getString(24);
					instru_duration = start_dt+"-"+end_dt;
				}
				rset.close();
				stmt.close();
			
			
				temp_period_start_dt=perd_start_dt[i];
				temp_period_end_dt=perd_end_dt[i];
				String fy_year=dateUtil.getFinancialYear(perd_end_dt[i]);
				queryString="SELECT INVOICE_SEQ,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),"
						+ "TO_CHAR(DUE_DT,'DD/MM/YYYY'),ALLOC_QTY,SALE_PRICE,SALE_PRICE_UNIT,SALE_AMT,BUY_PRICE,BUY_PRICE_UNIT,BUY_AMT,"
						+ "INVOICE_RAISED_IN,INVOICE_AMT,NET_PAYABLE_AMT,"
						+ "REMARK_1,REMARK_2,FINANCIAL_YEAR,TO_CHAR(PERIOD_START_DT,'DD/MM/YYYY'),TO_CHAR(PERIOD_END_DT,'DD/MM/YYYY'),"
						+ "INVOICE_REF_NO,INVOICE_ID_SEQ,CHECKED_FLAG,AUTHORIZED_FLAG,APPROVED_FLAG "
						+ "FROM FMS_DERV_INVOICE_MST "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? "
						+ "AND AGMT_NO=? AND PLANT_SEQ=? AND BU_UNIT=? AND CONTRACT_TYPE=? "
						+ "AND BU_STATE_TIN=? AND PERIOD_START_DT=TO_DATE(?,'DD/MM/YYYY') "
						+ "AND PERIOD_END_DT=TO_DATE(?,'DD/MM/YYYY') AND FINANCIAL_YEAR=? "
						+ "AND INVOICE_SEQ=? AND INSTRUMENT_NO=? AND INV_TYPE=? AND INV_FLAG='F'";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty_cd);
				stmt.setString(3, contNo[i]);
				stmt.setString(4, agmtNo[i]);
				stmt.setString(5, plant_seq);
				stmt.setString(6, bu_plant_seq);
				stmt.setString(7, contType[i]);
				stmt.setString(8, bu_state_tin);
				stmt.setString(9, perd_start_dt[i]);
				stmt.setString(10, perd_end_dt[i]);
				stmt.setString(11, fy_year);
				stmt.setString(12, inv_seq);
				stmt.setString(13, instruNo[i]);
				stmt.setString(14, inv_type);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					invoice_seq=rset.getString(1)==null?"":rset.getString(1);
					invoice_no=rset.getString(2)==null?"":rset.getString(2);
					inv_dt=rset.getString(3)==null?"":rset.getString(3);
					inv_due_dt=rset.getString(4)==null?"":rset.getString(4);
					alloc_qty=rset.getString(5)==null?"":rset.getString(5);
					sell_price=rset.getString(6)==null?"":rset.getString(6);
					sell_price_unit=rset.getString(7)==null?"":rset.getString(7);
					sell_amt=rset.getString(8)==null?"":rset.getString(8);
					buy_price=rset.getString(9)==null?"":rset.getString(9);
					buy_price_unit=rset.getString(10)==null?"":rset.getString(10);
					buy_amt=rset.getString(11)==null?"":rset.getString(11);
					inv_raised_in=rset.getString(12)==null?"":rset.getString(12);
					invoice_amt=rset.getString(13)==null?"":rset.getString(13);
					net_payable_amt=rset.getString(14)==null?"":rset.getString(14);
					remark1=rset.getString(15)==null?"":rset.getString(15);
					remark2=rset.getString(16)==null?"":rset.getString(16);
					period_start_dt=rset.getString(18)==null?"":rset.getString(18);
					period_end_dt=rset.getString(19)==null?"":rset.getString(19);
					inv_ref=rset.getString(20)==null?"":rset.getString(20);
					invoice_id_seq=rset.getString(21)==null?"":rset.getString(21);
					temp_tot_inv_amt+=Double.parseDouble(invoice_amt);
				}
				rset.close();
				stmt.close();
				
				VTRADE_DT.add(trade_dt);
				VDISP_DEAL_ID.add(utilBean.NewDealMappingId(comp_cd, counterparty_cd, agmtNo[i], "", contNo[i], "", contType[i], instruNo[i]));
				VCONT_REF.add(contRef);
				VRATE_UNIT.add("USD");
				VQTY.add(alloc_qty);
				VQTY_UNIT.add(instrument_volume_unit.toUpperCase());
				VBUY_RATE.add(nf3.format(Double.parseDouble(buy_price)));
				VSELL_RATE.add(nf3.format(Double.parseDouble(sell_price)));
				VINV_AMT.add(nf.format(Double.parseDouble(invoice_amt)));
				
				VINSTRUMENT_TYPE.add(instrument_type);
			  	VCURVE_NM.add(curve_nm);
			  	VINSTRUMENT_DURATION.add(instru_duration);
				
			}
			if(temp_tot_inv_amt<0)
			{
				temp_tot_inv_amt=temp_tot_inv_amt*(-1);
			}
			total_inv_amt=nf.format(temp_tot_inv_amt);
			
			String bank_formula="";
			String queryString0="SELECT COUNTERPARTY_CD,ENTITY,TO_CHAR(EFF_DT,'DD/MM/YYYY'),BANK_NAME,ACCOUNT_ID,IFSC_CODE,BRANCH_NAME,"
					+ "STATE_NM,CATEGORY  "
					+ "FROM FMS_ENTITY_BANK_MST A "
					+ "WHERE ENTITY=? AND COUNTERPARTY_CD=? AND COMPANY_CD=? AND CATEGORY=? "
					+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_BANK_MST B WHERE A.COUNTERPARTY_CD=B.COUNTERPARTY_CD "
					+ "AND A.ENTITY=B.ENTITY AND A.COMPANY_CD=B.COMPANY_CD AND A.CATEGORY=B.CATEGORY)";
			stmt=conn.prepareStatement(queryString0);
			stmt.setString(1, "B");
			stmt.setString(2, comp_cd);
			stmt.setString(3, comp_cd);
			stmt.setString(4, "DERV");
			rset=stmt.executeQuery();
			if(rset.next())
			{
				String bank_eff_dt = rset.getString(3)==null?"":rset.getString(3);
				String bank_name=rset.getString(4)==null?"":rset.getString(4);
				String bank_account_no=rset.getString(5)==null?"":rset.getString(5);
				String ifsc_code=rset.getString(6)==null?"":rset.getString(6);
				String bank_branch=rset.getString(7)==null?"":rset.getString(7);
				String bank_state=rset.getString(8)==null?"":rset.getString(8);
				String bank_category=rset.getString(9)==null?"":rset.getString(9);
				
				bank_formula=bank_name+", "+bank_branch+", "+bank_state+", A/C No : "+bank_account_no+", IFSC Code : "+ifsc_code;
			}
			rset.close();
			stmt.close();
			
			if(inv_type.equals("I") && (remark1.equals("") || remark1.equals("Please pay the invoiced amount by wire transfer at Bank Name: ")))
			{
				remark1="Please pay the invoiced amount by wire transfer at Bank Name: "+bank_formula;
			}
			
			HashMap bu_plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "B", comp_cd, bu_plant_seq);
			String bu_plantAddress=""+bu_plant_detail.get("plant_address");
			String bu_plantCity=""+bu_plant_detail.get("plant_city");
			String bu_plantState=""+bu_plant_detail.get("plant_state");
			String bu_plantPin=""+bu_plant_detail.get("plant_pin");
			String bu_plantNm=""+bu_plant_detail.get("plant_name");

			HashMap plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "T", counterparty_cd, plant_seq);
			String plantAddress=""+plant_detail.get("plant_address");
			String plantCity=""+plant_detail.get("plant_city");
			String plantState=""+plant_detail.get("plant_state");
			String plantPin=""+plant_detail.get("plant_pin");
			
			String print_pdf_type_nm="ORIGINAL";
			if(print_pdf_type.equals("O"))
			{
				print_pdf_type_nm="ORIGINAL";
			}
			else if(print_pdf_type.equals("D"))
			{
				print_pdf_type_nm="DUPLICATE";
			}
			else if(print_pdf_type.equals("T"))
			{
				print_pdf_type_nm="TRIPLICATE";
			}


	        String monthofinv = dateUtil.getMonthNameMON(period_end_dt);
	        String dtPeriod="";
	        if(!period_start_dt.equals("") && !period_end_dt.equals(""))
	        {
	        	dtPeriod=period_start_dt.substring(0,2);
	        	dtPeriod+="-";
	        	dtPeriod+=period_end_dt.substring(0,2);
	        }

	        String contNm="";
	        String invNm="";
	        String invTp="";
	        if(inv_type.equals("I"))
	        {
	        	contNm="Derivatives";
	        	invNm="INVOICE";
	        	invTp="Invoice";
	        }
	        else if(inv_type.equals("R"))
	        {
	        	contNm="Derivatives";
	        	invNm="REMITTANCE";
	        	invTp="Remittance";
	        }
	        

			file_nm=print_pdf_type+"-"+company_abbr+"-"+invNm+"-"+contNm+""+bu_state_tin+"-"+inv_seq+"-"+counterparty_abbr+"_"+financial_year+"_"+monthofinv.trim()+"_"+dtPeriod+".pdf";

			path = appPath+"/"+main_folder+"/"+sub_folder+"/"+sub_folder2+"/"+file_nm;
			PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream(path));

			document.open();
			document.setPageSize(pageSize);
            document.newPage();

            String context_nm = request.getContextPath();
			String server_nm = request.getServerName();
			String server_port = ""+request.getServerPort();

			file_url = CommonVariable.app_protocol+"://"+server_nm+":"+server_port+context_nm;

			Font small_black_normal = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
			Font small_black_normal_10 = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
			Font small_black_normal_14 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
			Font small_black_normal_12 = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
            Font small_black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            Font black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            Font black_bold1 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            
            PdfPCell company_logo_cell = new PdfPCell();
            if(!comp_logo.equals(""))
            {
            	String file_path = request.getRealPath("/"+CommonVariable.company_logo_path+"/"+comp_logo);
            	Image company_logo = Image.getInstance(file_path);
	            company_logo.setBorder(Rectangle.NO_BORDER);
	            company_logo.scaleAbsolute(44,40);
	            company_logo_cell = new PdfPCell(company_logo,false);
	            company_logo_cell.setBorder(Rectangle.NO_BORDER);
	            company_logo_cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            }
            
            float[] Contact1 = {0.50f};
   	     	PdfPTable LogoTable = new PdfPTable(Contact1);
   	     	LogoTable.setWidthPercentage(100);
   	     	LogoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	LogoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
   	     	LogoTable.addCell(company_logo_cell);

			float[] ContactAddrWidths1 = {0.100f};
   	     	PdfPTable HlplLogoTable = new PdfPTable(ContactAddrWidths1);
            HlplLogoTable.setWidthPercentage(100);
            HlplLogoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            HlplLogoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            HlplLogoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            HlplLogoTable.addCell(new Phrase(new Chunk(print_pdf_type_nm,small_black_normal_10)));

            float[] ContactAddrWidths2 = {0.100f};
   	     	PdfPTable Table = new PdfPTable(ContactAddrWidths2);
            Table.setWidthPercentage(100);
            Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table.addCell(new Phrase(new Chunk(company_nm,black_bold1)));

            float[] ContactAddrWidths3 = {0.100f};
   	     	PdfPTable Table1 = new PdfPTable(ContactAddrWidths3);
            Table1.setWidthPercentage(100);
            Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
        	Table1.addCell(new Phrase(new Chunk(""+invNm,small_black_normal_12)));
            
			period_start_dt=dateUtil.getDateFormatDD_MOM_YY(period_start_dt);
			period_end_dt=dateUtil.getDateFormatDD_MOM_YY(period_end_dt);


            float[] ContactAddrWidths4 = {0.100f};
   	     	PdfPTable Table2 = new PdfPTable(ContactAddrWidths4);
            Table2.setWidthPercentage(100);
            Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table2.addCell(new Phrase(new Chunk("",small_black_normal)));

            float[] ContactAddrWidths5 = {0.80f,0.10F,0.20F,0.80F};
   	     	PdfPTable Table3 = new PdfPTable(ContactAddrWidths5);
            Table3.setWidthPercentage(100);
            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            //Table3.addCell(new Phrase(new Chunk("Business Unit: "+bu_plantNm,black_bold)));
            Table3.addCell(new Phrase(new Chunk("From: ",black_bold)));
            
            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table3.addCell(new Phrase(new Chunk("",black_bold)));
            
            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table3.addCell(new Phrase(new Chunk("To:",black_bold)));

            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table3.addCell(new Phrase(new Chunk("",black_bold)));

            

			float[] ContactAddrWidths6 = {0.80f,0.30F,0.80F};
   	     	PdfPTable Table4 = new PdfPTable(ContactAddrWidths6);
            Table4.setWidthPercentage(100);
            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
        	Table4.addCell(new Phrase(new Chunk(company_nm,small_black_normal)));
            
            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table4.addCell(new Phrase(new Chunk("",small_black_normal)));

            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
        	Table4.addCell(new Phrase(new Chunk(counterparty_nm,small_black_normal)));

            float[] ContactAddrWidths7 = {0.80f,0.30F,0.80F};
   	     	PdfPTable Table5 = new PdfPTable(ContactAddrWidths7);
            Table5.setWidthPercentage(100);
            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
        	Table5.addCell(new Phrase(new Chunk(bu_plantAddress+","+bu_plantCity,small_black_normal)));
            
            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table5.addCell(new Phrase(new Chunk("",small_black_normal)));
            
            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
        	Table5.addCell(new Phrase(new Chunk(plantAddress+","+plantCity,small_black_normal)));

            float[] ContactAddrWidths8 = {0.80f,0.30F,0.80F};
   	     	PdfPTable Table6 = new PdfPTable(ContactAddrWidths8);
            Table6.setWidthPercentage(100);
            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
        	Table6.addCell(new Phrase(new Chunk(bu_plantState+" - "+bu_plantPin,small_black_normal)));

            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table6.addCell(new Phrase(new Chunk("",small_black_normal)));
            
            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
        	Table6.addCell(new Phrase(new Chunk(plantState+" - "+plantPin,small_black_normal)));

            String tax_info="";
            String bu_tax_info="";
            
			tax_info=getCounterpartyPlantTaxInfo(comp_cd, "T", counterparty_cd, plant_seq);
			
			bu_tax_info=getCounterpartyPlantTaxInfo(comp_cd, "B", comp_cd, bu_plant_seq);
            
            float[] ContactAddrWidths9 = {0.80f,0.30F,0.80F};
   	     	PdfPTable Table7 = new PdfPTable(ContactAddrWidths9);
            Table7.setWidthPercentage(100);
            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
        	Table7.addCell(new Phrase(new Chunk(bu_tax_info,small_black_normal)));

            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table7.addCell(new Phrase(new Chunk("",small_black_normal)));

            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
        	Table7.addCell(new Phrase(new Chunk(tax_info,small_black_normal)));
            
            
            PdfPTable InvoiceDateInfoTable;
            PdfPTable BillingPeriodInfoTable;
            
            float[] ContactAddrWidths10 = {0.80F,0.30F,0.30F,0.40F};
   	     	PdfPTable Table8 = new PdfPTable(ContactAddrWidths10);
            Table8.setWidthPercentage(100);
            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table8.addCell(new Phrase(new Chunk("",small_black_normal)));

            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table8.addCell(new Phrase(new Chunk("",small_black_normal)));

            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table8.addCell(new Phrase(new Chunk("Invoice Date :",black_bold)));

            Table8.getDefaultCell().setBorder(Rectangle.BOX);
            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            //Table8.addCell(new Phrase(new Chunk(dateUtil.getDateFormatDD_MOM_YY(invoice_dt),small_black_normal)));
            Table8.addCell(new Phrase(new Chunk(inv_dt,black_bold)));

            float[] ContactAddrWidths11 = {0.80F,0.30F,0.30F,0.40F};
   	     	PdfPTable Table9 = new PdfPTable(ContactAddrWidths11);
            Table9.setWidthPercentage(100);
            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table9.addCell(new Phrase(new Chunk("",small_black_normal)));

            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table9.addCell(new Phrase(new Chunk("",small_black_normal)));

            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table9.addCell(new Phrase(new Chunk("Payment Due Date :",black_bold)));

            Table9.getDefaultCell().setBorder(Rectangle.BOX);
            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            //Table9.addCell(new Phrase(new Chunk(dateUtil.getDateFormatDD_MOM_YY(invoice_due_dt),small_black_normal)));
            Table9.addCell(new Phrase(new Chunk(inv_due_dt,black_bold)));

            float[] ContactAddrWidths12 = {0.80F,0.10F,0.50F,0.40F};
   	     	PdfPTable Table10 = new PdfPTable(ContactAddrWidths12);
            Table10.setWidthPercentage(100);
            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table10.addCell(new Phrase(new Chunk("",small_black_normal)));

            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table10.addCell(new Phrase(new Chunk("",small_black_normal)));

            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table10.addCell(new Phrase(new Chunk(company_abbr+" "+invTp+" Seq No:",black_bold)));

            Table10.getDefaultCell().setBorder(Rectangle.BOX);
            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table10.addCell(new Phrase(new Chunk(invoice_no,black_bold)));
            
            	float[] ContactAddrWidths11_1 = {0.80F,0.30F,0.30F,0.40F};
       	     	PdfPTable Table9_1 = new PdfPTable(ContactAddrWidths11);
                Table9_1.setWidthPercentage(100);
                Table9_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
                Table9_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
                Table9_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
                Table9_1.addCell(new Phrase(new Chunk("",small_black_normal)));

                Table9_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
                Table9_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
                Table9_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
                Table9_1.addCell(new Phrase(new Chunk("",small_black_normal)));

                Table9_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
                Table9_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
                Table9_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
                Table9_1.addCell(new Phrase(new Chunk("Vendor Invoice No :",black_bold)));

                Table9_1.getDefaultCell().setBorder(Rectangle.BOX);
                Table9_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
                Table9_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
                //Table9_1.addCell(new Phrase(new Chunk(dateUtil.getDateFormatDD_MOM_YY(invoice_due_dt),small_black_normal)));
                Table9_1.addCell(new Phrase(new Chunk(inv_ref,black_bold)));

            float[] ContactAddrWidths13 = {0.08F,0.25F,0.50F,0.25f,0.30f,0.30f,0.25F,0.20F,0.20F,0.20F,0.30F};
   	     	PdfPTable Table11 = new PdfPTable(ContactAddrWidths13);
            Table11.setWidthPercentage(100);
            Table11.getDefaultCell().setBorder(Rectangle.BOX);
            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table11.addCell(new Phrase(new Chunk("Sr.No",small_black_bold)));

            Table11.getDefaultCell().setBorder(Rectangle.BOX);
            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table11.addCell(new Phrase(new Chunk("Trade Date",small_black_bold)));

            Table11.getDefaultCell().setBorder(Rectangle.BOX);
            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table11.addCell(new Phrase(new Chunk("Deal No.",small_black_bold)));
            
            Table11.getDefaultCell().setBorder(Rectangle.BOX);
            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table11.addCell(new Phrase(new Chunk("Item",small_black_bold)));
            
            Table11.getDefaultCell().setBorder(Rectangle.BOX);
            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table11.addCell(new Phrase(new Chunk("Index",small_black_bold)));
            
            Table11.getDefaultCell().setBorder(Rectangle.BOX);
            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table11.addCell(new Phrase(new Chunk("Trade Term",small_black_bold)));

            Table11.getDefaultCell().setBorder(Rectangle.BOX);
            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table11.addCell(new Phrase(new Chunk("Currency",small_black_bold)));

            Table11.getDefaultCell().setBorder(Rectangle.BOX);
            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table11.addCell(new Phrase(new Chunk("Quantity",small_black_bold)));

            Table11.getDefaultCell().setBorder(Rectangle.BOX);
            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table11.addCell(new Phrase(new Chunk("Rate (BUY)",small_black_bold)));
            
            Table11.getDefaultCell().setBorder(Rectangle.BOX);
            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table11.addCell(new Phrase(new Chunk("Rate (SELL)",small_black_bold)));

            Table11.getDefaultCell().setBorder(Rectangle.BOX);
            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table11.addCell(new Phrase(new Chunk("Amount",small_black_bold)));

            float[] ContactAddrWidths20 = {0.08F,0.25F,0.50F,0.25f,0.30f,0.30f,0.25F,0.20F,0.20F,0.20F,0.30F};
   	     	PdfPTable Table18 = new PdfPTable(ContactAddrWidths20);
   	     	
   	     	int k=0;
   	     	for(int i=0; i<contNo.length; i++)
			{
   	     		k+=1;
   	     		Table18.setWidthPercentage(100);
	            Table18.getDefaultCell().setBorder(Rectangle.BOX);
	            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table18.addCell(new Phrase(new Chunk(""+k,small_black_normal)));
	
	            Table18.getDefaultCell().setBorder(Rectangle.BOX);
	            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table18.addCell(new Phrase(new Chunk(""+VTRADE_DT.elementAt(i),small_black_normal)));
	
	            Table18.getDefaultCell().setBorder(Rectangle.BOX);
	            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table18.addCell(new Phrase(new Chunk(""+VDISP_DEAL_ID.elementAt(i)+" ("+VCONT_REF.elementAt(i)+")",small_black_normal)));
	            
	            Table18.getDefaultCell().setBorder(Rectangle.BOX);
	            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table18.addCell(new Phrase(new Chunk(""+VINSTRUMENT_TYPE.elementAt(i),small_black_normal)));
	            
	            Table18.getDefaultCell().setBorder(Rectangle.BOX);
	            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table18.addCell(new Phrase(new Chunk(""+VCURVE_NM.elementAt(i),small_black_normal)));
	            
	            Table18.getDefaultCell().setBorder(Rectangle.BOX);
	            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table18.addCell(new Phrase(new Chunk(""+VINSTRUMENT_DURATION.elementAt(i),small_black_normal)));
	
	            Table18.getDefaultCell().setBorder(Rectangle.BOX);
	            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table18.addCell(new Phrase(new Chunk(""+VRATE_UNIT.elementAt(i),small_black_normal)));
	
	            Table18.getDefaultCell().setBorder(Rectangle.BOX);
	            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table18.addCell(new Phrase(new Chunk(""+VQTY.elementAt(i)+" "+utilBean.getEnergyUnitNm(conn, ""+VQTY_UNIT.elementAt(i)),small_black_normal)));
	
	            Table18.getDefaultCell().setBorder(Rectangle.BOX);
	            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table18.addCell(new Phrase(new Chunk(""+VBUY_RATE.elementAt(i),small_black_normal)));
	            
	            Table18.getDefaultCell().setBorder(Rectangle.BOX);
	            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table18.addCell(new Phrase(new Chunk(""+VSELL_RATE.elementAt(i),small_black_normal)));
	
	            Table18.getDefaultCell().setBorder(Rectangle.BOX);
	            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table18.addCell(new Phrase(new Chunk(""+VINV_AMT.elementAt(i),small_black_normal)));
			}
   	     	
	   	    Table18.getDefaultCell().setBorder(Rectangle.LEFT | Rectangle.BOTTOM| Rectangle.TOP);
	   	    Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	   	    Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	   	    Table18.getDefaultCell().setColspan(10);
	   	    Table18.addCell(new Phrase(new Chunk("Total Invoice Amount (USD)", small_black_normal)));
	
	   	    Table18.getDefaultCell().setBorder(Rectangle.BOX);
	   	    Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	   	    Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	   	    Table18.addCell(new Phrase(new Chunk(total_inv_amt, small_black_normal)));


            float[] ContactAddrWidths21 = {0.100F};
   	     	PdfPTable Table19 = new PdfPTable(ContactAddrWidths21);
   	     	Table19.setWidthPercentage(100);
   	     	Table19.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	Table19.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
   	     	Table19.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
   	     	Table19.addCell(new Phrase(new Chunk(remark1,small_black_normal)));

   	     	float[] ContactAddrWidths22 = {0.100F};
	     	PdfPTable Table20 = new PdfPTable(ContactAddrWidths22);
	     	Table20.setWidthPercentage(100);
	     	Table20.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	     	Table20.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	     	Table20.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	     	Table20.addCell(new Phrase(new Chunk(remark2,small_black_normal)));
	     	
	     	
	     	document.add(LogoTable);
			document.add(HlplLogoTable);
			document.add(Table);
			document.add(Table1);
			document.add(Table2);
			document.add(new Paragraph("  "));
			document.add(Table3);
			document.add(Table4);
			document.add(Table5);
			document.add(Table6);
			document.add(Table7);
			document.add(new Paragraph("  "));
			document.add(new Paragraph("  "));
			document.add(Table8);
			document.add(Table9);
			document.add(Table10);
			if(inv_type.equals("R"))
            {
				document.add(Table9_1);
            }
			document.add(new Paragraph("  "));
			document.add(Table11);
			document.add(Table18);
			document.add(new Paragraph("  "));
			document.add(Table19);
			document.add(Table20);
			document.add(new Paragraph("  "));
			document.add(new Paragraph("  "));
			if(inv_type.endsWith("I"))
	     	{
		     	float[] ContactAddrWidths23 = {0.100F};
	   	     	PdfPTable Table21 = new PdfPTable(ContactAddrWidths21);
	   	     	Table21.setWidthPercentage(100);
	   	     	Table21.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	Table21.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	  		Table21.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	  		Table21.addCell(new Phrase(new Chunk("For "+company_nm,black_bold)));
	   	  		
	   	  		// create a signature form field
	   	     	PdfPTable BillingFieldsInfoTable81 = new PdfPTable(1);
	   	     	BillingFieldsInfoTable81.setWidthPercentage(20);
	   	     	BillingFieldsInfoTable81.setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	BillingFieldsInfoTable81.getDefaultCell().setBorder(Rectangle.BOX);
	   	     	BillingFieldsInfoTable81.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	BillingFieldsInfoTable81.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	        
	   	     	PdfFormField field = PdfFormField.createSignature(writer);
	   	     	field.setFieldName(SIGNAME);
	   	     	// set the widget properties
	   	     	field.setPage();
	   	     	field.setWidget(new Rectangle(72, 732, 144, 780), PdfAnnotation.HIGHLIGHT_NONE);
	   	     	field.setFlags(PdfAnnotation.FLAGS_PRINT);
	   	     	writer.addAnnotation(field);
	         
	   	     	PdfPCell sigCell = new PdfPCell();
	   	     	FieldPositioningEvents events = new FieldPositioningEvents(writer, field);
	   	     	sigCell.setCellEvent(events);
	   	     	sigCell.setFixedHeight(50f);
	   	     	BillingFieldsInfoTable81.addCell(sigCell);
	
	   	     	float[] ContactAddrWidths24 = {0.100F};
		     	PdfPTable Table22 = new PdfPTable(ContactAddrWidths22);
	
		     	Table22.setWidthPercentage(100);
		     	Table22.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		     	Table22.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		     	Table22.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		     	Table22.addCell(new Phrase(new Chunk("Authorised Signatory",black_bold)));
		     	document.add(Table21);
				document.add(BillingFieldsInfoTable81);
				document.add(Table22);
	     	}
			
			
			if(inv_type.equals("R"))
            {
				document.add(new Paragraph("  "));
				document.add(new Paragraph("  "));
				float[] footer = {0.100f};
		     	PdfPTable footer_tab = new PdfPTable(footer);
		     	footer_tab.setWidthPercentage(100);
		     	footer_tab.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			   	footer_tab.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			   	footer_tab.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			   	footer_tab.addCell(new Phrase(new Chunk("*** This is Computer Generated Report and No Signature Required ***",small_black_normal)));
	
			    document.add(footer_tab);
            }
			
            document.close();
            
            String dealMap = utilBean.NewDealMappingId(comp_cd, counterparty_cd, agmt_no, agmt_rev_no, cont_no, cont_rev_no, contract_type, cargo_no);
            File isPDFexist = new File(path);
			if(isPDFexist.exists())
			{
				String invoice_title="";
				int update_flag=0;
				int pdf_entry=0;
				
				for(int i=0; i<contNo.length; i++)
				{
				
					int cont=0;
					financial_year=dateUtil.getFinancialYear(perd_end_dt[i]);
					String queryString="UPDATE FMS_DERV_INVOICE_MST SET PDF_INV_DTL=? ";
						if(print_pdf_type.equals("O"))
						{
							queryString+= ",PRINT_BY_ORI=?,PRINT_DT_ORI=SYSDATE ";
						}
						queryString+= "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? "
							+ "AND AGMT_NO=? AND PLANT_SEQ=? AND BU_UNIT=? AND CONTRACT_TYPE=? "
							+ "AND FREQ=? AND PERIOD_START_DT=TO_DATE(?,'DD/MM/YYYY') "
							+ "AND PERIOD_END_DT=TO_DATE(?,'DD/MM/YYYY') AND FINANCIAL_YEAR=? "
							+ "AND INVOICE_SEQ=? AND BU_STATE_TIN=? AND INSTRUMENT_NO=? AND INV_TYPE=? AND INV_FLAG='F'";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(++cont, print_pdf_type);
					if(print_pdf_type.equals("O"))
					{
						stmt.setString(++cont, emp_cd);
					}
					stmt.setString(++cont, comp_cd);
					stmt.setString(++cont, counterparty_cd);
					stmt.setString(++cont, contNo[i]);
					stmt.setString(++cont, agmtNo[i]);
					stmt.setString(++cont, plant_seq);
					stmt.setString(++cont, bu_plant_seq);
					stmt.setString(++cont, contType[i]);
					stmt.setString(++cont, billing_cycle);
					stmt.setString(++cont, perd_start_dt[i]);
					stmt.setString(++cont, perd_end_dt[i]);
					stmt.setString(++cont, financial_year);
					stmt.setString(++cont, inv_seq);
					stmt.setString(++cont, bu_state_tin);
					stmt.setString(++cont, instruNo[i]);
					stmt.setString(++cont, inv_type);
					update_flag=stmt.executeUpdate();
					stmt.close();
				}
				
				int count=0;
		        queryString1="SELECT COUNT(*) "
		        		+ "FROM FMS_DERV_INV_FILE_DTL "
		        		+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
		        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
		        		+ "AND PDF_TYPE=? AND INV_TYPE=?";
		        stmt1=conn.prepareStatement(queryString1);
		        stmt1.setString(1, comp_cd);
		        stmt1.setString(2, bu_state_tin);
		        stmt1.setString(3, inv_seq);
		        stmt1.setString(4, financial_year);
		        stmt1.setString(5, print_pdf_type);
		        stmt1.setString(6, inv_type);
		        rset1=stmt1.executeQuery();
		        if(rset1.next())
		        {
		        	count=rset1.getInt(1);
		        }
		        rset1.close();
		        stmt1.close();
		        
		        if(count > 0)
		        {
		        	queryString1="UPDATE FMS_DERV_INV_FILE_DTL SET FILE_NAME=?,MODIFY_BY=?,MODIFY_DT=SYSDATE "
		        			+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
			        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE=? AND INV_TYPE=?";
		        	stmt1=conn.prepareStatement(queryString1);
		        	stmt1.setString(1, file_nm);
		        	stmt1.setString(2, emp_cd);
		        	stmt1.setString(3, comp_cd);
		 	        stmt1.setString(4, bu_state_tin);
		 	        stmt1.setString(5, inv_seq);
		 	        stmt1.setString(6, financial_year);
		 	        stmt1.setString(7, print_pdf_type);
		 	        stmt1.setString(8, inv_type);
		 	        pdf_entry=stmt1.executeUpdate();
		        	
		        	stmt1.close();
		        }
		        else
		        {
		        	queryString1="INSERT INTO FMS_DERV_INV_FILE_DTL(COMPANY_CD,BU_STATE_TIN,INVOICE_SEQ,FINANCIAL_YEAR,PDF_TYPE,"
		        			+ "FILE_NAME,ENT_BY,ENT_DT,INV_TYPE) "
		        			+ "VALUES(?,?,?,?,?,"
		        			+ "?,?,SYSDATE,?)";
		        	stmt1=conn.prepareStatement(queryString1);
		        	stmt1.setString(1, comp_cd);
		 	        stmt1.setString(2, bu_state_tin);
		 	        stmt1.setString(3, inv_seq);
		 	        stmt1.setString(4, financial_year);
		 	        stmt1.setString(5, print_pdf_type);
		 	        stmt1.setString(6, file_nm);
		        	stmt1.setString(7, emp_cd);
		        	stmt1.setString(8, inv_type);
		        	pdf_entry=stmt1.executeUpdate();
		        	
		        	stmt1.close();
		        }
		        
		        if(pdf_entry == 0 || update_flag == 0)
		        {
		        	conn.rollback();
		        	deletePdfFile(path);
		        	msg="Failed! - "+invdtl+" Invoice for "+counterparty_abbr+" PDF for "+dealMap+" Generation Failed!";
		        	msg_type="E";
		        }
		        else
		        {
		        	conn.commit();
		        	msg = "Successful! - "+invdtl+" Invoice for "+counterparty_abbr+" PDF "+file_nm+" for "+dealMap+" Generated Successfully!";
		        	msg_type="S";
		        }
			}
			else
			{
				msg="Failed! - "+invdtl+" Invoice for "+counterparty_abbr+" PDF for "+dealMap+" Generation Failed!";
				msg_type="E";
			}
		}
		catch(Exception e)
		{
			conn.rollback();
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
			
			document.close();
			deletePdfFile(path);
			
			msg="Error in Exception! - "+invdtl+" Invoice for "+counterparty_abbr+" PDF Generation Failed!";
			msg_type="E";	
		}
		finally
		{
			document.close();
		}
		
		try
		{
			new com.etrm.fms.util.InfoLogger().InsertInfoLogger(emp_cd, comp_cd,emp_nm, ip, form_id, form_nm,mod_cd,mod_nm, "", "", msg);  	
		}
		catch(Exception infoLogger)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, infoLogger);
		}
	}
	
	public void printPdfHedgeCompliance()
	{
		String function_nm="printPdfHedgeCompliance()";
		
		Rectangle pageSize = new Rectangle(595, 842);
		pageSize.setBackgroundColor(new BaseColor(0xffffff));
		Document document = new Document(pageSize);
		try
		{
			HttpSession session = request.getSession();
			String company_abbr = ""+session.getAttribute("comp_abbr")==null?"":""+session.getAttribute("comp_abbr");

			String appPath = request.getServletContext().getRealPath("");
			
			String main_folder="";
			if(!comp_cd.equals(""))
			{
				main_folder=CommonVariable.work_dir+comp_cd;
			}

			File main_folderDir = new File(appPath+File.separator+main_folder);
	        if(!main_folderDir.exists())
	        {
	        	main_folderDir.mkdir();
	        }

	        String sub_folder="derivatives_reports";
	        File sub_folderDir = new File(appPath+File.separator+main_folder+File.separator+sub_folder);
	        if(!sub_folderDir.exists())
	        {
	        	sub_folderDir.mkdir();
	        }
	        
	        file_nm=company_abbr+"-MONTHLY_HEDGE_REPORT_"+month_name+"_"+year+".pdf";
	        String path = appPath+"/"+main_folder+"/"+sub_folder+"/"+file_nm;
	        PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream(path));
	        
	        document.open();
			document.setPageSize(pageSize);
            document.newPage();

            String context_nm = request.getContextPath();
			String server_nm = request.getServerName();
			String server_port = ""+request.getServerPort();

			file_url = CommonVariable.app_protocol+"://"+server_nm+":"+server_port+context_nm;
	        
	        Font black_normal = FontFactory.getFont(FontFactory.TIMES_ROMAN, 9, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
            Font black_normal_small = FontFactory.getFont(FontFactory.TIMES_ROMAN, 6, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
            Font black_normal_green = FontFactory.getFont(FontFactory.TIMES_ROMAN, 6, Font.NORMAL, new BaseColor(0x00, 0x66, 0x00));
            Font black_bold_green = FontFactory.getFont(FontFactory.TIMES_ROMAN, 9, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            Font black_bold = FontFactory.getFont(FontFactory.TIMES_ROMAN, 9, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            Font white_bold = FontFactory.getFont(FontFactory.TIMES_ROMAN, 9, Font.BOLD, new BaseColor(0xff, 0xff, 0xff));
            Font white_bold2 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.BOLD, new BaseColor(0xff, 0xff, 0xff));
            
	        Paragraph company_address=new Paragraph();
            Paragraph customer_address=new Paragraph();
            
            ///GET COMPANY ADDRESS
            String comp_address=view_hedge_info.get("company_nm")+"\n"
            		+ view_hedge_info.get("ownAddress")+"\n"
            		+ view_hedge_info.get("ownCity")+"";
            if(!view_hedge_info.get("ownPin").toString().trim().equals(""))
            {
            	comp_address+="-"+view_hedge_info.get("ownPin");
            }
            if(!view_hedge_info.get("ownCity").toString().trim().equals(""))
            {
            	comp_address+=",";
            }
            comp_address+="\n"
            		+ view_hedge_info.get("ownState")+"\n"
            		+ "Tel: "+view_hedge_info.get("ownPhone")+"\n"
            		+ "Email: "+view_hedge_info.get("ownEmail");
            
            
            company_address.add(new Phrase(new Chunk("\n"+comp_address,black_normal)));
            
            PdfPCell company_logo_cell = new PdfPCell();
            if(!comp_logo.equals(""))
            {
            	String file_path = request.getRealPath("/"+CommonVariable.company_logo_path+"/"+comp_logo);
            	Image company_logo = Image.getInstance(file_path);
	            company_logo.setBorder(Rectangle.NO_BORDER);
	            company_logo.scaleAbsolute(44,40);
	            company_logo_cell = new PdfPCell(company_logo,false);
	            company_logo_cell.setBorder(Rectangle.NO_BORDER);
	            company_logo_cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            }
            
            float[] ContactAddrWidths1 = {0.50f,0.50f};
   	     	PdfPTable Table1 = new PdfPTable(ContactAddrWidths1);
   	     	Table1.setWidthPercentage(100);
   	     	Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
   	     	Table1.addCell(company_logo_cell);
   	     
   	     	Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
   	     	Table1.addCell(company_address);
	        
		    float[] headingWidths = {0.50f};
            PdfPTable headingTable = new PdfPTable(headingWidths);
            headingTable.setWidthPercentage(100);
            headingTable.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            headingTable.getDefaultCell().setBorder(Rectangle.BOX);
            headingTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            headingTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell headingCell = new PdfPCell(new Phrase(comp_nm,black_bold));
            headingCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
            headingCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            headingCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            headingCell.setBorderWidth(1);
            headingTable.addCell(headingCell);
            
            
            float[] tb1Widths = {1f, 1f, 1f, 1f, 1f, 1f};
            PdfPTable tb1Table = new PdfPTable(tb1Widths);
            tb1Table.setWidthPercentage(90);
            tb1Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell tb1Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb1Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb1Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb1Cell.setBorderWidth(0);
            tb1Table.addCell(tb1Cell);
            
            tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell tb2Cell = new PdfPCell(new Phrase(new Chunk("Reporting for the month of ",black_bold_green)));
            tb2Cell.setBackgroundColor(BaseColor.YELLOW);
            tb2Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb2Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb2Cell.setBorderWidth(0);
            tb1Table.addCell(tb2Cell);
            
            tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell tb3Cell = new PdfPCell(new Phrase(new Chunk(this.month_name+"-"+this.year,black_bold)));
            tb3Cell.setBackgroundColor(BaseColor.ORANGE);
            tb3Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb3Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb3Cell.setBorderWidth(0);
            tb1Table.addCell(tb3Cell);

            tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell tb4Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb4Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb4Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb4Cell.setBorderWidth(0);
            tb1Table.addCell(tb4Cell);

            tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell tb5Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb5Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb5Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb5Cell.setBorderWidth(0);
            tb1Table.addCell(tb5Cell);

            tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell tb6Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb6Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb6Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb6Cell.setBorderWidth(0);
            tb1Table.addCell(tb6Cell);
            
            
		    float[] headingWidths1 = {5.0f};
            PdfPTable headingTable1 = new PdfPTable(headingWidths1);
            headingTable1.setWidthPercentage(100);
            headingTable1.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            headingTable1.getDefaultCell().setBorder(Rectangle.BOX);
            headingTable1.getDefaultCell().setBorderColor(BaseColor.WHITE);
            headingTable1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            headingTable1.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell headingCell1 = new PdfPCell(new Phrase(new Chunk(" MONTHLY STATEMENT ON HEDGING TRANSACTIONS-ROUTED THROUGH ICICI BANK\n",white_bold)));
            BaseColor darkBrown = new BaseColor(0x7B, 0x3F, 0x00);
            headingCell1.setBackgroundColor(darkBrown);
            headingCell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            headingCell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            headingCell1.setBorderWidth(1);
            headingTable1.addCell(headingCell1);
            
            
            float[] DItb1Widths = {0.1176470588235f, 0.47058823529f, 0.41176470588f};
            PdfPTable DItb1Table = new PdfPTable(DItb1Widths);
            DItb1Table.setWidthPercentage(100);
            DItb1Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            DItb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DItb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DItb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell DItb1Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            DItb1Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            DItb1Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DItb1Table.addCell(DItb1Cell);
            
            DItb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DItb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DItb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell DItb2Cell = new PdfPCell(new Phrase(new Chunk("Direct Exposure\n",black_bold)));
            BaseColor pastelBlue = new BaseColor(140, 190, 214);
            DItb2Cell.setBackgroundColor(pastelBlue);
            DItb2Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            DItb2Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DItb1Table.addCell(DItb2Cell);
            
            DItb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DItb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DItb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell DItb3Cell = new PdfPCell(new Phrase(new Chunk("Indirect Exposure\n",black_bold)));
            BaseColor mintGreen = new BaseColor(197, 232, 183);
            DItb3Cell.setBackgroundColor(mintGreen);
            DItb3Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            DItb3Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DItb1Table.addCell(DItb3Cell);
            

            float[] DI1tb1Widths = {0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f,0.20f, 0.20f};
            PdfPTable DI1tb1Table = new PdfPTable(DI1tb1Widths);
            DI1tb1Table.setWidthPercentage(100);
            DI1tb1Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell Cell1 = new PdfPCell(new Phrase(new Chunk("Sr. No.",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
            
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Commodity",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
            
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Exposure / Eligible Limit (as per the approval letter from ICICI Bank)\n\nDirect Exposure",black_normal_small)));
            Cell1.setBackgroundColor(pastelBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
            
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Outstanding Balance as on Previous Month End[Long(+)/Short(-)*][A]",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
            
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Buy for the month\n[B]",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
            
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Sell for the month\n[C]",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
            
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Net Settlement Done this Month\n[D]",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
            
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Total Hedges Outstanding as on Month End\n[Sum(A:D)]",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
            
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Hedges Outstanding on Exchange as on Month End\n[Long(+)/\nShort(-)*]\n\n [A]",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
            
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Hedges Outstanding on OTC as on Month End\n[Long(+)/\nShort(-)*]\n\n[B]",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
            
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Exposure / Eligible Limit (as per the approval letter  from ICICI Bank)\n\n\nIndirect Exposure",black_normal_small)));
            Cell1.setBackgroundColor(mintGreen);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
            
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Outstanding Balance as on Previous Month End\n\n\n[Long(+)/\nShort(-)*]\n\n [A]",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
            
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Buy for the month\n\n[B]",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
            
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Sell for the month\n\n[C]",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
            
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Total Hedges Outstanding as on Month End\n\n\n\n[Sum(A:C)]",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
            
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Hedges Outstanding on Exchange as on Month End\n\n\n[Long(+)/\nShort(-)*]",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
            
            DI1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("OTC as on Month End\n\n\n\n[Long(+)/\nShort(-)*]",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI1tb1Table.addCell(Cell1);
		    
            
            
            float[] DI2tb1Widths = {0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f,0.20f, 0.20f};
            PdfPTable DI2tb1Table = new PdfPTable(DI2tb1Widths);
            DI2tb1Table.setWidthPercentage(100);
            DI2tb1Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("1",black_normal_green )));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("NATURAL GAS:",black_normal_green )));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk(eligibleLimit,black_normal_green)));
            Cell1.setBackgroundColor(pastelBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk(totalPrevMonthBal,black_normal_green )));
            Cell1.setBackgroundColor(pastelBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk(totalQty,black_normal_green )));
            Cell1.setBackgroundColor(pastelBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk(totalQtySell,black_normal_green )));
            Cell1.setBackgroundColor(pastelBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk(totalQtySettle,black_normal_green )));
            Cell1.setBackgroundColor(pastelBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk(totalMonthOutstanding,black_normal_green )));
            BaseColor lightBlue = new BaseColor(135, 206, 235);
            Cell1.setBackgroundColor(lightBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("-",black_normal_green )));
            Cell1.setBackgroundColor(lightBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk(totalMonthOutstanding,black_normal_green )));
            Cell1.setBackgroundColor(lightBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(mintGreen);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(mintGreen);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(mintGreen);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(mintGreen);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            BaseColor green = new BaseColor(0, 128, 0);
            Cell1.setBackgroundColor(green);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(green);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            DI2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(green);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI2tb1Table.addCell(Cell1);
            
            
            
            float[] DI3tb1Widths = {0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f,0.20f, 0.20f};
            PdfPTable DI3tb1Table = new PdfPTable(DI3tb1Widths);
            DI3tb1Table.setWidthPercentage(100);
            DI3tb1Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green )));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green )));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green )));
            Cell1.setBackgroundColor(pastelBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green )));
            Cell1.setBackgroundColor(pastelBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green )));
            Cell1.setBackgroundColor(pastelBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green )));
            Cell1.setBackgroundColor(pastelBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green )));
            Cell1.setBackgroundColor(pastelBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green )));
            Cell1.setBackgroundColor(lightBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green )));
            Cell1.setBackgroundColor(lightBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green )));
            Cell1.setBackgroundColor(lightBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(mintGreen);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(mintGreen);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(mintGreen);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(mintGreen);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(green);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(green);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            DI3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("\n\n",black_normal_small)));
            Cell1.setBackgroundColor(green);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI3tb1Table.addCell(Cell1);
            
            float[] DI4tb1Widths = {0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f,0.20f, 0.20f};
            PdfPTable DI4tb1Table = new PdfPTable(DI4tb1Widths);
            DI4tb1Table.setWidthPercentage(100);
            DI4tb1Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green )));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("TOTAL",black_normal_green )));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green )));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green )));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green )));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green )));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk(totalQtySettle,black_normal_green )));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk(totalMonthOutstanding,black_normal_green )));
            Cell1.setBackgroundColor(lightBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("-",black_normal_green )));
            Cell1.setBackgroundColor(lightBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk(totalMonthOutstanding,black_normal_green )));
            Cell1.setBackgroundColor(lightBlue);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(green);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(green);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
            DI4tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            DI4tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            DI4tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(green);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            DI4tb1Table.addCell(Cell1);
            
		    float[] headingWidths2 = {5.0f};
            PdfPTable headingTable2 = new PdfPTable(headingWidths2);
            headingTable2.setWidthPercentage(100);
            headingTable2.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            headingTable2.getDefaultCell().setBorder(Rectangle.BOX);
            headingTable2.getDefaultCell().setBorderColor(BaseColor.WHITE);
            headingTable2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            headingTable2.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell headingCell2 = new PdfPCell(new Phrase(new Chunk("TRANSACTION-WISE DETAILS OF CUSTOMER FOR THE MONTH OF "+this.month_name+" "+this.year+" ROUTED THROUGH ICICI BANK LTD\n",white_bold2)));
            BaseColor orangeBrown = new BaseColor(196, 98, 16);
            headingCell2.setBackgroundColor(orangeBrown);
            headingCell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            headingCell2.setVerticalAlignment(Element.ALIGN_MIDDLE);
            headingCell2.setBorderWidth(1);
            headingTable2.addCell(headingCell2);
            
            float[] tb2Widths = {1f, 1f, 1f, 1f, 1f, 1f};
            PdfPTable tb2Table = new PdfPTable(tb2Widths);
            tb2Table.setWidthPercentage(90);
            tb2Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            tb2Table.getDefaultCell().setBorder(Rectangle.BOX);
            tb2Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb2Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb2Cell = new PdfPCell(new Phrase(new Chunk("Commodity Name: \n",white_bold)));
            tb2Cell.setBackgroundColor(orangeBrown);
            tb2Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb2Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb2Cell.setBorderWidth((float) 0.5);
            tb2Table.addCell(tb2Cell);
            
            tb2Table.getDefaultCell().setBorder(Rectangle.BOX);
            tb2Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb2Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb3Cell = new PdfPCell(new Phrase(new Chunk(VQTYCURV_NM+" (Underlying Commodity is Natural Gas)",white_bold)));
            BaseColor pink = new BaseColor(255, 192, 203);
            tb3Cell.setBackgroundColor(pink);
            tb3Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb3Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb3Cell.setBorderWidth((float) 0.5);
            tb2Table.addCell(tb3Cell);
            
            tb2Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            tb2Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb2Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb1Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb1Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb1Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb1Cell.setBorderWidth(0);
            tb2Table.addCell(tb1Cell);
            
            tb2Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            tb2Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb2Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb4Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb4Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb4Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb4Cell.setBorderWidth(0);
            tb2Table.addCell(tb4Cell);

            tb2Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            tb2Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb2Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb5Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb5Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb5Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb5Cell.setBorderWidth(0);
            tb2Table.addCell(tb5Cell);

            tb2Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            tb2Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb2Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb6Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb6Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb6Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb6Cell.setBorderWidth(0);
            tb2Table.addCell(tb6Cell);
            
            float[] tb3Widths = {1f, 1f, 1f, 1f, 1f, 1f};
            PdfPTable tb3Table = new PdfPTable(tb3Widths);
            tb3Table.setWidthPercentage(90);
            tb3Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            tb3Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            tb3Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb3Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb2Cell = new PdfPCell(new Phrase(new Chunk("",black_bold_green)));
            tb2Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb2Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb2Cell.setBorderWidth(0);
            tb3Table.addCell(tb2Cell);
            
            tb3Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            tb3Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb3Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb3Cell = new PdfPCell(new Phrase(new Chunk("Direct\n",black_bold)));
            tb3Cell.setBackgroundColor(lightBlue);
            tb3Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb3Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb3Cell.setBorderWidth(0);
            tb3Table.addCell(tb3Cell);
            
            tb3Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            tb3Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb3Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb1Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb1Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb1Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb1Cell.setBorderWidth(0);
            tb3Table.addCell(tb1Cell);
            

            tb3Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            tb3Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb3Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb4Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb4Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb4Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb4Cell.setBorderWidth(0);
            tb3Table.addCell(tb4Cell);

            tb3Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            tb3Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb3Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb5Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb5Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb5Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb5Cell.setBorderWidth(0);
            tb3Table.addCell(tb5Cell);

            tb3Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            tb3Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            tb3Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb6Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb6Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb6Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb6Cell.setBorderWidth(0);
            tb3Table.addCell(tb6Cell);
            
            
            float[] TWD1tb1Widths = {0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f};
            PdfPTable TWD1tb1Table = new PdfPTable(TWD1tb1Widths);
            TWD1tb1Table.setWidthPercentage(100);
            TWD1tb1Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            TWD1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Sr. No.",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD1tb1Table.addCell(Cell1);
            
            TWD1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Contract Date",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD1tb1Table.addCell(Cell1);
            
            TWD1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Contract ID/Trade Reference",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD1tb1Table.addCell(Cell1);
            
            TWD1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Maturity Date/Prompt Date",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD1tb1Table.addCell(Cell1);
            
            TWD1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Trade Type\n(Forward /Futures /Options/Swaps)",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD1tb1Table.addCell(Cell1);
            
            TWD1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Buy for the Month\n(Barrels)",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD1tb1Table.addCell(Cell1);
            
            TWD1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Buy for the Month\n(mmBtu)\n equivalent",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD1tb1Table.addCell(Cell1);
            
            TWD1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Sell for the Month\n(Barrels)",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD1tb1Table.addCell(Cell1);
            
            TWD1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Sell for the Month\n(mmBtu)\n equivalent",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD1tb1Table.addCell(Cell1);
            
            TWD1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Deal Settled in the Month \n(MMBTU)",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD1tb1Table.addCell(Cell1);
            
            TWD1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Exchanges",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD1tb1Table.addCell(Cell1);
            
            TWD1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("OTC Counterparty Name",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD1tb1Table.addCell(Cell1);
            
            TWD1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Broker/Counterparty Name",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD1tb1Table.addCell(Cell1);
            
            TWD1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Remarks",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD1tb1Table.addCell(Cell1);
            
            PdfPTable TWD2tb1Table[] = new PdfPTable[VDISP_DEAL_ID.size()];
            PdfPTable TWD21tb1Table = null;
            if (VDISP_DEAL_ID.size() > 0) {
	            
	            for(int i=0;i<VDISP_DEAL_ID.size();i++) {
	            	float[] TWD2tb1Widths = {0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f};
	                TWD2tb1Table[i] = new PdfPTable(TWD2tb1Widths);
	                TWD2tb1Table[i].setWidthPercentage(100);
	                TWD2tb1Table[i].setHorizontalAlignment(Rectangle.ALIGN_CENTER);
	                TWD2tb1Table[i].getDefaultCell().setBorder(Rectangle.NO_BORDER);
	                TWD2tb1Table[i].getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                TWD2tb1Table[i].getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	                Cell1 = new PdfPCell(new Phrase(new Chunk(""+(i+1),black_normal_small)));
	                Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	                Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	                TWD2tb1Table[i].addCell(Cell1);
	                
	                TWD2tb1Table[i].getDefaultCell().setBorder(Rectangle.NO_BORDER);
	                TWD2tb1Table[i].getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                TWD2tb1Table[i].getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	                Cell1 = new PdfPCell(new Phrase(new Chunk(VTRADE_DT.elementAt(i).toString(),black_normal_small)));
	                Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	                Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	                TWD2tb1Table[i].addCell(Cell1);
	                
	                TWD2tb1Table[i].getDefaultCell().setBorder(Rectangle.NO_BORDER);
	                TWD2tb1Table[i].getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                TWD2tb1Table[i].getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	                Cell1 = new PdfPCell(new Phrase(new Chunk(VCONT_REF.elementAt(i).toString(),black_normal_small)));
	                Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	                Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	                TWD2tb1Table[i].addCell(Cell1);
	                
	                TWD2tb1Table[i].getDefaultCell().setBorder(Rectangle.NO_BORDER);
	                TWD2tb1Table[i].getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                TWD2tb1Table[i].getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	                Cell1 = new PdfPCell(new Phrase(new Chunk(VPRICE_END_DT.elementAt(i).toString(),black_normal_small)));
	                Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	                Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	                TWD2tb1Table[i].addCell(Cell1);
	                
	                TWD2tb1Table[i].getDefaultCell().setBorder(Rectangle.NO_BORDER);
	                TWD2tb1Table[i].getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                TWD2tb1Table[i].getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	                Cell1 = new PdfPCell(new Phrase(new Chunk("Swap",black_normal_small)));
	                Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	                Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	                TWD2tb1Table[i].addCell(Cell1);
	                
	                TWD2tb1Table[i].getDefaultCell().setBorder(Rectangle.NO_BORDER);
	                TWD2tb1Table[i].getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                TWD2tb1Table[i].getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	                Cell1 = new PdfPCell(new Phrase(new Chunk(VQTY_BBL.elementAt(i).toString(),black_normal_small)));
	                Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	                Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	                TWD2tb1Table[i].addCell(Cell1);
	                
	                TWD2tb1Table[i].getDefaultCell().setBorder(Rectangle.NO_BORDER);
	                TWD2tb1Table[i].getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                TWD2tb1Table[i].getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	                Cell1 = new PdfPCell(new Phrase(new Chunk(VQTY.elementAt(i).toString(),black_normal_small)));
	                Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	                Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	                TWD2tb1Table[i].addCell(Cell1);
	                
	                TWD2tb1Table[i].getDefaultCell().setBorder(Rectangle.NO_BORDER);
	                TWD2tb1Table[i].getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                TWD2tb1Table[i].getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	                Cell1 = new PdfPCell(new Phrase(new Chunk(VQTYSELL_BBL.elementAt(i).toString(),black_normal_small)));
	                Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	                Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	                TWD2tb1Table[i].addCell(Cell1);
	                
	                TWD2tb1Table[i].getDefaultCell().setBorder(Rectangle.NO_BORDER);
	                TWD2tb1Table[i].getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                TWD2tb1Table[i].getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	                Cell1 = new PdfPCell(new Phrase(new Chunk(VQTY_SELL.elementAt(i).toString(),black_normal_small)));
	                Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	                Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	                TWD2tb1Table[i].addCell(Cell1);
	                
	                TWD2tb1Table[i].getDefaultCell().setBorder(Rectangle.NO_BORDER);
	                TWD2tb1Table[i].getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                TWD2tb1Table[i].getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	                Cell1 = new PdfPCell(new Phrase(new Chunk(VQTY_SETTLE.elementAt(i).toString(),black_normal_small)));
	                Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	                Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	                TWD2tb1Table[i].addCell(Cell1);
	                
	                TWD2tb1Table[i].getDefaultCell().setBorder(Rectangle.NO_BORDER);
	                TWD2tb1Table[i].getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                TWD2tb1Table[i].getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	                Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
	                Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	                Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	                TWD2tb1Table[i].addCell(Cell1);
	                
	                TWD2tb1Table[i].getDefaultCell().setBorder(Rectangle.NO_BORDER);
	                TWD2tb1Table[i].getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                TWD2tb1Table[i].getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	                Cell1 = new PdfPCell(new Phrase(new Chunk(VCOUNTERPARTY_NM.elementAt(i).toString(),black_normal_small)));
	                Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	                Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	                TWD2tb1Table[i].addCell(Cell1);
	                
	                TWD2tb1Table[i].getDefaultCell().setBorder(Rectangle.NO_BORDER);
	                TWD2tb1Table[i].getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                TWD2tb1Table[i].getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	                Cell1 = new PdfPCell(new Phrase(new Chunk(VCOUNTERPARTY_NM.elementAt(i).toString(),black_normal_small)));
	                Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	                Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	                TWD2tb1Table[i].addCell(Cell1);
	                
	                TWD2tb1Table[i].getDefaultCell().setBorder(Rectangle.NO_BORDER);
	                TWD2tb1Table[i].getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                TWD2tb1Table[i].getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	                Cell1 = new PdfPCell(new Phrase(new Chunk(VDEAL_RMK.elementAt(i).toString(),black_normal_small)));
	                Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	                Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	                TWD2tb1Table[i].addCell(Cell1);
	            }
            }
            else 
            {
            	float[] TWD21tb1Widths = {0.50f};
                TWD21tb1Table = new PdfPTable(TWD21tb1Widths);
                TWD21tb1Table.setWidthPercentage(100);
                TWD21tb1Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
                TWD21tb1Table.getDefaultCell().setBorder(Rectangle.BOX);
                TWD21tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
                TWD21tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
                Cell1 = new PdfPCell(new Phrase(new Chunk("List Not Available!!!",black_normal_small)));
                BaseColor lightGrey = new BaseColor(211, 211, 211);
                Cell1.setBackgroundColor(lightGrey);
                Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
                Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
                Cell1.setBorderWidth(1);
                TWD21tb1Table.addCell(Cell1);
            }
            
            
            float[] TWD3tb1Widths = {0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f};
            PdfPTable TWD3tb1Table = new PdfPTable(TWD3tb1Widths);
            TWD3tb1Table.setWidthPercentage(100);
            TWD3tb1Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            TWD3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD3tb1Table.addCell(Cell1);
            
            TWD3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD3tb1Table.addCell(Cell1);
            
            TWD3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD3tb1Table.addCell(Cell1);
            
            TWD3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD3tb1Table.addCell(Cell1);
            
            TWD3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("TOTAL:",black_normal_green)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD3tb1Table.addCell(Cell1);
            
            TWD3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            BaseColor goldenYellow = new BaseColor(254, 237, 147);
            Cell1.setBackgroundColor(goldenYellow);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD3tb1Table.addCell(Cell1);
            
            TWD3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk(totalQty,black_normal_green)));
            Cell1.setBackgroundColor(goldenYellow);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD3tb1Table.addCell(Cell1);
            
            TWD3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(goldenYellow);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD3tb1Table.addCell(Cell1);
            
            TWD3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk(totalQtySell,black_normal_green)));
            Cell1.setBackgroundColor(goldenYellow);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD3tb1Table.addCell(Cell1);
            
            TWD3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk(totalQtySettle,black_normal_green)));
            Cell1.setBackgroundColor(goldenYellow);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD3tb1Table.addCell(Cell1);
            
            TWD3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(goldenYellow);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD3tb1Table.addCell(Cell1);
            
            TWD3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(goldenYellow);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD3tb1Table.addCell(Cell1);
            
            TWD3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(goldenYellow);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD3tb1Table.addCell(Cell1);
            
            TWD3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWD3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWD3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(goldenYellow);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWD3tb1Table.addCell(Cell1);
            
            float[] IDtb2Widths = {1f, 1f, 1f, 1f, 1f, 1f};
            PdfPTable IDtb2Table = new PdfPTable(IDtb2Widths);
            IDtb2Table.setWidthPercentage(90);
            IDtb2Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            IDtb2Table.getDefaultCell().setBorder(Rectangle.BOX);
            IDtb2Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            IDtb2Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb2Cell = new PdfPCell(new Phrase(new Chunk("Commodity Name: \n",white_bold)));
            tb2Cell.setBackgroundColor(orangeBrown);
            tb2Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb2Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb2Cell.setBorderWidth((float) 0.5);
            IDtb2Table.addCell(tb2Cell);
            
            IDtb2Table.getDefaultCell().setBorder(Rectangle.BOX);
            IDtb2Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            IDtb2Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb3Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb3Cell.setBackgroundColor(pink);
            tb3Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb3Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb3Cell.setBorderWidth((float) 0.5);
            IDtb2Table.addCell(tb3Cell);
            
            IDtb2Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            IDtb2Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            IDtb2Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb1Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb1Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb1Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb1Cell.setBorderWidth(0);
            IDtb2Table.addCell(tb1Cell);
            

            IDtb2Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            IDtb2Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            IDtb2Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb4Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb4Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb4Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb4Cell.setBorderWidth(0);
            IDtb2Table.addCell(tb4Cell);

            IDtb2Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            IDtb2Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            IDtb2Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb5Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb5Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb5Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb5Cell.setBorderWidth(0);
            IDtb2Table.addCell(tb5Cell);

            IDtb2Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            IDtb2Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            IDtb2Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb6Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb6Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb6Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb6Cell.setBorderWidth(0);
            IDtb2Table.addCell(tb6Cell);
            
            float[] IDtb3Widths = {1f, 1f, 1f, 1f, 1f, 1f};
            PdfPTable IDtb3Table = new PdfPTable(IDtb3Widths);
            IDtb3Table.setWidthPercentage(90);
            IDtb3Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            IDtb3Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            IDtb3Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            IDtb3Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb2Cell = new PdfPCell(new Phrase(new Chunk("",black_bold_green)));
            tb2Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb2Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb2Cell.setBorderWidth(0);
            IDtb3Table.addCell(tb2Cell);
            
            IDtb3Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            IDtb3Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            IDtb3Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb3Cell = new PdfPCell(new Phrase(new Chunk("IN Direct\n",black_bold)));
            tb3Cell.setBackgroundColor(green);
            tb3Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb3Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb3Cell.setBorderWidth(0);
            IDtb3Table.addCell(tb3Cell);
            
            IDtb3Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            IDtb3Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            IDtb3Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb1Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb1Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb1Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb1Cell.setBorderWidth(0);
            IDtb3Table.addCell(tb1Cell);
            

            IDtb3Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            IDtb3Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            IDtb3Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb4Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb4Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb4Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb4Cell.setBorderWidth(0);
            IDtb3Table.addCell(tb4Cell);

            IDtb3Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            IDtb3Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            IDtb3Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb5Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb5Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb5Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb5Cell.setBorderWidth(0);
            IDtb3Table.addCell(tb5Cell);

            IDtb3Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            IDtb3Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            IDtb3Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb6Cell = new PdfPCell(new Phrase(new Chunk("",black_bold)));
            tb6Cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tb6Cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tb6Cell.setBorderWidth(0);
            IDtb3Table.addCell(tb6Cell);
            
            float[] TWID1tb1Widths = {0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f};
            PdfPTable TWID1tb1Table = new PdfPTable(TWID1tb1Widths);
            TWID1tb1Table.setWidthPercentage(100);
            TWID1tb1Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            TWID1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Sr. No.",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID1tb1Table.addCell(Cell1);
            
            TWID1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Contract Date",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID1tb1Table.addCell(Cell1);
            
            TWID1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Contract ID/Trade Reference",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID1tb1Table.addCell(Cell1);
            
            TWID1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Maturity Date/Prompt Date",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID1tb1Table.addCell(Cell1);
            
            TWID1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Trade Type\n(Forward /Futures /Options/Swaps)",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID1tb1Table.addCell(Cell1);
            
            TWID1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Buy for the Month\n(MT) / Units",black_normal_small)));
            //Cell1.setBackgroundColor(new BaseColor(0x8cbed6));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            //Cell1.setBorderWidth(1);
            TWID1tb1Table.addCell(Cell1);
            
            TWID1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Sell for the Month\n(MT) / Units",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID1tb1Table.addCell(Cell1);
            
            TWID1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Exchanges",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID1tb1Table.addCell(Cell1);
            
            TWID1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("OTC",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID1tb1Table.addCell(Cell1);
            
            TWID1tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID1tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID1tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Broker Name",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID1tb1Table.addCell(Cell1);
            
            float[] TWID2tb1Widths = {0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f};
            PdfPTable TWID2tb1Table = new PdfPTable(TWID2tb1Widths);
            TWID2tb1Table.setWidthPercentage(100);
            TWID2tb1Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            TWID2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID2tb1Table.addCell(Cell1);
            
            TWID2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID2tb1Table.addCell(Cell1);
            
            TWID2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID2tb1Table.addCell(Cell1);
            
            TWID2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID2tb1Table.addCell(Cell1);
            
            TWID2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID2tb1Table.addCell(Cell1);
            
            TWID2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID2tb1Table.addCell(Cell1);
            
            TWID2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID2tb1Table.addCell(Cell1);
            
            TWID2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID2tb1Table.addCell(Cell1);
            
            TWID2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID2tb1Table.addCell(Cell1);
            
            TWID2tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID2tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID2tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("\n\n",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID2tb1Table.addCell(Cell1);
            
            
            float[] TWID3tb1Widths = {0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f, 0.20f};
            PdfPTable TWID3tb1Table = new PdfPTable(TWID3tb1Widths);
            TWID3tb1Table.setWidthPercentage(100);
            TWID3tb1Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            TWID3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID3tb1Table.addCell(Cell1);
            
            TWID3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID3tb1Table.addCell(Cell1);
            
            TWID3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID3tb1Table.addCell(Cell1);
            
            TWID3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID3tb1Table.addCell(Cell1);
            
            TWID3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID3tb1Table.addCell(Cell1);
            
            TWID3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("TOTAL:",black_normal_green)));
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID3tb1Table.addCell(Cell1);
            
            TWID3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_green)));
            Cell1.setBackgroundColor(goldenYellow);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID3tb1Table.addCell(Cell1);
            
            TWID3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(goldenYellow);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID3tb1Table.addCell(Cell1);
            
            TWID3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("",black_normal_small)));
            Cell1.setBackgroundColor(goldenYellow);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID3tb1Table.addCell(Cell1);
            
            TWID3tb1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            TWID3tb1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            TWID3tb1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("\n\n",black_normal_small)));
            Cell1.setBackgroundColor(goldenYellow);
            Cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            TWID3tb1Table.addCell(Cell1);
            
            float[] text1Widths = {0.20f};
            PdfPTable text1Table = new PdfPTable(text1Widths);
            text1Table.setWidthPercentage(100);
            text1Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            text1Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            text1Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            text1Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("we hereby confirm that all the above transaction has been carried out in pursuant to relevant RBI guidelines on Hedging of Commodity Price Risk & Freight Risk in Overseas Markets",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1.setBorderWidth(0);
            text1Table.addCell(Cell1);
            
            float[] text2Widths = {0.20f};
            PdfPTable text2Table = new PdfPTable(text2Widths);
            text2Table.setWidthPercentage(100);
            text2Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            text2Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            text2Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            text2Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("* All quantity proposed to be hedged and the tenure of the hedge are in line with the limit granted, at any given point of time",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1.setBorderWidth(0);
            text2Table.addCell(Cell1);
            
            float[] text3Widths = {0.20f};
            PdfPTable text3Table = new PdfPTable(text3Widths);
            text3Table.setWidthPercentage(100);
            text3Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            text3Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            text3Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            text3Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("* Alternatively, hedges can be depicted in the form of import, export",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1.setBorderWidth(0);
            text3Table.addCell(Cell1);
            
            float[] text4Widths = {0.20f};
            PdfPTable text4Table = new PdfPTable(text4Widths);
            text4Table.setWidthPercentage(100);
            text4Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            text4Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            text4Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            text4Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("* The margin remittance has been done in line with the exposure of the entity",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1.setBorderWidth(0);
            text4Table.addCell(Cell1);
            
            float[] text5Widths = {0.20f};
            PdfPTable text5Table = new PdfPTable(text5Widths);
            text5Table.setWidthPercentage(100);
            text5Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            text5Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            text5Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            text5Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Yours Faithfully,",black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1.setBorderWidth(0);
            text5Table.addCell(Cell1);
            
            float[] text6Widths = {0.20f};
            PdfPTable text6Table = new PdfPTable(text1Widths);
            text6Table.setWidthPercentage(100);
            text6Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            text6Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            text6Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            text6Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("For "+comp_nm,black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1.setBorderWidth(0);
            text6Table.addCell(Cell1);
            
            
            float[] text7Widths = {0.20f};
            PdfPTable text7Table = new PdfPTable(text7Widths);
            text7Table.setWidthPercentage(100);
            text7Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            text7Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            text7Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            text7Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("CIN: "+comp_cin_no,black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1.setBorderWidth(0);
            text7Table.addCell(Cell1);
            
            float[] text8Widths = {0.20f};
            PdfPTable text8Table = new PdfPTable(text8Widths);
            text8Table.setWidthPercentage(100);
            text8Table.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
            text8Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            text8Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            text8Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1 = new PdfPCell(new Phrase(new Chunk("Registered Office: "+comp_registered_addr,black_normal_small)));
            Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
            Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            Cell1.setBorderWidth(0);
            text8Table.addCell(Cell1);
            
            PdfPTable mainTable = new PdfPTable(1);
            mainTable.setWidthPercentage(100);
            mainTable.setTotalWidth(1000);
            mainTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            mainTable.getDefaultCell().setPadding(0);
            mainTable.setSplitRows(false);

            mainTable.addCell(Table1);
            mainTable.addCell("\n");
            mainTable.addCell("\n");
            mainTable.addCell(headingTable);
            mainTable.addCell(tb1Table);
            mainTable.addCell(headingTable1);
            mainTable.addCell(DItb1Table);
            mainTable.addCell(DI1tb1Table);
            mainTable.addCell(DI2tb1Table);
            mainTable.addCell(DI3tb1Table);
            mainTable.addCell(DI4tb1Table);
            mainTable.addCell("\n");
            mainTable.addCell("\n");
            mainTable.addCell(headingTable2);
            mainTable.addCell(tb2Table);
            mainTable.addCell(tb3Table);
            mainTable.addCell(TWD1tb1Table);
            if (VDISP_DEAL_ID.size() > 0) 
            {
	            for (int i=0;i<VDISP_DEAL_ID.size();i++) 
	            {
	            	mainTable.addCell(TWD2tb1Table[i]);
	            }
            }
            else 
            {
            	mainTable.addCell(TWD21tb1Table);
            }
            mainTable.addCell(TWD3tb1Table);
            mainTable.addCell(IDtb2Table);
            mainTable.addCell(IDtb3Table);
            mainTable.addCell(TWID1tb1Table);
            mainTable.addCell(TWID2tb1Table);
            mainTable.addCell(TWID3tb1Table);
            mainTable.addCell("\n");
            mainTable.addCell(text1Table);
            mainTable.addCell("\n");
            mainTable.addCell(text2Table);
            mainTable.addCell(text3Table);
            mainTable.addCell(text4Table);
            mainTable.addCell("\n");
            mainTable.addCell("\n");
            mainTable.addCell("\n");
            mainTable.addCell(text5Table);
            mainTable.addCell(text6Table);
            mainTable.addCell("\n");
            mainTable.addCell("\n");
            mainTable.addCell("\n");
            mainTable.addCell("\n");
            mainTable.addCell(text7Table);
            mainTable.addCell(text8Table);
            
            document.add(mainTable);
			document.close();
            
		}
		catch(Exception e)
		{	
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
		finally
		{
			document.close();
		}
	}
	
	public void printPdfJoinTicket()
	{
		String function_nm="printPdfJoinTicket()";
		
		Rectangle pageSize = new Rectangle(595, 842);
		pageSize.setBackgroundColor(new BaseColor(0xffffff));
		Document document = new Document(pageSize);
		try
		{
			HttpSession session = request.getSession();
			String company_abbr = ""+session.getAttribute("comp_abbr")==null?"":""+session.getAttribute("comp_abbr");

			String appPath = request.getServletContext().getRealPath("");
			
			String main_folder="";
			if(!comp_cd.equals(""))
			{
				main_folder=CommonVariable.work_dir+comp_cd;
			}

			File main_folderDir = new File(appPath+File.separator+main_folder);
	        if(!main_folderDir.exists())
	        {
	        	main_folderDir.mkdir();
	        }

	        String sub_folder="join_ticket";
	        File sub_folderDir = new File(appPath+File.separator+main_folder+File.separator+sub_folder);
	        if(!sub_folderDir.exists())
	        {
	        	sub_folderDir.mkdir();
	        }

	        file_nm=company_abbr+"-DLNG_JT-"+view_join_ticket_info.get("bu_plantState")+"-"+gas_dt.replaceAll("/", "")+"-"+utilBean.getSalesContractName(contract_type)+"-"+view_join_ticket_info.get("customer_abbr")+"-"+view_join_ticket_info.get("plant_nm")+".pdf";
	        
	        String path = appPath+"/"+main_folder+"/"+sub_folder+"/"+file_nm;
	        PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream(path));
	        
	        document.open();
			document.setPageSize(pageSize);
            document.newPage();

            String context_nm = request.getContextPath();
			String server_nm = request.getServerName();
			String server_port = ""+request.getServerPort();

			file_url = CommonVariable.app_protocol+"://"+server_nm+":"+server_port+context_nm;

			Font small_black_normal = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
			Font small_black_italic = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.ITALIC, new BaseColor(0x00, 0x00, 0x00));
			Font small_black_normal_10 = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
			Font small_black_normal_14 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
            Font small_black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            Font black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            Font header_black_bold = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            Font black_bold1 = FontFactory.getFont(FontFactory.HELVETICA, 11, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            
            Paragraph company_address=new Paragraph();
            Paragraph customer_address=new Paragraph();
            
            ///GET COMPANY ADDRESS
            String comp_address=view_join_ticket_info.get("company_nm")+"\n"
            		+ view_join_ticket_info.get("bu_plantAddress")+"\n"
            		+ view_join_ticket_info.get("bu_plantCity")+"";
            if(!view_join_ticket_info.get("bu_plantPin").toString().trim().equals(""))
            {
            	comp_address+="-"+view_join_ticket_info.get("bu_plantPin");
            }
            if(!view_join_ticket_info.get("bu_plantCity").toString().trim().equals(""))
            {
            	comp_address+=",";
            }
            comp_address+="\n"
            		+ view_join_ticket_info.get("bu_plantState")+"\n"
            		+ "Tel: "+view_join_ticket_info.get("ownPhone")+"\n"
            		+ "Email: "+view_join_ticket_info.get("ownEmail");
            
            ///GET CUSTOMER ADDRESS
            String cust_address="To:\n"+view_join_ticket_info.get("contact_person_nm")+"\n"
            		+ view_join_ticket_info.get("customer_nm")+"\n"
            		+ view_join_ticket_info.get("plantAddress")+""
            		+ view_join_ticket_info.get("plantCity")+"";
            if(!view_join_ticket_info.get("plantPin").toString().trim().equals(""))
            {
            	cust_address+="-"+view_join_ticket_info.get("plantPin");
            }
            if(!view_join_ticket_info.get("plantCity").toString().trim().equals(""))
            {
            	cust_address+=",";
            }
            cust_address+="\n"
            		+ view_join_ticket_info.get("plantState")+"\n"
            		+ "Tel: "+view_join_ticket_info.get("contact_person_phone")+"\n"
            		+ "Email: "+view_join_ticket_info.get("contact_person_fax");
            
            company_address.add(new Phrase(new Chunk("\n"+comp_address,small_black_normal)));
            customer_address.add(new Phrase(new Chunk("\n"+cust_address,small_black_normal)));
            
            PdfPCell company_logo_cell = new PdfPCell();
            if(!comp_logo.equals(""))
            {
            	String file_path = request.getRealPath("/"+CommonVariable.company_logo_path+"/"+comp_logo);
            	//Image company_logo = Image.getInstance(file_url+"/"+CommonVariable.company_logo_path+"/"+comp_logo);
            	Image company_logo = Image.getInstance(file_path);
	            company_logo.setBorder(Rectangle.NO_BORDER);
	            company_logo.scaleAbsolute(44,40);
	            company_logo_cell = new PdfPCell(company_logo,false);
	            company_logo_cell.setBorder(Rectangle.NO_BORDER);
	            company_logo_cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            }
            
            float[] ContactAddrWidths1 = {0.50f,0.50f};
   	     	PdfPTable Table1 = new PdfPTable(ContactAddrWidths1);
   	     	Table1.setWidthPercentage(100);
   	     	Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
   	     	Table1.addCell(company_logo_cell);
   	     
   	     	Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
   	     	Table1.addCell(company_address);
   	     	
   	     	float[] ContactAddrWidths1_1 = {0.100f};
	     	PdfPTable Table1_1 = new PdfPTable(ContactAddrWidths1_1);
	     	Table1_1.setWidthPercentage(100);
	     	Table1_1.getDefaultCell().setBorder(Rectangle.BOTTOM);
	     	Table1_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	     	Table1_1.addCell("");
   	     	
   	     	float[] ContactAddrWidths2 = {0.50f};
   	     	PdfPTable Table2 = new PdfPTable(ContactAddrWidths2);
   	     	Table2.setWidthPercentage(100);
   	     	Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
   	     	Table2.addCell(customer_address);
   	     	
   	     	float[] ContactAddrWidths3_1 = {0.100f};
	     	PdfPTable Table3_1 = new PdfPTable(ContactAddrWidths3_1);
	     	Table3_1.setWidthPercentage(80);
	     	Table3_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	     	Table3_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	     	Table3_1.addCell(new Phrase(new Chunk("Seq No: "+view_join_ticket_info.get("seq_no"),small_black_bold)));
   	     	
   	     	float[] ContactAddrWidths3 = {0.100f};
   	     	PdfPTable Table3 = new PdfPTable(ContactAddrWidths3);
   	     	Table3.setWidthPercentage(80);
   	     	Table3.setHorizontalAlignment(Element.ALIGN_CENTER);
   	     	Table3.getDefaultCell().setBorder(Rectangle.BOX);
   	     	Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
   	     	Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
   	     	Table3.addCell(new Phrase(new Chunk("DLNG JOINT TICKET ("+company_abbr+" - "+view_join_ticket_info.get("customer_abbr")+" : "+view_join_ticket_info.get("plant_nm")+")",header_black_bold)));
   	     	
   	     	float[] ContactAddrWidths4 = {0.20f, 0.20f, 0.20f, 0.20f,0.20f};
   	     	PdfPTable Table4 = new PdfPTable(ContactAddrWidths4);
   	     	PdfPCell cell;
   	     	Table4.setWidthPercentage(80);
   	     	Table4.setHorizontalAlignment(Element.ALIGN_CENTER);
   	     	Table4.getDefaultCell().setBorder(Rectangle.BOX);
   	     	Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
   	     	Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
   	     	Table4.addCell(new Phrase(new Chunk("Gas Day",black_bold)));
			Table4.getDefaultCell().setBorder(Rectangle.BOX);
			Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table4.addCell(new Phrase(new Chunk("Seller Nominated Qty",black_bold)));
			cell = new PdfPCell(new Phrase(new Chunk("Gas Delivered Quantity",black_bold)));
			cell.setBorder(Rectangle.BOX);
			cell.setColspan(2);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_BOTTOM);
            Table4.addCell(cell);
			Table4.getDefaultCell().setBorder(Rectangle.BOX);
			Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table4.addCell(new Phrase(new Chunk("Truck",black_bold)));
			
			PdfPTable Table4_1 = new PdfPTable(ContactAddrWidths4);
			Table4_1.getDefaultCell().setBorder(Rectangle.BOX);
			Table4_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table4_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table4_1.addCell(new Phrase(new Chunk("06:00 hours \n starting on",black_bold)));
			Table4_1.getDefaultCell().setBorder(Rectangle.BOX);
			Table4_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table4_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table4_1.addCell(new Phrase(new Chunk("MMBTU",black_bold)));
			Table4_1.getDefaultCell().setBorder(Rectangle.BOX);
			Table4_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table4_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table4_1.addCell(new Phrase(new Chunk("MMBTU",black_bold)));
			Table4_1.getDefaultCell().setBorder(Rectangle.BOX);
			Table4_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table4_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table4_1.addCell(new Phrase(new Chunk("MT",black_bold)));
			Table4_1.getDefaultCell().setBorder(Rectangle.BOX);
			Table4_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table4_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table4_1.addCell(new Phrase(new Chunk("",black_bold)));
	     	
	     	float[] ContactAddrWidths5 = {0.20f, 0.20f, 0.20f, 0.20f,0.20f};
			PdfPTable Table5 = new PdfPTable(ContactAddrWidths5);
			Table5.setWidthPercentage(80);
			Table5.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			if(view_join_ticket_data.containsKey("v_gas_dt"))
			{
				HashMap transport_wise = (HashMap) view_join_ticket_data.get("v_gas_dt");
				int key_count=0;
			    for(int i=0; i<transport_wise.size();i++) 
			    {
			    	key_count+=1;
			    	
			    	if(key_count==transport_wise.size())
			    	{
			    		Table5.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table5.addCell(new Phrase(new Chunk(""+transport_wise.get(""+key_count),small_black_bold)));
				    	Table5.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table5.addCell(new Phrase(new Chunk(""+((HashMap) view_join_ticket_data.get("v_sell_nom")).get(""+key_count),small_black_bold)));
				    	Table5.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table5.addCell(new Phrase(new Chunk(""+((HashMap) view_join_ticket_data.get("v_mmbtu")).get(""+key_count),small_black_bold)));
				    	Table5.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table5.addCell(new Phrase(new Chunk(""+((HashMap) view_join_ticket_data.get("v_scm")).get(""+key_count),small_black_bold)));
				    	Table5.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table5.addCell(new Phrase(new Chunk(""+((HashMap) view_join_ticket_data.get("v_grid")).get(""+key_count),small_black_bold)));
			    	}
			    	else
			    	{
				    	Table5.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table5.addCell(new Phrase(new Chunk(""+transport_wise.get(""+key_count),small_black_normal)));
				    	Table5.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table5.addCell(new Phrase(new Chunk(""+((HashMap) view_join_ticket_data.get("v_sell_nom")).get(""+key_count),small_black_normal)));
				    	Table5.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table5.addCell(new Phrase(new Chunk(""+((HashMap) view_join_ticket_data.get("v_mmbtu")).get(""+key_count),small_black_normal)));
				    	Table5.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table5.addCell(new Phrase(new Chunk(""+((HashMap) view_join_ticket_data.get("v_scm")).get(""+key_count),small_black_normal)));
				    	Table5.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table5.addCell(new Phrase(new Chunk(""+((HashMap) view_join_ticket_data.get("v_grid")).get(""+key_count),small_black_normal)));
			    	}
			    }
			}
			
			float[] ContactAddrWidths6 = {0.10f, 0.90f};
			PdfPTable Table6 = new PdfPTable(ContactAddrWidths6);
			Table6.setWidthPercentage(90);
			Table6.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			Table6.addCell(new Phrase(new Chunk("Note : ",black_bold)));
			Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			Table6.addCell(new Phrase(new Chunk(" ")));
			
			float[] ContactAddrWidths7 = {0.10f, 0.20f, 0.20f, 0.20f, 0.20f};
   	     	PdfPTable Table7 = new PdfPTable(ContactAddrWidths7);
   	     	Table7.setWidthPercentage(80);
   	     	Table7.setHorizontalAlignment(Element.ALIGN_CENTER);
   	     	Table7.getDefaultCell().setBorder(Rectangle.BOX);
   	     	Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
   	     	Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
   	     	Table7.addCell(new Phrase(new Chunk("Sr#",black_bold)));
   	     	Table7.getDefaultCell().setBorder(Rectangle.BOX);
   	     	Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
   	     	Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
   	     	Table7.addCell(new Phrase(new Chunk("Contract",black_bold)));
   	     	Table7.getDefaultCell().setBorder(Rectangle.BOX);
   	     	Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
   	     	Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
   	     	Table7.addCell(new Phrase(new Chunk("Gas Delivered Quantity\n(MMBTU)",black_bold)));
   	     	Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	     	Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	     	Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
	     	Table7.addCell(new Phrase(new Chunk("",black_bold)));
	     	Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	     	Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	     	Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
	     	Table7.addCell(new Phrase(new Chunk("",black_bold)));
			
			float[] ContactAddrWidths8 = {0.10f, 0.20f, 0.20f, 0.20f, 0.20f};
			PdfPTable Table8 = new PdfPTable(ContactAddrWidths8);
			Table8.setWidthPercentage(80);
			Table8.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			if(view_join_ticket_data.containsKey("v_contracts"))
			{
				HashMap contract_wise = (HashMap) view_join_ticket_data.get("v_contracts");
				int key_count=0;
			    for(int i=0; i<contract_wise.size();i++) 
			    {
			    	key_count+=1;
			    	
			    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
			    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			    	Table8.addCell(new Phrase(new Chunk(""+key_count,small_black_normal)));
			    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
			    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			    	Table8.addCell(new Phrase(new Chunk(""+contract_wise.get(""+key_count),small_black_normal)));
			    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
			    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_join_ticket_data.get("v_cont_mmbtu")).get(""+key_count),small_black_normal)));
			    	Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			    	Table8.addCell(new Phrase(new Chunk("",small_black_normal)));
			    	Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			    	Table8.addCell(new Phrase(new Chunk("",small_black_normal)));
			    }
			}
			
			float[] SignatureInfoWidths = {0.30f, 0.20f, 0.20f, 0.30f};
			PdfPTable SignatureInfoTable = new PdfPTable(SignatureInfoWidths);
			SignatureInfoTable.setWidthPercentage(100);
			SignatureInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable.addCell(new Phrase(new Chunk(""+view_join_ticket_info.get("emp_nm"),small_black_normal)));
			SignatureInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable.addCell(new Phrase(new Chunk(" ",small_black_normal)));
			SignatureInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable.addCell(new Phrase(new Chunk(" ",small_black_normal)));
			SignatureInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable.addCell(new Phrase(new Chunk(" ",small_black_normal)));
						
			PdfPTable SignatureInfoTable1 = new PdfPTable(SignatureInfoWidths);
			SignatureInfoTable1.setWidthPercentage(100);
			SignatureInfoTable1.getDefaultCell().setBorder(Rectangle.TOP);
			SignatureInfoTable1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable1.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable1.addCell(new Phrase(new Chunk("Authorised Signatory",small_black_normal)));
			SignatureInfoTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable1.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable1.addCell(new Phrase(new Chunk(" ",small_black_normal)));
			SignatureInfoTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable1.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable1.addCell(new Phrase(new Chunk(" ",small_black_normal)));
			SignatureInfoTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable1.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable1.addCell(new Phrase(new Chunk("",small_black_normal)));
			
			PdfPTable SignatureInfoTable2 = new PdfPTable(SignatureInfoWidths);
			SignatureInfoTable2.setWidthPercentage(100);
			SignatureInfoTable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable2.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable2.addCell(new Phrase(new Chunk(""+view_join_ticket_info.get("company_nm"),small_black_normal)));
			SignatureInfoTable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable2.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable2.addCell(new Phrase(new Chunk(" ",small_black_normal)));
			SignatureInfoTable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable2.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable2.addCell(new Phrase(new Chunk(" ",small_black_normal)));
			SignatureInfoTable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable2.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable2.addCell(new Phrase(new Chunk(" ",small_black_normal)));
			
   	     	document.add(Table1);
   	     	document.add(new Paragraph("              "));
   	     	document.add(Table1_1);
   	     	document.add(new Paragraph("              "));
   	     	document.add(Table2);
   	     	document.add(new Paragraph("              "));
   	     	document.add(new Paragraph("              "));
   	     	document.add(new Paragraph("              "));
   	     	document.add(Table3_1);
   	     	document.add(new Paragraph("              "));
   	     	document.add(Table3);
   	     	document.add(new Paragraph("              "));
   	     	document.add(Table4);
   	     	document.add(Table4_1);
   	     	document.add(Table5);
   	     	document.add(new Paragraph("              "));
   	     	document.add(Table6);
   	     	document.add(Table7);
   	     	document.add(Table8);
   	     	document.add(new Paragraph("              "));
   	     	document.add(new Paragraph("              "));
   	     	document.add(new Paragraph("              "));
	     	document.add(new Paragraph("              "));
   	     	document.add(SignatureInfoTable);
   	     	document.add(SignatureInfoTable1);
   	     	document.add(SignatureInfoTable2);
   	     	document.add(new Paragraph("              "));
   	     	document.add(new Paragraph("              "));
   	     	document.add(new Paragraph("              "));
   	     	
   	     	float[] footer = {0.100f};
	     	PdfPTable footer_tab = new PdfPTable(footer);
	     	footer_tab.setWidthPercentage(100);
	     	footer_tab.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		   	footer_tab.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		   	footer_tab.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		   	footer_tab.addCell(new Phrase(new Chunk("*** This is Computer Generated Report and No Signature Required ***",small_black_normal)));

		    document.add(footer_tab);
		    document.close();
	     	
	     	//AP20250509 INSERT/UPDATE PDF NAME IN TABLE.
   	     	int count=0;
			String query = "SELECT COUNT(*) "
					+ "FROM FMS_DAILY_JOINT_TICKET "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND CONTRACT_TYPE=? AND PLANT_SEQ=? "
					+ "AND GAS_DT=TO_DATE(?,'DD/MM/YYYY') AND BU_SEQ=? AND ENTITY_TYPE='C'";
			stmt = conn.prepareStatement(query);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, contract_type);
			stmt.setString(4, plant_seq);
			stmt.setString(5, gas_dt);
			stmt.setString(6, bu_plant_seq);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				count=rset.getInt(1);
			}
			rset.close();
			stmt.close();
			
			String seq_no="";
			String queryString4="SELECT NVL((SEQ_NO),'0') "
					+ "FROM FMS_DAILY_JOINT_TICKET A "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND CONTRACT_TYPE=? AND PLANT_SEQ=? "
					+ "AND GAS_DT=TO_DATE(?,'DD/MM/YYYY') AND BU_SEQ=? AND ENTITY_TYPE='C'";
			stmt4=conn.prepareStatement(queryString4);
			stmt4.setString(1, comp_cd);
			stmt4.setString(2, counterparty_cd);
			stmt4.setString(3, contract_type);
			stmt4.setString(4, plant_seq);
			stmt4.setString(5, gas_dt);
			stmt4.setString(6, bu_plant_seq);
			rset4=stmt4.executeQuery();
			if(rset4.next())
			{
				seq_no =""+(rset4.getInt(1)+1);
			}
			else
			{
				seq_no="1";
			}
			rset4.close();
			stmt4.close();
			
			if(count>0)
			{
				query="UPDATE FMS_DAILY_JOINT_TICKET SET ADDRESSED_TO=?,MODIFIY_BY=?,MODIFIY_DT=SYSDATE,PDF_NM=?,EMAIL_SENT='N',SEQ_NO=? "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
						+ "AND CONTRACT_TYPE=? AND PLANT_SEQ=? "
						+ "AND GAS_DT=TO_DATE(?,'DD/MM/YYYY') AND BU_SEQ=? AND ENTITY_TYPE='C'";
				stmt1 = conn.prepareStatement(query);
				stmt1.setString(1, contact_person_cd);
				stmt1.setString(2, emp_cd);
				stmt1.setString(3, file_nm);
				stmt1.setString(4, seq_no);
				stmt1.setString(5, comp_cd);
				stmt1.setString(6, counterparty_cd);
				stmt1.setString(7, contract_type);
				stmt1.setString(8, plant_seq);
				stmt1.setString(9, gas_dt);
				stmt1.setString(10, bu_plant_seq);
				stmt1.executeUpdate();
				
				stmt1.close();
			}
			else
			{
				query = "INSERT INTO FMS_DAILY_JOINT_TICKET(COMPANY_CD,COUNTERPARTY_CD,CONTRACT_TYPE,PLANT_SEQ,"
						+ "GAS_DT,ENT_DT,ENT_BY,BU_SEQ,ADDRESSED_TO,PDF_NM,EMAIL_SENT,SEQ_NO,ENTITY_TYPE) "
						+ "VALUES(?,?,?,?,"
						+ "TO_DATE(?,'DD/MM/YYYY'),SYSDATE,?,?,?,?,'N',?,'C')";
				stmt1 = conn.prepareStatement(query);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, counterparty_cd);
				stmt1.setString(3, contract_type);
				stmt1.setString(4, plant_seq);
				stmt1.setString(5, gas_dt);
				stmt1.setString(6, emp_cd);
				stmt1.setString(7, bu_plant_seq);
				stmt1.setString(8, contact_person_cd);
				stmt1.setString(9, file_nm);
				stmt1.setString(10, seq_no);
				stmt1.executeUpdate();
				
				stmt1.close();
			}
			conn.commit();
			all_pdf_print="Y";
		}
		catch(Exception e)
		{	
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
		finally
		{
			document.close();
		}
	}
	
	public void printDlngPdfNominationToTransporter()
	{
		String function_nm="printDlngPdfNominationToTransporter()";
		
		Rectangle pageSize = new Rectangle(595, 842);
		pageSize.setBackgroundColor(new BaseColor(0xffffff));
		Document document = new Document(pageSize);
		try
		{
			HttpSession session = request.getSession();
			String company_abbr = ""+session.getAttribute("comp_abbr")==null?"":""+session.getAttribute("comp_abbr");

			String appPath = request.getServletContext().getRealPath("");
			
			String main_folder="";
			if(!comp_cd.equals(""))
			{
				main_folder=CommonVariable.work_dir+comp_cd;
			}

			File main_folderDir = new File(appPath+File.separator+main_folder);
	        if(!main_folderDir.exists())
	        {
	        	main_folderDir.mkdir();
	        }

	        String sub_folder="daily_nomination";
	        File sub_folderDir = new File(appPath+File.separator+main_folder+File.separator+sub_folder);
	        if(!sub_folderDir.exists())
	        {
	        	sub_folderDir.mkdir();
	        }

	        file_nm=company_abbr+"-DLNG_TRANSPORTER_SELLER_NOM-"+gas_dt.replaceAll("/", "")+"-"+view_info.get("transporter_abbr")+"-"+view_info.get("truck_nm")+".pdf";
	        
	        String path = appPath+"/"+main_folder+"/"+sub_folder+"/"+file_nm;
	        PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream(path));
	        
	        document.open();
			document.setPageSize(pageSize);
            document.newPage();

            String context_nm = request.getContextPath();
			String server_nm = request.getServerName();
			String server_port = ""+request.getServerPort();

			file_url = CommonVariable.app_protocol+"://"+server_nm+":"+server_port+context_nm;

			Font small_black_italic = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.ITALIC, new BaseColor(0x00, 0x00, 0x00));
			Font small_black_normal = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
			Font small_black_normal_10 = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
			Font small_black_normal_14 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
            Font small_black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            Font black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            Font header_black_bold = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            Font black_bold1 = FontFactory.getFont(FontFactory.HELVETICA, 11, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            
            Paragraph company_address=new Paragraph();
            Paragraph customer_address=new Paragraph();
            
            ///GET COMPANY ADDRESS
            String comp_address=view_info.get("company_nm")+"\n"
            		+ view_info.get("ownAddress")+"\n"
            		+ view_info.get("ownCity")+"";
            if(!view_info.get("ownPin").toString().trim().equals(""))
            {
            	comp_address+="-"+view_info.get("ownPin");
            }
            if(!view_info.get("ownCity").toString().trim().equals(""))
            {
            	comp_address+=",";
            }
            comp_address+="\n"
            		+ view_info.get("ownState")+"\n"
            		+ "Tel: "+view_info.get("ownPhone")+"\n"
            		+ "Email: "+view_info.get("ownEmail");
            
            ///GET CUSTOMER ADDRESS
            String cust_address="To:\n"+view_info.get("contact_person_nm")+"\n"
            		+ view_info.get("transporter_nm")+"\n"
            		+ view_info.get("plantAddress")+""
            		+ view_info.get("plantCity")+"";
            if(!view_info.get("plantPin").toString().trim().equals(""))
            {
            	cust_address+="-"+view_info.get("plantPin");
            }
            if(!view_info.get("plantCity").toString().trim().equals(""))
            {
            	cust_address+=",";
            }
            cust_address+="\n"
            		+ view_info.get("plantState")+"\n"
            		+ "Tel: "+view_info.get("contact_person_phone")+"\n"
            		+ "Email: "+view_info.get("contact_person_fax");
            
            company_address.add(new Phrase(new Chunk("\n"+comp_address,small_black_normal)));
            customer_address.add(new Phrase(new Chunk("\n"+cust_address,small_black_normal)));
            
            PdfPCell company_logo_cell = new PdfPCell();
            if(!comp_logo.equals(""))
            {
            	String file_path = request.getRealPath("/"+CommonVariable.company_logo_path+"/"+comp_logo);
            	//Image company_logo = Image.getInstance(file_url+"/"+CommonVariable.company_logo_path+"/"+comp_logo);
            	Image company_logo = Image.getInstance(file_path);
	            company_logo.setBorder(Rectangle.NO_BORDER);
	            company_logo.scaleAbsolute(44,40);
	            company_logo_cell = new PdfPCell(company_logo,false);
	            company_logo_cell.setBorder(Rectangle.NO_BORDER);
	            company_logo_cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            }
            
            float[] ContactAddrWidths1 = {0.100f,0.100f};
   	     	PdfPTable Table1 = new PdfPTable(ContactAddrWidths1);
   	     	Table1.setWidthPercentage(100);
   	     	Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
   	     	Table1.addCell(company_logo_cell);
   	     
   	     	Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
   	     	Table1.addCell(company_address);
   	     	
   	     	float[] ContactAddrWidths1_1 = {0.200f};
	     	PdfPTable Table1_1 = new PdfPTable(ContactAddrWidths1_1);
	     	Table1_1.setWidthPercentage(100);
	     	Table1_1.getDefaultCell().setBorder(Rectangle.BOTTOM);
	     	Table1_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	     	Table1_1.addCell("");
   	     	
   	     	float[] ContactAddrWidths2 = {0.100f};
   	     	PdfPTable Table2 = new PdfPTable(ContactAddrWidths2);
   	     	Table2.setWidthPercentage(100);
   	     	Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
   	     	Table2.addCell(customer_address);
   	     	
   	     	float[] ContactAddrWidths3_1 = {0.100f};
	     	PdfPTable Table3_1 = new PdfPTable(ContactAddrWidths3_1);
	     	Table3_1.setWidthPercentage(95);
	     	Table3_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	     	Table3_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	     	Table3_1.addCell(new Phrase(new Chunk("Seq No: "+view_info.get("seq_no"),small_black_bold)));
   	     	
   	     	float[] ContactAddrWidths3 = {0.200f};
	     	PdfPTable Table3 = new PdfPTable(ContactAddrWidths3);
	     	Table3.setWidthPercentage(95);
	     	Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	     	Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	     	Table3.addCell(new Phrase(new Chunk("Date: "+dateUtil.getSysdateWithTime24hr(),small_black_normal)));
	     	
	     	float[] ContactAddrWidths6 = {0.200f};
   	     	PdfPTable Table6 = new PdfPTable(ContactAddrWidths6);
   	     	Table6.setWidthPercentage(95);
   	     	Table6.getDefaultCell().setBorder(Rectangle.BOX);
   			Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
   			Table6.addCell(new Phrase(new Chunk("DLNG SELLER NOMINATION ("+company_abbr+" - "+view_info.get("transporter_abbr")+" : "+view_info.get("truck_nm")+")",header_black_bold)));
            
   	     	float[] ContactAddrWidths7 = {0.80f, 0.80f, 0.80f, 0.80f, 0.80f,0.80f,0.80f, 0.80f,0.80f,0.80f, 0.80f, 0.80f};
   	     	PdfPTable Table7 = new PdfPTable(ContactAddrWidths7);
   	     	PdfPCell cell;
   	     	Table7.setWidthPercentage(95);
   	     	Table7.setHorizontalAlignment(Element.ALIGN_CENTER);
   	     	Table7.getDefaultCell().setBorder(Rectangle.BOTTOM);
	     	Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	     	Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
	     	Table7.addCell(new Phrase(new Chunk("",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOTTOM);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOTTOM);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOTTOM);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOTTOM);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOTTOM);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOTTOM);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOTTOM);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOTTOM);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOTTOM);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOTTOM);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOTTOM);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("",black_bold)));
			
			Table7.setWidthPercentage(95);
   	     	Table7.setHorizontalAlignment(Element.ALIGN_CENTER);
	     	Table7.getDefaultCell().setBorder(Rectangle.LEFT);
	     	Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	     	Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
	     	Table7.addCell(new Phrase(new Chunk("Gas Day",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.LEFT);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("Customer Name",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.LEFT);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("Customer Plant",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.LEFT);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			cell = new PdfPCell(new Phrase(new Chunk("Truck Confirmation",black_bold)));
			cell.setBorder(Rectangle.BOX);
			cell.setColspan(4);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(cell);
			cell = new PdfPCell(new Phrase(new Chunk("Nomination",black_bold)));
			cell.setBorder(Rectangle.BOX);
			cell.setColspan(3);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(cell);
			Table7.getDefaultCell().setBorder(Rectangle.RIGHT);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("Check Post",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.RIGHT);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("Seller's Comment",black_bold)));
			
   	     	Table7.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setBorder(Rectangle.LEFT);
	     	Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	     	Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
	     	Table7.addCell(new Phrase(new Chunk("",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.LEFT);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.LEFT);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOX);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("Truck No",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOX);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("Scheduled Date",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOX);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("Scheduled Time",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOX);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("Driver Name",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOX);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("MMBTU",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOX);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("MT",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOX);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("Rev No.",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.RIGHT);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.RIGHT);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("",black_bold)));
			
			float[] ContactAddrWidths8 = {0.80f, 0.80f, 0.80f, 0.80f, 0.80f,0.80f,0.80f, 0.80f,0.80f,0.80f, 0.80f, 0.80f};
			PdfPTable Table8 = new PdfPTable(ContactAddrWidths8);
			Table8.setWidthPercentage(95);
			Table8.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			if(view_data.containsKey("v_gas_dt"))
			{
				HashMap transport_wise = (HashMap) view_data.get("v_gas_dt");
				int key_count=0;
			    for(int i=0; i<transport_wise.size();i++) 
			    {
			    	key_count+=1;
			    	
			    	if(key_count==transport_wise.size())
			    	{
			    		Table8.getDefaultCell().setBorder(Rectangle.LEFT);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				    	Table8.addCell(new Phrase(new Chunk("Total",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_data.get("v_mmbtu")).get(""+key_count),small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_data.get("v_mt")).get(""+key_count),small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.RIGHT);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));

				    	
				    	Table8.getDefaultCell().setBorder(Rectangle.TOP);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.TOP);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.TOP);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.TOP);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.TOP);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.TOP);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.TOP);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.TOP);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.TOP);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.TOP);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.TOP);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
				    	Table8.getDefaultCell().setBorder(Rectangle.TOP);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				    	Table8.addCell(new Phrase(new Chunk("",small_black_bold)));
			    	}
			    	else
			    	{
				    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk(""+transport_wise.get(""+key_count),small_black_normal)));
				    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_data.get("v_customer")).get(""+key_count),small_black_normal)));
				    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_data.get("v_customer_plant")).get(""+key_count),small_black_normal)));
				    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_data.get("v_truck")).get(""+key_count),small_black_normal)));
				    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_data.get("v_nom_dt")).get(""+key_count),small_black_normal)));
				    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_data.get("v_nom_time")).get(""+key_count),small_black_normal)));
				    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_data.get("v_driver")).get(""+key_count),small_black_normal)));
				    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_data.get("v_mmbtu")).get(""+key_count),small_black_normal)));
				    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_data.get("v_mt")).get(""+key_count),small_black_normal)));
				    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_data.get("v_nom_rev")).get(""+key_count),small_black_normal)));
				    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_data.get("v_checkpost")).get(""+key_count),small_black_normal)));
				    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
				    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_data.get("v_remark")).get(""+key_count),small_black_normal)));
			    	}
			    }
			}
						
   	     	document.add(Table1);
   	     	document.add(new Paragraph("              "));
   	     	document.add(Table1_1);
   	     	document.add(new Paragraph("              "));
   	     	document.add(Table2);
   	     	document.add(new Paragraph("              "));
   	     	document.add(Table3_1);
   	     	document.add(Table3);
   	     	document.add(new Paragraph("              "));
   	     	document.add(Table6);
   	     	document.add(new Paragraph("              "));
	     	document.add(Table7);
	     	document.add(Table8);
   	     	document.add(new Paragraph("              "));
   	     	document.add(new Paragraph("              "));
   	     	float[] footer_1 = {0.200f};
	     	PdfPTable footer_tab_1 = new PdfPTable(footer_1);
	     	footer_tab_1.setWidthPercentage(100);
	     	footer_tab_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	     	footer_tab_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	     	footer_tab_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	     	footer_tab_1.addCell(new Phrase(new Chunk("Note: In case of late arrival of truck, kindly note that the Truck would be scheduled and accepted on the reasonable endeavour basis.",small_black_normal)));
		    document.add(footer_tab_1);
   	     	document.add(new Paragraph("              "));
	     	document.add(new Paragraph("              "));
   	     	// Adding content to the document
  			float[] footer = {0.200f};
 	     	PdfPTable footer_tab = new PdfPTable(footer);
 	     	footer_tab.setWidthPercentage(100);
 	     	footer_tab.getDefaultCell().setBorder(Rectangle.NO_BORDER);
  		   	footer_tab.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
  		   	footer_tab.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
  		   	footer_tab.addCell(new Phrase(new Chunk("*** This is Computer Generated Report and No Signature Required ***",small_black_normal)));

  		    document.add(footer_tab);
  		    document.close();
	     	
   	     	int count=0;
			String query = "SELECT COUNT(*) "
					+ "FROM FMS_DLNG_SELLER_NOM_TRANS "
					+ "WHERE COMPANY_CD=? AND TRUCK_TRANS_CD=? "
					//+ "AND TRUCK_CD=? "
					+ "AND GAS_DT=TO_DATE(?,'DD/MM/YYYY')";
			stmt = conn.prepareStatement(query);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			//stmt.setString(3, truck_cd);
			stmt.setString(3, gas_dt);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				count=rset.getInt(1);
			}
			rset.close();
			stmt.close();
			
			String seq_no="";
			String queryString4="SELECT NVL((SEQ_NO),'0') "
					+ "FROM FMS_DLNG_SELLER_NOM_TRANS A "
					+ "WHERE COMPANY_CD=? AND TRUCK_TRANS_CD=? "
					//+ "AND TRUCK_CD=? "
					+ "AND GAS_DT=TO_DATE(?,'DD/MM/YYYY')";
			stmt4=conn.prepareStatement(queryString4);
			stmt4.setString(1, comp_cd);
			stmt4.setString(2, counterparty_cd);
			//stmt4.setString(3, truck_cd);
			stmt4.setString(3, gas_dt);
			rset4=stmt4.executeQuery();
			if(rset4.next())
			{
				seq_no =""+(rset4.getInt(1)+1);
			}
			else
			{
				seq_no="1";
			}
			rset4.close();
			stmt4.close();
			
			if(count>0)
			{
				query="UPDATE FMS_DLNG_SELLER_NOM_TRANS SET ADDRESSED_TO=?,MODIFIY_BY=?,MODIFIY_DT=SYSDATE,PDF_NM=?,EMAIL_SENT='N',SEQ_NO=? "
						+ "WHERE COMPANY_CD=? AND TRUCK_TRANS_CD=? "
						//+ "AND TRUCK_CD=? "
						+ "AND GAS_DT=TO_DATE(?,'DD/MM/YYYY')";
				stmt1 = conn.prepareStatement(query);
				stmt1.setString(1, contact_person_cd);
				stmt1.setString(2, emp_cd);
				stmt1.setString(3, file_nm);
				stmt1.setString(4, seq_no);
				stmt1.setString(5, comp_cd);
				stmt1.setString(6, counterparty_cd);
				//stmt1.setString(7, truck_cd);
				stmt1.setString(7, gas_dt);
				stmt1.executeUpdate();
				
				stmt1.close();
			}
			else
			{
				query = "INSERT INTO FMS_DLNG_SELLER_NOM_TRANS(COMPANY_CD,TRUCK_TRANS_CD,"
						+ "GAS_DT,ENT_DT,ENT_BY,ADDRESSED_TO,PDF_NM,EMAIL_SENT,SEQ_NO) "
						+ "VALUES(?,?,"
						+ "TO_DATE(?,'DD/MM/YYYY'),SYSDATE,?,?,?,'N',?)";
				stmt1 = conn.prepareStatement(query);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, counterparty_cd);
				//stmt1.setString(3, truck_cd);
				stmt1.setString(3, gas_dt);
				stmt1.setString(4, emp_cd);
				stmt1.setString(5, contact_person_cd);
				stmt1.setString(6, file_nm);
				stmt1.setString(7, seq_no);
				stmt1.executeUpdate();
				
				stmt1.close();
			}
			conn.commit();
			all_pdf_print="Y";
		}
		catch(Exception e)
		{	
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
		finally
		{
			document.close();
		}
	}
	
	public void printDlngPdfNominationToCustomer()
	{
		String function_nm="printDlngPdfNominationToCustomer()";
		
		Rectangle pageSize = new Rectangle(595, 842);
		pageSize.setBackgroundColor(new BaseColor(0xffffff));
		Document document = new Document(pageSize);
		try
		{
			HttpSession session = request.getSession();
			String company_abbr = ""+session.getAttribute("comp_abbr")==null?"":""+session.getAttribute("comp_abbr");
			String appPath = request.getServletContext().getRealPath("");
			
			String main_folder="";
			if(!comp_cd.equals(""))
			{
				main_folder=CommonVariable.work_dir+comp_cd;
			}

			File main_folderDir = new File(appPath+File.separator+main_folder);
	        if(!main_folderDir.exists())
	        {
	        	main_folderDir.mkdir();
	        }

	        String sub_folder="daily_nomination";
	        File sub_folderDir = new File(appPath+File.separator+main_folder+File.separator+sub_folder);
	        if(!sub_folderDir.exists())
	        {
	        	sub_folderDir.mkdir();
	        }

	        file_nm=company_abbr+"-DLNG_CUSTOMER_SELLER_NOM-"+gas_dt.replaceAll("/", "")+"-"+view_seller_nomination_to_customer_info.get("customer_abbr")+"-"
	        		+view_seller_nomination_to_customer_info.get("plant_nm")
	        		+utilBean.getContractTypeName(contract_type)
	        		+utilBean.NewDealMappingId(comp_cd, counterparty_cd, agmt_no, "", cont_no, "", contract_type, "")+".pdf";
	        
	        String path = appPath+"/"+main_folder+"/"+sub_folder+"/"+file_nm;
	        PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream(path));
	        
	        document.open();
			document.setPageSize(pageSize);
            document.newPage();

            String context_nm = request.getContextPath();
			String server_nm = request.getServerName();
			String server_port = ""+request.getServerPort();

			file_url = CommonVariable.app_protocol+"://"+server_nm+":"+server_port+context_nm;

			Font small_black_normal = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
			Font small_black_italic = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.ITALIC, new BaseColor(0x00, 0x00, 0x00));
			Font small_black_normal_10 = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
			Font small_black_normal_14 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
            Font small_black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            Font black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            Font header_black_bold = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            Font black_bold1 = FontFactory.getFont(FontFactory.HELVETICA, 11, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
            
            Paragraph company_address=new Paragraph();
            Paragraph customer_address=new Paragraph();
            
            ///GET COMPANY ADDRESS
            String comp_address=view_seller_nomination_to_customer_info.get("company_nm")+"\n"
            		+ view_seller_nomination_to_customer_info.get("ownAddress")+"\n"
            		+ view_seller_nomination_to_customer_info.get("ownCity")+"";
            if(!view_seller_nomination_to_customer_info.get("ownPin").toString().trim().equals(""))
            {
            	comp_address+="-"+view_seller_nomination_to_customer_info.get("ownPin");
            }
            if(!view_seller_nomination_to_customer_info.get("ownCity").toString().trim().equals(""))
            {
            	comp_address+=",";
            }
            comp_address+="\n"
            		+ view_seller_nomination_to_customer_info.get("ownState")+"\n"
            		+ "Tel: "+view_seller_nomination_to_customer_info.get("ownPhone")+"\n"
            		+ "Email: "+view_seller_nomination_to_customer_info.get("ownEmail");
            
            ///GET CUSTOMER ADDRESS
            String cust_address="To:\n"+view_seller_nomination_to_customer_info.get("contact_person_nm")+"\n"
            		+ view_seller_nomination_to_customer_info.get("customer_nm")+"\n"
            		+ view_seller_nomination_to_customer_info.get("plantAddress")+"\n"
            		+ view_seller_nomination_to_customer_info.get("plantCity")+"";
            if(!view_seller_nomination_to_customer_info.get("plantPin").toString().trim().equals(""))
            {
            	cust_address+="-"+view_seller_nomination_to_customer_info.get("plantPin");
            }
            if(!view_seller_nomination_to_customer_info.get("plantCity").toString().trim().equals(""))
            {
            	cust_address+=",";
            }
            cust_address+="\n"
            		+ view_seller_nomination_to_customer_info.get("plantState")+"\n"
            		+ "Tel: "+view_seller_nomination_to_customer_info.get("contact_person_phone")+"\n"
            		+ "Email: "+view_seller_nomination_to_customer_info.get("contact_person_fax");
            
            company_address.add(new Phrase(new Chunk("\n"+comp_address,small_black_normal)));
            customer_address.add(new Phrase(new Chunk("\n"+cust_address,small_black_normal)));
            
            if(!view_seller_nomination_to_customer_info.get("remark").equals(""))
	     	{
            	remark=view_seller_nomination_to_customer_info.get("remark");
	     	}
            
            PdfPCell company_logo_cell = new PdfPCell();
            if(!comp_logo.equals(""))
            {
            	String file_path = request.getRealPath("/"+CommonVariable.company_logo_path+"/"+comp_logo);
            	//Image company_logo = Image.getInstance(file_url+"/"+CommonVariable.company_logo_path+"/"+comp_logo);
            	Image company_logo = Image.getInstance(file_path);
	            company_logo.setBorder(Rectangle.NO_BORDER);
	            company_logo.scaleAbsolute(44,40);
	            company_logo_cell = new PdfPCell(company_logo,false);
	            company_logo_cell.setBorder(Rectangle.NO_BORDER);
	            company_logo_cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            }
            
            float[] ContactAddrWidths1 = {0.50f,0.50f};
   	     	PdfPTable Table1 = new PdfPTable(ContactAddrWidths1);
   	     	Table1.setWidthPercentage(100);
   	     	Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
   	     	Table1.addCell(company_logo_cell);
   	     
   	     	Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
   	     	Table1.addCell(company_address);
   	     	
   	     	float[] ContactAddrWidths1_1 = {0.100f};
	     	PdfPTable Table1_1 = new PdfPTable(ContactAddrWidths1_1);
	     	Table1_1.setWidthPercentage(100);
	     	Table1_1.getDefaultCell().setBorder(Rectangle.BOTTOM);
	     	Table1_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	     	Table1_1.addCell("");
   	     	
   	     	float[] ContactAddrWidths2 = {0.50f};
   	     	PdfPTable Table2 = new PdfPTable(ContactAddrWidths2);
   	     	Table2.setWidthPercentage(100);
   	     	Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
   	     	Table2.addCell(customer_address);
   	     	
   	     	float[] ContactAddrWidths3_1 = {0.100f};
	     	PdfPTable Table3_1 = new PdfPTable(ContactAddrWidths3_1);
	     	Table3_1.setWidthPercentage(80);
	     	Table3_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	     	Table3_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	     	Table3_1.addCell(new Phrase(new Chunk("Seq No: "+view_seller_nomination_to_customer_info.get("seq_no"),small_black_bold)));
	     	
   	     	float[] ContactAddrWidths3 = {0.100f};
	     	PdfPTable Table3 = new PdfPTable(ContactAddrWidths3);
	     	Table3.setWidthPercentage(80);
	     	Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	     	Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	     	Table3.addCell(new Phrase(new Chunk("Date: "+dateUtil.getSysdateWithTime24hr(),small_black_normal)));
	     	
	     	float[] ContactAddrWidths4 = {0.100f};
	     	PdfPTable Table4 = new PdfPTable(ContactAddrWidths4);
	     	Table4.setWidthPercentage(80);
	     	Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	     	Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	     	Table4.addCell(new Phrase(new Chunk("Subject: DLNG Seller Nomination for "+view_seller_nomination_to_customer_info.get("customer_abbr")+" "+view_seller_nomination_to_customer_info.get("plant_nm"),small_black_bold)));
	     	
	     	float[] ContactAddrWidths5 = {0.100f};
	     	PdfPTable Table5 = new PdfPTable(ContactAddrWidths5);
	     	Table5.setWidthPercentage(80);
	     	Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	     	Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	     	Table5.addCell(new Phrase(new Chunk("Dear Sir/Madam,\n\n"+view_seller_nomination_to_customer_info.get("emailBody")+"\n\n",small_black_normal)));
   	     	
   	     	float[] ContactAddrWidths6 = {0.100f};
   	     	PdfPTable Table6 = new PdfPTable(ContactAddrWidths6);
   	     	Table6.setWidthPercentage(80);
   	     	Table6.getDefaultCell().setBorder(Rectangle.BOX);
   			Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
   			Table6.addCell(new Phrase(new Chunk("DLNG SELLER NOMINATION ("+company_abbr+" - "+view_seller_nomination_to_customer_info.get("customer_abbr")+" : "+view_seller_nomination_to_customer_info.get("plant_nm")+")",header_black_bold)));
            
   	     	float[] ContactAddrWidths7 = {0.40f, 0.80f, 0.90f, 0.40f, 0.40f, 0.40f};
   	     	PdfPTable Table7 = new PdfPTable(ContactAddrWidths7);
   	     	Table7.setWidthPercentage(80);
   	     	Table7.setHorizontalAlignment(Element.ALIGN_CENTER);
	     	Table7.getDefaultCell().setBorder(Rectangle.TOP | Rectangle.RIGHT | Rectangle.LEFT);
	     	Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	     	Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
	     	Table7.addCell(new Phrase(new Chunk("Gas Day",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOX);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("Seller Nominated",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.BOX);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("Truck Confirmation",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.TOP | Rectangle.RIGHT | Rectangle.LEFT);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("Buyer Facility",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.TOP | Rectangle.RIGHT | Rectangle.LEFT);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("Check Post",black_bold)));
			Table7.getDefaultCell().setBorder(Rectangle.TOP | Rectangle.RIGHT | Rectangle.LEFT);
			Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7.addCell(new Phrase(new Chunk("Seller's Remark",black_bold)));
			
			float[] ContactAddrWidths7_1 = {0.40f, 0.40f, 0.40f, 0.30f, 0.30f, 0.30f, 0.40f, 0.40f, 0.40f};
			PdfPTable Table7_1 = new PdfPTable(ContactAddrWidths7_1);
			Table7_1.setWidthPercentage(80);
			Table7_1.setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7_1.getDefaultCell().setBorder(Rectangle.BOTTOM | Rectangle.RIGHT | Rectangle.LEFT);
			Table7_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7_1.addCell(new Phrase(new Chunk("",black_bold)));
			Table7_1.getDefaultCell().setBorder(Rectangle.BOX);
			Table7_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7_1.addCell(new Phrase(new Chunk("MMBTU",black_bold)));
			Table7_1.getDefaultCell().setBorder(Rectangle.BOX);
			Table7_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7_1.addCell(new Phrase(new Chunk("MT",black_bold)));
			Table7_1.getDefaultCell().setBorder(Rectangle.BOX);
			Table7_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7_1.addCell(new Phrase(new Chunk("Truck No",black_bold)));
			Table7_1.getDefaultCell().setBorder(Rectangle.BOX);
			Table7_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7_1.addCell(new Phrase(new Chunk("Scheduling Date",black_bold)));
			Table7_1.getDefaultCell().setBorder(Rectangle.BOX);
			Table7_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7_1.addCell(new Phrase(new Chunk("Scheduling Time",black_bold)));
			Table7_1.getDefaultCell().setBorder(Rectangle.BOTTOM | Rectangle.RIGHT | Rectangle.LEFT);
			Table7_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7_1.addCell(new Phrase(new Chunk("",black_bold)));
			Table7_1.getDefaultCell().setBorder(Rectangle.BOTTOM | Rectangle.RIGHT | Rectangle.LEFT);
			Table7_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7_1.addCell(new Phrase(new Chunk("",black_bold)));
			Table7_1.getDefaultCell().setBorder(Rectangle.BOTTOM | Rectangle.RIGHT | Rectangle.LEFT);
			Table7_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			Table7_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			Table7_1.addCell(new Phrase(new Chunk("",black_bold)));
			
			float[] ContactAddrWidths8 = {0.40f, 0.40f, 0.40f, 0.30f, 0.30f, 0.30f, 0.40f, 0.40f, 0.40f};
			PdfPTable Table8 = new PdfPTable(ContactAddrWidths8);
			Table8.setWidthPercentage(80);
			Table8.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			if(view_seller_nomination_to_customer_data.containsKey("v_gas_dt"))
			{
				HashMap transport_wise = (HashMap) view_seller_nomination_to_customer_data.get("v_gas_dt");
				int key_count=0;
			    for(int i=0; i<transport_wise.size();i++) 
			    {
			    	key_count+=1;
			    	
			    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
			    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			    	Table8.addCell(new Phrase(new Chunk(""+transport_wise.get(""+key_count),small_black_normal)));
			    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
			    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
			    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_seller_nomination_to_customer_data.get("v_mmbtu")).get(""+key_count),small_black_normal)));
			    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
			    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
			    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_seller_nomination_to_customer_data.get("v_mt")).get(""+key_count),small_black_normal)));
			    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
			    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_seller_nomination_to_customer_data.get("v_grid")).get(""+key_count),small_black_normal)));
			    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
			    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_seller_nomination_to_customer_data.get("v_nom_dt")).get(""+key_count),small_black_normal)));
			    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
			    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_seller_nomination_to_customer_data.get("v_nom_time")).get(""+key_count),small_black_normal)));
			    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
			    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_seller_nomination_to_customer_data.get("v_plant_abbr")).get(""+key_count),small_black_normal)));
			    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
			    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_seller_nomination_to_customer_data.get("v_checkpost")).get(""+key_count),small_black_normal)));
			    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
			    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_seller_nomination_to_customer_data.get("v_remark")).get(""+key_count),small_black_normal)));
			    }
			    Table8.getDefaultCell().setBorder(Rectangle.BOX);
		    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		    	Table8.addCell(new Phrase(new Chunk("Total ",black_bold)));
		    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
		    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_seller_nomination_to_customer_data.get("v_total")).get(""+key_count),small_black_normal)));
		    	Table8.getDefaultCell().setBorder(Rectangle.BOX);
		    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		    	Table8.addCell(new Phrase(new Chunk(""+((HashMap) view_seller_nomination_to_customer_data.get("v_total_mt")).get(""+key_count),small_black_normal)));
			    Table8.getDefaultCell().setBorder(Rectangle.BOTTOM | Rectangle.TOP);
		    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		    	Table8.addCell(new Phrase(new Chunk("",black_bold)));
		    	Table8.getDefaultCell().setBorder(Rectangle.BOTTOM | Rectangle.TOP);
		    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		    	Table8.addCell(new Phrase(new Chunk("",black_bold)));
		    	Table8.getDefaultCell().setBorder(Rectangle.BOTTOM | Rectangle.TOP);
		    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		    	Table8.addCell(new Phrase(new Chunk("",black_bold)));
		    	Table8.getDefaultCell().setBorder(Rectangle.BOTTOM | Rectangle.TOP);
		    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		    	Table8.addCell(new Phrase(new Chunk("",black_bold)));
		    	Table8.getDefaultCell().setBorder(Rectangle.BOTTOM | Rectangle.TOP);
		    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		    	Table8.addCell(new Phrase(new Chunk("",black_bold)));
		    	Table8.getDefaultCell().setBorder(Rectangle.BOTTOM | Rectangle.TOP | Rectangle.RIGHT);
		    	Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		    	Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		    	Table8.addCell(new Phrase(new Chunk("",black_bold)));
			}
						
			float[] SignatureInfoWidths = {0.30f, 0.20f, 0.20f, 0.30f};
			PdfPTable SignatureInfoTable = new PdfPTable(SignatureInfoWidths);
			SignatureInfoTable.setWidthPercentage(100);
			SignatureInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			if(!view_seller_nomination_to_customer_info.get("emp_ph_no").equals(""))
			{
				SignatureInfoTable.addCell(new Phrase(new Chunk(""+view_seller_nomination_to_customer_info.get("emp_nm")+"\n("+view_seller_nomination_to_customer_info.get("emp_ph_no")+")",small_black_normal)));
			}
			else
			{
				SignatureInfoTable.addCell(new Phrase(new Chunk(""+view_seller_nomination_to_customer_info.get("emp_nm"),small_black_normal)));
			}
			SignatureInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable.addCell(new Phrase(new Chunk(" ",small_black_normal)));
			SignatureInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable.addCell(new Phrase(new Chunk(" ",small_black_normal)));
			SignatureInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable.addCell(new Phrase(new Chunk(" ",small_black_normal)));
						
			PdfPTable SignatureInfoTable1 = new PdfPTable(SignatureInfoWidths);
			SignatureInfoTable1.setWidthPercentage(100);
			SignatureInfoTable1.getDefaultCell().setBorder(Rectangle.TOP);
			SignatureInfoTable1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable1.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable1.addCell(new Phrase(new Chunk("Authorised Signatory",small_black_normal)));
			SignatureInfoTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable1.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable1.addCell(new Phrase(new Chunk(" ",small_black_normal)));
			SignatureInfoTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable1.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable1.addCell(new Phrase(new Chunk(" ",small_black_normal)));
			SignatureInfoTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable1.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable1.addCell(new Phrase(new Chunk("",small_black_normal)));
			
			PdfPTable SignatureInfoTable2 = new PdfPTable(SignatureInfoWidths);
			SignatureInfoTable2.setWidthPercentage(100);
			SignatureInfoTable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable2.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable2.addCell(new Phrase(new Chunk(""+view_seller_nomination_to_customer_info.get("company_nm"),small_black_normal)));
			SignatureInfoTable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable2.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable2.addCell(new Phrase(new Chunk(" ",small_black_normal)));
			SignatureInfoTable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable2.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable2.addCell(new Phrase(new Chunk(" ",small_black_normal)));
			SignatureInfoTable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			SignatureInfoTable2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			SignatureInfoTable2.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			SignatureInfoTable2.addCell(new Phrase(new Chunk("",small_black_normal)));
			
   	     	document.add(Table1);
   	     	document.add(new Paragraph("              "));
   	     	document.add(Table1_1);
   	     	document.add(new Paragraph("              "));
   	     	document.add(Table2);
   	     	document.add(new Paragraph("              "));
   	     	document.add(Table3_1);
   	     	document.add(Table3);
   	     	document.add(new Paragraph("              "));
   	     	document.add(Table4);
   	     	document.add(new Paragraph("              "));
   	     	document.add(Table5);
   	     	document.add(new Paragraph("              "));
   	     	document.add(Table6);
   	     	document.add(new Paragraph("              "));
	     	document.add(Table7);
	     	document.add(Table7_1);
	     	document.add(Table8);
   	     	document.add(new Paragraph("              "));
   	     	document.add(new Paragraph("              "));
   	     	document.add(new Paragraph("              "));
	     	document.add(new Paragraph("              "));
   	     	document.add(SignatureInfoTable);
   	     	document.add(SignatureInfoTable1);
   	     	document.add(SignatureInfoTable2);
   	     	document.add(new Paragraph("              "));
   	     	float[] footer_1 = {0.100f};
	     	PdfPTable footer_tab_1 = new PdfPTable(footer_1);
	     	footer_tab_1.setWidthPercentage(100);
	     	footer_tab_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	     	footer_tab_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	     	footer_tab_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	     	footer_tab_1.addCell(new Phrase(new Chunk("Note: In case of late arrival of truck, kindly note that the Truck would be scheduled and accepted on the reasonable endeavour basis.",small_black_normal)));
	     	document.add(footer_tab_1);
   	     	document.add(new Paragraph("              "));
   	     	document.add(new Paragraph("              "));
   	     	float[] footer = {0.100f};
	     	PdfPTable footer_tab = new PdfPTable(footer);
	     	footer_tab.setWidthPercentage(100);
	     	footer_tab.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		   	footer_tab.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		   	footer_tab.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		   	footer_tab.addCell(new Phrase(new Chunk("*** This is Computer Generated Report and No Signature Required ***",small_black_normal)));

		    document.add(footer_tab);
		    document.close();
   	     	
   	     	int count=0;
			String query = "SELECT COUNT(*) "
					+ "FROM FMS_DAILY_SELLER_NOM_REMARK "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND AGMT_NO=? AND CONT_NO=? "
					+ "AND CONTRACT_TYPE=? AND PLANT_SEQ=? "
					+ "AND GAS_DT=TO_DATE(?,'DD/MM/YYYY') AND CARGO_NO=?";
			stmt = conn.prepareStatement(query);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, agmt_no);
			stmt.setString(4, cont_no);
			stmt.setString(5, contract_type);
			stmt.setString(6, plant_seq);
			stmt.setString(7, gas_dt);
			stmt.setString(8, cargo_no);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				count=rset.getInt(1);
			}
			rset.close();
			stmt.close();
			
			String seq_no="";
			String queryString4="SELECT NVL((SEQ_NO),'0') "
					+ "FROM FMS_DAILY_SELLER_NOM_REMARK A "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND CONT_NO=? AND AGMT_NO=? AND CONTRACT_TYPE=? "
					+ "AND PLANT_SEQ=? AND GAS_DT=TO_DATE(?,'DD/MM/YYYY') AND CARGO_NO=?";
			stmt4=conn.prepareStatement(queryString4);
			stmt4.setString(1, comp_cd);
			stmt4.setString(2, counterparty_cd);
			stmt4.setString(3, cont_no);
			stmt4.setString(4, agmt_no);
			stmt4.setString(5, contract_type);
			stmt4.setString(6, plant_seq);
			stmt4.setString(7, gas_dt);
			stmt4.setString(8, cargo_no);
			rset4=stmt4.executeQuery();
			if(rset4.next())
			{
				seq_no =""+(rset4.getInt(1)+1);
			}
			else
			{
				seq_no="1";
			}
			rset4.close();
			stmt4.close();
			
			if(count>0)
			{
				query="UPDATE FMS_DAILY_SELLER_NOM_REMARK SET ADDRESSED_TO=?,REMARK=?,MODIFIY_BY=?,MODIFIY_DT=SYSDATE,PDF_NM=?,EMAIL_SENT='N',SEQ_NO=? "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
						+ "AND AGMT_NO=? AND CONT_NO=? "
						+ "AND CONTRACT_TYPE=? AND PLANT_SEQ=? "
						+ "AND GAS_DT=TO_DATE(?,'DD/MM/YYYY') AND CARGO_NO=?";
				stmt1 = conn.prepareStatement(query);
				stmt1.setString(1, contact_person_cd);
				stmt1.setString(2, remark);
				stmt1.setString(3, emp_cd);
				stmt1.setString(4, file_nm);
				stmt1.setString(5, seq_no);
				stmt1.setString(6, comp_cd);
				stmt1.setString(7, counterparty_cd);
				stmt1.setString(8, agmt_no);
				stmt1.setString(9, cont_no);
				stmt1.setString(10, contract_type);
				stmt1.setString(11, plant_seq);
				stmt1.setString(12, gas_dt);
				stmt1.setString(13, cargo_no);
				stmt1.executeUpdate();
				
				stmt1.close();
			}
			else
			{
				query = "INSERT INTO FMS_DAILY_SELLER_NOM_REMARK(COMPANY_CD,COUNTERPARTY_CD,AGMT_NO,CONT_NO,CONTRACT_TYPE,PLANT_SEQ,"
						+ "GAS_DT,REMARK,ENT_DT,ENT_BY,CARGO_NO,ADDRESSED_TO,PDF_NM,EMAIL_SENT,SEQ_NO) "
						+ "VALUES(?,?,?,?,?,?,"
						+ "TO_DATE(?,'DD/MM/YYYY'),?,SYSDATE,?,?,?,?,'N',?)";
				stmt1 = conn.prepareStatement(query);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, counterparty_cd);
				stmt1.setString(3, agmt_no);
				stmt1.setString(4, cont_no);
				stmt1.setString(5, contract_type);
				stmt1.setString(6, plant_seq);
				stmt1.setString(7, gas_dt);
				stmt1.setString(8, remark);
				stmt1.setString(9, emp_cd);
				stmt1.setString(10, "0");
				stmt1.setString(11, contact_person_cd);
				stmt1.setString(12, file_nm);
				stmt1.setString(13, seq_no);
				//stmt1.setString(14, cargo_no);
				stmt1.executeUpdate();
				
				stmt1.close();
			}
			conn.commit();
			all_pdf_print="Y";
		}
		catch(Exception e)
		{	
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
		finally
		{
			document.close();
		}
	}

	public void printPdfFileForDLNGInvoice() throws SQLException
	{
		String function_nm="printPdfFileForDLNGInvoice()";
		
		String emp_nm ="";
		String ip = "";
		msg="";
		//String msg_content="";
		String path ="";
		String counterparty_abbr="";
		String invdtl="DLNG Sales";
		
		Rectangle pageSize = new Rectangle(595, 842);
		Rectangle pageSize1=new Rectangle(842,595);
		
		pageSize.setBackgroundColor(new BaseColor(0xffffff));
		pageSize1.setBackgroundColor(new BaseColor(0xffffff));
		
		Document document = new Document(pageSize);
		try
		{
			HttpSession session = request.getSession();
			emp_nm = (String)session.getAttribute("emp_nm")==null?"":(String)session.getAttribute("emp_nm");
			ip = (String)session.getAttribute("ip")==null?"":(String)session.getAttribute("ip");
			
			String company_nm = ""+session.getAttribute("comp_nm")==null?"":""+session.getAttribute("comp_nm");
			String company_abbr = ""+session.getAttribute("comp_abbr")==null?"":""+session.getAttribute("comp_abbr");
			String counterparty_nm=""+utilBean.getCounterpartyName(conn,counterparty_cd);
			counterparty_abbr=""+utilBean.getCounterpartyABBR(conn,counterparty_cd);
			
			int pdfGenCount=0;
			queryString="SELECT COUNT(*) "
					+ "FROM FMS_DLNG_INVOICE_MST A ,FMS_DLNG_INV_FILE_DTL B "
					+ "WHERE A.COMPANY_CD=? AND A.FINANCIAL_YEAR=? AND A.INVOICE_SEQ=? AND A.BU_STATE_TIN=? ";
			if(print_pdf_type.equals("O"))
			{
				queryString+= "AND A.PRINT_BY_ORI IS NOT NULL AND A.PRINT_DT_ORI IS NOT NULL ";
			}
			else if(print_pdf_type.equals("T"))
			{
				queryString+= "AND A.PRINT_BY_TRI IS NOT NULL AND A.PRINT_DT_TRI IS NOT NULL ";
			}
			else if(print_pdf_type.equals("D"))
			{
				queryString+= "AND A.PRINT_BY_DUP IS NOT NULL AND A.PRINT_DT_DUP IS NOT NULL ";
			}
			queryString+= "AND B.PDF_TYPE=? AND B.FILE_NAME IS NOT NULL "
					+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.BU_STATE_TIN=B.BU_STATE_TIN AND A.INVOICE_SEQ=B.INVOICE_SEQ "
    		  		+ "AND A.FINANCIAL_YEAR=B.FINANCIAL_YEAR";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, financial_year);
			stmt.setString(3, inv_seq);
			stmt.setString(4, bu_state_tin);
			stmt.setString(5, print_pdf_type);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				pdfGenCount=rset.getInt(1);
			}
			rset.close();
			stmt.close();
			
			String dealMap = utilBean.NewDealMappingId(comp_cd, counterparty_cd, agmt_no, agmt_rev_no, cont_no, cont_rev_no, contract_type, cargo_no);
            
			if(pdfGenCount>0)
			{
				msg="Failed! - "+invdtl+" Invoice for "+counterparty_abbr+" PDF for "+dealMap+" already Generated for "+period_end_dt+"!";
				msg_type="E";
			}
			else
			{
				String contRef="";
				String signingDt="";
				String agmtSigningDt="";
				String dcq="";
				String agmt_base="";
				String auto_pay_flag="";
				double mdcq_percentage=100;
				
				queryString="SELECT CONT_REF_NO,TO_CHAR(SIGNING_DT,'DD-MON-YY'),TRADE_REF_NO,DCQ,"
						+ "MDCQ_PERCENTAGE,AGMT_BASE,ADV_ADJUST  "
						+ "FROM FMS_SUPPLY_CONT_MST A "
						+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE=? "
						+ "AND CONT_NO=? AND AGMT_NO=? AND COUNTERPARTY_CD=? "
						+ "AND CONT_REV = (SELECT MAX(CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
						+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) ";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, contract_type);
				stmt.setString(3, cont_no);
				stmt.setString(4, agmt_no);
				stmt.setString(5, counterparty_cd);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					contRef=rset.getString(1)==null?"":rset.getString(1);
					signingDt=rset.getString(2)==null?"":rset.getString(2);
					
					String trade_ref=rset.getString(3)==null?"":rset.getString(3);
					if(contract_type.equals("W"))
					{
						contRef=trade_ref;
					}
					dcq=nf.format(rset.getDouble(4));
					mdcq_percentage=rset.getDouble(5);
					if(Double.doubleToRawLongBits(mdcq_percentage)==Double.doubleToRawLongBits(0))
					{
						mdcq_percentage=100;
					}
					agmt_base=rset.getString(6)==null?"":rset.getString(6);
					auto_pay_flag=rset.getString(7)==null?"":rset.getString(7);
				}
				rset.close();
				stmt.close();
				
				if(contract_type.equals("F"))
				{
					queryString="SELECT TO_CHAR(SIGNING_DT,'DD-MON-YY')  "
							+ "FROM FMS_AGMT_MST A "
							+ "WHERE COMPANY_CD=? AND AGMT_TYPE=? "
							+ "AND AGMT_NO=? AND COUNTERPARTY_CD=? "
							+ "AND AGMT_REV = (SELECT MAX(AGMT_REV) FROM FMS_AGMT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
							+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_TYPE=B.AGMT_TYPE) ";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(1, comp_cd);
					stmt.setString(2, "D");
					stmt.setString(3, agmt_no);
					stmt.setString(4, counterparty_cd);
					rset=stmt.executeQuery();
					if(rset.next())
					{
						agmtSigningDt=rset.getString(1)==null?"":rset.getString(1);
					}
					rset.close();
					stmt.close();
				}
				
				HashMap bu_plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "B", comp_cd, bu_plant_seq);
				String bu_plantAddress=""+bu_plant_detail.get("plant_address");
				String bu_plantCity=""+bu_plant_detail.get("plant_city");
				String bu_plantState=""+bu_plant_detail.get("plant_state");
				String bu_plantPin=""+bu_plant_detail.get("plant_pin");
				String bu_plantNm=""+bu_plant_detail.get("plant_name");
	
				HashMap plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "C", counterparty_cd, plant_seq);
				String plantAddress=""+plant_detail.get("plant_address");
				String plantCity=""+plant_detail.get("plant_city");
				String plantState=""+plant_detail.get("plant_state");
				String plantPin=""+plant_detail.get("plant_pin");
				
				String bu_contact_person_cd="";
				String contact_person_cd="";
				String invoice_dt="";
				String invoice_due_dt="";
				String remark_1="";
				String remark_2="";
				String qty_mmbtu="";
				String price="";
				String price_cd="";
				String gross_amt="";
				String exchang_rate_cd="";
				String exchang_rate_dt="";
				String exchang_rate="";
				String exchang_rate_type="";
				String gross_amt1="";
				String tax_amt="";
				String tax_struct_cd="";
				String tax_struct_dt="";
				String invoice_amt="";
				String net_payable="";
				String applicable_abbr="";
				String applicable_amt="";
				String TCS_factor="";
				String tax_struct_dtl="";
				String invoice_no="";
				String invoice_raised_in="";
				String temp_invoice_dt="";
				String transportation_charges = "";
				String transportation_amount = "";
				String gross_include_transport_tariff = "";
				String marketing_margin = "";
				String marketing_margin_amount = "";
				String other_charges = "";
				String other_charges_amount = "";
				String irn_no="";
				String qr_code="";
				String sug_qty="";
				String sug_percent="";
				boolean isGrossIncTriff=false;
				
				double netPayable=0;
				double tdsAmt=0;
				
				String temp_period_start_dt=period_start_dt;
				String temp_period_end_dt=period_end_dt;
				
				String cont_map=counterparty_cd+"-"+contract_type+"-"+agmt_no+"-%-"+cont_no+"-%";
				String exit_point="C-"+counterparty_cd+"-"+plant_seq;
				
				queryString="SELECT BU_CONTACT_PERSON_CD,CONTACT_PERSON_CD,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD-MON-YY'),"
						+ "TO_CHAR(DUE_DT,'DD-MON-YY'),TO_CHAR(PERIOD_START_DT,'DD-MON-YY'),TO_CHAR(PERIOD_END_DT,'DD-MON-YY'),REMARK_1,REMARK_2,"
						+ "ALLOC_QTY,SALE_PRICE,SALE_PRICE_UNIT,SALE_AMT,EXCHG_RATE_VALUE,GROSS_AMT,TAX_AMT,TAX_STRUCT_CD,TO_CHAR(TAX_EFF_DT,'DD/MM/YYYY'),"
						+ "INVOICE_AMT,NET_PAYABLE_AMT,TCS_TDS,TCS_AMT,TCS_FACTOR,CHECKED_FLAG,APPROVED_FLAG, "
						+ "INVOICE_ID_SEQ,INVOICE_RAISED_IN,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),NULL,NULL,EXCHG_RATE_CD,"
						+ "TO_CHAR(EXCHG_RATE_DT,'DD-MON-YY'),EXCHG_RATE_TYPE,TDS_GROSS_AMT "
						+ "FROM FMS_DLNG_INVOICE_MST "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? "
						+ "AND AGMT_NO=? AND PLANT_SEQ=? AND BU_UNIT=? AND CONTRACT_TYPE=? "
						+ "AND BU_STATE_TIN=? AND PERIOD_START_DT=TO_DATE(?,'DD/MM/YYYY') "
						+ "AND PERIOD_END_DT=TO_DATE(?,'DD/MM/YYYY') AND FINANCIAL_YEAR=? "
						+ "AND INVOICE_SEQ=? AND MAPPING_ID=? AND INV_FLAG=? AND TRUCK_TRANS_CD=? AND TRUCK_CD=? ";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty_cd);
				stmt.setString(3, cont_no);
				stmt.setString(4, agmt_no);
				stmt.setString(5, plant_seq);
				stmt.setString(6, bu_plant_seq);
				stmt.setString(7, contract_type);
				stmt.setString(8, bu_state_tin);
				stmt.setString(9, period_start_dt);
				stmt.setString(10, period_end_dt);
				stmt.setString(11, financial_year);
				stmt.setString(12, inv_seq);
				stmt.setString(13, mapping_id);
				stmt.setString(14, inv_flag);
				stmt.setString(15, truck_trans_cd);
				stmt.setString(16, truck_cd);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					bu_contact_person_cd=rset.getString(1)==null?"0":rset.getString(1);
					contact_person_cd=rset.getString(2)==null?"0":rset.getString(2);
					
					//invoice_id_seq=rset.getString(26)==null?"":rset.getString(26);
					invoice_no=rset.getString(3)==null?"":rset.getString(3);
					invoice_dt=rset.getString(4)==null?"":rset.getString(4);
					invoice_due_dt=rset.getString(5)==null?"":rset.getString(5);
					//inv_period_start_dt=rset.getString(6)==null?"":rset.getString(6);
					//inv_period_end_dt=rset.getString(7)==null?"":rset.getString(7);
					
					remark_1=rset.getString(8)==null?"":rset.getString(8);
					remark_2=rset.getString(9)==null?"":rset.getString(9);
					
					qty_mmbtu=nf.format(rset.getDouble(10));
					price_cd=rset.getString(12)==null?"":rset.getString(12);
					price=utilBean.RateNumberFormat(rset.getDouble(11), price_cd);
					gross_amt=nf.format(rset.getDouble(13));
					exchang_rate=nf2.format(rset.getDouble(14));
					gross_amt1=nf.format(rset.getDouble(15));
					tax_amt=nf.format(rset.getDouble(16));
					tax_struct_cd=rset.getString(17)==null?"":rset.getString(17);
					tax_struct_dt=rset.getString(18)==null?"":rset.getString(18);
					invoice_amt=nf.format(rset.getDouble(19));
					net_payable=nf.format(rset.getDouble(20));
					netPayable=rset.getDouble(20);
					applicable_abbr=rset.getString(21)==null?"":rset.getString(21);
					applicable_amt=nf.format(rset.getDouble(22));
					TCS_factor=nf3.format(rset.getDouble(23));
					
					invoice_raised_in=rset.getString(27)==null?"":rset.getString(27);
					temp_invoice_dt=rset.getString(28)==null?"":rset.getString(28);
					
					transportation_charges=rset.getString(29)==null?"":nf2.format(rset.getDouble(29));
					transportation_amount=rset.getString(30)==null?"":nf.format(rset.getDouble(30));
					
					exchang_rate_cd=rset.getString(31)==null?"":rset.getString(31);
					exchang_rate_dt=rset.getString(32)==null?"":rset.getString(32);
					exchang_rate_type=rset.getString(33)==null?"":rset.getString(33);
					
					tdsAmt=rset.getDouble(34);
					
					
					gross_include_transport_tariff=nf.format(Double.parseDouble(gross_amt1));
					
					tax_struct_dtl=utilBean.getTaxDescr(conn, tax_struct_cd);
				}
				rset.close();
				stmt.close();
				
				/*if(contract_type.equals("O") || contract_type.equals("Q"))
				{
					queryString1="SELECT IRN_NO,SIGN_QR_CODE "
							+ "FROM FMS_INVOICE_IRN_DTL "
							+ "WHERE COMPANY_CD=? AND INVOICE_NO=? ";
					stmt1=conn.prepareStatement(queryString1);
					stmt1.setString(1, comp_cd);
					stmt1.setString(2, invoice_no);
					rset1=stmt1.executeQuery();
					if(rset1.next())
					{
						irn_no=rset1.getString(1)==null?"":rset1.getString(1);
						qr_code=rset1.getString(2)==null?"":rset1.getString(2);
					}
					rset1.close();
					stmt1.close();
				}*/
				
				String contact_person_nm="";
				String bu_contact_person_nm="";
				
				queryString="SELECT CONTACT_PERSON "
						+ "FROM FMS_ENTITY_CONTACT_MST A "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
						+ "AND ENTITY=? AND SEQ_NO=? AND ADDR_FLAG=? "
						+ "AND TYPE=? "
						+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO "
						+ "AND EFF_DT <= TO_DATE(?,'DD/MM/YYYY') AND A.TYPE=B.TYPE)";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty_cd);
				stmt.setString(3, "C");
				stmt.setString(4, contact_person_cd);
				stmt.setString(5, "P"+plant_seq);
				stmt.setString(6, "DLNG");
				stmt.setString(7, temp_invoice_dt);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					contact_person_nm=rset.getString(1)==null?"":rset.getString(1);
				}
				rset.close();
				stmt.close();
				
				queryString="SELECT CONTACT_PERSON "
						+ "FROM FMS_ENTITY_CONTACT_MST A "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
						+ "AND ENTITY=? AND SEQ_NO=? AND ADDR_FLAG=? "
						+ "AND TYPE=?"
						+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO "
						+ "AND EFF_DT <= TO_DATE(?,'DD/MM/YYYY') AND A.TYPE=B.TYPE)";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, comp_cd);
				stmt.setString(3, "B");
				stmt.setString(4, bu_contact_person_cd);
				stmt.setString(5, "P"+bu_plant_seq);
				stmt.setString(6, "DLNG");
				stmt.setString(7, temp_invoice_dt);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					bu_contact_person_nm=rset.getString(1)==null?"":rset.getString(1);
				}
				rset.close();
				stmt.close();
	
				String print_pdf_type_nm="ORIGINAL";
				if(print_pdf_type.equals("O"))
				{
					print_pdf_type_nm="ORIGINAL";
				}
				else if(print_pdf_type.equals("D"))
				{
					print_pdf_type_nm="DUPLICATE";
				}
				else if(print_pdf_type.equals("T"))
				{
					print_pdf_type_nm="TRIPLICATE";
				}
	
				String appPath = request.getServletContext().getRealPath("");
	
				String main_folder="";
				if(!comp_cd.equals(""))
				{
					main_folder=CommonVariable.work_dir+comp_cd;
				}
				
				String sub_folder="unsigned_pdf";
				String sub_folder2="dlng_sales_invoice";
				String temp_path=appPath+File.separator+main_folder+File.separator+sub_folder+File.separator+sub_folder2;
				File main_folderDir = new File(temp_path);
		        if(!main_folderDir.exists())
		        {
		        	main_folderDir.mkdirs();
		        }
	
		        String monthofinv = dateUtil.getMonthNameMON(period_end_dt);
		        String dtPeriod="";
		        if(!period_start_dt.equals("") && !period_end_dt.equals(""))
		        {
		        	dtPeriod=period_start_dt.substring(0,2);
		        	dtPeriod+="-";
		        	dtPeriod+=period_end_dt.substring(0,2);
		        }
	
		        String contNm="";
		        String invNm="";
		        if(contract_type.equals("W"))
		        {
		        	contNm="DLNG-IGX";
		        	invNm="DLNG_INVOICE";
		        }
		        else if(contract_type.equals("E"))
		        {
		        	contNm="DLNG-LOA";
		        	invNm="DLNG_INVOICE";
		        }
		        else if(contract_type.equals("F"))
		        {
		        	contNm="DLNG-SN";
		        	invNm="DLNG_INVOICE";
		        }
		       
				//file_nm=print_pdf_type+"-"+company_abbr+"-"+invNm+"-"+contNm+""+bu_state_tin+"-"+inv_seq+"-"+counterparty_abbr+"_"+financial_year+"_"+monthofinv.trim()+"_"+dtPeriod+".pdf";
				file_nm=print_pdf_type+"-"+company_abbr+"-"+invNm+"-"+invoice_no.replace("/", "-")+".pdf";
				
				path = appPath+"/"+main_folder+"/"+sub_folder+"/"+sub_folder2+"/"+file_nm;
				PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream(path));
	
				document.open();
				document.setPageSize(pageSize);
	            document.newPage();
	
	            String context_nm = request.getContextPath();
				String server_nm = request.getServerName();
				String server_port = ""+request.getServerPort();
	
				file_url = CommonVariable.app_protocol+"://"+server_nm+":"+server_port+context_nm;
	
				Font small_black_normal = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
				Font small_black_normal_10 = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
				Font small_black_normal_14 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
				Font small_black_normal_12 = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL, BaseColor.BLACK);
	            Font small_black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
	            Font black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
	            Font black_bold1 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
	            
	            PdfPCell company_logo_cell = new PdfPCell();
	            if(!comp_logo.equals(""))
	            {
	            	String file_path = request.getRealPath("/"+CommonVariable.company_logo_path+"/"+comp_logo);
	            	Image company_logo = Image.getInstance(file_path);
		            company_logo.setBorder(Rectangle.NO_BORDER);
		            company_logo.scaleAbsolute(44,40);
		            company_logo_cell = new PdfPCell(company_logo,false);
		            company_logo_cell.setBorder(Rectangle.NO_BORDER);
		            company_logo_cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	            }
	            
	            float[] Contact1 = {0.50f};
	   	     	PdfPTable LogoTable = new PdfPTable(Contact1);
	   	     	LogoTable.setWidthPercentage(100);
	   	     	LogoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	LogoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	LogoTable.addCell(company_logo_cell);
	
				float[] ContactAddrWidths1 = {0.100f};
	   	     	PdfPTable HlplLogoTable = new PdfPTable(ContactAddrWidths1);
	            HlplLogoTable.setWidthPercentage(100);
	            HlplLogoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            HlplLogoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            HlplLogoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            HlplLogoTable.addCell(new Phrase(new Chunk(print_pdf_type_nm,small_black_normal_10)));
	
	            float[] ContactAddrWidths2 = {0.100f};
	   	     	PdfPTable Table = new PdfPTable(ContactAddrWidths2);
	            Table.setWidthPercentage(100);
	            Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table.addCell(new Phrase(new Chunk(company_nm,black_bold1)));
	
	            float[] ContactAddrWidths3 = {0.100f};
	   	     	PdfPTable Table1 = new PdfPTable(ContactAddrWidths3);
	            Table1.setWidthPercentage(100);
	            Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            if(bu_plantState.equals(plantState))
	            {
	            	Table1.addCell(new Phrase(new Chunk("TAX INVOICE",small_black_normal_12)));
	            }
	            else
	            {
	            	Table1.addCell(new Phrase(new Chunk("RETAIL INVOICE",small_black_normal_12)));
	            }
	            
	            period_start_dt=dateUtil.getDateFormatDD_MOM_YY(period_start_dt);
				period_end_dt=dateUtil.getDateFormatDD_MOM_YY(period_end_dt);
	
				String info ="In respect of "; 
				if(contract_type.equals("F")){
					info+="Supply Notice ("+contRef+") executed on "+signingDt+" pursuant to Framework LNG Sales Agreement executed on "+agmtSigningDt+"";
				}else if(contract_type.equals("E")){
					info+="Letter of Agreement ("+contRef+") executed on "+signingDt; 
				}else if(contract_type.equals("W")){ 
					info+="Exchange Transaction ("+contRef+") executed on "+signingDt;
				} 
				info+="\nbetween "+company_nm+" and "+counterparty_nm;
	
	            float[] ContactAddrWidths4 = {0.100f};
	   	     	PdfPTable Table2 = new PdfPTable(ContactAddrWidths4);
	            Table2.setWidthPercentage(100);
	            Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table2.addCell(new Phrase(new Chunk(info,small_black_normal)));
	
	            float[] ContactAddrWidths5 = {0.80f,0.10F,0.20F,0.80F};
	   	     	PdfPTable Table3 = new PdfPTable(ContactAddrWidths5);
	            Table3.setWidthPercentage(100);
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            //Table3.addCell(new Phrase(new Chunk("Business Unit: "+bu_plantNm,black_bold)));
	            Table3.addCell(new Phrase(new Chunk("Business Unit: ",black_bold)));
	            
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table3.addCell(new Phrase(new Chunk("",black_bold)));
	            
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table3.addCell(new Phrase(new Chunk("To:",black_bold)));
	
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table3.addCell(new Phrase(new Chunk(""+contact_person_nm+",",black_bold)));
	
	            
	
				float[] ContactAddrWidths6 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table4 = new PdfPTable(ContactAddrWidths6);
	            Table4.setWidthPercentage(100);
	            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table4.addCell(new Phrase(new Chunk(company_nm,small_black_normal)));
	            
	            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table4.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table4.addCell(new Phrase(new Chunk(counterparty_nm,small_black_normal)));
	
	            float[] ContactAddrWidths7 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table5 = new PdfPTable(ContactAddrWidths7);
	            Table5.setWidthPercentage(100);
	            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table5.addCell(new Phrase(new Chunk(bu_plantAddress+","+bu_plantCity,small_black_normal)));
	            
	            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table5.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
	            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table5.addCell(new Phrase(new Chunk(plantAddress+","+plantCity,small_black_normal)));
	            
	
	            float[] ContactAddrWidths8 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table6 = new PdfPTable(ContactAddrWidths8);
	            Table6.setWidthPercentage(100);
	            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table6.addCell(new Phrase(new Chunk(bu_plantState+" - "+bu_plantPin,small_black_normal)));
	
	            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table6.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
	            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table6.addCell(new Phrase(new Chunk(plantState+" - "+plantPin,small_black_normal)));
	
	            String tax_info="";
	            String bu_tax_info="";
				tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "C", counterparty_cd, plant_seq);
				bu_tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "B", comp_cd, bu_plant_seq);
				
	           float[] ContactAddrWidths9 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table7 = new PdfPTable(ContactAddrWidths9);
	            Table7.setWidthPercentage(100);
	            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table7.addCell(new Phrase(new Chunk(bu_tax_info,small_black_normal)));
	
	            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table7.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table7.addCell(new Phrase(new Chunk(tax_info,small_black_normal)));
	            
	            PdfPTable InvoiceDateInfoTable;
	            PdfPTable BillingPeriodInfoTable;
	            
	           /* float[] InvoiceDateInfoWidths_qr = {0.30f, 0.20f, 0.70f};
				PdfPTable InvoiceDateInfoTable_qr = new PdfPTable(InvoiceDateInfoWidths_qr);
				if(!irn_no.equals("") && !qr_code.equals("") && (contract_type.equals("Q") || contract_type.equals("O")))
				{
					float[] InvoiceDateInfoWidths = {0.60F,0.40F};
		            InvoiceDateInfoTable = new PdfPTable(InvoiceDateInfoWidths);
		            InvoiceDateInfoTable.setWidthPercentage(100);
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
					InvoiceDateInfoTable.addCell(new Phrase(new Chunk("Invoice Date :",black_bold)));
					InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
					InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(invoice_dt,black_bold)));
		            
		            //due date
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk("Payment Due Date :",black_bold)));
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(invoice_due_dt,black_bold)));
		            
		            //inv no
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(company_abbr+" TAX Invoice Seq No:",black_bold)));
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(invoice_no,black_bold)));
		            
		            float[] BillingPeriodInfoWidths = {0.30F,0.20F,0.10F,0.20F};
		            BillingPeriodInfoTable = new PdfPTable(BillingPeriodInfoWidths);
		            BillingPeriodInfoTable.setWidthPercentage(100);
		            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.addCell(new Phrase(new Chunk("Billing Period : ",black_bold)));
		            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.addCell(new Phrase(new Chunk(""+period_start_dt,black_bold)));
		            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            BillingPeriodInfoTable.addCell(new Phrase(new Chunk("to",black_bold)));
		            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.addCell(new Phrase(new Chunk(""+period_end_dt,black_bold)));
		            
		            if(!inv_flag.equals("UG") && !inv_flag.equals("ST"))
		            {
		            	InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            	InvoiceDateInfoTable.getDefaultCell().setColspan(3);
		            	InvoiceDateInfoTable.addCell(BillingPeriodInfoTable);
		            }
		               
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            InvoiceDateInfoTable.getDefaultCell().setColspan(3);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk("",small_black_bold)));
					
					int width=90;
					int height=90;
					Hashtable<EncodeHintType, ErrorCorrectionLevel> hintMap = new Hashtable<>();
			        hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
	
			        QRCodeWriter qrCodeWriter = new QRCodeWriter();
			        BitMatrix matrix = qrCodeWriter.encode(qr_code, BarcodeFormat.QR_CODE, width, height, hintMap);
	
			        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			        for (int x = 0; x < width; x++) 
			        {
			            for (int y = 0; y < height; y++) 
			            {
			                image.setRGB(x, y, matrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
			            }
			        }
			        
			        BufferedImage qrImage = image;
			        
			        ByteArrayOutputStream baos = new ByteArrayOutputStream();
			        ImageIO.write(qrImage, "png", baos);
			        Image qr_codeimg = Image.getInstance(baos.toByteArray());
					qr_codeimg.setBorder(Rectangle.NO_BORDER);
	                qr_codeimg.setAlignment(Element.ALIGN_LEFT);
	                PdfPCell qrcode_cell = new PdfPCell(qr_codeimg,false);
	                qrcode_cell.setBorder(Rectangle.NO_BORDER);
	                qrcode_cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	                
	                String char_16= irn_no.substring(0,16);
	                String char_32= irn_no.substring(16,32);
	                String char_48= irn_no.substring(32,48);
	                String char_64= irn_no.substring(48,irn_no.length());
	                String final_irn_no=char_16+"\n"+char_32+"\n"+char_48+"\n"+char_64;
	                
	                PdfPTable InvoiceDateInfoTable_qr1 = new PdfPTable(1);
	       	        InvoiceDateInfoTable_qr1.setWidthPercentage(100);
	       	        InvoiceDateInfoTable_qr1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	       	        InvoiceDateInfoTable_qr1.getDefaultCell().setBorder(Rectangle.BOX);
	       	        InvoiceDateInfoTable_qr1.addCell(qrcode_cell);
	       	        
	       	        PdfPTable InvoiceDateInfoTable_qr11 = new PdfPTable(1);
	    	        InvoiceDateInfoTable_qr11.setWidthPercentage(100);
	    	        InvoiceDateInfoTable_qr11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	    	        InvoiceDateInfoTable_qr11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	    	        InvoiceDateInfoTable_qr11.addCell(new Phrase(new Chunk("IRN",black_bold)));
	    	        InvoiceDateInfoTable_qr11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	    	        InvoiceDateInfoTable_qr11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	    	        InvoiceDateInfoTable_qr11.addCell(new Phrase(new Chunk(final_irn_no,small_black_normal)));
	    	        
	    	        InvoiceDateInfoTable_qr.setWidthPercentage(100);
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	       	        InvoiceDateInfoTable_qr.addCell(InvoiceDateInfoTable_qr1);
	       	        
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setBorder(Rectangle.BOX);
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	       	        InvoiceDateInfoTable_qr.addCell(InvoiceDateInfoTable_qr11);
	       	        
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	       	        InvoiceDateInfoTable_qr.addCell(InvoiceDateInfoTable);
				}*/
	
	            float[] ContactAddrWidths10 = {0.80F,0.30F,0.30F,0.40F};
	   	     	PdfPTable Table8 = new PdfPTable(ContactAddrWidths10);
	            Table8.setWidthPercentage(100);
	            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table8.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table8.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table8.addCell(new Phrase(new Chunk("Invoice Date :",black_bold)));
	
	            Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            //Table8.addCell(new Phrase(new Chunk(dateUtil.getDateFormatDD_MOM_YY(invoice_dt),small_black_normal)));
	            Table8.addCell(new Phrase(new Chunk(invoice_dt,black_bold)));
	
	            float[] ContactAddrWidths11 = {0.80F,0.30F,0.30F,0.40F};
	   	     	PdfPTable Table9 = new PdfPTable(ContactAddrWidths11);
	            Table9.setWidthPercentage(100);
	            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table9.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table9.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table9.addCell(new Phrase(new Chunk("Payment Due Date :",black_bold)));
	
	            Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            //Table9.addCell(new Phrase(new Chunk(dateUtil.getDateFormatDD_MOM_YY(invoice_due_dt),small_black_normal)));
	            Table9.addCell(new Phrase(new Chunk(invoice_due_dt,black_bold)));
	
	            float[] ContactAddrWidths12 = {0.80F,0.10F,0.50F,0.40F};
	   	     	PdfPTable Table10 = new PdfPTable(ContactAddrWidths12);
	            Table10.setWidthPercentage(100);
	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk(company_abbr+" Invoice Seq No:",black_bold)));
	
	            Table10.getDefaultCell().setBorder(Rectangle.BOX);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk(invoice_no,black_bold)));
	
	            /*float[] ContactAddrWidths12_1 = {0.80F,0.20F,0.10F,0.20F};
	   	     	PdfPTable Table10_1 = new PdfPTable(ContactAddrWidths12_1);
	   	     	Table10_1.setWidthPercentage(100);
	            Table10_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.addCell(new Phrase(new Chunk("Billing Period : ",black_bold)));
	
	            Table10_1.getDefaultCell().setBorder(Rectangle.BOX);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.addCell(new Phrase(new Chunk(""+period_start_dt,black_bold)));
	
	            Table10_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table10_1.addCell(new Phrase(new Chunk("to",black_bold)));
	
	            Table10_1.getDefaultCell().setBorder(Rectangle.BOX);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.addCell(new Phrase(new Chunk(""+period_end_dt,black_bold)));
	            */
	
	            float[] ContactAddrWidths13 = {0.12F,0.60F,0.20F,0.20F,0.20F,0.20F};
	   	     	PdfPTable Table11 = new PdfPTable(ContactAddrWidths13);
	            Table11.setWidthPercentage(100);
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Sr.No.",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Item Description",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Currency",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Quantity\n(MMBTU)",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Rate",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Amount",small_black_bold)));
	
	            String salesValue="";
	            salesValue=""+gross_amt;
	
	            String curr="";
	            String curr1="";
	            if(price_cd.equals("1"))
	            {
	            	curr="INR";
	            }
	            else if(price_cd.equals("2"))
	            {
	            	curr="USD";
	            }
	
	            if(invoice_raised_in.equals("1"))
	            {
	            	curr1="INR";
	            }
	            else if(invoice_raised_in.equals("2"))
	            {
	            	curr1="USD";
	            }
	
	            int sr=1;
	
	            //float[] ContactAddrWidths14 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	//PdfPTable Table12 = new PdfPTable(ContactAddrWidths14);
	            //Table12.setWidthPercentage(100);
	            //Table12.getDefaultCell().setBorderWidthBottom(0);
	                      	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table11.addCell(new Phrase(new Chunk("LNG Delivered",small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk(""+curr,small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk(qty_mmbtu,small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk(price,small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk(""+salesValue,small_black_normal)));
	
	            if(!invoice_raised_in.equals(price_cd))
	            {
	            	sr+=1;
		            //float[] ContactAddrWidths15 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
		   	     	//PdfPTable Table13 = new PdfPTable(ContactAddrWidths15);
		            //Table13.setWidthPercentage(100);
		            //Table13.getDefaultCell().setBorderWidthTop(0);
		
		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
		
		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		            Table11.addCell(new Phrase(new Chunk("Exchange Rate",small_black_normal)));
		
		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table11.addCell(new Phrase(new Chunk("INR/USD",small_black_normal)));
		
		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
		
		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            Table11.addCell(new Phrase(new Chunk(exchang_rate,small_black_normal)));
		
		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	            }
	
	            sr+=1;
	   	     	//float[] ContactAddrWidths16 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	//PdfPTable Table14 = new PdfPTable(ContactAddrWidths16);
	            //Table14.setWidthPercentage(100);
	            //Table14.getDefaultCell().setBorderWidthBottom(0);
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table11.addCell(new Phrase(new Chunk("Gross Amount",small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk(gross_amt1,small_black_normal)));
	            
	            //float[] ContactAddrWidths26 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	    	    //PdfPTable Table24 = new PdfPTable(ContactAddrWidths26);
	    	    
	    	    //float[] ContactAddrWidths27 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	    	    //PdfPTable Table25 = new PdfPTable(ContactAddrWidths27);
	    	    
	            //if(agmt_base.equals("D"))
	    	    if(!transportation_charges.equals(""))
	            {
	    	    	if(Double.parseDouble(transportation_amount) > 0)
	    	    	{
		            	sr+=1;
		            	
		        	    Table11.setWidthPercentage(100);
		                 
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		        	    Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
		
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		        	    Table11.addCell(new Phrase(new Chunk("Transporation Tariff",small_black_normal)));
		
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		        	    Table11.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
		
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
		
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.addCell(new Phrase(new Chunk(transportation_charges,small_black_normal)));
		
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.addCell(new Phrase(new Chunk(transportation_amount,small_black_normal)));
	    	    	}
	            }
	            
	            if(!marketing_margin.equals(""))
	            {
	            	if(Double.parseDouble(marketing_margin) > 0)
	            	{
		            	sr+=1;
		            	
		        	    Table11.setWidthPercentage(100);
		                 
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		        	    Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
		
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		        	    Table11.addCell(new Phrase(new Chunk("Marketing Margin",small_black_normal)));
		
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		        	    Table11.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
		
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
		
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.addCell(new Phrase(new Chunk(marketing_margin,small_black_normal)));
		
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.addCell(new Phrase(new Chunk(marketing_margin_amount,small_black_normal)));
	            	}
	            }
	            
	            if(!other_charges.equals(""))
	            {
	            	if(Double.parseDouble(other_charges_amount) > 0)
	            	{
		            	sr+=1;
		            	
		        	    Table11.setWidthPercentage(100);
		                 
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		        	    Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
		
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		        	    Table11.addCell(new Phrase(new Chunk("Other Charges",small_black_normal)));
		
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		        	    Table11.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
		
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
		
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.addCell(new Phrase(new Chunk(other_charges,small_black_normal)));
		
		        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
		        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		        	    Table11.addCell(new Phrase(new Chunk(other_charges_amount,small_black_normal)));
	            	}
	            }
	            
	            if(isGrossIncTriff)
	            {
	            	sr+=1;
	            	
	        	    Table11.setWidthPercentage(100);
	                 
	        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
	        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	        	    Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
	        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	        	    Table11.addCell(new Phrase(new Chunk("Total Gross Amount",small_black_normal)));
	
	        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
	        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	        	    Table11.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
	        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
	        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
	        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	        	    Table11.addCell(new Phrase(new Chunk(gross_include_transport_tariff,small_black_normal)));
	            }
	
	            sr+=1;
	            //float[] ContactAddrWidths17 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	//PdfPTable Table15 = new PdfPTable(ContactAddrWidths17);
	   	     	/*if(!contract_type.equals("I")) {
	   	     	Table15.getDefaultCell().setBorderWidthTop(0);
	   	     	}else {
	   	     	Table15.getDefaultCell().setBorderWidthTop(0);
	   	     	Table15.getDefaultCell().setBorderWidthBottom(0);
	   	     	}*/
	
	   	     	Table11.setWidthPercentage(100);
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table11.addCell(new Phrase(new Chunk("Tax ("+tax_struct_dtl+")",small_black_normal)));
	            
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk(tax_amt,small_black_normal)));
	            
	            queryString1="SELECT COUNT(*) "
						+ "FROM FMS_DLNG_INV_TAX_DTL "
						+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
						+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
	            stmt1=conn.prepareStatement(queryString1);
	            stmt1.setString(1, comp_cd);
	            stmt1.setString(2, bu_state_tin);
	            stmt1.setString(3, financial_year);
	            stmt1.setString(4, inv_seq);
	            rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					if(rset1.getInt(1)>1)
					{
						double temp_srno=sr;
						queryString="SELECT TAX_CODE,TAX_DESCR,TAX_AMT,TAX_BASE_AMT "
								+ "FROM FMS_DLNG_INV_TAX_DTL "
								+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
								+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
						stmt=conn.prepareStatement(queryString);
			            stmt.setString(1, comp_cd);
			            stmt.setString(2, bu_state_tin);
			            stmt.setString(3, financial_year);
			            stmt.setString(4, inv_seq);
			            rset=stmt.executeQuery();
						while(rset.next())
						{
							temp_srno=temp_srno+0.1;
							
							String tax_descr=rset.getString(2)==null?"":rset.getString(2);
							String taxAmt=rset.getString(3)==null?"":nf.format(rset.getDouble(3));
							
							Table11.setWidthPercentage(100);
				            Table11.getDefaultCell().setBorder(Rectangle.BOX);
				            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				            Table11.addCell(new Phrase(new Chunk(""+nf0.format(temp_srno),small_black_normal)));
	
				            Table11.getDefaultCell().setBorder(Rectangle.BOX);
				            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				            Table11.addCell(new Phrase(new Chunk(""+tax_descr+"",small_black_normal)));
				            
				            Table11.getDefaultCell().setBorder(Rectangle.BOX);
				            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				            Table11.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
				            Table11.getDefaultCell().setBorder(Rectangle.BOX);
				            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
				            Table11.getDefaultCell().setBorder(Rectangle.BOX);
				            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
				            Table11.getDefaultCell().setBorder(Rectangle.BOX);
				            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
				            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
				            Table11.addCell(new Phrase(new Chunk(taxAmt,small_black_normal)));
						}
						rset.close();
						stmt.close();
					}
				}
				rset1.close();
				stmt1.close();
				
	            
				String invAmtLbl="Invoice Amount";
	            sr+=1;
	            //float[] ContactAddrWidths18 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	//PdfPTable Table16 = new PdfPTable(ContactAddrWidths18);
	   	     	//Table16.getDefaultCell().setBorderWidthBottom(0);
	
	   	     	Table11.setWidthPercentage(100);
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table11.addCell(new Phrase(new Chunk(invAmtLbl,small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk(invoice_amt,small_black_normal)));
	            
	            if(applicable_abbr.equals("TCS"))
	            {
	            	sr+=1;
	            	
	            	Table11.setWidthPercentage(100);
	                Table11.getDefaultCell().setBorder(Rectangle.BOX);
	                Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	                Table11.getDefaultCell().setBorder(Rectangle.BOX);
	                Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	                Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	                Table11.addCell(new Phrase(new Chunk("TCS",small_black_normal)));
	
	                Table11.getDefaultCell().setBorder(Rectangle.BOX);
	                Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table11.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	                Table11.getDefaultCell().setBorder(Rectangle.BOX);
	                Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	                Table11.getDefaultCell().setBorder(Rectangle.BOX);
	                Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table11.addCell(new Phrase(new Chunk(TCS_factor+"%",small_black_normal)));
	
	                Table11.getDefaultCell().setBorder(Rectangle.BOX);
	                Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table11.addCell(new Phrase(new Chunk(applicable_amt,small_black_normal)));
	            }
	            
	            sr+=1;
	            //float[] ContactAddrWidths20 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	//PdfPTable Table18 = new PdfPTable(ContactAddrWidths20);
	
	   	     	Table11.setWidthPercentage(100);
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk(""+sr,black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table11.addCell(new Phrase(new Chunk("Net Amount Payable",black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk(""+curr1,black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk("",black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk("",black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk(net_payable,black_bold)));
	
	            float[] ContactAddrWidths21 = {0.100F};
	   	     	PdfPTable Table19 = new PdfPTable(ContactAddrWidths21);
	   	     	Table19.setWidthPercentage(100);
	   	     	Table19.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	Table19.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	Table19.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	     	Table19.addCell(new Phrase(new Chunk(remark_1,small_black_normal)));
	
	   	     	float[] ContactAddrWidths22 = {0.100F};
		     	PdfPTable Table20 = new PdfPTable(ContactAddrWidths22);
		     	Table20.setWidthPercentage(100);
		     	Table20.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		     	Table20.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		     	Table20.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		     	Table20.addCell(new Phrase(new Chunk(remark_2,small_black_normal)));
		     	
		     	float[] ContactAddrWidths23 = {0.100F};
	   	     	PdfPTable Table21 = new PdfPTable(ContactAddrWidths21);
	   	     	Table21.setWidthPercentage(100);
	   	     	Table21.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	Table21.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	  		Table21.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	  		Table21.addCell(new Phrase(new Chunk("For "+company_nm,black_bold)));
	   	  		
	   	  		// create a signature form field
	   	     	PdfPTable BillingFieldsInfoTable81 = new PdfPTable(1);
	   	     	BillingFieldsInfoTable81.setWidthPercentage(20);
	   	     	BillingFieldsInfoTable81.setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	BillingFieldsInfoTable81.getDefaultCell().setBorder(Rectangle.BOX);
	   	     	BillingFieldsInfoTable81.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	BillingFieldsInfoTable81.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	        
	   	     	PdfFormField field = PdfFormField.createSignature(writer);
	   	     	field.setFieldName(SIGNAME);
	   	     	// set the widget properties
	   	     	field.setPage();
	   	     	field.setWidget(new Rectangle(72, 732, 144, 780), PdfAnnotation.HIGHLIGHT_NONE);
	   	     	field.setFlags(PdfAnnotation.FLAGS_PRINT);
	   	     	writer.addAnnotation(field);
	         
	   	     	PdfPCell sigCell = new PdfPCell();
	   	     	FieldPositioningEvents events = new FieldPositioningEvents(writer, field);
	   	     	sigCell.setCellEvent(events);
	   	     	sigCell.setFixedHeight(50f);
	   	     	BillingFieldsInfoTable81.addCell(sigCell);
	
	   	     	float[] ContactAddrWidths24 = {0.100F};
		     	PdfPTable Table22 = new PdfPTable(ContactAddrWidths22);
	
		     	Table22.setWidthPercentage(100);
		     	Table22.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		     	Table22.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		     	Table22.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		     	Table22.addCell(new Phrase(new Chunk("Authorised Signatory",black_bold)));
		     	
		     	document.add(LogoTable);
				document.add(HlplLogoTable);
				document.add(Table);
				document.add(Table1);
				document.add(Table2);
				document.add(new Paragraph("  "));
				document.add(Table3);
				document.add(Table4);
				document.add(Table5);
				document.add(Table6);
				document.add(Table7);
				document.add(new Paragraph("  "));
				document.add(new Paragraph("  "));
				/*if(!irn_no.equals("") && !qr_code.equals("") && (contract_type.equals("Q") || contract_type.equals("O")))
				{
					document.add(InvoiceDateInfoTable_qr);
				}
				else*/
				{
					document.add(Table8);
					document.add(Table9);
					document.add(Table10);
					/*if(!inv_flag.equals("UG") && !inv_flag.equals("ST"))
		            {
						document.add(Table10_1);
		            }*/
				}
				document.add(new Paragraph("  "));
				document.add(Table11);
				document.add(new Paragraph("  "));
				document.add(Table19);
				document.add(Table20);
				document.add(new Paragraph("  "));
				document.add(new Paragraph("  "));
				document.add(Table21);
				document.add(BillingFieldsInfoTable81);
				document.add(Table22);
				
	            document.close();
	            
	            File isPDFexist = new File(path);
				if(isPDFexist.exists())
				{
					String invoice_title="";
					int update_flag=0;
					int pdf_entry=0;
					
					int cont=0;
					queryString="UPDATE FMS_DLNG_INVOICE_MST SET PDF_INV_DTL=? ";
						if(print_pdf_type.equals("O"))
						{
							queryString+= ",PRINT_BY_ORI=?,PRINT_DT_ORI=SYSDATE ";
						}
						else if(print_pdf_type.equals("T"))
						{
							queryString+= ",PRINT_BY_TRI=?,PRINT_DT_TRI=SYSDATE ";
						}
						else if(print_pdf_type.equals("D"))
						{
							queryString+= ",PRINT_BY_DUP=?,PRINT_DT_DUP=SYSDATE ";
						}
						queryString+= "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? "
							+ "AND AGMT_NO=? AND PLANT_SEQ=? AND BU_UNIT=? AND CONTRACT_TYPE=? "
							+ "AND PERIOD_START_DT=TO_DATE(?,'DD/MM/YYYY') AND PERIOD_END_DT=TO_DATE(?,'DD/MM/YYYY') "
							+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? AND MAPPING_ID=? AND INV_FLAG=? AND TRUCK_TRANS_CD=? AND TRUCK_CD=? ";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(++cont, print_pdf_type);
					if(print_pdf_type.equals("O"))
					{
						stmt.setString(++cont, emp_cd);
					}
					else if(print_pdf_type.equals("T"))
					{
						stmt.setString(++cont, emp_cd);
					}
					else if(print_pdf_type.equals("D"))
					{
						stmt.setString(++cont, emp_cd);
					}
					stmt.setString(++cont, comp_cd);
					stmt.setString(++cont, counterparty_cd);
					stmt.setString(++cont, cont_no);
					stmt.setString(++cont, agmt_no);
					stmt.setString(++cont, plant_seq);
					stmt.setString(++cont, bu_plant_seq);
					stmt.setString(++cont, contract_type);
					stmt.setString(++cont, temp_period_start_dt);
					stmt.setString(++cont, temp_period_end_dt);
					stmt.setString(++cont, financial_year);
					stmt.setString(++cont, inv_seq);
					stmt.setString(++cont, bu_state_tin);
					stmt.setString(++cont, mapping_id);
					stmt.setString(++cont, inv_flag);
					stmt.setString(++cont, truck_trans_cd);
					stmt.setString(++cont, truck_cd);
					update_flag=stmt.executeUpdate();
					stmt.close();
					
					int count=0;
			        queryString1="SELECT COUNT(*) "
			        		+ "FROM FMS_DLNG_INV_FILE_DTL "
			        		+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
			        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE=?";
			        stmt1=conn.prepareStatement(queryString1);
			        stmt1.setString(1, comp_cd);
			        stmt1.setString(2, bu_state_tin);
			        stmt1.setString(3, inv_seq);
			        stmt1.setString(4, financial_year);
			        stmt1.setString(5, print_pdf_type);
			        rset1=stmt1.executeQuery();
			        if(rset1.next())
			        {
			        	count=rset1.getInt(1);
			        }
			        rset1.close();
			        stmt1.close();
			        
			        if(count > 0)
			        {
			        	queryString1="UPDATE FMS_DLNG_INV_FILE_DTL SET FILE_NAME=?,MODIFY_BY=?,MODIFY_DT=SYSDATE "
			        			+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
				        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE=?";
			        	stmt1=conn.prepareStatement(queryString1);
			        	stmt1.setString(1, file_nm);
			        	stmt1.setString(2, emp_cd);
			        	stmt1.setString(3, comp_cd);
			 	        stmt1.setString(4, bu_state_tin);
			 	        stmt1.setString(5, inv_seq);
			 	        stmt1.setString(6, financial_year);
			 	        stmt1.setString(7, print_pdf_type);
			 	        pdf_entry=stmt1.executeUpdate();
			        	
			        	stmt1.close();
			        }
			        else
			        {
			        	queryString1="INSERT INTO FMS_DLNG_INV_FILE_DTL(COMPANY_CD,BU_STATE_TIN,INVOICE_SEQ,FINANCIAL_YEAR,PDF_TYPE,"
			        			+ "FILE_NAME,ENT_BY,ENT_DT) "
			        			+ "VALUES(?,?,?,?,?,"
			        			+ "?,?,SYSDATE)";
			        	stmt1=conn.prepareStatement(queryString1);
			        	stmt1.setString(1, comp_cd);
			 	        stmt1.setString(2, bu_state_tin);
			 	        stmt1.setString(3, inv_seq);
			 	        stmt1.setString(4, financial_year);
			 	        stmt1.setString(5, print_pdf_type);
			 	        stmt1.setString(6, file_nm);
			        	stmt1.setString(7, emp_cd);
			        	pdf_entry=stmt1.executeUpdate();
			        	
			        	stmt1.close();
			        }
			        
			        
			        String tempRePrintMsg="";
			        String re_printFlag="";
			        String re_print_Seq_No="";
			        queryString2="SELECT FLAG,SEQ_NO "
			        		+ "FROM FMS_INVOICE_CHANGE_DTL A "
			        		+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
							+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND SEGMENT=? AND CHANGE_TYPE=? "
							+ "AND SEQ_NO=(SELECT MAX(B.SEQ_NO) FROM FMS_INVOICE_CHANGE_DTL B WHERE A.COMPANY_CD=B.COMPANY_CD "
							+ "AND A.BU_STATE_TIN=B.BU_STATE_TIN AND A.INVOICE_SEQ=B.INVOICE_SEQ AND A.FINANCIAL_YEAR=B.FINANCIAL_YEAR "
							+ "AND A.SEGMENT=B.SEGMENT AND A.CHANGE_TYPE=B.CHANGE_TYPE)";
			        stmt2=conn.prepareStatement(queryString2);
			        stmt2.setString(1, comp_cd);
			        stmt2.setString(2, bu_state_tin);
			        stmt2.setString(3, inv_seq);
			        stmt2.setString(4, financial_year);
			        stmt2.setString(5, "DLNG");
			        stmt2.setString(6, "REPRINT_PDF");
			        rset2=stmt2.executeQuery();
			        if(rset2.next())
			        {
			        	re_printFlag=rset2.getString(1)==null?"":rset2.getString(1);
			        	re_print_Seq_No=rset2.getString(2)==null?"":rset2.getString(2);
			        }
			        rset2.close();
			        stmt2.close();
			        
			        if(re_printFlag.equals("A"))
			        {
			        	tempRePrintMsg="Re-Printed ";
			        	int reprint_pdf_count=0;
			        	queryString2="SELECT COUNT(*) "
				        		+ "FROM FMS_DLNG_INV_FILE_DTL "
				        		+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
				        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE IN ('O','D','T')";
				        stmt2=conn.prepareStatement(queryString2);
				        stmt2.setString(1, comp_cd);
				        stmt2.setString(2, bu_state_tin);
				        stmt2.setString(3, inv_seq);
				        stmt2.setString(4, financial_year);
				        rset2=stmt2.executeQuery();
				        if(rset2.next())
				        {
				        	reprint_pdf_count=rset2.getInt(1);
				        }
				        rset2.close();
				        stmt2.close();
				        
				        if(reprint_pdf_count==3)
				        {
				        	queryString2="UPDATE FMS_INVOICE_CHANGE_DTL SET FLAG=? "
				    				+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
									+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
									+ "AND SEGMENT=? AND CHANGE_TYPE=? AND FLAG=? AND SEQ_NO=? ";
				    		stmt2=conn.prepareStatement(queryString2);
				    		stmt2.setString(1, "P");
					        stmt2.setString(2, comp_cd);
					        stmt2.setString(3, bu_state_tin);
					        stmt2.setString(4, inv_seq);
					        stmt2.setString(5, financial_year);
					        stmt2.setString(6, "DLNG");
					        stmt2.setString(7, "REPRINT_PDF");
					        stmt2.setString(8, re_printFlag);
					        stmt2.setString(9, re_print_Seq_No);
					        stmt2.executeUpdate();
							
							stmt2.close();
				        }
			        }
			        
			        if(re_printFlag.equals(""))
			        {
				     	if(update_flag > 0 && pdf_entry > 0 && print_pdf_type.equals("O") && !contract_type.equals("W"))
				        {	
				        	double hold_amt=utilBean.getInvoiceHoldAmount(conn,comp_cd,counterparty_cd,agmt_no,cont_no,contract_type,plant_seq,bu_plant_seq, 
									temp_period_end_dt,tax_struct_dtl,gross_amt1,bu_state_tin,temp_invoice_dt);
				        	if(hold_amt > 0)
				        	{
				        		queryString="UPDATE FMS_DLNG_INVOICE_MST SET HOLD_AMT=? "
									+ "WHERE COMPANY_CD=? AND FINANCIAL_YEAR=? "
									+ "AND INVOICE_SEQ=? AND BU_STATE_TIN=? ";
				        		cont=0;
								stmt=conn.prepareStatement(queryString);
								stmt.setString(++cont, nf.format(hold_amt));
								stmt.setString(++cont, comp_cd);
								stmt.setString(++cont, financial_year);
								stmt.setString(++cont, inv_seq);
								stmt.setString(++cont, bu_state_tin);
								stmt.executeUpdate();
								stmt.close();
				        	}
				        	
				        	if(auto_pay_flag.equals("Y"))
				        	{
					        	double tot_Adv_amt=utilBean.getAdvanceAmount(conn,comp_cd, counterparty_cd, agmt_no, cont_no, contract_type, "K", dateUtil.getSysdate());
					        	
					        	if(tot_Adv_amt>0)
					        	{
					        		netPayable=netPayable-tdsAmt;
						        	double short_received = netPayable;
						        	
						        	String payRecvAmt="";
						        	if(tot_Adv_amt >= short_received && tot_Adv_amt > 0)
						        	{
						        		payRecvAmt=nf.format(short_received);
						        	}
						        	else if(tot_Adv_amt < short_received && tot_Adv_amt > 0)
						        	{
						        		payRecvAmt=nf.format(tot_Adv_amt);
						        	}
						        	
						        	if(!payRecvAmt.equals(""))
						        	{	
							        	String remark="Auto Paid";
							        	queryString="UPDATE FMS_DLNG_INVOICE_MST SET PAY_RECV_AMT=?,"
												+ "PAY_RECV_DT=TO_DATE(?,'DD/MM/YYYY'),PAY_INSERT_BY=?,PAY_INSERT_DT=SYSDATE,"
												+ "PAY_REMARK=? "
												+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? "
												+ "AND AGMT_NO=? AND CONTRACT_TYPE=? AND INVOICE_SEQ=? "
												+ "AND BU_STATE_TIN=? AND FINANCIAL_YEAR=? ";
										stmt = conn.prepareStatement(queryString);
										stmt.setString(1, payRecvAmt);
										stmt.setString(2, temp_invoice_dt);
										stmt.setString(3, emp_cd);
										stmt.setString(4, remark);
										stmt.setString(5, comp_cd);
										stmt.setString(6, counterparty_cd);
										stmt.setString(7, cont_no);
										stmt.setString(8, agmt_no);
										stmt.setString(9, contract_type);
										stmt.setString(10, inv_seq);
										stmt.setString(11, bu_state_tin);
										stmt.setString(12, financial_year);
										stmt.executeUpdate();
										stmt.close();
										
										queryString1="SELECT NVL(MAX(SEQ_NO),0) "
												+ "FROM FMS_DLNG_INV_PAY_RECV_DTL "
												+ "WHERE COMPANY_CD=? AND INVOICE_SEQ=? "
												+ "AND BU_STATE_TIN=? AND FINANCIAL_YEAR=?";
										stmt1 = conn.prepareStatement(queryString1);
										stmt1.setString(1, comp_cd);
										stmt1.setString(2, inv_seq);
										stmt1.setString(3, bu_state_tin);
										stmt1.setString(4, financial_year);
										rset1=stmt1.executeQuery();
										if(rset1.next())
										{
											String seq_no=""+(rset1.getInt(1)+1);
											
											queryString2="INSERT INTO FMS_DLNG_INV_PAY_RECV_DTL(COMPANY_CD,BU_STATE_TIN,INVOICE_SEQ,FINANCIAL_YEAR,SEQ_NO,"
													+ "PAY_RECV_DT,PAY_RECV_AMT,PAY_REMARK,ENT_BY,ENT_DT,ADV_AMT,ADV_FLAG) "
													+ "VALUES(?,?,?,?,?,"
													+ "TO_DATE(?,'DD/MM/YYYY'),?,?,?,SYSDATE,?,?)";
											stmt2 = conn.prepareStatement(queryString2);
											stmt2.setString(1, comp_cd);
											stmt2.setString(2, bu_state_tin);
											stmt2.setString(3, inv_seq);
											stmt2.setString(4, financial_year);
											stmt2.setString(5, seq_no);
											stmt2.setString(6, temp_invoice_dt);
											stmt2.setString(7, payRecvAmt);
											stmt2.setString(8, remark);
											stmt2.setString(9, emp_cd);
											stmt2.setString(10, payRecvAmt);
											stmt2.setString(11, "Y");
											stmt2.executeUpdate();
											stmt2.close();
										}
										rset1.close();
										stmt1.close();
						        	}
					        	}
				        	}
				        }
					}	        
			        
			        if(pdf_entry == 0 || update_flag == 0)
			        {
			        	conn.rollback();
			        	deletePdfFile(path);
			        	msg="Failed! - "+invdtl+" Invoice for "+counterparty_abbr+" PDF for "+dealMap+" Generation Failed for "+temp_period_end_dt+"!";
			        	msg_type="E";
			        }
			        else
			        {
			        	conn.commit();
			        	msg = "Successful! - "+invdtl+" Invoice for "+counterparty_abbr+" PDF "+file_nm+" for "+dealMap+" Generated Successfully for "+temp_period_end_dt+"!";
			        	msg_type="S";
			        }
				}
				else
				{
					msg="Failed! - "+invdtl+" Invoice for "+counterparty_abbr+" PDF for "+dealMap+" Generation Failed for "+temp_period_end_dt+"!";
					msg_type="E";
				}
			}
		}
		catch(Exception e)
		{
			conn.rollback();
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
			
			document.close();
			deletePdfFile(path);
			
			msg="Error in Exception! - "+invdtl+" Invoice for "+counterparty_abbr+" PDF Generation Failed!";
			msg_type="E";	
		}
		finally
		{
			document.close();
		}
		
		try
		{
			new com.etrm.fms.util.InfoLogger().InsertInfoLogger(emp_cd, comp_cd,emp_nm, ip, form_id, form_nm,mod_cd,mod_nm, "", "", msg);  	
		}
		catch(Exception infoLogger)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, infoLogger);
		}
	}
	
	public void printPdfFileForDLNG_CRDRInvoice() throws SQLException
	{
		String function_nm="printPdfFileForDLNG_CRDRInvoice()";
		
		String emp_nm ="";
		String ip = "";
		msg="";
		//String msg_content="";
		String path ="";
		String counterparty_abbr="";
		String invdtl="DLNG Sales";
		
		Rectangle pageSize = new Rectangle(595, 842);
		//Rectangle pageSize1=new Rectangle(842,595);
		Rectangle pageSize1 = new Rectangle(595, 842);
		
		pageSize.setBackgroundColor(new BaseColor(0xffffff));
		pageSize1.setBackgroundColor(new BaseColor(0xffffff));
		
		Document document = new Document(pageSize);
		try
		{
			HttpSession session = request.getSession();
			emp_nm = (String)session.getAttribute("emp_nm")==null?"":(String)session.getAttribute("emp_nm");
			ip = (String)session.getAttribute("ip")==null?"":(String)session.getAttribute("ip");
			
			String company_nm = ""+session.getAttribute("comp_nm")==null?"":""+session.getAttribute("comp_nm");
			String company_abbr = ""+session.getAttribute("comp_abbr")==null?"":""+session.getAttribute("comp_abbr");
			String counterparty_nm=""+utilBean.getCounterpartyName(conn,counterparty_cd);
			counterparty_abbr=""+utilBean.getCounterpartyABBR(conn,counterparty_cd);
			
			//FOLLOWING IS ALSO USED FOR PDF CONTENT
			if(inv_flag.equals("DR"))
			{
				invdtl="Debit Note";
			}
			else if(inv_flag.equals("CR"))
			{
				invdtl="Credit Note";
			}
			
			int pdfGenCount=0;
			queryString="SELECT COUNT(*) "
					+ "FROM FMS_DLNG_INVOICE_MST A ,FMS_DLNG_INV_FILE_DTL B "
					+ "WHERE A.COMPANY_CD=? AND A.FINANCIAL_YEAR=? AND A.INVOICE_SEQ=? AND A.BU_STATE_TIN=? ";
			if(print_pdf_type.equals("O"))
			{
				queryString+= "AND A.PRINT_BY_ORI IS NOT NULL AND A.PRINT_DT_ORI IS NOT NULL ";
			}
			else if(print_pdf_type.equals("T"))
			{
				queryString+= "AND A.PRINT_BY_TRI IS NOT NULL AND A.PRINT_DT_TRI IS NOT NULL ";
			}
			else if(print_pdf_type.equals("D"))
			{
				queryString+= "AND A.PRINT_BY_DUP IS NOT NULL AND A.PRINT_DT_DUP IS NOT NULL ";
			}
			queryString+= "AND B.PDF_TYPE=? AND B.FILE_NAME IS NOT NULL "
					+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.BU_STATE_TIN=B.BU_STATE_TIN AND A.INVOICE_SEQ=B.INVOICE_SEQ "
    		  		+ "AND A.FINANCIAL_YEAR=B.FINANCIAL_YEAR";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, financial_year);
			stmt.setString(3, inv_seq);
			stmt.setString(4, bu_state_tin);
			stmt.setString(5, print_pdf_type);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				pdfGenCount=rset.getInt(1);
			}
			rset.close();
			stmt.close();
			
			String dealMap = utilBean.NewDealMappingId(comp_cd, counterparty_cd, agmt_no, agmt_rev_no, cont_no, cont_rev_no, contract_type, cargo_no);
            
			if(pdfGenCount>0)
			{
				msg="Failed! - "+invdtl+" for "+counterparty_abbr+" PDF for "+dealMap+" already Generated for "+period_end_dt+"!";
				msg_type="E";
			}
			else
			{
				String contRef="";
				String signingDt="";
				String agmtSigningDt="";
				String dcq="";
				String agmt_base="";
				String auto_pay_flag="";
				double mdcq_percentage=100;
				
				queryString="SELECT CONT_REF_NO,TO_CHAR(SIGNING_DT,'DD-MON-YY'),TRADE_REF_NO,DCQ,"
						+ "MDCQ_PERCENTAGE,AGMT_BASE,ADV_ADJUST  "
						+ "FROM FMS_SUPPLY_CONT_MST A "
						+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE=? "
						+ "AND CONT_NO=? AND AGMT_NO=? AND COUNTERPARTY_CD=? "
						+ "AND CONT_REV = (SELECT MAX(CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
						+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) ";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, contract_type);
				stmt.setString(3, cont_no);
				stmt.setString(4, agmt_no);
				stmt.setString(5, counterparty_cd);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					contRef=rset.getString(1)==null?"":rset.getString(1);
					signingDt=rset.getString(2)==null?"":rset.getString(2);
					
					String trade_ref=rset.getString(3)==null?"":rset.getString(3);
					if(contract_type.equals("W"))
					{
						contRef=trade_ref;
					}
					dcq=nf.format(rset.getDouble(4));
					mdcq_percentage=rset.getDouble(5);
					if(Double.doubleToRawLongBits(mdcq_percentage)==Double.doubleToRawLongBits(0))
					{
						mdcq_percentage=100;
					}
					agmt_base=rset.getString(6)==null?"":rset.getString(6);
					auto_pay_flag=rset.getString(7)==null?"":rset.getString(7);
				}
				rset.close();
				stmt.close();
				
				if(contract_type.equals("F"))
				{
					queryString="SELECT TO_CHAR(SIGNING_DT,'DD-MON-YY')  "
							+ "FROM FMS_AGMT_MST A "
							+ "WHERE COMPANY_CD=? AND AGMT_TYPE=? "
							+ "AND AGMT_NO=? AND COUNTERPARTY_CD=? "
							+ "AND AGMT_REV = (SELECT MAX(AGMT_REV) FROM FMS_AGMT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
							+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_TYPE=B.AGMT_TYPE) ";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(1, comp_cd);
					stmt.setString(2, "D");
					stmt.setString(3, agmt_no);
					stmt.setString(4, counterparty_cd);
					rset=stmt.executeQuery();
					if(rset.next())
					{
						agmtSigningDt=rset.getString(1)==null?"":rset.getString(1);
					}
					rset.close();
					stmt.close();
				}
				
				HashMap bu_plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "B", comp_cd, bu_plant_seq);
				String bu_plantAddress=""+bu_plant_detail.get("plant_address");
				String bu_plantCity=""+bu_plant_detail.get("plant_city");
				String bu_plantState=""+bu_plant_detail.get("plant_state");
				String bu_plantPin=""+bu_plant_detail.get("plant_pin");
				String bu_plantNm=""+bu_plant_detail.get("plant_name");
	
				HashMap plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "C", counterparty_cd, plant_seq);
				String plantAddress=""+plant_detail.get("plant_address");
				String plantCity=""+plant_detail.get("plant_city");
				String plantState=""+plant_detail.get("plant_state");
				String plantPin=""+plant_detail.get("plant_pin");
				
				String bu_contact_person_cd="";
				String contact_person_cd="";
				String invoice_dt="";
				String invoice_due_dt="";
				String remark_1="";
				String remark_2="";
				String qty_mmbtu="";
				String price="";
				String price_cd="";
				String gross_amt="";
				String exchang_rate_cd="";
				String exchang_rate_dt="";
				String exchang_rate="";
				String exchang_rate_type="";
				String gross_amt1="";
				String tax_amt="";
				String tax_struct_cd="";
				String tax_struct_dt="";
				String invoice_amt="";
				String net_payable="";
				String applicable_abbr="";
				String applicable_amt="";
				String TCS_factor="";
				String tax_struct_dtl="";
				String invoice_no="";
				String invoice_raised_in="";
				String temp_invoice_dt="";
				String transportation_charges = "";
				String transportation_amount = "";
				String gross_include_transport_tariff = "";
				String marketing_margin = "";
				String marketing_margin_amount = "";
				String other_charges = "";
				String other_charges_amount = "";
				String irn_no="";
				String qr_code="";
				String sug_qty="";
				String sug_percent="";
				String sel_inv_ref="";
				String criteri_formula="";
				boolean isGrossIncTriff=false;
				
				double netPayable=0;
				double tdsAmt=0;
				
				String temp_period_start_dt=period_start_dt;
				String temp_period_end_dt=period_end_dt;
				
				String cont_map=counterparty_cd+"-"+contract_type+"-"+agmt_no+"-%-"+cont_no+"-%";
				String exit_point="C-"+counterparty_cd+"-"+plant_seq;
				
				queryString="SELECT BU_CONTACT_PERSON_CD,CONTACT_PERSON_CD,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD-MON-YY'),"
						+ "TO_CHAR(DUE_DT,'DD-MON-YY'),TO_CHAR(PERIOD_START_DT,'DD-MON-YY'),TO_CHAR(PERIOD_END_DT,'DD-MON-YY'),REMARK_1,REMARK_2,"
						+ "ALLOC_QTY,SALE_PRICE,SALE_PRICE_UNIT,SALE_AMT,EXCHG_RATE_VALUE,GROSS_AMT,TAX_AMT,TAX_STRUCT_CD,TO_CHAR(TAX_EFF_DT,'DD/MM/YYYY'),"
						+ "INVOICE_AMT,NET_PAYABLE_AMT,TCS_TDS,TCS_AMT,TCS_FACTOR,CHECKED_FLAG,APPROVED_FLAG, "
						+ "INVOICE_ID_SEQ,INVOICE_RAISED_IN,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),NULL,NULL,EXCHG_RATE_CD,"
						+ "TO_CHAR(EXCHG_RATE_DT,'DD-MON-YY'),EXCHG_RATE_TYPE,TDS_GROSS_AMT,REF_NO,CRITERIA "
						+ "FROM FMS_DLNG_INVOICE_MST "
						+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? AND FINANCIAL_YEAR=? "
						+ "AND INVOICE_SEQ=? AND INV_FLAG=? ";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, bu_state_tin);
				stmt.setString(3, financial_year);
				stmt.setString(4, inv_seq);
				stmt.setString(5, inv_flag);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					bu_contact_person_cd=rset.getString(1)==null?"0":rset.getString(1);
					contact_person_cd=rset.getString(2)==null?"0":rset.getString(2);
					
					//invoice_id_seq=rset.getString(26)==null?"":rset.getString(26);
					invoice_no=rset.getString(3)==null?"":rset.getString(3);
					invoice_dt=rset.getString(4)==null?"":rset.getString(4);
					invoice_due_dt=rset.getString(5)==null?"":rset.getString(5);
					//inv_period_start_dt=rset.getString(6)==null?"":rset.getString(6);
					//inv_period_end_dt=rset.getString(7)==null?"":rset.getString(7);
					
					remark_1=rset.getString(8)==null?"":rset.getString(8);
					remark_2=rset.getString(9)==null?"":rset.getString(9);
					
					qty_mmbtu=nf.format(rset.getDouble(10));
					price_cd=rset.getString(12)==null?"":rset.getString(12);
					price=utilBean.RateNumberFormat(rset.getDouble(11), price_cd);
					gross_amt=nf.format(rset.getDouble(13));
					exchang_rate=nf2.format(rset.getDouble(14));
					gross_amt1=nf.format(rset.getDouble(15));
					tax_amt=nf.format(rset.getDouble(16));
					tax_struct_cd=rset.getString(17)==null?"":rset.getString(17);
					tax_struct_dt=rset.getString(18)==null?"":rset.getString(18);
					invoice_amt=nf.format(rset.getDouble(19));
					net_payable=nf.format(rset.getDouble(20));
					netPayable=rset.getDouble(20);
					applicable_abbr=rset.getString(21)==null?"":rset.getString(21);
					applicable_amt=nf.format(rset.getDouble(22));
					TCS_factor=nf3.format(rset.getDouble(23));
					
					invoice_raised_in=rset.getString(27)==null?"":rset.getString(27);
					temp_invoice_dt=rset.getString(28)==null?"":rset.getString(28);
					
					transportation_charges=rset.getString(29)==null?"":nf2.format(rset.getDouble(29));
					transportation_amount=rset.getString(30)==null?"":nf.format(rset.getDouble(30));
					
					exchang_rate_cd=rset.getString(31)==null?"":rset.getString(31);
					exchang_rate_dt=rset.getString(32)==null?"":rset.getString(32);
					exchang_rate_type=rset.getString(33)==null?"":rset.getString(33);
					
					tdsAmt=rset.getDouble(34);
					sel_inv_ref=rset.getString(35)==null?"":rset.getString(35);
					criteri_formula=rset.getString(36)==null?"":rset.getString(36);
					
					gross_include_transport_tariff=nf.format(Double.parseDouble(gross_amt1));
					
					tax_struct_dtl=utilBean.getTaxDescr(conn, tax_struct_cd);
				}
				rset.close();
				stmt.close();
				
				//SELECTED INVOICE
				String main_inv_dt="";
				queryString1="SELECT ALLOC_QTY,SALE_PRICE,SALE_PRICE_UNIT,SALE_AMT,EXCHG_RATE_VALUE,GROSS_AMT,TO_CHAR(INVOICE_DT,'DD-MON-YY') "
						+ "FROM FMS_DLNG_INVOICE_MST "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND INVOICE_NO=? ";
				stmt1=conn.prepareStatement(queryString1);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, counterparty_cd);
				stmt1.setString(3, sel_inv_no);
				rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					//main_qty_mmbtu=nf.format(rset1.getDouble(1));
					//main_price_cd=rset1.getString(3)==null?"":rset1.getString(3);
					//main_price=utilBean.RateNumberFormat(rset1.getDouble(2), price_cd);
					//main_gross_amt=nf.format(rset1.getDouble(4));
					//main_exchang_rate=nf2.format(rset1.getDouble(5));
					//main_gross_amt1=nf.format(rset1.getDouble(6));
					main_inv_dt=rset1.getString(7)==null?"":rset1.getString(7);
				}
				rset1.close();
				stmt1.close();
				
				/*if(contract_type.equals("O") || contract_type.equals("Q"))
				{
					queryString1="SELECT IRN_NO,SIGN_QR_CODE "
							+ "FROM FMS_INVOICE_IRN_DTL "
							+ "WHERE COMPANY_CD=? AND INVOICE_NO=? ";
					stmt1=conn.prepareStatement(queryString1);
					stmt1.setString(1, comp_cd);
					stmt1.setString(2, invoice_no);
					rset1=stmt1.executeQuery();
					if(rset1.next())
					{
						irn_no=rset1.getString(1)==null?"":rset1.getString(1);
						qr_code=rset1.getString(2)==null?"":rset1.getString(2);
					}
					rset1.close();
					stmt1.close();
				}*/
				
				String contact_person_nm="";
				String bu_contact_person_nm="";
				
				queryString="SELECT CONTACT_PERSON "
						+ "FROM FMS_ENTITY_CONTACT_MST A "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
						+ "AND ENTITY=? AND SEQ_NO=? AND ADDR_FLAG=? "
						+ "AND TYPE=? "
						+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO "
						+ "AND EFF_DT <= TO_DATE(?,'DD/MM/YYYY') AND A.TYPE=B.TYPE)";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty_cd);
				stmt.setString(3, "C");
				stmt.setString(4, contact_person_cd);
				stmt.setString(5, "P"+plant_seq);
				stmt.setString(6, "DLNG");
				stmt.setString(7, temp_invoice_dt);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					contact_person_nm=rset.getString(1)==null?"":rset.getString(1);
				}
				rset.close();
				stmt.close();
				
				queryString="SELECT CONTACT_PERSON "
						+ "FROM FMS_ENTITY_CONTACT_MST A "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
						+ "AND ENTITY=? AND SEQ_NO=? AND ADDR_FLAG=? "
						+ "AND TYPE=?"
						+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO "
						+ "AND EFF_DT <= TO_DATE(?,'DD/MM/YYYY') AND A.TYPE=B.TYPE)";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, comp_cd);
				stmt.setString(3, "B");
				stmt.setString(4, bu_contact_person_cd);
				stmt.setString(5, "P"+bu_plant_seq);
				stmt.setString(6, "DLNG");
				stmt.setString(7, temp_invoice_dt);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					bu_contact_person_nm=rset.getString(1)==null?"":rset.getString(1);
				}
				rset.close();
				stmt.close();
	
				String print_pdf_type_nm="ORIGINAL";
				if(print_pdf_type.equals("O"))
				{
					print_pdf_type_nm="ORIGINAL";
				}
				else if(print_pdf_type.equals("D"))
				{
					print_pdf_type_nm="DUPLICATE";
				}
				else if(print_pdf_type.equals("T"))
				{
					print_pdf_type_nm="TRIPLICATE";
				}
	
				String appPath = request.getServletContext().getRealPath("");
	
				String main_folder="";
				if(!comp_cd.equals(""))
				{
					main_folder=CommonVariable.work_dir+comp_cd;
				}
				
				String sub_folder="unsigned_pdf";
				String sub_folder2="dlng_sales_invoice";
				String temp_path=appPath+File.separator+main_folder+File.separator+sub_folder+File.separator+sub_folder2;
				File main_folderDir = new File(temp_path);
		        if(!main_folderDir.exists())
		        {
		        	main_folderDir.mkdirs();
		        }
	
		        String monthofinv = dateUtil.getMonthNameMON(period_end_dt);
		        String dtPeriod="";
		        if(!period_start_dt.equals("") && !period_end_dt.equals(""))
		        {
		        	dtPeriod=period_start_dt.substring(0,2);
		        	dtPeriod+="-";
		        	dtPeriod+=period_end_dt.substring(0,2);
		        }
	
		        String contNm="";
		        String invNm="";
		        /*if(contract_type.equals("W"))
		        {
		        	contNm="DLNG-IGX";
		        	invNm="DLNG_INVOICE";
		        }
		        else if(contract_type.equals("E"))
		        {
		        	contNm="DLNG-LOA";
		        	invNm="DLNG_INVOICE";
		        }
		        else if(contract_type.equals("F"))
		        {
		        	contNm="DLNG-SN";
		        	invNm="DLNG_INVOICE";
		        }*/
		       
				//file_nm=print_pdf_type+"-"+company_abbr+"-"+invNm+"-"+contNm+""+bu_state_tin+"-"+inv_seq+"-"+counterparty_abbr+"_"+financial_year+"_"+monthofinv.trim()+"_"+dtPeriod+".pdf";
				file_nm=print_pdf_type+"-"+company_abbr+"-DLNG_"+inv_flag+"-"+invoice_no.replace("/", "-")+".pdf";
				
				path = appPath+"/"+main_folder+"/"+sub_folder+"/"+sub_folder2+"/"+file_nm;
				PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream(path));
	
				document.open();
				document.setPageSize(pageSize);
	            document.newPage();
	
	            String context_nm = request.getContextPath();
				String server_nm = request.getServerName();
				String server_port = ""+request.getServerPort();
	
				file_url = CommonVariable.app_protocol+"://"+server_nm+":"+server_port+context_nm;
	
				Font small_black_normal = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
				Font small_black_normal_10 = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
				Font small_black_normal_14 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
				Font small_black_normal_12 = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL, BaseColor.BLACK);
	            Font small_black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
	            Font black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
	            Font black_bold1 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
	            
	            PdfPCell company_logo_cell = new PdfPCell();
	            if(!comp_logo.equals(""))
	            {
	            	String file_path = request.getRealPath("/"+CommonVariable.company_logo_path+"/"+comp_logo);
	            	Image company_logo = Image.getInstance(file_path);
		            company_logo.setBorder(Rectangle.NO_BORDER);
		            company_logo.scaleAbsolute(44,40);
		            company_logo_cell = new PdfPCell(company_logo,false);
		            company_logo_cell.setBorder(Rectangle.NO_BORDER);
		            company_logo_cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	            }
	            
	            float[] Contact1 = {0.50f};
	   	     	PdfPTable LogoTable = new PdfPTable(Contact1);
	   	     	LogoTable.setWidthPercentage(100);
	   	     	LogoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	LogoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	LogoTable.addCell(company_logo_cell);
	
				float[] ContactAddrWidths1 = {0.100f};
	   	     	PdfPTable HlplLogoTable = new PdfPTable(ContactAddrWidths1);
	            HlplLogoTable.setWidthPercentage(100);
	            HlplLogoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            HlplLogoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            HlplLogoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            HlplLogoTable.addCell(new Phrase(new Chunk(print_pdf_type_nm,small_black_normal_10)));
	
	            float[] ContactAddrWidths2 = {0.100f};
	   	     	PdfPTable Table = new PdfPTable(ContactAddrWidths2);
	            Table.setWidthPercentage(100);
	            Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table.addCell(new Phrase(new Chunk(company_nm,black_bold1)));
	
	            float[] ContactAddrWidths3 = {0.100f};
	   	     	PdfPTable Table1 = new PdfPTable(ContactAddrWidths3);
	            Table1.setWidthPercentage(100);
	            Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table1.addCell(new Phrase(new Chunk(invdtl,small_black_normal_12)));
	            
	            period_start_dt=dateUtil.getDateFormatDD_MOM_YY(period_start_dt);
				period_end_dt=dateUtil.getDateFormatDD_MOM_YY(period_end_dt);
	
				String info ="In respect of "; 
				if(contract_type.equals("F")){
					info+="Supply Notice ("+contRef+") executed on "+signingDt+" pursuant to Framework LNG Sales Agreement executed on "+agmtSigningDt+"";
				}else if(contract_type.equals("E")){
					info+="Letter of Agreement ("+contRef+") executed on "+signingDt; 
				}else if(contract_type.equals("W")){ 
					info+="Exchange Transaction ("+contRef+") executed on "+signingDt;
				} 
				info+="\nbetween "+company_nm+" and "+counterparty_nm;
	
	            float[] ContactAddrWidths4 = {0.100f};
	   	     	PdfPTable Table2 = new PdfPTable(ContactAddrWidths4);
	            Table2.setWidthPercentage(100);
	            Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table2.addCell(new Phrase(new Chunk(info,small_black_normal)));
	
	            float[] ContactAddrWidths5 = {0.80f,0.10F,0.20F,0.80F};
	   	     	PdfPTable Table3 = new PdfPTable(ContactAddrWidths5);
	            Table3.setWidthPercentage(100);
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            //Table3.addCell(new Phrase(new Chunk("Business Unit: "+bu_plantNm,black_bold)));
	            Table3.addCell(new Phrase(new Chunk("Business Unit: ",black_bold)));
	            
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table3.addCell(new Phrase(new Chunk("",black_bold)));
	            
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table3.addCell(new Phrase(new Chunk("To:",black_bold)));
	
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table3.addCell(new Phrase(new Chunk(""+contact_person_nm+",",black_bold)));
	
	            
				float[] ContactAddrWidths6 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table4 = new PdfPTable(ContactAddrWidths6);
	            Table4.setWidthPercentage(100);
	            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table4.addCell(new Phrase(new Chunk(company_nm,small_black_normal)));
	            
	            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table4.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table4.addCell(new Phrase(new Chunk(counterparty_nm,small_black_normal)));
	
	            float[] ContactAddrWidths7 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table5 = new PdfPTable(ContactAddrWidths7);
	            Table5.setWidthPercentage(100);
	            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table5.addCell(new Phrase(new Chunk(bu_plantAddress+","+bu_plantCity,small_black_normal)));
	            
	            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table5.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
	            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table5.addCell(new Phrase(new Chunk(plantAddress+","+plantCity,small_black_normal)));
	            
	
	            float[] ContactAddrWidths8 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table6 = new PdfPTable(ContactAddrWidths8);
	            Table6.setWidthPercentage(100);
	            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table6.addCell(new Phrase(new Chunk(bu_plantState+" - "+bu_plantPin,small_black_normal)));
	
	            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table6.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
	            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table6.addCell(new Phrase(new Chunk(plantState+" - "+plantPin,small_black_normal)));
	
	            String tax_info="";
	            String bu_tax_info="";
				tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "C", counterparty_cd, plant_seq);
				bu_tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "B", comp_cd, bu_plant_seq);
				
	           float[] ContactAddrWidths9 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table7 = new PdfPTable(ContactAddrWidths9);
	            Table7.setWidthPercentage(100);
	            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table7.addCell(new Phrase(new Chunk(bu_tax_info,small_black_normal)));
	
	            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table7.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table7.addCell(new Phrase(new Chunk(tax_info,small_black_normal)));
	            
	            PdfPTable InvoiceDateInfoTable;
	            PdfPTable BillingPeriodInfoTable;
	            
	           /* float[] InvoiceDateInfoWidths_qr = {0.30f, 0.20f, 0.70f};
				PdfPTable InvoiceDateInfoTable_qr = new PdfPTable(InvoiceDateInfoWidths_qr);
				if(!irn_no.equals("") && !qr_code.equals("") && (contract_type.equals("Q") || contract_type.equals("O")))
				{
					float[] InvoiceDateInfoWidths = {0.60F,0.40F};
		            InvoiceDateInfoTable = new PdfPTable(InvoiceDateInfoWidths);
		            InvoiceDateInfoTable.setWidthPercentage(100);
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
					InvoiceDateInfoTable.addCell(new Phrase(new Chunk("Invoice Date :",black_bold)));
					InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
					InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(invoice_dt,black_bold)));
		            
		            //due date
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk("Payment Due Date :",black_bold)));
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(invoice_due_dt,black_bold)));
		            
		            //inv no
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(company_abbr+" TAX Invoice Seq No:",black_bold)));
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(invoice_no,black_bold)));
		            
		            float[] BillingPeriodInfoWidths = {0.30F,0.20F,0.10F,0.20F};
		            BillingPeriodInfoTable = new PdfPTable(BillingPeriodInfoWidths);
		            BillingPeriodInfoTable.setWidthPercentage(100);
		            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.addCell(new Phrase(new Chunk("Billing Period : ",black_bold)));
		            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.addCell(new Phrase(new Chunk(""+period_start_dt,black_bold)));
		            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            BillingPeriodInfoTable.addCell(new Phrase(new Chunk("to",black_bold)));
		            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.addCell(new Phrase(new Chunk(""+period_end_dt,black_bold)));
		            
		            if(!inv_flag.equals("UG") && !inv_flag.equals("ST"))
		            {
		            	InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            	InvoiceDateInfoTable.getDefaultCell().setColspan(3);
		            	InvoiceDateInfoTable.addCell(BillingPeriodInfoTable);
		            }
		               
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            InvoiceDateInfoTable.getDefaultCell().setColspan(3);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk("",small_black_bold)));
					
					int width=90;
					int height=90;
					Hashtable<EncodeHintType, ErrorCorrectionLevel> hintMap = new Hashtable<>();
			        hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
	
			        QRCodeWriter qrCodeWriter = new QRCodeWriter();
			        BitMatrix matrix = qrCodeWriter.encode(qr_code, BarcodeFormat.QR_CODE, width, height, hintMap);
	
			        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			        for (int x = 0; x < width; x++) 
			        {
			            for (int y = 0; y < height; y++) 
			            {
			                image.setRGB(x, y, matrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
			            }
			        }
			        
			        BufferedImage qrImage = image;
			        
			        ByteArrayOutputStream baos = new ByteArrayOutputStream();
			        ImageIO.write(qrImage, "png", baos);
			        Image qr_codeimg = Image.getInstance(baos.toByteArray());
					qr_codeimg.setBorder(Rectangle.NO_BORDER);
	                qr_codeimg.setAlignment(Element.ALIGN_LEFT);
	                PdfPCell qrcode_cell = new PdfPCell(qr_codeimg,false);
	                qrcode_cell.setBorder(Rectangle.NO_BORDER);
	                qrcode_cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	                
	                String char_16= irn_no.substring(0,16);
	                String char_32= irn_no.substring(16,32);
	                String char_48= irn_no.substring(32,48);
	                String char_64= irn_no.substring(48,irn_no.length());
	                String final_irn_no=char_16+"\n"+char_32+"\n"+char_48+"\n"+char_64;
	                
	                PdfPTable InvoiceDateInfoTable_qr1 = new PdfPTable(1);
	       	        InvoiceDateInfoTable_qr1.setWidthPercentage(100);
	       	        InvoiceDateInfoTable_qr1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	       	        InvoiceDateInfoTable_qr1.getDefaultCell().setBorder(Rectangle.BOX);
	       	        InvoiceDateInfoTable_qr1.addCell(qrcode_cell);
	       	        
	       	        PdfPTable InvoiceDateInfoTable_qr11 = new PdfPTable(1);
	    	        InvoiceDateInfoTable_qr11.setWidthPercentage(100);
	    	        InvoiceDateInfoTable_qr11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	    	        InvoiceDateInfoTable_qr11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	    	        InvoiceDateInfoTable_qr11.addCell(new Phrase(new Chunk("IRN",black_bold)));
	    	        InvoiceDateInfoTable_qr11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	    	        InvoiceDateInfoTable_qr11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	    	        InvoiceDateInfoTable_qr11.addCell(new Phrase(new Chunk(final_irn_no,small_black_normal)));
	    	        
	    	        InvoiceDateInfoTable_qr.setWidthPercentage(100);
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	       	        InvoiceDateInfoTable_qr.addCell(InvoiceDateInfoTable_qr1);
	       	        
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setBorder(Rectangle.BOX);
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	       	        InvoiceDateInfoTable_qr.addCell(InvoiceDateInfoTable_qr11);
	       	        
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	       	        InvoiceDateInfoTable_qr.addCell(InvoiceDateInfoTable);
				}*/
	
	            float[] ContactAddrWidths10 = {0.80F,0.30F,0.30F,0.40F};
	   	     	PdfPTable Table8 = new PdfPTable(ContactAddrWidths10);
	            Table8.setWidthPercentage(100);
	            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table8.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table8.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table8.addCell(new Phrase(new Chunk(invdtl+" Date :",black_bold)));
	
	            Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            //Table8.addCell(new Phrase(new Chunk(dateUtil.getDateFormatDD_MOM_YY(invoice_dt),small_black_normal)));
	            Table8.addCell(new Phrase(new Chunk(invoice_dt,black_bold)));
	
	            float[] ContactAddrWidths11 = {0.80F,0.30F,0.30F,0.40F};
	   	     	PdfPTable Table9 = new PdfPTable(ContactAddrWidths11);
	            Table9.setWidthPercentage(100);
	            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table9.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table9.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table9.addCell(new Phrase(new Chunk("Payment Due Date :",black_bold)));
	
	            Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            //Table9.addCell(new Phrase(new Chunk(dateUtil.getDateFormatDD_MOM_YY(invoice_due_dt),small_black_normal)));
	            Table9.addCell(new Phrase(new Chunk(invoice_due_dt,black_bold)));
	
	            float[] ContactAddrWidths12 = {0.80F,0.10F,0.50F,0.40F};
	   	     	PdfPTable Table10 = new PdfPTable(ContactAddrWidths12);
	            Table10.setWidthPercentage(100);
	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk(company_abbr+" "+invdtl+" No :",black_bold)));
	
	            Table10.getDefaultCell().setBorder(Rectangle.BOX);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk(invoice_no,black_bold)));
	            
	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk("Invoice Ref :",black_bold)));
	
	            Table10.getDefaultCell().setBorder(Rectangle.BOX);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk(sel_inv_ref,black_bold)));
	
	            /*float[] ContactAddrWidths12_1 = {0.80F,0.20F,0.10F,0.20F};
	   	     	PdfPTable Table10_1 = new PdfPTable(ContactAddrWidths12_1);
	   	     	Table10_1.setWidthPercentage(100);
	            Table10_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.addCell(new Phrase(new Chunk("Billing Period : ",black_bold)));
	
	            Table10_1.getDefaultCell().setBorder(Rectangle.BOX);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.addCell(new Phrase(new Chunk(""+period_start_dt,black_bold)));
	
	            Table10_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table10_1.addCell(new Phrase(new Chunk("to",black_bold)));
	
	            Table10_1.getDefaultCell().setBorder(Rectangle.BOX);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.addCell(new Phrase(new Chunk(""+period_end_dt,black_bold)));
	            */
	
	            float[] ContactAddrWidths13 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	PdfPTable Table11 = new PdfPTable(ContactAddrWidths13);
	            Table11.setWidthPercentage(100);
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Sr.No.",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Item Description",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Attachment",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Currency",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Quantity\n(MMBTU)",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Rate",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Amount",small_black_bold)));
	
	            String salesValue="";
	            salesValue=""+gross_amt;
	
	            String curr="";
	            String curr1="";
	            if(price_cd.equals("1"))
	            {
	            	curr="INR";
	            }
	            else if(price_cd.equals("2"))
	            {
	            	curr="USD";
	            }
	
	            if(invoice_raised_in.equals("1"))
	            {
	            	curr1="INR";
	            }
	            else if(invoice_raised_in.equals("2"))
	            {
	            	curr1="USD";
	            }
	
	            int sr=1;
	
	            float[] ContactAddrWidths14 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	PdfPTable Table12 = new PdfPTable(ContactAddrWidths14);
	            Table12.setWidthPercentage(100);
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table12.addCell(new Phrase(new Chunk("Reference Att-1 "+invdtl+" against Invoice No : "+sel_inv_ref+" dated "+main_inv_dt,small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            sr+=1;
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table12.addCell(new Phrase(new Chunk("Gross Amount",small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk("Att1",small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk(gross_amt1.equals("")?"":Double.doubleToRawLongBits(Double.parseDouble(gross_amt1))==Double.doubleToRawLongBits(0)?"":nf.format(Math.abs(Double.parseDouble(gross_amt1))),small_black_normal)));
	
	            sr+=1;
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table12.addCell(new Phrase(new Chunk("Tax ("+tax_struct_dtl+")",small_black_normal)));
	            
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk(tax_amt.equals("")?"":nf.format(Math.abs(Double.parseDouble(tax_amt))),small_black_normal)));
	            
	            Vector VTAX_CODE_1 = new Vector();
				Vector VTAX_DESCR_1 = new Vector();
				Vector VTAX_AMT_1 = new Vector();
				Vector VTAX_BASE_AMT_1 = new Vector();
				Vector VTAX_FACTOR_1 = new Vector();
				
				Vector VMULTI_TAX_STRUCT = new Vector();
				
	            queryString1="SELECT COUNT(*) "
						+ "FROM FMS_DLNG_INV_TAX_DTL "
						+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
						+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
	            stmt1=conn.prepareStatement(queryString1);
	            stmt1.setString(1, comp_cd);
	            stmt1.setString(2, bu_state_tin);
	            stmt1.setString(3, financial_year);
	            stmt1.setString(4, inv_seq);
	            rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					if(rset1.getInt(1)>1)
					{
						double temp_srno=sr;
						queryString="SELECT TAX_CODE,TAX_DESCR,TAX_AMT,TAX_BASE_AMT "
								+ "FROM FMS_DLNG_INV_TAX_DTL "
								+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
								+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
						stmt=conn.prepareStatement(queryString);
			            stmt.setString(1, comp_cd);
			            stmt.setString(2, bu_state_tin);
			            stmt.setString(3, financial_year);
			            stmt.setString(4, inv_seq);
			            rset=stmt.executeQuery();
						while(rset.next())
						{
							temp_srno=temp_srno+0.1;
							
							String tax_descr=rset.getString(2)==null?"":rset.getString(2);
							String taxAmt=rset.getString(3)==null?"":nf.format(rset.getDouble(3));
							
							VTAX_CODE_1.add(rset.getString(1)==null?"":rset.getString(1));
							VTAX_DESCR_1.add(rset.getString(2)==null?"":rset.getString(2));
							VTAX_AMT_1.add(rset.getString(3)==null?"":nf.format(rset.getDouble(3)));
							VTAX_BASE_AMT_1.add(rset.getString(4)==null?"":nf.format(rset.getDouble(4)));
							VTAX_FACTOR_1.add("");
							
							Table12.getDefaultCell().setBorder(Rectangle.BOX);
				            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				            Table12.addCell(new Phrase(new Chunk(""+nf0.format(temp_srno),small_black_normal)));
	
				            Table12.getDefaultCell().setBorder(Rectangle.BOX);
				            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				            Table12.addCell(new Phrase(new Chunk(""+tax_descr+"",small_black_normal)));
				            
				            Table12.getDefaultCell().setBorder(Rectangle.BOX);
				            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				            Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
				            Table12.getDefaultCell().setBorder(Rectangle.BOX);
				            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				            Table12.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
				            Table12.getDefaultCell().setBorder(Rectangle.BOX);
				            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				            Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
				            Table12.getDefaultCell().setBorder(Rectangle.BOX);
				            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				            Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
				            Table12.getDefaultCell().setBorder(Rectangle.BOX);
				            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
				            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
				            Table12.addCell(new Phrase(new Chunk(taxAmt.equals("")?"":nf.format(Math.abs(Double.parseDouble(taxAmt))),small_black_normal)));
						}
						rset.close();
						stmt.close();
					}
				}
				rset1.close();
				stmt1.close();
				
				Vector VTEMP_TAX_DTL_1 = new Vector();
				
				VTEMP_TAX_DTL_1.add(VTAX_CODE_1);
				VTEMP_TAX_DTL_1.add(VTAX_DESCR_1);
				VTEMP_TAX_DTL_1.add(VTAX_AMT_1);
				VTEMP_TAX_DTL_1.add(VTAX_BASE_AMT_1);
				VTEMP_TAX_DTL_1.add(VTAX_FACTOR_1);
				
				VMULTI_TAX_STRUCT.add(VTEMP_TAX_DTL_1);
				
	            
				String invAmtLbl=invdtl+" Amount";
	            sr+=1;
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table12.addCell(new Phrase(new Chunk(invAmtLbl,small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk(invoice_amt.equals("")?"":nf.format(Math.abs(Double.parseDouble(invoice_amt))),small_black_normal)));
	            
	            if(applicable_abbr.equals("TCS"))
	            {
	            	sr+=1;
	            	Table12.getDefaultCell().setBorder(Rectangle.BOX);
	                Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table12.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	                Table12.getDefaultCell().setBorder(Rectangle.BOX);
	                Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	                Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	                Table12.addCell(new Phrase(new Chunk("TCS",small_black_normal)));
	
	                Table12.getDefaultCell().setBorder(Rectangle.BOX);
	                Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	                Table12.getDefaultCell().setBorder(Rectangle.BOX);
	                Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table12.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	                Table12.getDefaultCell().setBorder(Rectangle.BOX);
	                Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	                Table12.getDefaultCell().setBorder(Rectangle.BOX);
	                Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table12.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	                Table12.getDefaultCell().setBorder(Rectangle.BOX);
	                Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table12.addCell(new Phrase(new Chunk(applicable_amt,small_black_normal)));
	            }
	            
	            sr+=1;
	   	     	Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk(""+sr,black_bold)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table12.addCell(new Phrase(new Chunk("Net Amount Payable",black_bold)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk("",black_bold)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk(""+curr1,black_bold)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk("",black_bold)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk("",black_bold)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk(net_payable.equals("")?"":nf.format(Math.abs(Double.parseDouble(net_payable))),black_bold)));
	
	            float[] ContactAddrWidths21 = {0.100F};
	   	     	PdfPTable Table19 = new PdfPTable(ContactAddrWidths21);
	   	     	Table19.setWidthPercentage(100);
	   	     	Table19.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	Table19.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	Table19.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	     	Table19.addCell(new Phrase(new Chunk(remark_1,small_black_normal)));
	
	   	     	float[] ContactAddrWidths22 = {0.100F};
		     	PdfPTable Table20 = new PdfPTable(ContactAddrWidths22);
		     	Table20.setWidthPercentage(100);
		     	Table20.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		     	Table20.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		     	Table20.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		     	Table20.addCell(new Phrase(new Chunk(remark_2,small_black_normal)));
		     	
		     	float[] ContactAddrWidths23 = {0.100F};
	   	     	PdfPTable Table21 = new PdfPTable(ContactAddrWidths21);
	   	     	Table21.setWidthPercentage(100);
	   	     	Table21.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	Table21.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	  		Table21.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	  		Table21.addCell(new Phrase(new Chunk("For "+company_nm,black_bold)));
	   	  		
	   	  		// create a signature form field
	   	     	PdfPTable BillingFieldsInfoTable81 = new PdfPTable(1);
	   	     	BillingFieldsInfoTable81.setWidthPercentage(20);
	   	     	BillingFieldsInfoTable81.setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	BillingFieldsInfoTable81.getDefaultCell().setBorder(Rectangle.BOX);
	   	     	BillingFieldsInfoTable81.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	BillingFieldsInfoTable81.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	        
	   	     	PdfFormField field = PdfFormField.createSignature(writer);
	   	     	field.setFieldName(SIGNAME);
	   	     	// set the widget properties
	   	     	field.setPage();
	   	     	field.setWidget(new Rectangle(72, 732, 144, 780), PdfAnnotation.HIGHLIGHT_NONE);
	   	     	field.setFlags(PdfAnnotation.FLAGS_PRINT);
	   	     	writer.addAnnotation(field);
	         
	   	     	PdfPCell sigCell = new PdfPCell();
	   	     	FieldPositioningEvents events = new FieldPositioningEvents(writer, field);
	   	     	sigCell.setCellEvent(events);
	   	     	sigCell.setFixedHeight(50f);
	   	     	BillingFieldsInfoTable81.addCell(sigCell);
	
	   	     	float[] ContactAddrWidths24 = {0.100F};
		     	PdfPTable Table22 = new PdfPTable(ContactAddrWidths22);
	
		     	Table22.setWidthPercentage(100);
		     	Table22.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		     	Table22.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		     	Table22.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		     	Table22.addCell(new Phrase(new Chunk("Authorised Signatory",black_bold)));
		     	
		     	document.add(LogoTable);
				document.add(HlplLogoTable);
				document.add(Table);
				document.add(Table1);
				document.add(Table2);
				document.add(new Paragraph("  "));
				document.add(Table3);
				document.add(Table4);
				document.add(Table5);
				document.add(Table6);
				document.add(Table7);
				document.add(new Paragraph("  "));
				document.add(new Paragraph("  "));
				/*if(!irn_no.equals("") && !qr_code.equals("") && (contract_type.equals("Q") || contract_type.equals("O")))
				{
					document.add(InvoiceDateInfoTable_qr);
				}
				else*/
				{
					document.add(Table8);
					document.add(Table9);
					document.add(Table10);
					/*if(!inv_flag.equals("UG") && !inv_flag.equals("ST"))
		            {
						document.add(Table10_1);
		            }*/
				}
				document.add(new Paragraph("  "));
				document.add(Table11);
				document.add(Table12);
				document.add(new Paragraph("  "));
				document.add(Table19);
				document.add(Table20);
				document.add(new Paragraph("  "));
				document.add(new Paragraph("  "));
				document.add(Table21);
				document.add(BillingFieldsInfoTable81);
				document.add(Table22);
				
				//For Attachment 1
				Font big_black_bold = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD, BaseColor.BLACK);
				Font small_black_bold2 = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, BaseColor.BLACK);
				
				document.setPageSize(pageSize1);
	            document.newPage();
	            
	            String main_qty_mmbtu = "";
	            String main_price = "";
	            String main_price_cd = "";
	            String main_price_cd_nm = "";
	            String main_invoice_raised_in = "";
	            String main_invoice_raised_in_nm = "";
	            String main_exchng_rate_cd = "";
	            String main_exchng_rate_cal = "";
	            String main_exchang_rate = "";
	            String main_exchang_rate_dt = "";
	            String main_exchang_rate_type = "";
	            String main_exchang_criteria = "";
	            String main_invoice_seq = "";
	            String main_invoice_no = "";
	            String main_invoice_dt = "";
	            String main_invoice_due_dt = "";
	            String main_gross_amt = "";
	            String main_gross_amt1 = "";
	            String main_remark_1 = "";
	            String main_remark_2 = "";
	            String main_last_avlb_exchng_dt = "";
	            String main_lable_inv_criteria = "";
	            String main_lable_inv_date = "";
	            String main_correction_msg = "";
	            String main_daily_tot_amt_inr = "";
	            String main_daily_tot_amt_usd = "";
	            String main_daily_tot_qty = "";
	            String main_tax_amt = "";
	            String main_tax_struct_cd = "";
	            String main_tax_struct_dt = "";
	            String main_tax_struct_dtl = "";
	            String main_tax_info = "";
	            String main_tax_factor = "";
	            String main_invoice_amt = "";
	            String main_net_payable = "";
	            String main_applicable_flag = "";
	            String main_applicable_amt = "";
	            String main_applicable_abbr = "";
	            String main_TCS_factor = "";
	            String main_contract_ref = "";
	            String main_tcs_struct_cd = "";
	            String main_tcs_struct_dt = "";
	            String main_tds_amt = "";
	            String main_tds_factor = "";
	            String main_tds_struct_cd = "";
	            String main_tds_struct_dt = "";
	            String main_invoice_id_seq = "";
	            String main_agmt_base = "";
	            String main_transportation_charges = "";
	            String main_transportation_amount = "";
	            String main_gross_include_transport_tariff = "";
	            String main_marketing_margin = "";
	            String main_marketing_margin_amount = "";
	            String main_other_charges = "";
	            String main_other_charges_amount = "";
	            
	            String new_qty_mmbtu = "";
	        	String new_price = "";
	        	String new_price_cd = "";
	        	String new_price_cd_nm = "";
	        	String new_invoice_raised_in = "";
	        	String new_invoice_raised_in_nm = "";
	        	String new_exchng_rate_cd = "";
	        	String new_exchng_rate_cal = "";
	        	String new_exchang_rate = "";
	        	String new_exchang_rate_dt = "";
	        	String new_exchang_rate_type = "";
	        	String new_exchang_criteria = "";
	        	String new_invoice_seq = "";
	        	String new_invoice_no = "";
	        	String new_invoice_dt = "";
	        	String new_invoice_due_dt = "";
	        	String new_gross_amt = "";
	        	String new_gross_amt1 = "";
	        	String new_remark_1 = "";
	        	String new_remark_2 = "";
	        	String new_last_avlb_exchng_dt = "";
	        	String new_lable_inv_criteria = "";
	        	String new_lable_inv_date = "";
	        	String new_correction_msg = "";
	        	String new_daily_tot_amt_inr = "";
	        	String new_daily_tot_amt_usd = "";
	        	String new_daily_tot_qty = "";
	        	String new_tax_amt = "";
	        	String new_tax_struct_cd = "";
	        	String new_tax_struct_dt = "";
	        	String new_tax_struct_dtl = "";
	        	String new_tax_info = "";
	        	String new_tax_factor = "";
	        	String new_invoice_amt = "";
	        	String new_net_payable = "";
	        	String new_applicable_flag = "";
	        	String new_applicable_amt = "";
	        	String new_applicable_abbr = "";
	        	String new_TCS_factor = "";
	        	String new_contract_ref = "";
	        	String new_tcs_struct_cd = "";
	        	String new_tcs_struct_dt = "";
	        	String new_tds_amt = "";
	        	String new_tds_factor = "";
	        	String new_tds_struct_cd = "";
	        	String new_tds_struct_dt = "";
	        	String new_invoice_id_seq = "";
	        	String new_agmt_base = "";
	        	String new_transportation_charges = "";
	        	String new_transportation_amount = "";
	        	String new_gross_include_transport_tariff = "";
	        	String new_marketing_margin = "";
	        	String new_marketing_margin_amount = "";
	        	String new_other_charges = "";
	        	String new_other_charges_amount = "";
	            
	        	Vector VNEW_MULTI_TAX_STRUCT = new Vector();
	        	Vector VMAIN_MULTI_TAX_STRUCT = new Vector();
	        	
	        	queryString="SELECT BU_CONTACT_PERSON_CD,CONTACT_PERSON_CD,INVOICE_SEQ,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),TO_CHAR(DUE_DT,'DD/MM/YYYY'),"
						+ "ALLOC_QTY,SALE_PRICE,SALE_PRICE_UNIT,SALE_AMT,EXCHG_RATE_CD,TO_CHAR(EXCHG_RATE_DT,'DD/MM/YYYY'),EXCHG_RATE_VALUE,"
						+ "INVOICE_RAISED_IN,GROSS_AMT,TAX_AMT,TAX_STRUCT_CD,TO_CHAR(TAX_EFF_DT,'DD/MM/YYYY'),INVOICE_AMT,NET_PAYABLE_AMT,"
						+ "REMARK_1,REMARK_2,TCS_TDS,TCS_AMT,TCS_FACTOR,NULL,NULL,TCS_STRUCT_CD,TO_CHAR(TCS_EFF_DT,'DD/MM/YYYY'),"
						+ "TDS_GROSS_AMT,TDS_GROSS_PERCENT,TDS_STRUCT_CD,TO_CHAR(TDS_EFF_DT,'DD/MM/YYYY'),NULL,NULL,NULL,NULL,"
						+ "TO_CHAR(ENT_DT,'DD/MM/YYYY HH24:MI:SS'),TO_CHAR(APPROVED_DT,'DD/MM/YYYY HH24:MI:SS'),FINANCIAL_YEAR,NULL,NULL,"
						+ "AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,CONTRACT_TYPE,BU_UNIT,PLANT_SEQ,"
						+ "TO_CHAR(PERIOD_START_DT,'DD/MM/YYYY'),TO_CHAR(PERIOD_END_DT,'DD/MM/YYYY'),BU_STATE_TIN "
						+ "FROM FMS_DLNG_INVOICE_MST "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND INVOICE_NO=? ";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty_cd);
				stmt.setString(3, sel_inv_ref);
				rset=stmt.executeQuery();
				if(rset.next())
				{	
					//bu_contact_person_cd=rset.getString(1)==null?"0":rset.getString(1);//
					//contact_person_cd=rset.getString(2)==null?"0":rset.getString(2);//
					//invoice_seq=rset.getString(3)==null?"":rset.getString(3);
					String invoice_seq=rset.getString(3)==null?"":rset.getString(3);
					//invoice_no=rset.getString(4)==null?"":rset.getString(4);//
					main_invoice_dt=rset.getString(5)==null?"":rset.getString(5);
					main_invoice_due_dt=rset.getString(6)==null?"":rset.getString(6);
					
					//exchng_rate_cd=rset.getString(11)==null?"":rset.getString(11);//
					//exchang_rate_dt=rset.getString(12)==null?"":rset.getString(12);//
					main_exchang_rate=rset.getString(13)==null?"":nf2.format(rset.getDouble(13));
				
					main_qty_mmbtu=rset.getString(7)==null?"":nf.format(rset.getDouble(7));
					main_price=rset.getString(8)==null?"":nf.format(rset.getDouble(8));
					//price_cd=rset.getString(9)==null?"":rset.getString(9);//
					//price_cd_nm=utilBean.getRateUnitNm(conn, price_cd);
					if(!main_price.equals(""))
					{
						main_price=utilBean.RateNumberFormat(rset.getDouble(8), price_cd);
					}
					main_gross_amt=rset.getString(10)==null?"":nf.format(rset.getDouble(10));
					
					//invoice_raised_in=rset.getString(14)==null?"":rset.getString(14);//
					//invoice_raised_in_nm=utilBean.getRateUnitNm(conn, invoice_raised_in);//
					main_gross_amt1=rset.getString(15)==null?"":nf.format(rset.getDouble(15));
					main_tax_amt=rset.getString(16)==null?"":nf.format(rset.getDouble(16));
					main_tax_struct_cd=rset.getString(17)==null?"":rset.getString(17);
					//tax_struct_cd=rset.getString(17)==null?"":rset.getString(17);
					//new_tax_struct_cd=rset.getString(17)==null?"":rset.getString(17);
					main_tax_struct_dt=rset.getString(18)==null?"":rset.getString(18);
					main_invoice_amt=rset.getString(19)==null?"":nf.format(rset.getDouble(19));
					main_net_payable=rset.getString(20)==null?"":nf.format(rset.getDouble(20));
					
					//applicable_abbr=rset.getString(23)==null?"":rset.getString(23);//
					main_applicable_amt=rset.getString(24)==null?"":rset.getString(24);
					main_TCS_factor=rset.getString(25)==null?"":rset.getString(25);
					
					main_tax_struct_dtl=utilBean.getTaxDescr(conn, main_tax_struct_cd);
					
					main_transportation_charges=rset.getString(26)==null?"":nf2.format(rset.getDouble(26));
					main_transportation_amount=rset.getString(27)==null?"":nf.format(rset.getDouble(27));
					
					main_tcs_struct_cd=rset.getString(28)==null?"":rset.getString(28);
					main_tcs_struct_dt=rset.getString(29)==null?"":rset.getString(29);
					
					main_tds_amt=rset.getString(30)==null?"":nf.format(rset.getDouble(30));
					main_tds_factor=rset.getString(31)==null?"":nf.format(rset.getDouble(31));
					main_tds_struct_cd=rset.getString(32)==null?"":rset.getString(32);
					main_tds_struct_dt=rset.getString(33)==null?"":rset.getString(33);
					
					main_marketing_margin=rset.getString(34)==null?"":nf2.format(rset.getDouble(34));
					main_marketing_margin_amount=rset.getString(35)==null?"":nf.format(rset.getDouble(35));
					main_other_charges=rset.getString(36)==null?"":nf2.format(rset.getDouble(36));
					main_other_charges_amount=rset.getString(37)==null?"":nf.format(rset.getDouble(37));
					
					String fiscal_yr=rset.getString(40)==null?"":rset.getString(40);
					
					main_gross_include_transport_tariff=nf.format(Double.parseDouble(main_gross_amt1));
					if(!main_transportation_amount.equals(""))
					{
						main_gross_include_transport_tariff=nf.format(Double.parseDouble(main_gross_include_transport_tariff) + Double.parseDouble(main_transportation_amount));
					}
					if(!main_marketing_margin_amount.equals(""))
					{
						main_gross_include_transport_tariff=nf.format(Double.parseDouble(main_gross_include_transport_tariff) + Double.parseDouble(main_marketing_margin_amount));
					}
					if(!main_other_charges_amount.equals(""))
					{
						main_gross_include_transport_tariff=nf.format(Double.parseDouble(main_gross_include_transport_tariff) + Double.parseDouble(main_other_charges_amount));
					}
					
					Vector VTAX_CODE = new Vector();
					Vector VTAX_DESCR = new Vector();
					Vector VTAX_AMT = new Vector();
					Vector VTAX_BASE_AMT = new Vector();
					Vector VTAX_FACTOR = new Vector();
					
					queryString1="SELECT TAX_CODE,TAX_DESCR,TAX_AMT,TAX_BASE_AMT "
							+ "FROM FMS_DLNG_INV_TAX_DTL "
							+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
							+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
					stmt1=conn.prepareStatement(queryString1);
					stmt1.setString(1, comp_cd);
					stmt1.setString(2, bu_state_tin);
					stmt1.setString(3, fiscal_yr);
					stmt1.setString(4, invoice_seq);
					rset1=stmt1.executeQuery();
					while(rset1.next())
					{
						VTAX_CODE.add(rset1.getString(1)==null?"":rset1.getString(1));
						VTAX_DESCR.add(rset1.getString(2)==null?"":rset1.getString(2));
						VTAX_AMT.add(rset1.getString(3)==null?"":nf.format(rset1.getDouble(3)));
						VTAX_BASE_AMT.add(rset1.getString(4)==null?"":nf.format(rset1.getDouble(4)));
						VTAX_FACTOR.add("");
					}
					rset1.close();
					stmt1.close();
					
					Vector VTEMP_TAX_DTL = new Vector();
					
					VTEMP_TAX_DTL.add(VTAX_CODE);
					VTEMP_TAX_DTL.add(VTAX_DESCR);
					VTEMP_TAX_DTL.add(VTAX_AMT);
					VTEMP_TAX_DTL.add(VTAX_BASE_AMT);
					VTEMP_TAX_DTL.add(VTAX_FACTOR);
					
					VMAIN_MULTI_TAX_STRUCT.add(VTEMP_TAX_DTL);
				}
				rset.close();
				stmt.close();
	        	
	            queryString="SELECT ALLOC_QTY,SALE_PRICE,SALE_PRICE_UNIT,SALE_AMT,EXCHG_RATE_CD,EXCHG_RATE_DT,EXCHG_RATE_VALUE,"
						+ "INVOICE_RAISED_IN,GROSS_AMT,TAX_AMT,TAX_STRUCT_CD,INVOICE_AMT,NET_PAYABLE_AMT,"
						+ "TCS_TDS,TCS_AMT,TCS_FACTOR,TDS_GROSS_AMT,TDS_GROSS_PERCENT "
						+ "FROM FMS_DLNG_INV_CRDR_REF "
						+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? AND INVOICE_SEQ=? AND FINANCIAL_YEAR=?";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, bu_state_tin);
				stmt.setString(3, inv_seq);
				stmt.setString(4, financial_year);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					new_qty_mmbtu=rset.getString(1)==null?"":nf.format(rset.getDouble(1));
					new_price=rset.getString(2)==null?"":nf.format(rset.getDouble(2));
					if(!new_price.equals(""))
					{
						new_price=utilBean.RateNumberFormat(rset.getDouble(2), price_cd);
					}
					new_gross_amt=rset.getString(4)==null?"":nf.format(rset.getDouble(4));
					new_exchang_rate=rset.getString(7)==null?"":nf2.format(rset.getDouble(7));
					new_gross_amt1=rset.getString(9)==null?"":nf.format(rset.getDouble(9));
					new_tax_amt=rset.getString(10)==null?"":nf.format(rset.getDouble(10));
					new_tax_struct_cd=rset.getString(11)==null?"":rset.getString(11);
					new_tax_struct_dtl=utilBean.getTaxDescr(conn, new_tax_struct_cd);
					new_tax_struct_dt="";
					new_invoice_amt=rset.getString(12)==null?"":nf.format(rset.getDouble(12));
					new_net_payable=rset.getString(13)==null?"":nf.format(rset.getDouble(13));
					
					new_applicable_amt=rset.getString(15)==null?"":rset.getString(15);
					new_TCS_factor=rset.getString(16)==null?"":rset.getString(16);
					new_tds_amt=rset.getString(17)==null?"":nf.format(rset.getDouble(17));
					new_tds_factor=rset.getString(18)==null?"":nf.format(rset.getDouble(18));
					
					/*new_transportation_charges=rset.getString(19)==null?"":nf2.format(rset.getDouble(19));
					new_transportation_amount=rset.getString(20)==null?"":nf.format(rset.getDouble(20));
					new_marketing_margin=rset.getString(21)==null?"":nf2.format(rset.getDouble(21));
					new_marketing_margin_amount=rset.getString(22)==null?"":nf.format(rset.getDouble(22));
					new_other_charges=rset.getString(23)==null?"":nf2.format(rset.getDouble(23));
					new_other_charges_amount=rset.getString(24)==null?"":nf.format(rset.getDouble(24));
					
					new_gross_include_transport_tariff=nf.format(Double.parseDouble(new_gross_amt1));
					if(!new_transportation_amount.equals(""))
					{
						new_gross_include_transport_tariff=nf.format(Double.parseDouble(new_gross_include_transport_tariff) + Double.parseDouble(new_transportation_amount));
					}
					if(!new_marketing_margin_amount.equals(""))
					{
						new_gross_include_transport_tariff=nf.format(Double.parseDouble(new_gross_include_transport_tariff) + Double.parseDouble(new_marketing_margin_amount));
					}
					if(!new_other_charges_amount.equals(""))
					{
						new_gross_include_transport_tariff=nf.format(Double.parseDouble(new_gross_include_transport_tariff) + Double.parseDouble(new_other_charges_amount));
					}*/
					
					Vector VTAX_CODE = new Vector();
					Vector VTAX_DESCR = new Vector();
					Vector VTAX_AMT = new Vector();
					Vector VTAX_BASE_AMT = new Vector();
					Vector VTAX_FACTOR = new Vector();
					queryString1="SELECT TAX_CODE,TAX_DESCR,TAX_AMT,TAX_BASE_AMT "
							+ "FROM FMS_DLNG_INV_CRDR_TAX_DTL "
							+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
							+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
					stmt1=conn.prepareStatement(queryString1);
					stmt1.setString(1, comp_cd);
					stmt1.setString(2, bu_state_tin);
					stmt1.setString(3, financial_year);
					stmt1.setString(4, inv_seq);
					rset1=stmt1.executeQuery();
					while(rset1.next())
					{
						VTAX_CODE.add(rset1.getString(1)==null?"":rset1.getString(1));
						VTAX_DESCR.add(rset1.getString(2)==null?"":rset1.getString(2));
						VTAX_AMT.add(rset1.getString(3)==null?"":nf.format(rset1.getDouble(3)));
						VTAX_BASE_AMT.add(rset1.getString(4)==null?"":nf.format(rset1.getDouble(4)));
						VTAX_FACTOR.add("");
					}
					rset1.close();
					stmt1.close();
					
					Vector VTEMP_TAX_DTL = new Vector();
					
					VTEMP_TAX_DTL.add(VTAX_CODE);
					VTEMP_TAX_DTL.add(VTAX_DESCR);
					VTEMP_TAX_DTL.add(VTAX_AMT);
					VTEMP_TAX_DTL.add(VTAX_BASE_AMT);
					VTEMP_TAX_DTL.add(VTAX_FACTOR);
					
					VNEW_MULTI_TAX_STRUCT.add(VTEMP_TAX_DTL);
				}
				rset.close();
				stmt.close();
	            
	            float[] att1_ContactAddrWidths1 = {0.80f,0.10F,0.20F,0.80F};
	   	     	PdfPTable att1_Table1 = new PdfPTable(att1_ContactAddrWidths1);
	            att1_Table1.setWidthPercentage(100);
	            att1_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.addCell(new Phrase(new Chunk("Business Unit: ",black_bold)));
	            
	            att1_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.addCell(new Phrase(new Chunk("",black_bold)));
	            
	            att1_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.addCell(new Phrase(new Chunk("To:",black_bold)));
	
	            att1_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.addCell(new Phrase(new Chunk(""+contact_person_nm+",",black_bold)));
	
				float[] att1_ContactAddrWidths2 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable att1_Table2 = new PdfPTable(att1_ContactAddrWidths2);
	   	     	att1_Table2.setWidthPercentage(100);
	            att1_Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table2.addCell(new Phrase(new Chunk(company_nm,small_black_normal)));
	            
	            att1_Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table2.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table2.addCell(new Phrase(new Chunk(counterparty_nm,small_black_normal)));
	
	            float[] att1_ContactAddrWidths3 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable att1_Table3 = new PdfPTable(att1_ContactAddrWidths3);
	            att1_Table3.setWidthPercentage(100);
	            att1_Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table3.addCell(new Phrase(new Chunk(bu_plantAddress+","+bu_plantCity,small_black_normal)));
	            
	            att1_Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table3.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
	            att1_Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table3.addCell(new Phrase(new Chunk(plantAddress+","+plantCity,small_black_normal)));
	            
	
	            float[] att1_ContactAddrWidths4 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable att1_Table4 = new PdfPTable(att1_ContactAddrWidths4);
	            att1_Table4.setWidthPercentage(100);
	            att1_Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table4.addCell(new Phrase(new Chunk(bu_plantState+" - "+bu_plantPin,small_black_normal)));
	
	            att1_Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table4.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
	            att1_Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table4.addCell(new Phrase(new Chunk(plantState+" - "+plantPin,small_black_normal)));
	            
	            String title_note="ATTACHMENT 1 - "+invdtl+" Detail";
	            
	            PdfPTable title_note_table = new PdfPTable(1);
	            title_note_table.setWidthPercentage(100);
	            title_note_table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            title_note_table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            title_note_table.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            title_note_table.addCell(new Phrase(new Chunk(title_note,big_black_bold)));
	            
	            float[] att1_ContactAddrWidths5 = {0.80F,0.30F,0.30F,0.40F};
	   	     	PdfPTable att1_Table5 = new PdfPTable(att1_ContactAddrWidths5);
	            att1_Table5.setWidthPercentage(100);
	            att1_Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.addCell(new Phrase(new Chunk(invdtl+" Date :",black_bold)));
	
	            att1_Table5.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.addCell(new Phrase(new Chunk(invoice_dt,black_bold)));
	
	            float[] att1_ContactAddrWidths6 = {0.80F,0.30F,0.30F,0.40F};
	   	     	PdfPTable att1_Table6 = new PdfPTable(att1_ContactAddrWidths6);
	            att1_Table6.setWidthPercentage(100);
	            att1_Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.addCell(new Phrase(new Chunk("Payment Due Date :",black_bold)));
	
	            att1_Table6.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.addCell(new Phrase(new Chunk(invoice_due_dt,black_bold)));
	
	            float[] att1_ContactAddrWidths7 = {0.80F,0.10F,0.50F,0.40F};
	   	     	PdfPTable att1_Table7 = new PdfPTable(att1_ContactAddrWidths7);
	            att1_Table7.setWidthPercentage(100);
	            att1_Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk("",black_bold)));
	
	            att1_Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk(company_abbr+" "+invdtl+" No :",black_bold)));
	
	            att1_Table7.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk(invoice_no,black_bold)));
	            
	            att1_Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk("",black_bold)));
	
	            att1_Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk("Invoice Ref :",black_bold)));
	
	            att1_Table7.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk(sel_inv_ref,black_bold)));
	
	            float[] att1_ContactAddrWidths8 = {0.80F,0.20F,0.10F,0.20F};
	   	     	PdfPTable att1_Table8 = new PdfPTable(att1_ContactAddrWidths8);
	   	     	att1_Table8.setWidthPercentage(100);
	            att1_Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table8.addCell(new Phrase(new Chunk("Billing Period : ",black_bold)));
	
	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table8.addCell(new Phrase(new Chunk(""+period_start_dt,black_bold)));
	
	            att1_Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.addCell(new Phrase(new Chunk("to",black_bold)));
	
	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table8.addCell(new Phrase(new Chunk(""+period_end_dt,black_bold)));
	            
	            float[] att1_ContactAddrWidths9 = {0.22F,0.10F,0.22F,0.22F,0.15F};
	   	     	PdfPTable att1_Table9 = new PdfPTable(att1_ContactAddrWidths9);
	   	     	att1_Table9.setWidthPercentage(100);
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.addCell(new Phrase(new Chunk("",small_black_bold)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.addCell(new Phrase(new Chunk("UOM",small_black_bold)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.addCell(new Phrase(new Chunk(sel_inv_ref+" [A]",small_black_bold)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.addCell(new Phrase(new Chunk("Revised Invoice [B]",small_black_bold)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.addCell(new Phrase(new Chunk(invdtl+" [B-A]",small_black_bold)));
	            
	            //
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table9.addCell(new Phrase(new Chunk("Allocated Qty",small_black_bold)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.addCell(new Phrase(new Chunk("MMBTU",small_black_normal)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk(main_qty_mmbtu,small_black_normal)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk(new_qty_mmbtu,small_black_normal)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk(qty_mmbtu,small_black_normal)));
	            
	            //
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table9.addCell(new Phrase(new Chunk("Confirmed Price",small_black_bold)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.addCell(new Phrase(new Chunk(curr,small_black_normal)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk(main_price,small_black_normal)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk(new_price,small_black_normal)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk(price,small_black_normal)));
	            
	            if(!price_cd.equals(invoice_raised_in))
	            {
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.addCell(new Phrase(new Chunk("Gross Amount",small_black_bold)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.addCell(new Phrase(new Chunk(curr,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(main_gross_amt,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(new_gross_amt,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(gross_amt,small_black_normal)));
	            
		            //
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.addCell(new Phrase(new Chunk("Exchange Rate",small_black_bold)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.addCell(new Phrase(new Chunk("INR/USD",small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(main_exchang_rate,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(new_exchang_rate,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(exchang_rate,small_black_normal)));
	            }
	            
	            //
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table9.addCell(new Phrase(new Chunk("Gross Amount",small_black_bold)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.addCell(new Phrase(new Chunk(curr1,small_black_normal)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk(main_gross_amt1,small_black_normal)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk(new_gross_amt1,small_black_normal)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk(gross_amt1,small_black_normal)));
	            
	            if(!transportation_charges.equals(""))
	            {
		            //
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.addCell(new Phrase(new Chunk("Transportation Tariff",small_black_bold)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.addCell(new Phrase(new Chunk("INR/MMBTU",small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(main_transportation_charges,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(new_transportation_charges,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(transportation_charges,small_black_normal)));
		            
		            //
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.addCell(new Phrase(new Chunk("Transportation Tariff Amount",small_black_bold)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.addCell(new Phrase(new Chunk(curr1,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(main_transportation_amount,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(new_transportation_amount,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(transportation_amount,small_black_normal)));
	            }
	            
	            //
	            if(!marketing_margin.equals(""))
	            {
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.addCell(new Phrase(new Chunk("Marketing Margin",small_black_bold)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.addCell(new Phrase(new Chunk("INR/MMBTU",small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(main_marketing_margin,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(new_marketing_margin,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(marketing_margin,small_black_normal)));
		            
		            //
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.addCell(new Phrase(new Chunk("Marketing Margin Amount",small_black_bold)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.addCell(new Phrase(new Chunk(curr1,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(main_marketing_margin_amount,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(new_marketing_margin_amount,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(marketing_margin_amount,small_black_normal)));
	            }
		            
		         //
	            if(!other_charges.equals(""))
	            {
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.addCell(new Phrase(new Chunk("Other Charges",small_black_bold)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.addCell(new Phrase(new Chunk("INR/MMBTU",small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(main_other_charges,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(new_other_charges,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(other_charges,small_black_normal)));
		            
		            //
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.addCell(new Phrase(new Chunk("Other Charges Amount",small_black_bold)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.addCell(new Phrase(new Chunk(curr1,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(main_other_charges_amount,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(new_other_charges_amount,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(other_charges_amount,small_black_normal)));
	            }
	            
	            if(isGrossIncTriff)
	            {
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		            att1_Table9.addCell(new Phrase(new Chunk("Total Gross Amount",small_black_bold)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.addCell(new Phrase(new Chunk(curr1,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(main_gross_include_transport_tariff,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(new_gross_include_transport_tariff,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(gross_include_transport_tariff,small_black_normal)));
	            }
	            
	            //
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table9.addCell(new Phrase(new Chunk("Tax Amount",small_black_bold)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.addCell(new Phrase(new Chunk(curr1,small_black_normal)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk("("+main_tax_struct_dtl+") "+main_tax_amt,small_black_normal)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk("("+new_tax_struct_dtl+") "+new_tax_amt,small_black_normal)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk(tax_amt,small_black_normal)));
	            
	            if(VMAIN_MULTI_TAX_STRUCT.size()>0)
	            {
	        		for(int i=0;i<VMAIN_MULTI_TAX_STRUCT.size();i++)
	        		{
	        			Vector main_temp =(Vector)((Vector)((Vector)VMAIN_MULTI_TAX_STRUCT.elementAt(i)));
	        			
	        			Vector new_temp =(Vector)((Vector)((Vector)VNEW_MULTI_TAX_STRUCT.elementAt(i)));
	        			
	        			Vector temp =(Vector)((Vector)((Vector)VMULTI_TAX_STRUCT.elementAt(i)));
	        			
	        			if(((Vector) main_temp.elementAt(0)).size() > 1)
	        			{
	        				for(int j=0;j<((Vector) main_temp.elementAt(0)).size(); j++)
	        				{
	        					//
	        		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	        		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	        		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	        		            att1_Table9.addCell(new Phrase(new Chunk(""+((Vector) main_temp.elementAt(1)).elementAt(j),small_black_bold)));
	        		
	        		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	        		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	        		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	        		            att1_Table9.addCell(new Phrase(new Chunk(curr1,small_black_normal)));
	        		
	        		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	        		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	        		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	        		            att1_Table9.addCell(new Phrase(new Chunk("("+((Vector) main_temp.elementAt(1)).elementAt(j)+") "+((Vector) main_temp.elementAt(2)).elementAt(j),small_black_normal)));
	        		
	        		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	        		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	        		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	        		            att1_Table9.addCell(new Phrase(new Chunk("("+((Vector) new_temp.elementAt(1)).elementAt(j)+") "+((Vector) new_temp.elementAt(2)).elementAt(j),small_black_normal)));
	        		
	        		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	        		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	        		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	        		            att1_Table9.addCell(new Phrase(new Chunk(""+((Vector) temp.elementAt(2)).elementAt(j),small_black_normal)));
	        				}
	        			}
	        		}
	            }
	                        
	            //
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table9.addCell(new Phrase(new Chunk("Invoice Amount",small_black_bold)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.addCell(new Phrase(new Chunk(curr1,small_black_normal)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk(main_invoice_amt,small_black_normal)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk(new_invoice_amt,small_black_normal)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk(invoice_amt,small_black_normal)));
	            
	            //
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table9.addCell(new Phrase(new Chunk("Net Payable",small_black_bold)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table9.addCell(new Phrase(new Chunk(curr1,small_black_bold)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk(main_net_payable,small_black_bold)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk(new_net_payable,small_black_bold)));
	
	            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table9.addCell(new Phrase(new Chunk(net_payable,small_black_bold)));
	            
	            String reason="Change in ";
				if(!criteri_formula.equals(""))
				{
					String[] split_criteri_formula = criteri_formula.split("#");
					for(int i=0; i<split_criteri_formula.length; i++)
					{
						if(i!=0)
						{
							if((i+1) == split_criteri_formula.length)
							{
								reason+=" and ";
							}
							else
							{
								reason+=", ";
							}
						}
						
						if(split_criteri_formula[i].toString().equals("QTY"))
						{
							reason+="Quantity";
						}
						else if(split_criteri_formula[i].toString().equals("PRICE"))
						{
							reason+="Price";
						}
						else if(split_criteri_formula[i].toString().equals("EXCHG"))
						{
							reason+="Exchange Rate";
						}
						else if(split_criteri_formula[i].toString().equals("TAXP"))
						{
							reason+="Tax %";
						}
					}
				}
	            
	            float[] att1_ContactAddrWidths10 = {0.20F,0.80F};
	   	     	PdfPTable att1_Table10 = new PdfPTable(att1_ContactAddrWidths10);
	   	     	att1_Table10.setWidthPercentage(100);
	   	     	att1_Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	     	att1_Table10.addCell(new Phrase(new Chunk("Reason for "+invdtl+" : ",small_black_bold)));
	   	     	
	   	     	att1_Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	     	att1_Table10.addCell(new Phrase(new Chunk(reason,small_black_normal)));
	   	     	
	   	     	float[] att1_ContactAddrWidths11 = {0.07F,0.93F};
	   	     	PdfPTable att1_Table11 = new PdfPTable(att1_ContactAddrWidths11);
	   	     	att1_Table11.setWidthPercentage(100);
	   	     	att1_Table11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	att1_Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	att1_Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	     	att1_Table11.addCell(new Phrase(new Chunk("Note : ",small_black_bold)));
	   	     	
	   	     	att1_Table11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	att1_Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	att1_Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	     	att1_Table11.addCell(new Phrase(new Chunk("Negative(-) Value indicate Credit and Postive(+) Value indicate Debit.",small_black_normal)));
	            
	            document.add(LogoTable);
	            document.add(att1_Table1);  
	            document.add(att1_Table2);  
	            document.add(att1_Table3);  
	            document.add(att1_Table4);
	            document.add(new Paragraph("              "));
	            document.add(title_note_table);
	            document.add(new Paragraph("              "));
	            document.add(att1_Table5);  
	            document.add(att1_Table6);  
	            document.add(att1_Table7);  
	            document.add(att1_Table8);
	            document.add(new Paragraph("              "));
	            document.add(att1_Table9);
	            document.add(new Paragraph("              "));
	            document.add(att1_Table10);
	            document.add(att1_Table11);
				
	            document.close();
	            
	            File isPDFexist = new File(path);
				if(isPDFexist.exists())
				{
					String invoice_title="";
					int update_flag=0;
					int pdf_entry=0;
					
					int cont=0;
					queryString="UPDATE FMS_DLNG_INVOICE_MST SET PDF_INV_DTL=? ";
						if(print_pdf_type.equals("O"))
						{
							queryString+= ",PRINT_BY_ORI=?,PRINT_DT_ORI=SYSDATE ";
						}
						else if(print_pdf_type.equals("T"))
						{
							queryString+= ",PRINT_BY_TRI=?,PRINT_DT_TRI=SYSDATE ";
						}
						else if(print_pdf_type.equals("D"))
						{
							queryString+= ",PRINT_BY_DUP=?,PRINT_DT_DUP=SYSDATE ";
						}
						queryString+= "WHERE COMPANY_CD=? AND FINANCIAL_YEAR=? "
								+ "AND INVOICE_SEQ=? AND BU_STATE_TIN=? AND INV_FLAG=? ";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(++cont, print_pdf_type);
					if(print_pdf_type.equals("O"))
					{
						stmt.setString(++cont, emp_cd);
					}
					else if(print_pdf_type.equals("T"))
					{
						stmt.setString(++cont, emp_cd);
					}
					else if(print_pdf_type.equals("D"))
					{
						stmt.setString(++cont, emp_cd);
					}
					stmt.setString(++cont, comp_cd);
					stmt.setString(++cont, financial_year);
					stmt.setString(++cont, inv_seq);
					stmt.setString(++cont, bu_state_tin);
					stmt.setString(++cont, inv_flag);
					update_flag=stmt.executeUpdate();
					stmt.close();
					
					int count=0;
			        queryString1="SELECT COUNT(*) "
			        		+ "FROM FMS_DLNG_INV_FILE_DTL "
			        		+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
			        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE=?";
			        stmt1=conn.prepareStatement(queryString1);
			        stmt1.setString(1, comp_cd);
			        stmt1.setString(2, bu_state_tin);
			        stmt1.setString(3, inv_seq);
			        stmt1.setString(4, financial_year);
			        stmt1.setString(5, print_pdf_type);
			        rset1=stmt1.executeQuery();
			        if(rset1.next())
			        {
			        	count=rset1.getInt(1);
			        }
			        rset1.close();
			        stmt1.close();
			        
			        if(count > 0)
			        {
			        	queryString1="UPDATE FMS_DLNG_INV_FILE_DTL SET FILE_NAME=?,MODIFY_BY=?,MODIFY_DT=SYSDATE "
			        			+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
				        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE=?";
			        	stmt1=conn.prepareStatement(queryString1);
			        	stmt1.setString(1, file_nm);
			        	stmt1.setString(2, emp_cd);
			        	stmt1.setString(3, comp_cd);
			 	        stmt1.setString(4, bu_state_tin);
			 	        stmt1.setString(5, inv_seq);
			 	        stmt1.setString(6, financial_year);
			 	        stmt1.setString(7, print_pdf_type);
			 	        pdf_entry=stmt1.executeUpdate();
			        	
			        	stmt1.close();
			        }
			        else
			        {
			        	queryString1="INSERT INTO FMS_DLNG_INV_FILE_DTL(COMPANY_CD,BU_STATE_TIN,INVOICE_SEQ,FINANCIAL_YEAR,PDF_TYPE,"
			        			+ "FILE_NAME,ENT_BY,ENT_DT) "
			        			+ "VALUES(?,?,?,?,?,"
			        			+ "?,?,SYSDATE)";
			        	stmt1=conn.prepareStatement(queryString1);
			        	stmt1.setString(1, comp_cd);
			 	        stmt1.setString(2, bu_state_tin);
			 	        stmt1.setString(3, inv_seq);
			 	        stmt1.setString(4, financial_year);
			 	        stmt1.setString(5, print_pdf_type);
			 	        stmt1.setString(6, file_nm);
			        	stmt1.setString(7, emp_cd);
			        	pdf_entry=stmt1.executeUpdate();
			        	
			        	stmt1.close();
			        }
			        

			        String tempRePrintMsg="";
			        String re_printFlag="";
			        String re_print_Seq_No="";
			        queryString2="SELECT FLAG,SEQ_NO "
			        		+ "FROM FMS_INVOICE_CHANGE_DTL A "
			        		+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
							+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND SEGMENT=? AND CHANGE_TYPE=? "
							+ "AND SEQ_NO=(SELECT MAX(B.SEQ_NO) FROM FMS_INVOICE_CHANGE_DTL B WHERE A.COMPANY_CD=B.COMPANY_CD "
							+ "AND A.BU_STATE_TIN=B.BU_STATE_TIN AND A.INVOICE_SEQ=B.INVOICE_SEQ AND A.FINANCIAL_YEAR=B.FINANCIAL_YEAR "
							+ "AND A.SEGMENT=B.SEGMENT AND A.CHANGE_TYPE=B.CHANGE_TYPE)";
			        stmt2=conn.prepareStatement(queryString2);
			        stmt2.setString(1, comp_cd);
			        stmt2.setString(2, bu_state_tin);
			        stmt2.setString(3, inv_seq);
			        stmt2.setString(4, financial_year);
			        stmt2.setString(5, "DLNG");
			        stmt2.setString(6, "REPRINT_PDF");
			        rset2=stmt2.executeQuery();
			        if(rset2.next())
			        {
			        	re_printFlag=rset2.getString(1)==null?"":rset2.getString(1);
			        	re_print_Seq_No=rset2.getString(2)==null?"":rset2.getString(2);
			        }
			        rset2.close();
			        stmt2.close();
			        
			        if(re_printFlag.equals("A"))
			        {
			        	tempRePrintMsg="Re-Printed ";
			        	int reprint_pdf_count=0;
			        	queryString2="SELECT COUNT(*) "
				        		+ "FROM FMS_DLNG_INV_FILE_DTL "
				        		+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
				        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE IN ('O','D','T')";
				        stmt2=conn.prepareStatement(queryString2);
				        stmt2.setString(1, comp_cd);
				        stmt2.setString(2, bu_state_tin);
				        stmt2.setString(3, inv_seq);
				        stmt2.setString(4, financial_year);
				        rset2=stmt2.executeQuery();
				        if(rset2.next())
				        {
				        	reprint_pdf_count=rset2.getInt(1);
				        }
				        rset2.close();
				        stmt2.close();
				        
				        if(reprint_pdf_count==3)
				        {
				        	queryString2="UPDATE FMS_INVOICE_CHANGE_DTL SET FLAG=? "
				    				+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
									+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
									+ "AND SEGMENT=? AND CHANGE_TYPE=? AND FLAG=? AND SEQ_NO=? ";
				    		stmt2=conn.prepareStatement(queryString2);
				    		stmt2.setString(1, "P");
					        stmt2.setString(2, comp_cd);
					        stmt2.setString(3, bu_state_tin);
					        stmt2.setString(4, inv_seq);
					        stmt2.setString(5, financial_year);
					        stmt2.setString(6, "DLNG");
					        stmt2.setString(7, "REPRINT_PDF");
					        stmt2.setString(8, re_printFlag);
					        stmt2.setString(9, re_print_Seq_No);
					        stmt2.executeUpdate();
							
							stmt2.close();
				        }
			        }
			        
			        if(re_printFlag.equals(""))
			        {
				        if(update_flag > 0 && pdf_entry > 0 && print_pdf_type.equals("O") && !contract_type.equals("W") && inv_flag.equals("DR"))
				        {	
				        	double hold_amt=utilBean.getInvoiceHoldAmount(conn,comp_cd,counterparty_cd,agmt_no,cont_no,contract_type,plant_seq,bu_plant_seq, 
									temp_period_end_dt,tax_struct_dtl,gross_amt1,bu_state_tin,temp_invoice_dt);
				        	if(hold_amt > 0)
				        	{
				        		queryString="UPDATE FMS_DLNG_INVOICE_MST SET HOLD_AMT=? "
									+ "WHERE COMPANY_CD=? AND FINANCIAL_YEAR=? "
									+ "AND INVOICE_SEQ=? AND BU_STATE_TIN=? ";
				        		cont=0;
								stmt=conn.prepareStatement(queryString);
								stmt.setString(++cont, nf.format(hold_amt));
								stmt.setString(++cont, comp_cd);
								stmt.setString(++cont, financial_year);
								stmt.setString(++cont, inv_seq);
								stmt.setString(++cont, bu_state_tin);
								stmt.executeUpdate();
								stmt.close();
				        	}
				        }
					}
			        
			        if(pdf_entry == 0 || update_flag == 0)
			        {
			        	conn.rollback();
			        	deletePdfFile(path);
			        	msg="Failed! - "+invdtl+" for "+counterparty_abbr+" PDF for "+dealMap+" Generation Failed for "+temp_period_end_dt+"!";
			        	msg_type="E";
			        }
			        else
			        {
			        	conn.commit();
			        	msg = "Successful! - "+invdtl+" for "+counterparty_abbr+" PDF "+file_nm+" for "+dealMap+" Generated Successfully for "+temp_period_end_dt+"!";
			        	msg_type="S";
			        }
				}
				else
				{
					msg="Failed! - "+invdtl+" for "+counterparty_abbr+" PDF for "+dealMap+" Generation Failed for "+temp_period_end_dt+"!";
					msg_type="E";
				}
			}
		}
		catch(Exception e)
		{
			conn.rollback();
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
			
			document.close();
			deletePdfFile(path);
			
			msg="Error in Exception! - "+invdtl+" for "+counterparty_abbr+" PDF Generation Failed!";
			msg_type="E";	
		}
		finally
		{
			document.close();
		}
		
		try
		{
			new com.etrm.fms.util.InfoLogger().InsertInfoLogger(emp_cd, comp_cd,emp_nm, ip, form_id, form_nm,mod_cd,mod_nm, "", "", msg);  	
		}
		catch(Exception infoLogger)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, infoLogger);
		}
	}
	
	public void printPdfFileForDLNG_F_FlowInvoice() throws SQLException
	{
		String function_nm="printPdfFileForDLNG_F_FlowInvoice()";
		
		String emp_nm ="";
		String ip = "";
		msg="";
		//String msg_content="";
		String path ="";
		String counterparty_abbr="";
		
		Rectangle pageSize = new Rectangle(595, 842);
		pageSize.setBackgroundColor(BaseColor.WHITE);
		Document document = new Document(pageSize);
		try
		{
			HttpSession session = request.getSession();
			emp_nm = (String)session.getAttribute("emp_nm")==null?"":(String)session.getAttribute("emp_nm");
			ip = (String)session.getAttribute("ip")==null?"":(String)session.getAttribute("ip");
			
			String company_nm = ""+session.getAttribute("comp_nm")==null?"":""+session.getAttribute("comp_nm");
			String company_abbr = ""+session.getAttribute("comp_abbr")==null?"":""+session.getAttribute("comp_abbr");

			String counterparty_nm=""+utilBean.getCounterpartyName(conn,counterparty_cd);
			counterparty_abbr=""+utilBean.getCounterpartyABBR(conn,counterparty_cd);

			if(!mapping_id.equals("") && !mapping_id.equals("0"))
			{
				String[] temp = mapping_id.split("-");
				contract_type=temp[0];
				agmt_no=temp[1];
				agmt_rev_no=temp[2];
				cont_no=temp[3];
				cont_rev_no=temp[4];
				if(temp.length==6)
				{
					cargo_no=temp[5];
				}
			}
			
			String inv_nm="";
            /*if(inv_type.equals("CR"))
			{
            	inv_nm="Credit Note";
			}
			else if(inv_type.equals("DR"))
			{
				inv_nm="Debit Note";
			}
			else if(inv_type.equals("LP"))
			{
				inv_nm="Late Payment Invoice";
			}
			else if(inv_type.equals("OR"))
			{
				inv_nm="Other";
			}*/
			
			String inv_dt="";
			String temp_inv_dt="";
			String inv_due_dt="";
			String note="";
			String bu_contact_person_cd="";
			String inv_no="";
			String contact_person_cd="";
			queryString="SELECT TO_CHAR(PERIOD_START_DT,'DD/MM/YYYY'),TO_CHAR(PERIOD_END_DT,'DD/MM/YYYY'),"
					+ "BU_UNIT,ADDR_FLAG,TO_CHAR(INVOICE_DT,'DD-MON-YY'),TO_CHAR(DUE_DT,'DD-MON-YY'),"
					+ "NOTE,OTHER_INV_STR,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),CONTACT_PERSON_CD,BU_CONTACT_PERSON_CD,INVOICE_NO "
					+ "FROM FMS_DLNG_FFLOW_INV_MST "
					+ "WHERE COMPANY_CD=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
					+ "AND INVOICE_TYPE=? AND FINANCIAL_YEAR=?";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, inv_seq);
			stmt.setString(3, bu_state_tin);
			stmt.setString(4, inv_type);
			stmt.setString(5, financial_year);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				period_start_dt=rset.getString(1)==null?"":rset.getString(1);
				period_end_dt=rset.getString(2)==null?"":rset.getString(2);
				bu_plant_seq=rset.getString(3)==null?"":rset.getString(3);
				
				String addressType=rset.getString(4)==null?"":rset.getString(4);
				if(!addressType.equals("R") && !addressType.equals("B") && !addressType.equals("C"))
				{
					plant_seq=addressType.substring(1,addressType.length());
				}
				inv_dt=rset.getString(5)==null?"":rset.getString(5);
				inv_due_dt=rset.getString(6)==null?"":rset.getString(6);
				note=rset.getString(7)==null?"":rset.getString(7);

				//if(inv_type.equals("OR"))
				{
					inv_nm=rset.getString(8)==null?"":rset.getString(8);
				}
				
				temp_inv_dt=rset.getString(9)==null?"":rset.getString(9);
				contact_person_cd=rset.getString(10)==null?"":rset.getString(10);
				bu_contact_person_cd=rset.getString(11)==null?"":rset.getString(11);

				inv_no=rset.getString(12)==null?"":rset.getString(12);
			}
			rset.close();
			stmt.close();
			
			String appPath = request.getServletContext().getRealPath("");

			String main_folder="";
			if(!comp_cd.equals(""))
			{
				main_folder=CommonVariable.work_dir+comp_cd;
			}

			String sub_folder="unsigned_pdf";
			String sub_folder2="dlng_freeflow_invoice";
			String temp_path=appPath+File.separator+main_folder+File.separator+sub_folder+File.separator+sub_folder2;
			File main_folderDir = new File(temp_path);
	        if(!main_folderDir.exists())
	        {
	        	main_folderDir.mkdirs();
	        }

	        String monthofinv = dateUtil.getMonthNameMON(period_end_dt);
	        String dtPeriod="";
	        if(!period_start_dt.equals("") && !period_end_dt.equals(""))
	        {
	        	dtPeriod=period_start_dt.substring(0,2);
	        	dtPeriod+="-";
	        	dtPeriod+=period_end_dt.substring(0,2);
	        }

	        String contNm="";
	        String invNm="";
	        if(contract_type.equals("W"))
	        {
	        	contNm="DLNG IGX";
	        	invNm="INVOICE";
	        }
	        else if(contract_type.equals("E"))
	        {
	        	contNm="DLNG LOA";
	        	invNm="INVOICE";
	        }
	        else if(contract_type.equals("F"))
	        {
	        	contNm="DLNG SN";
	        	invNm="INVOICE";
	        }
	        else if(contract_type.equals("O"))
	        {
	        	contNm="Period";
	        	invNm="LTCORA_INVOICE";
	        }
	        else if(contract_type.equals("Q"))
	        {
	        	contNm="CN";
	        	invNm="LTCORA_INVOICE";
	        }
	        
	        String print_pdf_type_nm="ORIGINAL";
			if(print_pdf_type.equals("O"))
			{
				print_pdf_type_nm="ORIGINAL";
			}
			else if(print_pdf_type.equals("D"))
			{
				print_pdf_type_nm="DUPLICATE";
			}
			else if(print_pdf_type.equals("T"))
			{
				print_pdf_type_nm="TRIPLICATE";
			}
			
	        if(is_print.equals("1"))
	        {
	        	//file_nm=print_pdf_type+"-"+inv_type+"-"+company_abbr+"-"+invNm+"-"+contNm+inv_seq+"-"+counterparty_abbr+"_"+financial_year+"_"+monthofinv.trim()+"_"+dtPeriod+".pdf";
	        	file_nm=print_pdf_type+"-"+company_abbr+"_"+"DLNG"+"_"+inv_type+"-"+inv_no+".pdf";
	        }
	        else
	        {
	        	file_nm="temp.pdf";
	        }
	        
	        file_nm = file_nm.replace('/', '_');
	        
			path = appPath+File.separator+main_folder+File.separator+sub_folder+File.separator+sub_folder2+File.separator+file_nm;
			
			PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream(path));

			document.open();
			document.setPageSize(pageSize);
            document.newPage();

            String context_nm = request.getContextPath();
			String server_nm = request.getServerName();
			String server_port = ""+request.getServerPort();

			file_url = CommonVariable.app_protocol+"://"+server_nm+":"+server_port+context_nm;

			Font small_black_normal = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL, BaseColor.BLACK);
			Font small_black_normal_10 = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);
			Font small_black_normal_14 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.NORMAL, BaseColor.BLACK);
			Font small_black_normal_12 = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL, BaseColor.BLACK);
            Font small_black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, BaseColor.BLACK);
            Font black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, BaseColor.BLACK);
            Font black_bold1 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.BOLD, BaseColor.BLACK);
            
            PdfPCell company_logo_cell = new PdfPCell();
            if(!comp_logo.equals(""))
            {
            	String file_path = request.getRealPath("/"+CommonVariable.company_logo_path+"/"+comp_logo);
            	Image company_logo = Image.getInstance(file_path);
	            company_logo.setBorder(Rectangle.NO_BORDER);
	            company_logo.scaleAbsolute(44,40);
	            company_logo_cell = new PdfPCell(company_logo,false);
	            company_logo_cell.setBorder(Rectangle.NO_BORDER);
	            company_logo_cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            }
            
            float[] Contact1 = {0.50f};
   	     	PdfPTable LogoTable = new PdfPTable(Contact1);
   	     	LogoTable.setWidthPercentage(100);
   	     	LogoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	LogoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
   	     	LogoTable.addCell(company_logo_cell);

            float[] ContactAddrWidths = {0.100f};
   	     	PdfPTable Table = new PdfPTable(ContactAddrWidths);
   	     	Table.setWidthPercentage(100);
   	     	Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
   	  		Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
   	  		Table.addCell(new Phrase(new Chunk(print_pdf_type_nm,small_black_normal_10)));
            

            float[] ContactAddrWidths1 = {0.100f};
   	     	PdfPTable Table1 = new PdfPTable(ContactAddrWidths1);
            Table1.setWidthPercentage(100);
            Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table1.addCell(new Phrase(new Chunk(company_nm,black_bold1)));

            String contRef="";
			String signingDt="";
			String agmtSigningDt="";
			String irn_no="";
			String qr_code="";
			
			if(contract_type.equals("O") || contract_type.equals("Q"))
			{
				queryString="SELECT A.CONT_REF_NO,TO_CHAR(A.DDA_DT,'DD-MON-YY'),A.CONT_REF_NO,B.SHIP_CD,B.BOE_NO,TO_CHAR(B.BOE_DT,'DD-MON-YY'),TO_CHAR(SIGNING_DT,'DD-MON-YY'),"
						+ "B.CSOC_QTY,A.MDCQ_PERCENTAGE "
						+ "FROM FMS_LTCORA_CONT_MST A,"
							+ "FMS_LTCORA_CONT_CARGO_DTL B "
						+ "WHERE A.COMPANY_CD=? AND A.COUNTERPARTY_CD=? AND A.BUY_SALE=? "
						+ "AND A.AGMT_NO=? AND A.AGMT_TYPE=? AND A.CONT_NO=? AND A.CONTRACT_TYPE=? AND B.CARGO_NO=? "
						+ "AND A.CONT_REV = (SELECT MAX(B.CONT_REV) FROM FMS_LTCORA_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
						+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE AND A.BUY_SALE=B.BUY_SALE AND A.AGMT_TYPE=B.AGMT_TYPE) "
						+ ""
						+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO "
						+ "AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV AND A.CONTRACT_TYPE=B.CONTRACT_TYPE AND A.BUY_SALE=B.BUY_SALE AND A.AGMT_TYPE=B.AGMT_TYPE ";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty_cd);
				stmt.setString(3, "C");
				stmt.setString(4, agmt_no);
				stmt.setString(5, "A");
				stmt.setString(6, cont_no);
				stmt.setString(7, contract_type);
				stmt.setString(8, cargo_no);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					contRef=rset.getString(1)==null?"":rset.getString(1);
					//dda_dt=rset.getString(2)==null?"":rset.getString(2);
					//cargoRef=rset.getString(3)==null?"":rset.getString(3);
					
					String ship_cd=rset.getString(4)==null?"":rset.getString(4);
					//ship_nm=utilBean.getShipName(conn,ship_cd);
					//boe_number = rset.getString(5)==null?"":rset.getString(5);
					//boe_date=rset.getString(6)==null?"":rset.getString(6);
					
					signingDt=rset.getString(7)==null?"":rset.getString(7);
					/*dcq=nf.format(rset.getDouble(8));
					mdcq_percentage=rset.getDouble(9);
					if(mdcq_percentage==0)
					{
						mdcq_percentage=100;
					}*/
				}
				rset.close();
				stmt.close();
				
				queryString1="SELECT TO_CHAR(SIGNING_DT,'DD-MON-YY')  "
						+ "FROM FMS_LTCORA_AGMT_MST A "
						+ "WHERE COMPANY_CD=? AND AGMT_TYPE=? "
						+ "AND AGMT_NO=? AND COUNTERPARTY_CD=? AND BUY_SALE=? "
						+ "AND AGMT_REV = (SELECT MAX(AGMT_REV) FROM FMS_LTCORA_AGMT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_TYPE=B.AGMT_TYPE AND A.BUY_SALE=B.BUY_SALE) ";
				stmt1=conn.prepareStatement(queryString1);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, "A");
				stmt1.setString(3, agmt_no);
				stmt1.setString(4, counterparty_cd);
				stmt1.setString(5, "C");
				rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					agmtSigningDt=rset1.getString(1)==null?"":rset1.getString(1);
				}
				rset1.close();
				stmt1.close();
				
				queryString1="SELECT IRN_NO,SIGN_QR_CODE "
						+ "FROM FMS_INVOICE_IRN_DTL "
						+ "WHERE COMPANY_CD=? AND INVOICE_NO=? ";
				stmt1=conn.prepareStatement(queryString1);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, inv_no);
				rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					irn_no=rset1.getString(1)==null?"":rset1.getString(1);
					qr_code=rset1.getString(2)==null?"":rset1.getString(2);
				}
				rset1.close();
				stmt1.close();
			}
			else
			{
				queryString="SELECT CONT_REF_NO,TO_CHAR(SIGNING_DT,'DD-MON-YY'),TRADE_REF_NO  "
						+ "FROM FMS_SUPPLY_CONT_MST A "
						+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE=? "
						+ "AND CONT_NO=? AND AGMT_NO=? AND COUNTERPARTY_CD=? "
						+ "AND CONT_REV = (SELECT MAX(CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
						+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) ";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, contract_type);
				stmt.setString(3, cont_no);
				stmt.setString(4, agmt_no);
				stmt.setString(5, counterparty_cd);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					contRef=rset.getString(1)==null?"":rset.getString(1);
					signingDt=rset.getString(2)==null?"":rset.getString(2);
					
					String trade_ref=rset.getString(3)==null?"":rset.getString(3);
					if(contract_type.equals("W"))
					{
						contRef=trade_ref;
					}
				}
				rset.close();
				stmt.close();
				
				if(contract_type.equals("F"))
				{
					queryString="SELECT TO_CHAR(SIGNING_DT,'DD-MON-YY')  "
							+ "FROM FMS_AGMT_MST A "
							+ "WHERE COMPANY_CD=? AND AGMT_TYPE=? "
							+ "AND AGMT_NO=? AND COUNTERPARTY_CD=? "
							+ "AND AGMT_REV = (SELECT MAX(AGMT_REV) FROM FMS_AGMT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
							+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_TYPE=B.AGMT_TYPE) ";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(1, comp_cd);
					stmt.setString(2, "D");
					stmt.setString(3, agmt_no);
					stmt.setString(4, counterparty_cd);
					rset=stmt.executeQuery();
					if(rset.next())
					{
						agmtSigningDt=rset.getString(1)==null?"":rset.getString(1);
					}
					rset.close();
					stmt.close();
				}
			}

			float[] ContactAddrWidths2 = {0.100f};
   	     	PdfPTable Table2 = new PdfPTable(ContactAddrWidths2);
            Table2.setWidthPercentage(100);
            Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table2.addCell(new Phrase(new Chunk(""+inv_nm,small_black_normal_12)));

            if(contract_type.equals("Q") || contract_type.equals("O"))
            {
            	if(!inv_type.equals("CCR") && !inv_type.equals("CDR"))
            	{
	            	Table2.setWidthPercentage(100);
	                Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	                Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table2.addCell(new Phrase(new Chunk("Tax Invoice issued under Rule 46 of the Central Goods and Services Tax Rules, 2017",small_black_normal_10)));
            	}
            }
            
			period_start_dt=dateUtil.getDateFormatDD_MOM_YY(period_start_dt);
			period_end_dt=dateUtil.getDateFormatDD_MOM_YY(period_end_dt);
			
			String info ="In respect of "; 
			if(contract_type.equals("F")){
				info+="Supply Notice ("+contRef+") executed on "+signingDt+" pursuant to Framework Gas Agreement executed on "+agmtSigningDt+"";
			}else if(contract_type.equals("E")){
				info+="Letter of Agreement ("+contRef+") executed on "+signingDt; 
			}else if(contract_type.equals("W")){ 
				info+="Exchange Transaction ("+contRef+") executed on "+signingDt;
			}else if(contract_type.equals("Q")){
				//info+="Period ("+contRef+") executed on "+signingDt+" pursuant to Framework LTCORA Agreement executed on "+agmtSigningDt+"";
				info+="LTCORA Agreement executed on "+agmtSigningDt+"";
			}else if(contract_type.equals("O")){
				//info+="CN ("+contRef+") executed on "+signingDt+" pursuant to Framework LTCORA Agreement executed on "+agmtSigningDt+"";
				info+="LTCORA Agreement executed on "+agmtSigningDt+" & CN ("+contRef+") executed on "+signingDt+"";
			} 
			info+="\nbetween "+company_nm+" and "+counterparty_nm;

            float[] ContactAddrWidths3 = {0.100f};
   	     	PdfPTable Table3 = new PdfPTable(ContactAddrWidths3);
            Table3.setWidthPercentage(100);
            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table3.addCell(new Phrase(new Chunk(info,small_black_normal)));
            
            HashMap bu_plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "B", comp_cd, bu_plant_seq);
            String bu_plantAddress=""+bu_plant_detail.get("plant_address");
            String bu_plantCity=""+bu_plant_detail.get("plant_city");
            String bu_plantState=""+bu_plant_detail.get("plant_state");
            String bu_plantPin=""+bu_plant_detail.get("plant_pin");
			String bu_plantNm=""+bu_plant_detail.get("plant_name");
			
			HashMap plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "C", counterparty_cd, plant_seq);
			String plantAddress=""+plant_detail.get("plant_address");
			String plantCity=""+plant_detail.get("plant_city");
			String plantState=""+plant_detail.get("plant_state");
			String plantPin=""+plant_detail.get("plant_pin");
			
			String contact_person_nm="";
			String bu_contact_person_nm="";
			
			queryString="SELECT CONTACT_PERSON "
					+ "FROM FMS_ENTITY_CONTACT_MST A "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND ENTITY=? AND SEQ_NO=? AND ADDR_FLAG=? "
					+ "AND TYPE=? "
					+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO "
					+ "AND EFF_DT <= TO_DATE(?,'DD/MM/YYYY') AND A.TYPE=B.TYPE)";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, "C");
			stmt.setString(4, contact_person_cd);
			stmt.setString(5, "P"+plant_seq);
			stmt.setString(6, "DLNG");
			stmt.setString(7, temp_inv_dt);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				contact_person_nm=rset.getString(1)==null?"":rset.getString(1);
			}
			rset.close();
			stmt.close();
			
			queryString="SELECT CONTACT_PERSON "
					+ "FROM FMS_ENTITY_CONTACT_MST A "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND ENTITY=? AND SEQ_NO=? AND ADDR_FLAG=? "
					+ "AND TYPE=? "
					+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO "
					+ "AND EFF_DT <= TO_DATE(?,'DD/MM/YYYY') AND A.TYPE=B.TYPE)";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, comp_cd);
			stmt.setString(3, "B");
			stmt.setString(4, bu_contact_person_cd);
			stmt.setString(5, "P"+bu_plant_seq);
			stmt.setString(6, "DLNG");
			stmt.setString(7, temp_inv_dt);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				bu_contact_person_nm=rset.getString(1)==null?"":rset.getString(1);
			}
			rset.close();
			stmt.close();

            float[] ContactAddrWidths4 = {0.80f,0.10F,0.20F,0.80F};
   	     	PdfPTable Table4 = new PdfPTable(ContactAddrWidths4);
   	     	Table4.setWidthPercentage(100);
   	     	Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
   	     	Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            //Table4.addCell(new Phrase(new Chunk("Business Unit: "+bu_plantNm,black_bold)));
   	     	Table4.addCell(new Phrase(new Chunk("Business Unit: ",black_bold)));
            
            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table4.addCell(new Phrase(new Chunk("",black_bold)));
            
            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table4.addCell(new Phrase(new Chunk("To:",black_bold)));

            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table4.addCell(new Phrase(new Chunk(""+contact_person_nm+",",black_bold)));

            float[] ContactAddrWidths5 = {0.80f,0.30F,0.80F};
   	     	PdfPTable Table5 = new PdfPTable(ContactAddrWidths5);
            Table5.setWidthPercentage(100);
            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table5.addCell(new Phrase(new Chunk(company_nm,small_black_normal)));
            
            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table5.addCell(new Phrase(new Chunk("",small_black_normal)));

            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table5.addCell(new Phrase(new Chunk(counterparty_nm,small_black_normal)));

            float[] ContactAddrWidths6 = {0.80f,0.30F,0.80F};
   	     	PdfPTable Table6 = new PdfPTable(ContactAddrWidths6);
            Table6.setWidthPercentage(100);
            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table6.addCell(new Phrase(new Chunk(bu_plantAddress+","+bu_plantCity,small_black_normal)));

            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table6.addCell(new Phrase(new Chunk("",small_black_normal)));
            
            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table6.addCell(new Phrase(new Chunk(plantAddress+","+plantCity,small_black_normal)));

            float[] ContactAddrWidths7 = {0.80f,0.30F,0.80F};
   	     	PdfPTable Table7 = new PdfPTable(ContactAddrWidths7);
            Table7.setWidthPercentage(100);
            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table7.addCell(new Phrase(new Chunk(bu_plantState+" - "+bu_plantPin,small_black_normal)));

            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table7.addCell(new Phrase(new Chunk("",small_black_normal)));
           
            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table7.addCell(new Phrase(new Chunk(plantState+" - "+plantPin,small_black_normal)));
                        
			String inv_raised="";
			String cuurency_nm ="";
			String sales_amt="";
			String echng_rate="";
			String gross_amt="";
			String tax_amt="";
			String inv_amt="";
			String adj_amt="";
			String net_amt="";
			String amount_in_word="";
			String link_invoice_ref="";
			String tax_struct_info="";
			String tax_struct_cd="";
			String tax_struct_dt="";
			String tax_struct_dtl="";
			String tcs_tds="";
			String tcs_amt="";
			String tcs_struct_info="";
			String tcs_struct_cd="";
			String tcs_struct_dt="";
			String inv_cetegory="";
			String sac_no="";

			queryString="SELECT INVOICE_RAISED_IN,GROSS_AMT_USD,EXCHG_RATE_VALUE,GROSS_AMT_INR,TAX_AMT,INVOICE_AMT,ADJUST_AMT,NET_PAYABLE_AMT,"
					+ "AMT_WORD,LINKED_INVOICE,TAX_STRUCT_CD,TO_CHAR(TAX_EFF_DT,'DD/MM/YYYY'),TCS_TDS,TCS_AMT,TCS_STRUCT_CD,TO_CHAR(TCS_EFF_DT,'DD/MM/YYYY'),INVOICE_CATEGORY,"
					+ "SAC_CD "
					+ "FROM FMS_DLNG_FFLOW_INV_MST "
					+ "WHERE COMPANY_CD=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
					+ "AND INVOICE_TYPE=? AND FINANCIAL_YEAR=? ";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, inv_seq);
			stmt.setString(3, bu_state_tin);
			stmt.setString(4, inv_type);
			stmt.setString(5, financial_year);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				inv_raised=rset.getString(1)==null?"":rset.getString(1);
				cuurency_nm = utilBean.getRateUnitNm(conn,inv_raised);
				sales_amt=rset.getString(2)==null?"":rset.getString(2);
				echng_rate=rset.getString(3)==null?"":rset.getString(3);
				gross_amt=rset.getString(4)==null?"":rset.getString(4);
				tax_amt=rset.getString(5)==null?"":rset.getString(5);
				inv_amt=rset.getString(6)==null?"":rset.getString(6);
				adj_amt=rset.getString(7)==null?"":rset.getString(7);
				net_amt=rset.getString(8)==null?"":rset.getString(8);
				amount_in_word=rset.getString(9)==null?"":rset.getString(9);
				link_invoice_ref=rset.getString(10)==null?"":rset.getString(10);
				tax_struct_cd =rset.getString(11)==null?"":rset.getString(11);
				tax_struct_dt =rset.getString(12)==null?"":rset.getString(12);
				tax_struct_dtl=utilBean.getTaxDescr(conn, tax_struct_cd);
				
				tcs_tds =rset.getString(13)==null?"":rset.getString(13);
				tcs_amt =rset.getString(14)==null?"":nf.format(rset.getDouble(14));
				tcs_struct_cd =rset.getString(15)==null?"":rset.getString(15);
				tcs_struct_dt =rset.getString(16)==null?"":rset.getString(16);

				inv_cetegory =rset.getString(17)==null?"":rset.getString(17);
				sac_no =rset.getString(18)==null?"":rset.getString(18);
				
				tax_struct_info=utilBean.getTaxDescr(conn,tax_struct_cd);
				tcs_struct_info=utilBean.getTaxDescr(conn,tcs_struct_cd);
			}
			rset.close();
			stmt.close();
			
            String tax_info="";
            String bu_tax_info="";
            
            if(contract_type.equals("O") || contract_type.equals("Q"))
			{
				tax_info="State : "+plantState;
				tax_info+="\nState Code : "+utilBean.getState_TIN(conn, comp_cd, counterparty_cd, "C", plant_seq);
				
				queryString = "SELECT A.STAT_NO, TO_CHAR(A.EFF_DT,'DD/MM/YYYY'), B.STAT_NM "
						+ "FROM FMS_COUNTERPARTY_PLANT_TAX A, FMS_GOVT_STAT_TAX B "
						+ "WHERE A.COUNTERPARTY_CD=? AND A.ENTITY=? "
						+ "AND A.PLANT_SEQ_NO=? AND A.COMPANY_CD=? "
						+ "AND A.STAT_CD=B.STAT_CD AND A.STAT_NO IS NOT NULL AND B.STAT_CD IN ('1003','1001')";
				stmt = conn.prepareStatement(queryString);
				stmt.setString(1, counterparty_cd);
				stmt.setString(2, "C");
				stmt.setString(3, plant_seq);
				stmt.setString(4, comp_cd);
				rset = stmt.executeQuery();
				while(rset.next())
				{
					String no = rset.getString(1)==null?"":rset.getString(1);
					String nm = rset.getString(3)==null?"":rset.getString(3);
	
					tax_info+="\n"+nm+" : "+no;
				}
				stmt.close();
				rset.close();
				
				bu_tax_info="State : "+bu_plantState;
				bu_tax_info+="\nState Code : "+utilBean.getState_TIN(conn, comp_cd, comp_cd, "B", bu_plant_seq);
				
				queryString = "SELECT A.STAT_NO, TO_CHAR(A.EFF_DT,'DD/MM/YYYY'), B.STAT_NM "
						+ "FROM FMS_COUNTERPARTY_PLANT_TAX A, FMS_GOVT_STAT_TAX B "
						+ "WHERE A.COUNTERPARTY_CD=? AND A.ENTITY=? "
						+ "AND A.PLANT_SEQ_NO=? AND A.COMPANY_CD=? "
						+ "AND A.STAT_CD=B.STAT_CD AND A.STAT_NO IS NOT NULL AND B.STAT_CD IN ('1003','1001')";
				stmt = conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, "B");
				stmt.setString(3, bu_plant_seq);
				stmt.setString(4, comp_cd);
				rset = stmt.executeQuery();
				while(rset.next())
				{
					String no = rset.getString(1)==null?"":rset.getString(1);
					String nm = rset.getString(3)==null?"":rset.getString(3);
	
					bu_tax_info+="\n"+nm+" : "+no;
				}
				stmt.close();
				rset.close();

				queryString = "SELECT SAC_CODE,SAC_DESC,REMARKS,SAC_FLAG "
						+ "FROM FMS_SAC_MST "
						+ "WHERE SAC_FLAG=? AND SAC_CD=? ";
				stmt = conn.prepareStatement(queryString);
				stmt.setString(1, "Y");
				stmt.setString(2, sac_no);
				rset = stmt.executeQuery();
				while(rset.next())
				{
					String no = rset.getString(1)==null?"":rset.getString(1);
					String sac_desc = rset.getString(2)==null?"":rset.getString(2);
					
					bu_tax_info+="\nSAC : "+no
							+ "\nDescription of Service : "+sac_desc
							+ "\nPlace Of Supply : "+bu_plantState;
				}
				stmt.close();
				rset.close();
			}
			else
			{
				tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "C", counterparty_cd, plant_seq);
				bu_tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "B", comp_cd, bu_plant_seq);
			}
            
			float[] ContactAddrWidths8 = {0.80f,0.30F,0.80F};
	     	PdfPTable Table8 = new PdfPTable(ContactAddrWidths8);
	        Table8.setWidthPercentage(100);
	        Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	        Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	        Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	        Table8.addCell(new Phrase(new Chunk(bu_tax_info,small_black_normal)));

	        Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	        Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	        Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	        Table8.addCell(new Phrase(new Chunk("",small_black_normal)));
	        
	        Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	        Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	        Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	        Table8.addCell(new Phrase(new Chunk(tax_info,small_black_normal)));
	        
	        
	        PdfPTable InvoiceDateInfoTable;
            PdfPTable BillingPeriodInfoTable;
            
            float[] InvoiceDateInfoWidths_qr = {0.30f, 0.20f, 0.70f};
			PdfPTable InvoiceDateInfoTable_qr = new PdfPTable(InvoiceDateInfoWidths_qr);
			if(!irn_no.equals("") && !qr_code.equals("") && (contract_type.equals("Q") || contract_type.equals("O")))
			{
				float[] InvoiceDateInfoWidths = {0.60F,0.40F};
	            InvoiceDateInfoTable = new PdfPTable(InvoiceDateInfoWidths);
	            InvoiceDateInfoTable.setWidthPercentage(100);
	            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				InvoiceDateInfoTable.addCell(new Phrase(new Chunk("Invoice Date :",black_bold)));
				InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
				InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(inv_dt,black_bold)));
	            
	            if(!inv_due_dt.equals(""))
				{
		            //due date
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk("Payment Due Date :",black_bold)));
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(inv_due_dt,black_bold)));
				}
	            
	            //inv no
	            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            if(inv_type.equals("CR") || inv_type.equals("CCR"))
	            {
	            	InvoiceDateInfoTable.addCell(new Phrase(new Chunk(company_abbr+" Credit Note:",black_bold)));
	            }
	            else if(inv_type.equals("DR") || inv_type.equals("CDR"))
	            {
	            	InvoiceDateInfoTable.addCell(new Phrase(new Chunk(company_abbr+" Debit Note:",black_bold)));
	            }
	            else
	            {
	            	InvoiceDateInfoTable.addCell(new Phrase(new Chunk(company_abbr+" Invoice Seq No:",black_bold)));
	            }
	            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
	            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(inv_no,black_bold)));
	            
	            if(!link_invoice_ref.equals(""))
				{
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk("Reference Invoice# :",black_bold)));
		
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(""+link_invoice_ref,black_bold)));
				}
	            
	            /*float[] BillingPeriodInfoWidths = {0.30F,0.20F,0.10F,0.20F};
	            BillingPeriodInfoTable = new PdfPTable(BillingPeriodInfoWidths);
	            BillingPeriodInfoTable.setWidthPercentage(100);
	            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            BillingPeriodInfoTable.addCell(new Phrase(new Chunk("Billing Period : ",black_bold)));
	            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
	            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            BillingPeriodInfoTable.addCell(new Phrase(new Chunk(""+period_start_dt,black_bold)));
	            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            BillingPeriodInfoTable.addCell(new Phrase(new Chunk("to",black_bold)));
	            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
	            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            BillingPeriodInfoTable.addCell(new Phrase(new Chunk(""+period_end_dt,black_bold)));
	            
	            if(!inv_flag.equals("UG") && !inv_flag.equals("ST"))
	            {
	            	InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            	InvoiceDateInfoTable.getDefaultCell().setColspan(3);
	            	InvoiceDateInfoTable.addCell(BillingPeriodInfoTable);
	            }*/
	               
	            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            InvoiceDateInfoTable.getDefaultCell().setColspan(3);
	            InvoiceDateInfoTable.addCell(new Phrase(new Chunk("",small_black_bold)));
				
				int width=90;
				int height=90;
				Hashtable<EncodeHintType, ErrorCorrectionLevel> hintMap = new Hashtable<>();
		        hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);

		        QRCodeWriter qrCodeWriter = new QRCodeWriter();
		        BitMatrix matrix = qrCodeWriter.encode(qr_code, BarcodeFormat.QR_CODE, width, height, hintMap);

		        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		        for (int x = 0; x < width; x++) 
		        {
		            for (int y = 0; y < height; y++) 
		            {
		                image.setRGB(x, y, matrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
		            }
		        }
		        
		        BufferedImage qrImage = image;
		        
		        ByteArrayOutputStream baos = new ByteArrayOutputStream();
		        ImageIO.write(qrImage, "png", baos);
		        Image qr_codeimg = Image.getInstance(baos.toByteArray());
				qr_codeimg.setBorder(Rectangle.NO_BORDER);
                qr_codeimg.setAlignment(Element.ALIGN_LEFT);
                PdfPCell qrcode_cell = new PdfPCell(qr_codeimg,false);
                qrcode_cell.setBorder(Rectangle.NO_BORDER);
                qrcode_cell.setHorizontalAlignment(Element.ALIGN_LEFT);
                
                String char_16= irn_no.substring(0,16);
                String char_32= irn_no.substring(16,32);
                String char_48= irn_no.substring(32,48);
                String char_64= irn_no.substring(48,irn_no.length());
                String final_irn_no=char_16+"\n"+char_32+"\n"+char_48+"\n"+char_64;
                
                PdfPTable InvoiceDateInfoTable_qr1 = new PdfPTable(1);
       	        InvoiceDateInfoTable_qr1.setWidthPercentage(100);
       	        InvoiceDateInfoTable_qr1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
       	        InvoiceDateInfoTable_qr1.getDefaultCell().setBorder(Rectangle.BOX);
       	        InvoiceDateInfoTable_qr1.addCell(qrcode_cell);
       	        
       	        PdfPTable InvoiceDateInfoTable_qr11 = new PdfPTable(1);
    	        InvoiceDateInfoTable_qr11.setWidthPercentage(100);
    	        InvoiceDateInfoTable_qr11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
    	        InvoiceDateInfoTable_qr11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
    	        InvoiceDateInfoTable_qr11.addCell(new Phrase(new Chunk("IRN",black_bold)));
    	        InvoiceDateInfoTable_qr11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
    	        InvoiceDateInfoTable_qr11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
    	        InvoiceDateInfoTable_qr11.addCell(new Phrase(new Chunk(final_irn_no,small_black_normal)));
    	        
    	        InvoiceDateInfoTable_qr.setWidthPercentage(100);
       	        InvoiceDateInfoTable_qr.getDefaultCell().setBorder(Rectangle.NO_BORDER);
       	        InvoiceDateInfoTable_qr.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
       	        InvoiceDateInfoTable_qr.addCell(InvoiceDateInfoTable_qr1);
       	        
       	        InvoiceDateInfoTable_qr.getDefaultCell().setBorder(Rectangle.BOX);
       	        InvoiceDateInfoTable_qr.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
       	        InvoiceDateInfoTable_qr.addCell(InvoiceDateInfoTable_qr11);
       	        
       	        InvoiceDateInfoTable_qr.getDefaultCell().setBorder(Rectangle.NO_BORDER);
       	        InvoiceDateInfoTable_qr.addCell(InvoiceDateInfoTable);
			}

	        float[] ContactAddrWidths9 = {0.50F,0.30F,0.70F,0.40F};
   	     	PdfPTable Table9 = new PdfPTable(ContactAddrWidths9);
            Table9.setWidthPercentage(100);
            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table9.addCell(new Phrase(new Chunk("",black_bold)));

            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table9.addCell(new Phrase(new Chunk("",black_bold)));

            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table9.addCell(new Phrase(new Chunk("Invoice Date :",black_bold)));

            Table9.getDefaultCell().setBorder(Rectangle.BOX);
            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table9.addCell(new Phrase(new Chunk(""+inv_dt,black_bold)));

            float[] ContactAddrWidths10 = {0.50F,0.30F,0.70F,0.40F};
   	     	PdfPTable Table10 = new PdfPTable(ContactAddrWidths10);
            Table10.setWidthPercentage(100);
            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table10.addCell(new Phrase(new Chunk("",black_bold)));

            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table10.addCell(new Phrase(new Chunk("",black_bold)));

            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table10.addCell(new Phrase(new Chunk("Payment Due Date :",black_bold)));

            Table10.getDefaultCell().setBorder(Rectangle.BOX);
            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table10.addCell(new Phrase(new Chunk(""+inv_due_dt,black_bold)));

            float[] ContactAddrWidths11 = {0.50F,0.30F,0.70F,0.40F};
   	     	PdfPTable Table11 = new PdfPTable(ContactAddrWidths11);
            Table11.setWidthPercentage(100);
            Table11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table11.addCell(new Phrase(new Chunk("",black_bold)));

            Table11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table11.addCell(new Phrase(new Chunk("",black_bold)));

            Table11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            if(inv_type.equals("CR") || inv_type.equals("CCR"))
            {
            	Table11.addCell(new Phrase(new Chunk(company_abbr+" Credit Note:",black_bold)));
            }
            else if(inv_type.equals("DR") || inv_type.equals("CDR"))
            {
            	Table11.addCell(new Phrase(new Chunk(company_abbr+" Debit Note:",black_bold)));
            }
            else
            {
            	Table11.addCell(new Phrase(new Chunk(company_abbr+" Invoice Seq No:",black_bold)));
            }
            

            Table11.getDefaultCell().setBorder(Rectangle.BOX);
            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
            Table11.addCell(new Phrase(new Chunk(""+inv_no,black_bold)));
            
            /*Table11.getDefaultCell().setBorder(Rectangle.BOX);
            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            Table11.addCell(new Phrase(new Chunk(""+inv_ref,small_black_normal)));*/

            if(!link_invoice_ref.equals(""))
			{
	            Table11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk("",black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk("",black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk("Reference Invoice# :",black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk(""+link_invoice_ref,black_bold)));
			}

            float[] ContactAddrWidths12 = {0.05F,0.60F,0.20F,0.20F,0.20F,0.20F};
   	     	PdfPTable Table12 = new PdfPTable(ContactAddrWidths12);
            Table12.setWidthPercentage(100);
            Table12.getDefaultCell().setBorder(Rectangle.BOX);
            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table12.addCell(new Phrase(new Chunk("Sr.No.",small_black_normal)));

            Table12.getDefaultCell().setBorder(Rectangle.BOX);
            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table12.addCell(new Phrase(new Chunk("Item Description",small_black_normal)));

            Table12.getDefaultCell().setBorder(Rectangle.BOX);
            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table12.addCell(new Phrase(new Chunk("Currency",small_black_normal)));

            Table12.getDefaultCell().setBorder(Rectangle.BOX);
            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table12.addCell(new Phrase(new Chunk("Quantity(MMBTU)",small_black_normal)));

            Table12.getDefaultCell().setBorder(Rectangle.BOX);
            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table12.addCell(new Phrase(new Chunk("Rate",small_black_normal)));

            Table12.getDefaultCell().setBorder(Rectangle.BOX);
            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            Table12.addCell(new Phrase(new Chunk("Amount",small_black_normal)));

            float[] ContactAddrWidths13 = {0.05F,0.60F,0.20F,0.20F,0.20F,0.20F};
   	     	PdfPTable Table13 = new PdfPTable(ContactAddrWidths13);
            Table13.setWidthPercentage(100);

            int count_row=0;
            queryString="SELECT LINE_NO,LINE_DESC,UNIT,"
					+ "QTY,RATE,AMOUNT "
					+ "FROM FMS_DLNG_FFLOW_INV_DTL "
					+ "WHERE COMPANY_CD=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
					+ "AND INVOICE_TYPE=? AND FINANCIAL_YEAR=? "
					+ "ORDER BY LINE_NO";
            stmt=conn.prepareStatement(queryString);
            stmt.setString(1, comp_cd);
            stmt.setString(2, inv_seq);
            stmt.setString(3, bu_state_tin);
            stmt.setString(4, inv_type);
            stmt.setString(5, financial_year);
            rset=stmt.executeQuery();
			while(rset.next())
			{
				count_row+=1;

				String line_no = rset.getString(1)==null?"":rset.getString(1);
				String line_desc = rset.getString(2)==null?"":rset.getString(2);
				String unit = rset.getString(3)==null?"":rset.getString(3);
				String qty = rset.getString(4)==null?"":rset.getString(4);
				String rate = rset.getString(5)==null?"":rset.getString(5);
				String amount = rset.getString(6)==null?"":rset.getString(6);

				Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk(""+line_no,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table13.addCell(new Phrase(new Chunk(""+line_desc,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk(""+unit,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk(""+qty,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk(""+rate,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk(""+amount,small_black_normal)));
			}
			rset.close();
			stmt.close();

			if(!sales_amt.equals(""))
			{
				count_row+=1;
				Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk(""+count_row,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table13.addCell(new Phrase(new Chunk("Gross Amount",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk("USD",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk(""+sales_amt,small_black_normal)));
			}

			if(!echng_rate.equals(""))
			{
				count_row+=1;
				Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk(""+count_row,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table13.addCell(new Phrase(new Chunk("Exchange Rate",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk("INR/USD",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk(""+echng_rate,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));
			}

			if(!gross_amt.equals(""))
			{
				count_row+=1;
				Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk(""+count_row,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table13.addCell(new Phrase(new Chunk("Gross Amount",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk("INR",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk(""+gross_amt,small_black_normal)));
			}

			if(!tax_amt.equals(""))
			{
				count_row+=1;
				Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk(""+count_row,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table13.addCell(new Phrase(new Chunk("Tax ("+tax_struct_info+")",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk(""+cuurency_nm,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk(""+tax_amt,small_black_normal)));
			}
			
			queryString1="SELECT COUNT(*) "
            		+ "FROM FMS_DLNG_FFLOW_INV_TAX_DTL "
					+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
					+ "AND INVOICE_TYPE=? "
					+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
			stmt1=conn.prepareStatement(queryString1);
			stmt1.setString(1, comp_cd);
			stmt1.setString(2, bu_state_tin);
			stmt1.setString(3, inv_type);
			stmt1.setString(4, financial_year);
			stmt1.setString(5, inv_seq);
			rset1=stmt1.executeQuery();
			if(rset1.next())
			{
				if(rset1.getInt(1)>1)
				{
					String temp_srno=""+count_row;
					int count_sub_tax=0;
					queryString="SELECT TAX_CODE,TAX_DESCR,TAX_AMT,TAX_BASE_AMT "
							+ "FROM FMS_DLNG_FFLOW_INV_TAX_DTL "
							+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
							+ "AND INVOICE_TYPE=? "
							+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(1, comp_cd);
					stmt.setString(2, bu_state_tin);
					stmt.setString(3, inv_type);
					stmt.setString(4, financial_year);
					stmt.setString(5, inv_seq);
					rset=stmt.executeQuery();
					while(rset.next())
					{
						count_sub_tax+=1;;
						String sub_row_no=temp_srno+"."+count_sub_tax;
						
						String tax_descr=rset.getString(2)==null?"":rset.getString(2);
						String taxAmt=rset.getString(3)==null?"":nf.format(rset.getDouble(3));
						
						Table13.getDefaultCell().setBorder(Rectangle.BOX);
			            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			            Table13.addCell(new Phrase(new Chunk(""+sub_row_no,small_black_normal)));
	
			            Table13.getDefaultCell().setBorder(Rectangle.BOX);
			            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
			            Table13.addCell(new Phrase(new Chunk(""+tax_descr,small_black_normal)));
	
			            Table13.getDefaultCell().setBorder(Rectangle.BOX);
			            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			            Table13.addCell(new Phrase(new Chunk(""+cuurency_nm,small_black_normal)));
	
			            Table13.getDefaultCell().setBorder(Rectangle.BOX);
			            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
			            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));
	
			            Table13.getDefaultCell().setBorder(Rectangle.BOX);
			            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
			            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));
	
			            Table13.getDefaultCell().setBorder(Rectangle.BOX);
			            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
			            Table13.addCell(new Phrase(new Chunk(""+taxAmt,small_black_normal)));
					}
					rset.close();
					stmt.close();
				}
			}
			rset1.close();
			stmt1.close();
			
			if(!inv_amt.equals(""))
			{
				count_row+=1;
				Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk(""+count_row,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table13.addCell(new Phrase(new Chunk("Invoice Amount",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk(""+cuurency_nm,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk(""+inv_amt,small_black_normal)));
			}
			
			if(!tcs_amt.equals("") && tcs_tds.equals("TCS"))
			{
				count_row+=1;
				Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk(""+count_row,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table13.addCell(new Phrase(new Chunk("TCS("+tcs_struct_info+")",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk(""+cuurency_nm,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk(""+tcs_amt,small_black_normal)));
			}

			if(!adj_amt.equals(""))
			{
				count_row+=1;
				Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk(""+count_row,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table13.addCell(new Phrase(new Chunk("Adjustment Amount",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk(""+cuurency_nm,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk(""+adj_amt,small_black_normal)));
			}

			if(!net_amt.equals(""))
			{
				count_row+=1;
				Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk(""+count_row,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table13.addCell(new Phrase(new Chunk("Net Payable",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk(""+cuurency_nm,small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk(""+net_amt,small_black_normal)));
			}

			float[] amountInWord = {0.100F};
   	     	PdfPTable amountInWordTable = new PdfPTable(amountInWord);
   	     	amountInWordTable.setWidthPercentage(100);

   	     	amountInWordTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	amountInWordTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
   	     	amountInWordTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
   	     	amountInWordTable.addCell(new Phrase(new Chunk("Amount(in word) : "+amount_in_word,small_black_normal)));

			float[] ContactAddrWidths14 = {0.100F};
   	     	PdfPTable Table14 = new PdfPTable(ContactAddrWidths14);

   	     	Table14.setWidthPercentage(100);
   	     	Table14.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	Table14.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
   	     	Table14.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
   	     	Table14.addCell(new Phrase(new Chunk(""+note,small_black_normal)));

			float[] ContactAddrWidths21 = {0.100F};
   	     	PdfPTable Table21 = new PdfPTable(ContactAddrWidths21);

   	     	Table21.setWidthPercentage(100);
   	     	Table21.getDefaultCell().setBorder(Rectangle.NO_BORDER);
   	     	Table21.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
   	     	Table21.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
   	     	Table21.addCell(new Phrase(new Chunk("For "+company_nm,black_bold)));
   	     	
   	     	// create a signature form field
   	     	PdfPTable BillingFieldsInfoTable81 = new PdfPTable(1);
   	     	BillingFieldsInfoTable81.setWidthPercentage(20);
   	     	BillingFieldsInfoTable81.setHorizontalAlignment(Element.ALIGN_LEFT);
   	     	BillingFieldsInfoTable81.getDefaultCell().setBorder(Rectangle.BOX);
   	     	BillingFieldsInfoTable81.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
   	     	BillingFieldsInfoTable81.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
        
   	     	PdfFormField field = PdfFormField.createSignature(writer);
   	     	field.setFieldName(SIGNAME);
   	     	// set the widget properties
   	     	field.setPage();
   	     	field.setWidget(new Rectangle(72, 732, 144, 780), PdfAnnotation.HIGHLIGHT_NONE);
   	     	field.setFlags(PdfAnnotation.FLAGS_PRINT);
   	     	writer.addAnnotation(field);
         
   	     	PdfPCell sigCell = new PdfPCell();
   	     	FieldPositioningEvents events = new FieldPositioningEvents(writer, field);
   	     	sigCell.setCellEvent(events);
   	     	sigCell.setFixedHeight(50f);
   	     	BillingFieldsInfoTable81.addCell(sigCell);

   	     	float[] ContactAddrWidths22 = {0.100F};
	     	PdfPTable Table22 = new PdfPTable(ContactAddrWidths22);

	     	Table22.setWidthPercentage(100);
	     	Table22.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	     	Table22.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	     	Table22.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	     	Table22.addCell(new Phrase(new Chunk("Authorised Signatory",black_bold)));
	     	
	     	document.add(LogoTable);
			document.add(Table);
			document.add(Table1);
			document.add(Table2);
			document.add(Table3);
			document.add(new Paragraph("  "));
			document.add(Table4);
			document.add(Table5);
			document.add(Table6);
			document.add(Table7);
			document.add(Table8);
			document.add(new Paragraph("  "));
			document.add(new Paragraph("  "));
			if(!irn_no.equals("") && !qr_code.equals("") && (contract_type.equals("Q") || contract_type.equals("O")))
			{
				document.add(InvoiceDateInfoTable_qr);
			}
			else
			{
				document.add(Table9);
				if(!inv_due_dt.equals(""))
				{
					document.add(Table10);
				}
				document.add(Table11);
			}
			document.add(new Paragraph("  "));
			document.add(Table12);
			document.add(Table13);
			document.add(new Paragraph("  "));
			/*document.add(amountInWordTable);
			document.add(new Paragraph("  "));*/
			document.add(Table14);
			document.add(new Paragraph("  "));
			document.add(new Paragraph("  "));
			document.add(Table21);
			document.add(BillingFieldsInfoTable81);
			document.add(Table22);
			
			document.close();
			
			String dealMap = utilBean.NewDealMappingId(comp_cd, counterparty_cd, agmt_no, agmt_rev_no, cont_no, cont_rev_no, contract_type, cargo_no);
			if(is_print.equals("1"))
			{
				File isPDFexist = new File(path);
				if(isPDFexist.exists())
				{
					String invoice_title="";
					int update_flag=0;
					int pdf_entry=0;
					
					int cont=0;
					queryString="UPDATE FMS_DLNG_FFLOW_INV_MST SET PDF_INV_DTL=? ";
						if(print_pdf_type.equals("O"))
						{
							queryString+= ",PRINT_BY_ORI=?,PRINT_DT_ORI=SYSDATE ";
						}
						else if(print_pdf_type.equals("T"))
						{
							queryString+= ",PRINT_BY_TRI=?,PRINT_DT_TRI=SYSDATE ";
						}
						else if(print_pdf_type.equals("D"))
						{
							queryString+= ",PRINT_BY_DUP=?,PRINT_DT_DUP=SYSDATE ";
						}
						queryString+= "WHERE COMPANY_CD=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
								+ "AND INVOICE_TYPE=? AND FINANCIAL_YEAR=?";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(++cont, print_pdf_type);
					if(print_pdf_type.equals("O"))
					{
						stmt.setString(++cont, emp_cd);
					}
					else if(print_pdf_type.equals("T"))
					{
						stmt.setString(++cont, emp_cd);
					}
					else if(print_pdf_type.equals("D"))
					{
						stmt.setString(++cont, emp_cd);
					}
					stmt.setString(++cont, comp_cd);
					stmt.setString(++cont, inv_seq);
					stmt.setString(++cont, bu_state_tin);
					stmt.setString(++cont, inv_type);
					stmt.setString(++cont, financial_year);
					update_flag=stmt.executeUpdate();
					stmt.close();
					
					int count=0;
			        queryString1="SELECT COUNT(*) "
			        		+ "FROM FMS_DLNG_FFLOW_INV_FILE_DTL "
			        		+"WHERE COMPANY_CD=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
							+ "AND INVOICE_TYPE=? AND FINANCIAL_YEAR=? "
			        		+ "AND PDF_TYPE=?";
			        stmt1=conn.prepareStatement(queryString1);
			        stmt1.setString(1, comp_cd);
			        stmt1.setString(2, inv_seq);
			        stmt1.setString(3, bu_state_tin);
			        stmt1.setString(4, inv_type);
			        stmt1.setString(5, financial_year);
			        stmt1.setString(6, print_pdf_type);
			        rset1=stmt1.executeQuery();
			        if(rset1.next())
			        {
			        	count=rset1.getInt(1);
			        }
			        rset1.close();
			        stmt1.close();
			        
			        if(count > 0)
			        {
			        	queryString2="UPDATE FMS_DLNG_FFLOW_INV_FILE_DTL SET FILE_NAME=?,MODIFY_BY=?,MODIFY_DT=SYSDATE "
			        			+"WHERE COMPANY_CD=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
								+ "AND INVOICE_TYPE=? AND FINANCIAL_YEAR=? "
				        		+ "AND PDF_TYPE=?";
			        	stmt2=conn.prepareStatement(queryString2);
			        	stmt2.setString(1, file_nm);
			        	stmt2.setString(2, emp_cd);
			        	stmt2.setString(3, comp_cd);
			 	        stmt2.setString(4, inv_seq);
			 	        stmt2.setString(5, bu_state_tin);
			 	        stmt2.setString(6, inv_type);
			 	        stmt2.setString(7, financial_year);
			 	        stmt2.setString(8, print_pdf_type);
			 	        pdf_entry=stmt2.executeUpdate();
			        	
			        	stmt2.close();
			        }
			        else
			        {
			        	queryString2="INSERT INTO FMS_DLNG_FFLOW_INV_FILE_DTL(COMPANY_CD,BU_STATE_TIN,INVOICE_SEQ,FINANCIAL_YEAR,PDF_TYPE,"
			        			+ "FILE_NAME,ENT_BY,ENT_DT,INVOICE_TYPE) "
			        			+ "VALUES(?,?,?,?,?,"
			        			+ "?,?,SYSDATE,?)";
			        	stmt2=conn.prepareStatement(queryString2);
			        	stmt2.setString(1, comp_cd);
			        	stmt2.setString(2, bu_state_tin);
			        	stmt2.setString(3, inv_seq);
			        	stmt2.setString(4, financial_year);
			        	stmt2.setString(5, print_pdf_type);
			        	stmt2.setString(6, file_nm);
			        	stmt2.setString(7, emp_cd);
			 	        stmt2.setString(8, inv_type);
			 	        pdf_entry=stmt2.executeUpdate();
			        	
			        	stmt2.close();
			        }
			        

			        String tempRePrintMsg="";
			        String re_printFlag="";
			        String re_print_Seq_No="";
			        queryString2="SELECT FLAG,SEQ_NO "
			        		+ "FROM FMS_FFLOW_INV_CHANGE_DTL A "
			        		+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
							+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND SEGMENT=? AND CHANGE_TYPE=? AND INVOICE_TYPE=? "
							+ "AND SEQ_NO=(SELECT MAX(B.SEQ_NO) FROM FMS_FFLOW_INV_CHANGE_DTL B WHERE A.COMPANY_CD=B.COMPANY_CD "
							+ "AND A.BU_STATE_TIN=B.BU_STATE_TIN AND A.INVOICE_SEQ=B.INVOICE_SEQ AND A.FINANCIAL_YEAR=B.FINANCIAL_YEAR "
							+ "AND A.SEGMENT=B.SEGMENT AND A.CHANGE_TYPE=B.CHANGE_TYPE AND A.INVOICE_TYPE=B.INVOICE_TYPE)";
			        stmt2=conn.prepareStatement(queryString2);
			        stmt2.setString(1, comp_cd);
			        stmt2.setString(2, bu_state_tin);
			        stmt2.setString(3, inv_seq);
			        stmt2.setString(4, financial_year);
			        stmt2.setString(5, "DLNG");
			        stmt2.setString(6, "REPRINT_PDF");
			        stmt2.setString(7, inv_type);
			        rset2=stmt2.executeQuery();
			        if(rset2.next())
			        {
			        	re_printFlag=rset2.getString(1)==null?"":rset2.getString(1);
			        	re_print_Seq_No=rset2.getString(2)==null?"":rset2.getString(2);
			        }
			        rset2.close();
			        stmt2.close();
			        
			        if(re_printFlag.equals("A"))
			        {
			        	tempRePrintMsg="Re-Printed ";
			        	int reprint_pdf_count=0;
			        	queryString2="SELECT COUNT(*) "
				        		+ "FROM FMS_DLNG_FFLOW_INV_FILE_DTL "
				        		+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
				        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND INVOICE_TYPE=? AND PDF_TYPE IN ('O','D','T')";
				        stmt2=conn.prepareStatement(queryString2);
				        stmt2.setString(1, comp_cd);
				        stmt2.setString(2, bu_state_tin);
				        stmt2.setString(3, inv_seq);
				        stmt2.setString(4, financial_year);
				        stmt2.setString(5, inv_type);
				        rset2=stmt2.executeQuery();
				        if(rset2.next())
				        {
				        	reprint_pdf_count=rset2.getInt(1);
				        }
				        rset2.close();
				        stmt2.close();
				        
				        if(reprint_pdf_count==3)
				        {
				        	queryString2="UPDATE FMS_FFLOW_INV_CHANGE_DTL SET FLAG=? "
				    				+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
									+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
									+ "AND SEGMENT=? AND CHANGE_TYPE=? AND FLAG=? AND SEQ_NO=? AND INVOICE_TYPE=? ";
				    		stmt2=conn.prepareStatement(queryString2);
				    		stmt2.setString(1, "P");
					        stmt2.setString(2, comp_cd);
					        stmt2.setString(3, bu_state_tin);
					        stmt2.setString(4, inv_seq);
					        stmt2.setString(5, financial_year);
					        stmt2.setString(6, "DLNG");
					        stmt2.setString(7, "REPRINT_PDF");
					        stmt2.setString(8, re_printFlag);
					        stmt2.setString(9, re_print_Seq_No);
					        stmt2.setString(10, inv_type);
					        stmt2.executeUpdate();
							
							stmt2.close();
				        }
			        }
			        
			        
			        if(re_printFlag.equals(""))
			        {
				        if(update_flag > 0 && pdf_entry > 0 && print_pdf_type.equals("O") && !contract_type.equals("W") 
				        		&& (inv_type.equals("DR") || inv_type.equals("CDR") || inv_type.equals("S")))
				        {
				        	double hold_amt=utilBean.getInvoiceHoldAmount(conn,comp_cd,counterparty_cd,agmt_no,cont_no,contract_type,plant_seq,bu_plant_seq, 
				        			temp_inv_dt,tax_struct_dtl,gross_amt,bu_state_tin,temp_inv_dt);
				        	
				        	if(hold_amt > 0)
				        	{
				        		cont=0;
								queryString="UPDATE FMS_DLNG_FFLOW_INV_MST SET HOLD_AMT=? "
										+ "WHERE COMPANY_CD=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
										+ "AND INVOICE_TYPE=? AND FINANCIAL_YEAR=?";
								stmt=conn.prepareStatement(queryString);
								stmt.setString(++cont, nf.format(hold_amt));
								stmt.setString(++cont, comp_cd);
								stmt.setString(++cont, inv_seq);
								stmt.setString(++cont, bu_state_tin);
								stmt.setString(++cont, inv_type);
								stmt.setString(++cont, financial_year);
								stmt.executeUpdate();
								stmt.close();
				        	}
				        }
					}
					
			        if(pdf_entry == 0 || update_flag == 0)
			        {
			        	conn.rollback();
			        	deletePdfFile(path);
			        	msg="Failed! - DLNG Freeflow Invoice for "+counterparty_abbr+" PDF for "+dealMap+" Generation Failed!";
			        	msg_type="E";
			        }
			        else
			        {
			        	conn.commit();
			        	msg = "Successful! - DLNG Freeflow Invoice for "+counterparty_abbr+" PDF "+file_nm+" for "+dealMap+" Generated Successfully!";
			        	msg_type="S";
			        }
				}
				else
				{
					msg="Failed! - Freeflow Invoice for "+counterparty_abbr+" PDF for "+dealMap+" Generation Failed!";
					msg_type="E";
				}
			}
		}
		catch(Exception e)
		{
			conn.rollback();
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
			
			document.close();
			deletePdfFile(path);
			
			msg="Error in Exception! - DLNG Freeflow Invoice for "+counterparty_abbr+" PDF Generation Failed!";
			msg_type="E";
		}
		finally
		{
			document.close();
		}
		
		if(is_print.equals("1"))
		{
			try
			{
				new com.etrm.fms.util.InfoLogger().InsertInfoLogger(emp_cd, comp_cd,emp_nm, ip, form_id, form_nm,mod_cd,mod_nm, "", "", msg);  	
			}
			catch(Exception infoLogger)
			{
				new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, infoLogger);
			}
		}
	}
	
	public void printPdfFileForDlngServiceInvoice() throws SQLException
	{
		String function_nm="printPdfFileForDlngServiceInvoice()";
		
		String emp_nm ="";
		String ip = "";
		msg="";
		//String msg_content="";
		String path ="";
		String counterparty_abbr="";
		String invdtl="DLNG Service";
		
		Rectangle pageSize = new Rectangle(595, 842);
		Rectangle pageSize1=new Rectangle(842,595);
		
		pageSize.setBackgroundColor(BaseColor.WHITE);
		pageSize1.setBackgroundColor(BaseColor.WHITE);
		
		Document document = new Document(pageSize);
		try
		{
			HttpSession session = request.getSession();
			emp_nm = (String)session.getAttribute("emp_nm")==null?"":(String)session.getAttribute("emp_nm");
			ip = (String)session.getAttribute("ip")==null?"":(String)session.getAttribute("ip");
			
			String company_nm = ""+session.getAttribute("comp_nm")==null?"":""+session.getAttribute("comp_nm");
			String company_abbr = ""+session.getAttribute("comp_abbr")==null?"":""+session.getAttribute("comp_abbr");
			String counterparty_nm=""+utilBean.getCounterpartyName(conn,counterparty_cd);
			counterparty_abbr=""+utilBean.getCounterpartyABBR(conn,counterparty_cd);
			
			int pdfGenCount=0;
			queryString="SELECT COUNT(*) "
					+ "FROM FMS_DLNG_SVC_INVOICE_MST A ,FMS_DLNG_SVC_INV_FILE_DTL B "
					+ "WHERE A.COMPANY_CD=? AND A.FINANCIAL_YEAR=? AND A.INVOICE_SEQ=? AND A.BU_STATE_TIN=? "
					+ "AND A.PRINT_BY_ORI IS NOT NULL AND A.PRINT_DT_ORI IS NOT NULL AND B.PDF_TYPE=? AND B.FILE_NAME IS NOT NULL "
					+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.BU_STATE_TIN=B.BU_STATE_TIN AND A.INVOICE_SEQ=B.INVOICE_SEQ "
    		  		+ "AND A.FINANCIAL_YEAR=B.FINANCIAL_YEAR";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, financial_year);
			stmt.setString(3, inv_seq);
			stmt.setString(4, bu_state_tin);
			stmt.setString(5, print_pdf_type);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				pdfGenCount=rset.getInt(1);
			}
			rset.close();
			stmt.close();
			
			String dealMap = utilBean.NewDealMappingId(comp_cd, counterparty_cd, agmt_no, agmt_rev_no, cont_no, cont_rev_no, contract_type, cargo_no);
            
			if(pdfGenCount>0)
			{
				msg="Failed! - "+invdtl+" Invoice for "+counterparty_abbr+" PDF for "+dealMap+" already Generated!";
	        	msg_type="E";
	        }
			else
			{
				String contRef="";
				String signingDt="";
				String agmtSigningDt="";
				String dcq="";
				String agmt_base="";
				double mdcq_percentage=100;
				String ship_nm="";
				String boe_number="";
				String boe_date="";
				String arrivalDt="";
				String auto_pay_flag="";
				String unit= "";
				String unit_desc= "";

				queryString="SELECT CONT_REF_NO,TO_CHAR(SIGNING_DT,'DD-MON-YY'),DCQ,TRANSPORT_MGMT_UNIT "
						+ "FROM FMS_SVC_CONT_MST A "
						+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE=? "
						+ "AND CONT_NO=? AND AGMT_NO=? AND COUNTERPARTY_CD=? "
						+ "AND CONT_REV = (SELECT MAX(CONT_REV) FROM FMS_SVC_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
						+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) ";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, contract_type);
				stmt.setString(3, cont_no);
				stmt.setString(4, agmt_no);
				stmt.setString(5, counterparty_cd);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					contRef=rset.getString(1)==null?"":rset.getString(1);
					signingDt=rset.getString(2)==null?"":rset.getString(2);
					dcq=nf.format(rset.getDouble(3));
					unit=rset.getString(4)==null?"":rset.getString(4);
				}
				rset.close();
				stmt.close();
				
				if(unit.equals("1") || unit.equals("2")) {
					unit_desc = "MMBTU";
				}else if(unit.equals("3")) {
					unit_desc = "TRUCK";
				}else if(unit.equals("4")) {
					unit_desc = "MT";
				}else if(unit.equals("5")) {
					unit_desc = "KM";
				}
				
				if(contract_type.equals("B"))
				{
					queryString="SELECT TO_CHAR(SIGNING_DT,'DD-MON-YY')  "
							+ "FROM FMS_AGMT_SVC_MST A "
							+ "WHERE COMPANY_CD=? AND AGMT_TYPE=? "
							+ "AND AGMT_NO=? AND COUNTERPARTY_CD=? "
							+ "AND AGMT_REV = (SELECT MAX(AGMT_REV) FROM FMS_AGMT_SVC_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
							+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_TYPE=B.AGMT_TYPE) ";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(1, comp_cd);
					stmt.setString(2, "T");
					stmt.setString(3, agmt_no);
					stmt.setString(4, counterparty_cd);
					rset=stmt.executeQuery();
					if(rset.next())
					{
						agmtSigningDt=rset.getString(1)==null?"":rset.getString(1);
					}
					rset.close();
					stmt.close();
				}
				
				HashMap bu_plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "B", comp_cd, bu_plant_seq);
				String bu_plantAddress=""+bu_plant_detail.get("plant_address");
				String bu_plantCity=""+bu_plant_detail.get("plant_city");
				String bu_plantState=""+bu_plant_detail.get("plant_state");
				String bu_plantPin=""+bu_plant_detail.get("plant_pin");
				String bu_plantNm=""+bu_plant_detail.get("plant_name");
	
				HashMap plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "C", counterparty_cd, plant_seq);
				String plantAddress=""+plant_detail.get("plant_address");
				String plantCity=""+plant_detail.get("plant_city");
				String plantState=""+plant_detail.get("plant_state");
				String plantPin=""+plant_detail.get("plant_pin");
				
				String bu_contact_person_cd="";
				String contact_person_cd="";
				String invoice_dt="";
				String invoice_due_dt="";
				String remark_1="";
				String remark_2="";
				String qty_mmbtu="";
				String price="";
				String price_cd="";
				String gross_amt="";
				String exchang_rate_cd="";
				String exchang_rate_dt="";
				String exchang_rate="";
				String exchang_rate_type="";
				String gross_amt1="";
				String tax_amt="";
				String tax_struct_cd="";
				String tax_struct_dt="";
				String invoice_amt="";
				String net_payable="";
				String applicable_abbr="";
				String applicable_amt="";
				String TCS_factor="";
				String tax_struct_dtl="";
				String invoice_no="";
				String invoice_raised_in="";
				String temp_invoice_dt="";
				String transportation_charges = "";
				String transportation_amount = "";
				String gross_include_transport_tariff = "";
				String marketing_margin = "";
				String marketing_margin_amount = "";
				String other_charges = "";
				String other_charges_amount = "";
				String irn_no="";
				String qr_code="";
				String sug_qty="";
				String sug_percent="";
				String sac_cd="";
				boolean isGrossIncTriff=false;
				
				double netPayable=0;
				double tdsAmt=0;
				
				String temp_period_start_dt=period_start_dt;
				String temp_period_end_dt=period_end_dt;
				
				String cont_map=counterparty_cd+"-"+contract_type+"-"+agmt_no+"-%-"+cont_no+"-%";
				String exit_point="C-"+counterparty_cd+"-"+plant_seq;
				
				queryString="SELECT BU_CONTACT_PERSON_CD,CONTACT_PERSON_CD,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD-MON-YY'),"
						+ "TO_CHAR(DUE_DT,'DD-MON-YY'),TO_CHAR(PERIOD_START_DT,'DD-MON-YY'),TO_CHAR(PERIOD_END_DT,'DD-MON-YY'),REMARK_1,REMARK_2,"
						+ "QTY,SALE_PRICE,SALE_PRICE_UNIT,SALE_AMT,EXCHG_RATE_VALUE,GROSS_AMT,TAX_AMT,TAX_STRUCT_CD,NULL,"
						+ "INVOICE_AMT,NET_PAYABLE_AMT,TCS_TDS,TCS_AMT,TCS_FACTOR,CHECKED_FLAG,APPROVED_FLAG, "
						+ "INVOICE_ID_SEQ,INVOICE_RAISED_IN,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),NULL,NULL,EXCHG_RATE_CD,"
						+ "TO_CHAR(EXCHG_RATE_DT,'DD-MON-YY'),EXCHG_RATE_TYPE,TDS_GROSS_AMT,QTY_UNIT,SAC_CD "
						+ "FROM FMS_DLNG_SVC_INVOICE_MST "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? "
						+ "AND AGMT_NO=? AND PLANT_SEQ=? AND BU_UNIT=? AND CONTRACT_TYPE=? "
						+ "AND BU_STATE_TIN=? AND PERIOD_START_DT=TO_DATE(?,'DD/MM/YYYY') "
						+ "AND PERIOD_END_DT=TO_DATE(?,'DD/MM/YYYY') AND FINANCIAL_YEAR=? "
						+ "AND INVOICE_SEQ=? AND INV_FLAG=? ";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty_cd);
				stmt.setString(3, cont_no);
				stmt.setString(4, agmt_no);
				stmt.setString(5, plant_seq);
				stmt.setString(6, bu_plant_seq);
				stmt.setString(7, contract_type);
				stmt.setString(8, bu_state_tin);
				stmt.setString(9, period_start_dt);
				stmt.setString(10, period_end_dt);
				stmt.setString(11, financial_year);
				stmt.setString(12, inv_seq);
				stmt.setString(13, inv_flag);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					bu_contact_person_cd=rset.getString(1)==null?"0":rset.getString(1);
					contact_person_cd=rset.getString(2)==null?"0":rset.getString(2);
					
					//invoice_id_seq=rset.getString(26)==null?"":rset.getString(26);
					invoice_no=rset.getString(3)==null?"":rset.getString(3);
					invoice_dt=rset.getString(4)==null?"":rset.getString(4);
					invoice_due_dt=rset.getString(5)==null?"":rset.getString(5);
					//inv_period_start_dt=rset.getString(6)==null?"":rset.getString(6);
					//inv_period_end_dt=rset.getString(7)==null?"":rset.getString(7);
					
					remark_1=rset.getString(8)==null?"":rset.getString(8);
					remark_2=rset.getString(9)==null?"":rset.getString(9);
					
					qty_mmbtu=nf.format(rset.getDouble(10));
					price_cd=rset.getString(12)==null?"":rset.getString(12);
					price=utilBean.RateNumberFormat(rset.getDouble(11), price_cd);
					gross_amt=nf.format(rset.getDouble(13));
					exchang_rate=nf2.format(rset.getDouble(14));
					gross_amt1=nf.format(rset.getDouble(15));
					tax_amt=nf.format(rset.getDouble(16));
					tax_struct_cd=rset.getString(17)==null?"":rset.getString(17);
					tax_struct_dt=rset.getString(18)==null?"":rset.getString(18);
					invoice_amt=nf.format(rset.getDouble(19));
					net_payable=nf.format(rset.getDouble(20));
					netPayable=rset.getDouble(20);
					applicable_abbr=rset.getString(21)==null?"":rset.getString(21);
					applicable_amt=nf.format(rset.getDouble(22));
					TCS_factor=nf3.format(rset.getDouble(23));
					
					invoice_raised_in=rset.getString(27)==null?"":rset.getString(27);
					temp_invoice_dt=rset.getString(28)==null?"":rset.getString(28);
					
					exchang_rate_cd=rset.getString(31)==null?"":rset.getString(31);
					exchang_rate_dt=rset.getString(32)==null?"":rset.getString(32);
					exchang_rate_type=rset.getString(33)==null?"":rset.getString(33);
					
					sac_cd=rset.getString(36)==null?"":rset.getString(36);
					
					tdsAmt=rset.getDouble(34);
					
					gross_include_transport_tariff=nf.format(Double.parseDouble(gross_amt1));
					
					tax_struct_dtl=utilBean.getTaxDescr(conn, tax_struct_cd);
				}
				rset.close();
				stmt.close();
				
				queryString1="SELECT IRN_NO,SIGN_QR_CODE "
						+ "FROM FMS_INVOICE_IRN_DTL "
						+ "WHERE COMPANY_CD=? AND INVOICE_NO=? ";
				stmt1=conn.prepareStatement(queryString1);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, invoice_no);
				rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					irn_no=rset1.getString(1)==null?"":rset1.getString(1);
					qr_code=rset1.getString(2)==null?"":rset1.getString(2);
				}
				rset1.close();
				stmt1.close();
				
				String contact_person_nm="";
				String bu_contact_person_nm="";
				
				queryString="SELECT CONTACT_PERSON "
						+ "FROM FMS_ENTITY_CONTACT_MST A "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
						+ "AND ENTITY=? AND SEQ_NO=? AND ADDR_FLAG=? "
						+ "AND TYPE=? "
						+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO "
						+ "AND EFF_DT <= TO_DATE(?,'DD/MM/YYYY') AND A.TYPE=B.TYPE)";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty_cd);
				stmt.setString(3, "C");
				stmt.setString(4, contact_person_cd);
				stmt.setString(5, "P"+plant_seq);
				stmt.setString(6, "DLNG");
				stmt.setString(7, temp_invoice_dt);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					contact_person_nm=rset.getString(1)==null?"":rset.getString(1);
				}
				rset.close();
				stmt.close();
				
				queryString="SELECT CONTACT_PERSON "
						+ "FROM FMS_ENTITY_CONTACT_MST A "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
						+ "AND ENTITY=? AND SEQ_NO=? AND ADDR_FLAG=? "
						+ "AND TYPE=?"
						+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO "
						+ "AND EFF_DT <= TO_DATE(?,'DD/MM/YYYY') AND A.TYPE=B.TYPE)";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, comp_cd);
				stmt.setString(3, "B");
				stmt.setString(4, bu_contact_person_cd);
				stmt.setString(5, "P"+bu_plant_seq);
				stmt.setString(6, "DLNG");
				stmt.setString(7, temp_invoice_dt);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					bu_contact_person_nm=rset.getString(1)==null?"":rset.getString(1);
				}
				rset.close();
				stmt.close();
	
				String print_pdf_type_nm="ORIGINAL";
				if(print_pdf_type.equals("O"))
				{
					print_pdf_type_nm="ORIGINAL";
				}
				else if(print_pdf_type.equals("D"))
				{
					print_pdf_type_nm="DUPLICATE";
				}
				else if(print_pdf_type.equals("T"))
				{
					print_pdf_type_nm="TRIPLICATE";
				}
	
				String appPath = request.getServletContext().getRealPath("");
	
				String main_folder="";
				if(!comp_cd.equals(""))
				{
					main_folder=CommonVariable.work_dir+comp_cd;
				}
				
				String sub_folder="unsigned_pdf";
				String sub_folder2="dlng_service_invoice";
				String temp_path=appPath+File.separator+main_folder+File.separator+sub_folder+File.separator+sub_folder2;
				File main_folderDir = new File(temp_path);
		        if(!main_folderDir.exists())
		        {
		        	main_folderDir.mkdirs();
		        }
	
		        String monthofinv = dateUtil.getMonthNameMON(period_end_dt);
		        String dtPeriod="";
		        if(!period_start_dt.equals("") && !period_end_dt.equals(""))
		        {
		        	dtPeriod=period_start_dt.substring(0,2);
		        	dtPeriod+="-";
		        	dtPeriod+=period_end_dt.substring(0,2);
		        }
	
		        String contNm="";
		        String invNm="";
		        if(contract_type.equals("M"))
		        {
		        	contNm="TS";
		        	invNm="INVOICE";
		        }
		        else if(contract_type.equals("B"))
		        {
		        	contNm="SO";
		        	invNm="INVOICE";
		        }
	
				//file_nm=print_pdf_type+"-"+company_abbr+"-"+invNm+"-"+contNm+""+bu_state_tin+"-"+inv_seq+"-"+counterparty_abbr+"_"+financial_year+"_"+monthofinv.trim()+"_"+dtPeriod+".pdf";
		        file_nm=print_pdf_type+"-"+company_abbr+"-"+invNm+"-"+invoice_no.replace("/", "-")+".pdf";
		        
				path = appPath+"/"+main_folder+"/"+sub_folder+"/"+sub_folder2+"/"+file_nm;
				PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream(path));
	
				document.open();
				document.setPageSize(pageSize);
	            document.newPage();
	
	            String context_nm = request.getContextPath();
				String server_nm = request.getServerName();
				String server_port = ""+request.getServerPort();
	
				file_url = CommonVariable.app_protocol+"://"+server_nm+":"+server_port+context_nm;
	
				Font small_black_normal = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL, BaseColor.BLACK);
				Font small_black_normal_10 = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);
				Font small_black_normal_14 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.NORMAL, BaseColor.BLACK);
				Font small_black_normal_12 = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL, BaseColor.BLACK);
				Font small_black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, BaseColor.BLACK);
	            Font black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, BaseColor.BLACK);
	            Font black_bold1 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.BOLD, BaseColor.BLACK);
	            Font black_bold_12 = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.BOLD, BaseColor.BLACK);
	            Font black_bold_10 = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD, BaseColor.BLACK);
	            
	            PdfPCell company_logo_cell = new PdfPCell();
	            if(!comp_logo.equals(""))
	            {
	            	String file_path = request.getRealPath("/"+CommonVariable.company_logo_path+"/"+comp_logo);
	            	Image company_logo = Image.getInstance(file_path);
		            company_logo.setBorder(Rectangle.NO_BORDER);
		            company_logo.scaleAbsolute(44,40);
		            company_logo_cell = new PdfPCell(company_logo,false);
		            company_logo_cell.setBorder(Rectangle.NO_BORDER);
		            company_logo_cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	            }
	            
	            float[] Contact1 = {0.50f};
	   	     	PdfPTable LogoTable = new PdfPTable(Contact1);
	   	     	LogoTable.setWidthPercentage(100);
	   	     	LogoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	LogoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	LogoTable.addCell(company_logo_cell);
	
				float[] ContactAddrWidths1 = {0.100f};
	   	     	PdfPTable HlplLogoTable = new PdfPTable(ContactAddrWidths1);
	            HlplLogoTable.setWidthPercentage(100);
	            HlplLogoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            HlplLogoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            HlplLogoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            HlplLogoTable.addCell(new Phrase(new Chunk(print_pdf_type_nm,small_black_normal_10)));
	
	            float[] ContactAddrWidths2 = {0.100f};
	   	     	PdfPTable Table = new PdfPTable(ContactAddrWidths2);
	            Table.setWidthPercentage(100);
	            Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table.addCell(new Phrase(new Chunk(company_nm,black_bold1)));
	
	            float[] ContactAddrWidths3 = {0.100f};
	   	     	PdfPTable Table1 = new PdfPTable(ContactAddrWidths3);
	            Table1.setWidthPercentage(100);
	            Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				/*if(contract_type.equals("Q") || contract_type.equals("O"))
				{
					Table1.addCell(new Phrase(new Chunk("TAX INVOICE",small_black_normal_12)));
				}
				else */
	            	
	            if(bu_plantState.equals(plantState))
	            {
	            	Table1.addCell(new Phrase(new Chunk("TAX INVOICE",black_bold_12)));
	            }
	            else
	            {
	            	Table1.addCell(new Phrase(new Chunk("RETAIL INVOICE",black_bold_12)));
	            }
	            

            	Table1.setWidthPercentage(100);
                Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
                Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
                Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
                Table1.addCell(new Phrase(new Chunk("Tax Invoice issued under Rule 46 of the Central Goods and Services Tax Rules, 2017",black_bold_10)));
            
				period_start_dt=dateUtil.getDateFormatDD_MOM_YY(period_start_dt);
				period_end_dt=dateUtil.getDateFormatDD_MOM_YY(period_end_dt);
	
				String info ="In respect of "; 
				info+=" Transport Management Service Agreement  ("+contRef+") executed on "+signingDt+" ";
				info+="\nbetween "+company_nm+" and "+counterparty_nm;
	
	            float[] ContactAddrWidths4 = {0.100f};
	   	     	PdfPTable Table2 = new PdfPTable(ContactAddrWidths4);
	            Table2.setWidthPercentage(100);
	            Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table2.addCell(new Phrase(new Chunk(info,small_black_normal)));
	
	            float[] ContactAddrWidths5 = {0.80f,0.10F,0.20F,0.80F};
	   	     	PdfPTable Table3 = new PdfPTable(ContactAddrWidths5);
	            Table3.setWidthPercentage(100);
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            //Table3.addCell(new Phrase(new Chunk("Business Unit: "+bu_plantNm,black_bold)));
	            Table3.addCell(new Phrase(new Chunk("Business Unit: ",black_bold)));
	            
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table3.addCell(new Phrase(new Chunk("",black_bold)));
	            
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table3.addCell(new Phrase(new Chunk("To:",black_bold)));
	
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table3.addCell(new Phrase(new Chunk(""+contact_person_nm+",",black_bold)));
	
	            
	
				float[] ContactAddrWidths6 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table4 = new PdfPTable(ContactAddrWidths6);
	            Table4.setWidthPercentage(100);
	            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table4.addCell(new Phrase(new Chunk(company_nm,small_black_normal)));
	            
	            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table4.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table4.addCell(new Phrase(new Chunk(counterparty_nm,small_black_normal)));
	
	            float[] ContactAddrWidths7 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table5 = new PdfPTable(ContactAddrWidths7);
	            Table5.setWidthPercentage(100);
	            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table5.addCell(new Phrase(new Chunk(bu_plantAddress+","+bu_plantCity,small_black_normal)));
	            
	            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table5.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
	            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table5.addCell(new Phrase(new Chunk(plantAddress+","+plantCity,small_black_normal)));
	            
	
	            float[] ContactAddrWidths8 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table6 = new PdfPTable(ContactAddrWidths8);
	            Table6.setWidthPercentage(100);
	            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table6.addCell(new Phrase(new Chunk(bu_plantState+" - "+bu_plantPin,small_black_normal)));
	
	            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table6.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
	            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table6.addCell(new Phrase(new Chunk(plantState+" - "+plantPin,small_black_normal)));
	
	            String tax_info="";
	            String bu_tax_info="";
	            

				tax_info="State : "+plantState;
				tax_info+="\nState Code : "+utilBean.getState_TIN(conn, comp_cd, counterparty_cd, "C", plant_seq);
				
				queryString = "SELECT A.STAT_NO, TO_CHAR(A.EFF_DT,'DD/MM/YYYY'), B.STAT_NM "
						+ "FROM FMS_COUNTERPARTY_PLANT_TAX A, FMS_GOVT_STAT_TAX B "
						+ "WHERE A.COUNTERPARTY_CD=? AND A.ENTITY=? "
						+ "AND A.PLANT_SEQ_NO=? AND A.COMPANY_CD=? "
						+ "AND A.STAT_CD=B.STAT_CD AND A.STAT_NO IS NOT NULL AND B.STAT_CD IN ('1003','1001')";
				stmt = conn.prepareStatement(queryString);
				stmt.setString(1, counterparty_cd);
				stmt.setString(2, "C");
				stmt.setString(3, plant_seq);
				stmt.setString(4, comp_cd);
				rset = stmt.executeQuery();
				while(rset.next())
				{
					String no = rset.getString(1)==null?"":rset.getString(1);
					String nm = rset.getString(3)==null?"":rset.getString(3);
	
					tax_info+="\n"+nm+" : "+no;
				}
				stmt.close();
				rset.close();
				
				bu_tax_info="State : "+bu_plantState;
				bu_tax_info+="\nState Code : "+utilBean.getState_TIN(conn, comp_cd, comp_cd, "B", bu_plant_seq);
				
				queryString = "SELECT A.STAT_NO, TO_CHAR(A.EFF_DT,'DD/MM/YYYY'), B.STAT_NM "
						+ "FROM FMS_COUNTERPARTY_PLANT_TAX A, FMS_GOVT_STAT_TAX B "
						+ "WHERE A.COUNTERPARTY_CD=? AND A.ENTITY=? "
						+ "AND A.PLANT_SEQ_NO=? AND A.COMPANY_CD=? "
						+ "AND A.STAT_CD=B.STAT_CD AND A.STAT_NO IS NOT NULL AND B.STAT_CD IN ('1003','1001')";
				stmt = conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, "B");
				stmt.setString(3, bu_plant_seq);
				stmt.setString(4, comp_cd);
				rset = stmt.executeQuery();
				while(rset.next())
				{
					String no = rset.getString(1)==null?"":rset.getString(1);
					String nm = rset.getString(3)==null?"":rset.getString(3);
	
					bu_tax_info+="\n"+nm+" : "+no;
				}
				stmt.close();
				rset.close();
				
				queryString = "SELECT SAC_CODE,SAC_DESC,REMARKS,SAC_FLAG "
						+ "FROM FMS_SAC_MST "
						+ "WHERE SAC_FLAG=? AND SAC_CD=? ";
				stmt = conn.prepareStatement(queryString);
				stmt.setString(1, "Y");
				stmt.setString(2, sac_cd);
				rset = stmt.executeQuery();
				while(rset.next())
				{
					String no = rset.getString(1)==null?"":rset.getString(1);
					String sac_desc = rset.getString(2)==null?"":rset.getString(2);
					
					bu_tax_info+="\nSAC No : "+no
							+ "\nDescription of Service : "+sac_desc
							+ "\nPlace Of Supply : "+plantState;
				}
				
				/*bu_tax_info+="\nSAC No.: "
						+ "\nDescription of Service : Other Miscellaneous services - Other Services n.e.c."
						+ "\nPlace Of Supply : "+plantState; //WILL BE CUSTOMER PLANT STATE AS DISCUSSED BY JAYASRI MAM WITH VIJAY ON 20250725
				*/			
	            
	           float[] ContactAddrWidths9 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table7 = new PdfPTable(ContactAddrWidths9);
	            Table7.setWidthPercentage(100);
	            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table7.addCell(new Phrase(new Chunk(bu_tax_info,small_black_normal)));
	
	            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table7.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table7.addCell(new Phrase(new Chunk(tax_info,small_black_normal)));
	            
	            PdfPTable InvoiceDateInfoTable;
	            PdfPTable BillingPeriodInfoTable;
	            
	            float[] InvoiceDateInfoWidths_qr = {0.30f, 0.20f, 0.70f};
				PdfPTable InvoiceDateInfoTable_qr = new PdfPTable(InvoiceDateInfoWidths_qr);
				if(!irn_no.equals("") && !qr_code.equals(""))
				{
					float[] InvoiceDateInfoWidths = {0.60F,0.40F};
		            InvoiceDateInfoTable = new PdfPTable(InvoiceDateInfoWidths);
		            InvoiceDateInfoTable.setWidthPercentage(100);
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
					InvoiceDateInfoTable.addCell(new Phrase(new Chunk("Invoice Date :",black_bold)));
					InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
					InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(invoice_dt,black_bold)));
		            
		            //due date
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk("Payment Due Date :",black_bold)));
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(invoice_due_dt,black_bold)));
		            
		            //inv no
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(company_abbr+" TAX Invoice Seq No:",black_bold)));
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(invoice_no,black_bold)));
		            
		            float[] BillingPeriodInfoWidths = {0.30F,0.20F,0.10F,0.20F};
		            BillingPeriodInfoTable = new PdfPTable(BillingPeriodInfoWidths);
		            BillingPeriodInfoTable.setWidthPercentage(100);
		            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.addCell(new Phrase(new Chunk("Billing Period : ",black_bold)));
		            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.addCell(new Phrase(new Chunk(""+period_start_dt,black_bold)));
		            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            BillingPeriodInfoTable.addCell(new Phrase(new Chunk("to",black_bold)));
		            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.addCell(new Phrase(new Chunk(""+period_end_dt,black_bold)));
		            
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            	InvoiceDateInfoTable.getDefaultCell().setColspan(3);
	            	InvoiceDateInfoTable.addCell(BillingPeriodInfoTable);
		               
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            InvoiceDateInfoTable.getDefaultCell().setColspan(3);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk("",small_black_bold)));
					
					int width=90;
					int height=90;
					Hashtable<EncodeHintType, ErrorCorrectionLevel> hintMap = new Hashtable<>();
			        hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
	
			        QRCodeWriter qrCodeWriter = new QRCodeWriter();
			        BitMatrix matrix = qrCodeWriter.encode(qr_code, BarcodeFormat.QR_CODE, width, height, hintMap);
	
			        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			        for (int x = 0; x < width; x++) 
			        {
			            for (int y = 0; y < height; y++) 
			            {
			                image.setRGB(x, y, matrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
			            }
			        }
			        
			        BufferedImage qrImage = image;
			        
			        ByteArrayOutputStream baos = new ByteArrayOutputStream();
			        ImageIO.write(qrImage, "png", baos);
			        Image qr_codeimg = Image.getInstance(baos.toByteArray());
					qr_codeimg.setBorder(Rectangle.NO_BORDER);
	                qr_codeimg.setAlignment(Element.ALIGN_LEFT);
	                PdfPCell qrcode_cell = new PdfPCell(qr_codeimg,false);
	                qrcode_cell.setBorder(Rectangle.NO_BORDER);
	                qrcode_cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	                
	                String char_16= irn_no.substring(0,16);
	                String char_32= irn_no.substring(16,32);
	                String char_48= irn_no.substring(32,48);
	                String char_64= irn_no.substring(48,irn_no.length());
	                String final_irn_no=char_16+"\n"+char_32+"\n"+char_48+"\n"+char_64;
	                
	                PdfPTable InvoiceDateInfoTable_qr1 = new PdfPTable(1);
	       	        InvoiceDateInfoTable_qr1.setWidthPercentage(100);
	       	        InvoiceDateInfoTable_qr1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	       	        InvoiceDateInfoTable_qr1.getDefaultCell().setBorder(Rectangle.BOX);
	       	        InvoiceDateInfoTable_qr1.addCell(qrcode_cell);
	       	        
	       	        PdfPTable InvoiceDateInfoTable_qr11 = new PdfPTable(1);
	    	        InvoiceDateInfoTable_qr11.setWidthPercentage(100);
	    	        InvoiceDateInfoTable_qr11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	    	        InvoiceDateInfoTable_qr11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	    	        InvoiceDateInfoTable_qr11.addCell(new Phrase(new Chunk("IRN",black_bold)));
	    	        InvoiceDateInfoTable_qr11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	    	        InvoiceDateInfoTable_qr11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	    	        InvoiceDateInfoTable_qr11.addCell(new Phrase(new Chunk(final_irn_no,small_black_normal)));
	    	        
	    	        InvoiceDateInfoTable_qr.setWidthPercentage(100);
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	       	        InvoiceDateInfoTable_qr.addCell(InvoiceDateInfoTable_qr1);
	       	        
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setBorder(Rectangle.BOX);
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	       	        InvoiceDateInfoTable_qr.addCell(InvoiceDateInfoTable_qr11);
	       	        
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	       	        InvoiceDateInfoTable_qr.addCell(InvoiceDateInfoTable);
				}
	
	            float[] ContactAddrWidths10 = {0.80F,0.30F,0.30F,0.40F};
	   	     	PdfPTable Table8 = new PdfPTable(ContactAddrWidths10);
	            Table8.setWidthPercentage(100);
	            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table8.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table8.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table8.addCell(new Phrase(new Chunk("Invoice Date :",black_bold)));
	
	            Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            //Table8.addCell(new Phrase(new Chunk(dateUtil.getDateFormatDD_MOM_YY(invoice_dt),small_black_normal)));
	            Table8.addCell(new Phrase(new Chunk(invoice_dt,black_bold)));
	
	            float[] ContactAddrWidths11 = {0.80F,0.30F,0.30F,0.40F};
	   	     	PdfPTable Table9 = new PdfPTable(ContactAddrWidths11);
	            Table9.setWidthPercentage(100);
	            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table9.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table9.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table9.addCell(new Phrase(new Chunk("Payment Due Date :",black_bold)));
	
	            Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            //Table9.addCell(new Phrase(new Chunk(dateUtil.getDateFormatDD_MOM_YY(invoice_due_dt),small_black_normal)));
	            Table9.addCell(new Phrase(new Chunk(invoice_due_dt,black_bold)));
	
	            float[] ContactAddrWidths12 = {0.80F,0.10F,0.50F,0.40F};
	   	     	PdfPTable Table10 = new PdfPTable(ContactAddrWidths12);
	            Table10.setWidthPercentage(100);
	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk(company_abbr+" TAX Invoice Seq No:",black_bold)));
	
	            Table10.getDefaultCell().setBorder(Rectangle.BOX);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk(invoice_no,black_bold)));
	
	            float[] ContactAddrWidths12_1 = {0.80F,0.20F,0.10F,0.20F};
	   	     	PdfPTable Table10_1 = new PdfPTable(ContactAddrWidths12_1);
	   	     	Table10_1.setWidthPercentage(100);
	            Table10_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.addCell(new Phrase(new Chunk("Billing Period : ",black_bold)));
	
	            Table10_1.getDefaultCell().setBorder(Rectangle.BOX);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.addCell(new Phrase(new Chunk(""+period_start_dt,black_bold)));
	
	            Table10_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table10_1.addCell(new Phrase(new Chunk("to",black_bold)));
	
	            Table10_1.getDefaultCell().setBorder(Rectangle.BOX);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.addCell(new Phrase(new Chunk(""+period_end_dt,black_bold)));
	
	            float[] ContactAddrWidths13 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	PdfPTable Table11 = new PdfPTable(ContactAddrWidths13);
	            Table11.setWidthPercentage(100);
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Sr.No.",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Item Description",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Attachment",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Currency",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            if(unit_desc.equals("TRUCK")) {
	            	Table11.addCell(new Phrase(new Chunk("Quantity\n(No.Of Trucks)",small_black_bold)));
	            }
	            else {
	            	Table11.addCell(new Phrase(new Chunk("Quantity\n("+unit_desc+")",small_black_bold)));
	            }
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Rate",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Amount",small_black_bold)));
	
	            String salesValue="";
	            salesValue=""+gross_amt;
	
	            String curr="";
	            String curr1="";
	            if(price_cd.equals("1"))
	            {
	            	curr="INR";
	            }
	            else if(price_cd.equals("2"))
	            {
	            	curr="USD";
	            }
	
	            if(invoice_raised_in.equals("1"))
	            {
	            	curr1="INR";
	            }
	            else if(invoice_raised_in.equals("2"))
	            {
	            	curr1="USD";
	            }
	
	            int sr=1;
	
	            float[] ContactAddrWidths14 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	PdfPTable Table12 = new PdfPTable(ContactAddrWidths14);
	            Table12.setWidthPercentage(100);
	            //Table12.getDefaultCell().setBorderWidthBottom(0);

            	String mnthYr="";
				if(!temp_period_end_dt.equals(""))
				{
					mnthYr=temp_period_end_dt.substring(3,temp_period_end_dt.length());
					String[] split= mnthYr.split("/");
					mnthYr=dateUtil.getMonthName(temp_period_end_dt)+"-"+split[1];
				}
				
            	Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table12.addCell(new Phrase(new Chunk("Transport Management Services Charge",small_black_normal)));
				
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk("Att1",small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table12.addCell(new Phrase(new Chunk(curr1,small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk(qty_mmbtu,small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk(price,small_black_normal)));
	
	            Table12.getDefaultCell().setBorder(Rectangle.BOX);
	            Table12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table12.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table12.addCell(new Phrase(new Chunk(gross_amt,small_black_normal)));
	            
	            if(!invoice_raised_in.equals(price_cd))
	            {
	            	sr+=1;
	            }
	            float[] ContactAddrWidths15 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	PdfPTable Table13 = new PdfPTable(ContactAddrWidths15);
	            Table13.setWidthPercentage(100);
	            //Table13.getDefaultCell().setBorderWidthTop(0);
	
	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table13.addCell(new Phrase(new Chunk("Exchange Rate",small_black_normal)));
	
	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk("Att2",small_black_normal)));
	
	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table13.addCell(new Phrase(new Chunk("INR/USD",small_black_normal)));
	
	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk(exchang_rate,small_black_normal)));
	
	            Table13.getDefaultCell().setBorder(Rectangle.BOX);
	            Table13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table13.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table13.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            if(!inv_flag.equals("UG"))
	   	     	{
	            	sr+=1;
	   	     	}
	            float[] ContactAddrWidths16 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	PdfPTable Table14 = new PdfPTable(ContactAddrWidths16);
	            Table14.setWidthPercentage(100);
	            //Table14.getDefaultCell().setBorderWidthBottom(0);
	
	            Table14.getDefaultCell().setBorder(Rectangle.BOX);
	            Table14.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table14.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table14.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	            Table14.getDefaultCell().setBorder(Rectangle.BOX);
	            Table14.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table14.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table14.addCell(new Phrase(new Chunk("Gross Amount",small_black_normal)));
	
	            Table14.getDefaultCell().setBorder(Rectangle.BOX);
	            Table14.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table14.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table14.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table14.getDefaultCell().setBorder(Rectangle.BOX);
	            Table14.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table14.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table14.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	            Table14.getDefaultCell().setBorder(Rectangle.BOX);
	            Table14.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table14.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table14.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table14.getDefaultCell().setBorder(Rectangle.BOX);
	            Table14.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table14.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table14.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table14.getDefaultCell().setBorder(Rectangle.BOX);
	            Table14.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table14.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table14.addCell(new Phrase(new Chunk(gross_amt1,small_black_normal)));
	            
	            float[] ContactAddrWidths26 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	    	    PdfPTable Table24 = new PdfPTable(ContactAddrWidths26);
	    	    
	    	    float[] ContactAddrWidths27 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	    	    PdfPTable Table25 = new PdfPTable(ContactAddrWidths27);
	    	    
	            if(isGrossIncTriff)
	            {
	            	sr+=1;
	            	
	        	    Table25.setWidthPercentage(100);
	                 
	        	    Table25.getDefaultCell().setBorder(Rectangle.BOX);
	        	    Table25.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	        	    Table25.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	        	    Table25.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	        	    Table25.getDefaultCell().setBorder(Rectangle.BOX);
	        	    Table25.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	        	    Table25.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	        	    Table25.addCell(new Phrase(new Chunk("Total Gross Amount",small_black_normal)));
	
	        	    Table25.getDefaultCell().setBorder(Rectangle.BOX);
	        	    Table25.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	        	    Table25.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	        	    Table25.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	        	    Table25.getDefaultCell().setBorder(Rectangle.BOX);
	        	    Table25.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	        	    Table25.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	        	    Table25.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	        	    Table25.getDefaultCell().setBorder(Rectangle.BOX);
	        	    Table25.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	        	    Table25.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	        	    Table25.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	        	    Table25.getDefaultCell().setBorder(Rectangle.BOX);
	        	    Table25.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	        	    Table25.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	        	    Table25.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	        	    Table25.getDefaultCell().setBorder(Rectangle.BOX);
	        	    Table25.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	        	    Table25.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	        	    Table25.addCell(new Phrase(new Chunk(gross_include_transport_tariff,small_black_normal)));
	            }
	
	            sr+=1;
	            float[] ContactAddrWidths17 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	PdfPTable Table15 = new PdfPTable(ContactAddrWidths17);
	   	     	/*if(!contract_type.equals("I")) {
	   	     	Table15.getDefaultCell().setBorderWidthTop(0);
	   	     	}else {
	   	     	Table15.getDefaultCell().setBorderWidthTop(0);
	   	     	Table15.getDefaultCell().setBorderWidthBottom(0);
	   	     	}*/
	
	   	     	Table15.setWidthPercentage(100);
	            Table15.getDefaultCell().setBorder(Rectangle.BOX);
	            Table15.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table15.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table15.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	            Table15.getDefaultCell().setBorder(Rectangle.BOX);
	            Table15.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table15.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table15.addCell(new Phrase(new Chunk("Tax ("+tax_struct_dtl+")",small_black_normal)));
	            
	            Table15.getDefaultCell().setBorder(Rectangle.BOX);
	            Table15.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table15.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table15.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table15.getDefaultCell().setBorder(Rectangle.BOX);
	            Table15.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table15.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table15.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	            Table15.getDefaultCell().setBorder(Rectangle.BOX);
	            Table15.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table15.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table15.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table15.getDefaultCell().setBorder(Rectangle.BOX);
	            Table15.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table15.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table15.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table15.getDefaultCell().setBorder(Rectangle.BOX);
	            Table15.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table15.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table15.addCell(new Phrase(new Chunk(tax_amt,small_black_normal)));
	            
	            queryString1="SELECT COUNT(*) "
						+ "FROM FMS_DLNG_SVC_INV_TAX_DTL "
						+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
						+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
	            stmt1=conn.prepareStatement(queryString1);
	            stmt1.setString(1, comp_cd);
	            stmt1.setString(2, bu_state_tin);
	            stmt1.setString(3, financial_year);
	            stmt1.setString(4, inv_seq);
	            rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					if(rset1.getInt(1)>1)
					{
						double temp_srno=sr;
						queryString="SELECT TAX_CODE,TAX_DESCR,TAX_AMT,TAX_BASE_AMT "
								+ "FROM FMS_DLNG_SVC_INV_TAX_DTL "
								+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
								+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
						stmt=conn.prepareStatement(queryString);
			            stmt.setString(1, comp_cd);
			            stmt.setString(2, bu_state_tin);
			            stmt.setString(3, financial_year);
			            stmt.setString(4, inv_seq);
			            rset=stmt.executeQuery();
						while(rset.next())
						{
							temp_srno=temp_srno+0.1;
							
							String tax_descr=rset.getString(2)==null?"":rset.getString(2);
							String taxAmt=rset.getString(3)==null?"":nf.format(rset.getDouble(3));
							
							Table15.setWidthPercentage(100);
				            Table15.getDefaultCell().setBorder(Rectangle.BOX);
				            Table15.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				            Table15.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				            Table15.addCell(new Phrase(new Chunk(""+nf0.format(temp_srno),small_black_normal)));
	
				            Table15.getDefaultCell().setBorder(Rectangle.BOX);
				            Table15.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            Table15.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				            Table15.addCell(new Phrase(new Chunk(""+tax_descr+"",small_black_normal)));
				            
				            Table15.getDefaultCell().setBorder(Rectangle.BOX);
				            Table15.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				            Table15.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				            Table15.addCell(new Phrase(new Chunk("",small_black_normal)));
	
				            Table15.getDefaultCell().setBorder(Rectangle.BOX);
				            Table15.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				            Table15.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				            Table15.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
				            Table15.getDefaultCell().setBorder(Rectangle.BOX);
				            Table15.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            Table15.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				            Table15.addCell(new Phrase(new Chunk("",small_black_normal)));
	
				            Table15.getDefaultCell().setBorder(Rectangle.BOX);
				            Table15.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            Table15.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				            Table15.addCell(new Phrase(new Chunk("",small_black_normal)));
	
				            Table15.getDefaultCell().setBorder(Rectangle.BOX);
				            Table15.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
				            Table15.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
				            Table15.addCell(new Phrase(new Chunk(taxAmt,small_black_normal)));
						}
						rset.close();
						stmt.close();
					}
				}
				rset1.close();
				stmt1.close();
				
	            /*float[] ContactAddrWidths23 = {0.05F,0.60F,0.20F,0.20F,0.20F,0.20F};
	   	     	PdfPTable Table21 = new PdfPTable(ContactAddrWidths23);
	
	            float[] ContactAddrWidths24 = {0.05F,0.60F,0.20F,0.20F,0.20F,0.20F};
	   	     	PdfPTable Table25 = new PdfPTable(ContactAddrWidths24);
	   	     	if(contract_type.equals("I"))
	            {
	            	sr+=1;
	            	Table21.getDefaultCell().setBorderWidthTop(0);
	            	Table21.getDefaultCell().setBorderWidthBottom(0);
	
	            	Table21.setWidthPercentage(100);
	                Table21.getDefaultCell().setBorder(Rectangle.BOX);
	                Table21.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table21.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table21.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	                Table21.getDefaultCell().setBorder(Rectangle.BOX);
	                Table21.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	                Table21.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	
	                if(inv_type.equals("P"))
	                {
	                	Table21.addCell(new Phrase(new Chunk("IGX TXN Charges",small_black_normal)));
	                }
	                else
	                {
	                	Table21.addCell(new Phrase(new Chunk("IGX TXN Charges ("+invoice_data.get("TxnChrg")+"%)",small_black_normal)));
	                }
	                Table21.getDefaultCell().setBorder(Rectangle.BOX);
	                Table21.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table21.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table21.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	                Table21.getDefaultCell().setBorder(Rectangle.BOX);
	                Table21.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table21.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table21.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	                Table21.getDefaultCell().setBorder(Rectangle.BOX);
	                Table21.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table21.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table21.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	                Table21.getDefaultCell().setBorder(Rectangle.BOX);
	                Table21.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table21.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table21.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	                Table21.getDefaultCell().setBorder(Rectangle.BOX);
	                Table21.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table21.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table21.addCell(new Phrase(new Chunk(""+invoice_data.get("TxnAmount"),small_black_normal)));
	
	                sr+=1;
	                Table22.getDefaultCell().setBorderWidthTop(0);
	
	       	     	Table22.setWidthPercentage(100);
	                Table22.getDefaultCell().setBorder(Rectangle.BOX);
	                Table22.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table22.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table22.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	                Table22.getDefaultCell().setBorder(Rectangle.BOX);
	                Table22.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	                Table22.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	
	                if(inv_type.equals("P"))
	                {
	                	Table22.addCell(new Phrase(new Chunk("Tax on IGX TXN",small_black_normal)));
	                }
	                else
	                {
	                	Table22.addCell(new Phrase(new Chunk("Tax on IGX TXN ("+invoice_data.get("TaxTxnDtl")+")",small_black_normal)));
	                }
	                Table22.getDefaultCell().setBorder(Rectangle.BOX);
	                Table22.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table22.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table22.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	                Table22.getDefaultCell().setBorder(Rectangle.BOX);
	                Table22.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table22.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table22.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	                Table22.getDefaultCell().setBorder(Rectangle.BOX);
	                Table22.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table22.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table22.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	                Table22.getDefaultCell().setBorder(Rectangle.BOX);
	                Table22.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table22.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table22.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	                Table22.getDefaultCell().setBorder(Rectangle.BOX);
	                Table22.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table22.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table22.addCell(new Phrase(new Chunk(""+invoice_data.get("TaxTxnChrg"),small_black_normal)));
	            }*/
	
				String invAmtLbl="Invoice Amount";
	            sr+=1;
	            float[] ContactAddrWidths18 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	PdfPTable Table16 = new PdfPTable(ContactAddrWidths18);
	   	     	//Table16.getDefaultCell().setBorderWidthBottom(0);
	
	   	     	Table16.setWidthPercentage(100);
	            Table16.getDefaultCell().setBorder(Rectangle.BOX);
	            Table16.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table16.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table16.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	            Table16.getDefaultCell().setBorder(Rectangle.BOX);
	            Table16.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table16.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table16.addCell(new Phrase(new Chunk(invAmtLbl,small_black_normal)));
	
	            Table16.getDefaultCell().setBorder(Rectangle.BOX);
	            Table16.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table16.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table16.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table16.getDefaultCell().setBorder(Rectangle.BOX);
	            Table16.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table16.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table16.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	            Table16.getDefaultCell().setBorder(Rectangle.BOX);
	            Table16.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table16.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table16.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table16.getDefaultCell().setBorder(Rectangle.BOX);
	            Table16.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table16.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table16.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table16.getDefaultCell().setBorder(Rectangle.BOX);
	            Table16.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table16.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table16.addCell(new Phrase(new Chunk(invoice_amt,small_black_normal)));
	            
	            if(applicable_abbr.equals("TCS"))
	            {
	            	sr+=1;
	            	
	            	Table16.setWidthPercentage(100);
	                Table16.getDefaultCell().setBorder(Rectangle.BOX);
	                Table16.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table16.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table16.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	                Table16.getDefaultCell().setBorder(Rectangle.BOX);
	                Table16.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	                Table16.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	                Table16.addCell(new Phrase(new Chunk("TCS",small_black_normal)));
	
	                Table16.getDefaultCell().setBorder(Rectangle.BOX);
	                Table16.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table16.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table16.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	                Table16.getDefaultCell().setBorder(Rectangle.BOX);
	                Table16.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table16.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table16.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	                Table16.getDefaultCell().setBorder(Rectangle.BOX);
	                Table16.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table16.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table16.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	                Table16.getDefaultCell().setBorder(Rectangle.BOX);
	                Table16.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table16.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table16.addCell(new Phrase(new Chunk(TCS_factor+"%",small_black_normal)));
	
	                Table16.getDefaultCell().setBorder(Rectangle.BOX);
	                Table16.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table16.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table16.addCell(new Phrase(new Chunk(applicable_amt,small_black_normal)));
	            }
	            
	            float[] ContactAddrWidths20 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	PdfPTable Table18 = new PdfPTable(ContactAddrWidths20);
	            int adv_count=0;
	            double adjted_amt=0;
//	            queryString1="SELECT COUNT(*) "
//						+ "FROM FMS_INV_ADV_DTL "
//						+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
//						+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
//	            stmt1=conn.prepareStatement(queryString1);
//	            stmt1.setString(1, comp_cd);
//	            stmt1.setString(2, bu_state_tin);
//	            stmt1.setString(3, financial_year);
//	            stmt1.setString(4, inv_seq);
//	            rset1=stmt1.executeQuery();
//				if(rset1.next())
//				{
//					adv_count=rset1.getInt(1);
//				}
//				rset1.close();
//				stmt1.close();
				
				if(adv_count > 0)
				{
					queryString2="SELECT SUM(AMOUNT), LISTAGG(SEC_INT_REF, ',') WITHIN GROUP (ORDER BY SEC_INT_REF) AS SEC_INT_REF_LIST "
							+ "FROM FMS_INV_ADV_DTL "
							+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
							+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? AND INV_COMPONENT=? ";
					stmt2=conn.prepareStatement(queryString2);
					stmt2.setString(1, comp_cd);
					stmt2.setString(2, bu_state_tin);
					stmt2.setString(3, financial_year);
					stmt2.setString(4, inv_seq);
					stmt2.setString(5, "GROSS");
					rset2=stmt2.executeQuery();
					if(rset2.next())
					{
						adjted_amt+=rset2.getDouble(1);
						String receVouchMap=rset2.getString(2)==null?"":rset2.getString(2);
						
						sr+=1;
			   	     	Table18.setWidthPercentage(100);
			            Table18.getDefaultCell().setBorder(Rectangle.BOX);
			            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			            Table18.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
			
			            Table18.getDefaultCell().setBorder(Rectangle.BOX);
			            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
			            Table18.addCell(new Phrase(new Chunk("Adjustment for Advance Gross paid against Receipt Voucher No "+receVouchMap,small_black_normal)));
			
			            Table18.getDefaultCell().setBorder(Rectangle.BOX);
			            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			            Table18.addCell(new Phrase(new Chunk("",small_black_normal)));
			
			            Table18.getDefaultCell().setBorder(Rectangle.BOX);
			            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
			            Table18.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
			
			            Table18.getDefaultCell().setBorder(Rectangle.BOX);
			            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
			            Table18.addCell(new Phrase(new Chunk("",small_black_normal)));
			
			            Table18.getDefaultCell().setBorder(Rectangle.BOX);
			            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
			            Table18.addCell(new Phrase(new Chunk("",small_black_normal)));
			
			            Table18.getDefaultCell().setBorder(Rectangle.BOX);
			            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
			            Table18.addCell(new Phrase(new Chunk(rset2.getString(1)==null?"":nf.format(rset2.getDouble(1)),small_black_normal)));
					}
					rset2.close();
					stmt2.close();
					
					queryString="SELECT TAX_DESCR "
							+ "FROM FMS_DLNG_SVC_INV_TAX_DTL "
							+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
							+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(1, comp_cd);
					stmt.setString(2, bu_state_tin);
					stmt.setString(3, financial_year);
					stmt.setString(4, inv_seq);
					rset=stmt.executeQuery();
					while(rset.next())
					{
						String taxDesc=rset.getString(1)==null?"":rset.getString(1);
						String taxAbbr="";
						if(!taxDesc.equals(""))
						{
							String[] split=taxDesc.split(" ");
							taxAbbr=split[0];
						}
						
						queryString2="SELECT SUM(AMOUNT), LISTAGG(SEC_INT_REF, ',') WITHIN GROUP (ORDER BY SEC_INT_REF) AS SEC_INT_REF_LIST "
								+ "FROM FMS_INV_ADV_DTL "
								+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
								+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? AND INV_COMPONENT=? ";
						stmt2=conn.prepareStatement(queryString2);
						stmt2.setString(1, comp_cd);
						stmt2.setString(2, bu_state_tin);
						stmt2.setString(3, financial_year);
						stmt2.setString(4, inv_seq);
						stmt2.setString(5, taxAbbr);
						rset2=stmt2.executeQuery();
						if(rset2.next())
						{
							adjted_amt+=rset2.getDouble(1);
							String receVouchMap=rset2.getString(2)==null?"":rset2.getString(2);
							
							sr+=1;
				   	     	Table18.setWidthPercentage(100);
				            Table18.getDefaultCell().setBorder(Rectangle.BOX);
				            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				            Table18.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
				
				            Table18.getDefaultCell().setBorder(Rectangle.BOX);
				            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
				            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
				            Table18.addCell(new Phrase(new Chunk("Adjustment for Advance "+taxAbbr+" paid against Receipt Voucher No "+receVouchMap,small_black_normal)));
				
				            Table18.getDefaultCell().setBorder(Rectangle.BOX);
				            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				            Table18.addCell(new Phrase(new Chunk("",small_black_normal)));
				
				            Table18.getDefaultCell().setBorder(Rectangle.BOX);
				            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				            Table18.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
				
				            Table18.getDefaultCell().setBorder(Rectangle.BOX);
				            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				            Table18.addCell(new Phrase(new Chunk("",small_black_normal)));
				
				            Table18.getDefaultCell().setBorder(Rectangle.BOX);
				            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				            Table18.addCell(new Phrase(new Chunk("",small_black_normal)));
				
				            Table18.getDefaultCell().setBorder(Rectangle.BOX);
				            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
				            Table18.addCell(new Phrase(new Chunk(rset2.getString(1)==null?"":nf.format(rset2.getDouble(1)),small_black_normal)));
						}
						rset2.close();
						stmt2.close();
					}
					rset.close();
					stmt.close();
					
					sr+=1;
		   	     	Table18.setWidthPercentage(100);
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table18.addCell(new Phrase(new Chunk(""+sr,black_bold)));
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		            Table18.addCell(new Phrase(new Chunk("Net Amount Payable",black_bold)));
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table18.addCell(new Phrase(new Chunk("",black_bold)));
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table18.addCell(new Phrase(new Chunk(""+curr1,black_bold)));
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            Table18.addCell(new Phrase(new Chunk("",black_bold)));
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            Table18.addCell(new Phrase(new Chunk("",black_bold)));
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            Table18.addCell(new Phrase(new Chunk(nf.format(Double.parseDouble(net_payable) - adjted_amt),black_bold)));
				}
				else
				{
		            sr+=1;
		   	     	Table18.setWidthPercentage(100);
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table18.addCell(new Phrase(new Chunk(""+sr,black_bold)));
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		            Table18.addCell(new Phrase(new Chunk("Net Amount Payable",black_bold)));
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table18.addCell(new Phrase(new Chunk("",black_bold)));
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table18.addCell(new Phrase(new Chunk(""+curr1,black_bold)));
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            Table18.addCell(new Phrase(new Chunk("",black_bold)));
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            Table18.addCell(new Phrase(new Chunk("",black_bold)));
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            Table18.addCell(new Phrase(new Chunk(net_payable,black_bold)));
				}
	
	            float[] ContactAddrWidths21 = {0.100F};
	   	     	PdfPTable Table19 = new PdfPTable(ContactAddrWidths21);
	   	     	Table19.setWidthPercentage(100);
	   	     	Table19.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	Table19.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	Table19.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	     	Table19.addCell(new Phrase(new Chunk(remark_1,small_black_normal)));
	
	   	     	float[] ContactAddrWidths22 = {0.100F};
		     	PdfPTable Table20 = new PdfPTable(ContactAddrWidths22);
		     	Table20.setWidthPercentage(100);
		     	Table20.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		     	Table20.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		     	Table20.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		     	Table20.addCell(new Phrase(new Chunk(remark_2,small_black_normal)));
		     	
		     	float[] ContactAddrWidths23 = {0.100F};
	   	     	PdfPTable Table21 = new PdfPTable(ContactAddrWidths21);
	   	     	Table21.setWidthPercentage(100);
	   	     	Table21.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	Table21.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	  		Table21.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	  		Table21.addCell(new Phrase(new Chunk("For "+company_nm,black_bold)));
	   	  		
	   	  		// create a signature form field
	   	     	PdfPTable BillingFieldsInfoTable81 = new PdfPTable(1);
	   	     	BillingFieldsInfoTable81.setWidthPercentage(20);
	   	     	BillingFieldsInfoTable81.setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	BillingFieldsInfoTable81.getDefaultCell().setBorder(Rectangle.BOX);
	   	     	BillingFieldsInfoTable81.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	BillingFieldsInfoTable81.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	        
	   	     	PdfFormField field = PdfFormField.createSignature(writer);
	   	     	field.setFieldName(SIGNAME);
	   	     	// set the widget properties
	   	     	field.setPage();
	   	     	field.setWidget(new Rectangle(72, 732, 144, 780), PdfAnnotation.HIGHLIGHT_NONE);
	   	     	field.setFlags(PdfAnnotation.FLAGS_PRINT);
	   	     	writer.addAnnotation(field);
	         
	   	     	PdfPCell sigCell = new PdfPCell();
	   	     	FieldPositioningEvents events = new FieldPositioningEvents(writer, field);
	   	     	sigCell.setCellEvent(events);
	   	     	sigCell.setFixedHeight(50f);
	   	     	BillingFieldsInfoTable81.addCell(sigCell);
	
	   	     	float[] ContactAddrWidths24 = {0.100F};
		     	PdfPTable Table22 = new PdfPTable(ContactAddrWidths22);
	
		     	Table22.setWidthPercentage(100);
		     	Table22.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		     	Table22.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		     	Table22.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		     	Table22.addCell(new Phrase(new Chunk("Authorised Signatory",black_bold)));
		     	
		     	document.add(LogoTable);
				document.add(HlplLogoTable);
				document.add(Table);
				document.add(Table1);
				document.add(Table2);
				document.add(new Paragraph("  "));
				document.add(Table3);
				document.add(Table4);
				document.add(Table5);
				document.add(Table6);
				document.add(Table7);
				document.add(new Paragraph("  "));
				document.add(new Paragraph("  "));
				if(!irn_no.equals("") && !qr_code.equals(""))
				{
					document.add(InvoiceDateInfoTable_qr);
				}
				else
				{
					document.add(Table8);
					document.add(Table9);
					document.add(Table10);
					document.add(Table10_1);
				}
				document.add(new Paragraph("  "));
				document.add(Table11);
				document.add(Table12);
				if(!price_cd.equals(invoice_raised_in))
				{
					document.add(Table13);
				}
				
				document.add(Table14);
				
				//if(agmt_base.equals("D"))
				{
					document.add(Table24);
					document.add(Table25);
				}
				document.add(Table15);
				/*if(contract_type.equals("I"))
	            {
					document.add(Table21);
					document.add(Table22);
	            }*/
				document.add(Table16);
				document.add(Table18);
				document.add(new Paragraph("  "));
				document.add(Table19);
				document.add(Table20);
				document.add(new Paragraph("  "));
				document.add(new Paragraph("  "));
				document.add(Table21);
				document.add(BillingFieldsInfoTable81);
				document.add(Table22);
				
				//////////////////////////////////////////////////////
				
				//For Attachment 1
				Font big_black_bold = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD, BaseColor.BLACK);
				Font small_black_bold2 = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, BaseColor.BLACK);
				
				document.setPageSize(pageSize1);
	            document.newPage();
	            
	            float[] att1_ContactAddrWidths1 = {0.80f,0.10F,0.20F,0.80F};
	   	     	PdfPTable att1_Table1 = new PdfPTable(att1_ContactAddrWidths1);
	            att1_Table1.setWidthPercentage(100);
	            att1_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            //att1_Table1.addCell(new Phrase(new Chunk("Business Unit: "+bu_plantNm,black_bold)));
	            att1_Table1.addCell(new Phrase(new Chunk("Business Unit: ",black_bold)));
	            
	            att1_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.addCell(new Phrase(new Chunk("",black_bold)));
	            
	            att1_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.addCell(new Phrase(new Chunk("To:",black_bold)));
	
	            att1_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.addCell(new Phrase(new Chunk(""+contact_person_nm+",",black_bold)));
	
				float[] att1_ContactAddrWidths2 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable att1_Table2 = new PdfPTable(att1_ContactAddrWidths2);
	   	     	att1_Table2.setWidthPercentage(100);
	            att1_Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table2.addCell(new Phrase(new Chunk(company_nm,small_black_normal)));
	            
	            att1_Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table2.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table2.addCell(new Phrase(new Chunk(counterparty_nm,small_black_normal)));
	
	            float[] att1_ContactAddrWidths3 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable att1_Table3 = new PdfPTable(att1_ContactAddrWidths3);
	            att1_Table3.setWidthPercentage(100);
	            att1_Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table3.addCell(new Phrase(new Chunk(bu_plantAddress+","+bu_plantCity,small_black_normal)));
	            
	            att1_Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table3.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
	            att1_Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table3.addCell(new Phrase(new Chunk(plantAddress+","+plantCity,small_black_normal)));
	            
	
	            float[] att1_ContactAddrWidths4 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable att1_Table4 = new PdfPTable(att1_ContactAddrWidths4);
	            att1_Table4.setWidthPercentage(100);
	            att1_Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table4.addCell(new Phrase(new Chunk(bu_plantState+" - "+bu_plantPin,small_black_normal)));
	
	            att1_Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table4.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
	            att1_Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table4.addCell(new Phrase(new Chunk(plantState+" - "+plantPin,small_black_normal)));
	            
	            String title_note="ATTACHMENT 1 -  Service Invoice Details";
	            
	            PdfPTable title_note_table = new PdfPTable(1);
	            title_note_table.setWidthPercentage(100);
	            title_note_table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            title_note_table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            title_note_table.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            title_note_table.addCell(new Phrase(new Chunk(title_note,big_black_bold)));
	            
	            float[] att1_ContactAddrWidths5 = {0.80F,0.30F,0.30F,0.40F};
	   	     	PdfPTable att1_Table5 = new PdfPTable(att1_ContactAddrWidths5);
	            att1_Table5.setWidthPercentage(100);
	            att1_Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.addCell(new Phrase(new Chunk("Invoice Date :",black_bold)));
	
	            att1_Table5.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            //att1_Table5.addCell(new Phrase(new Chunk(dateUtil.getDateFormatDD_MOM_YY(invoice_dt),small_black_normal)));
	            att1_Table5.addCell(new Phrase(new Chunk(invoice_dt,black_bold)));
	
	            float[] att1_ContactAddrWidths6 = {0.80F,0.30F,0.30F,0.40F};
	   	     	PdfPTable att1_Table6 = new PdfPTable(att1_ContactAddrWidths6);
	            att1_Table6.setWidthPercentage(100);
	            att1_Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.addCell(new Phrase(new Chunk("Payment Due Date :",black_bold)));
	
	            att1_Table6.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            //att1_Table6.addCell(new Phrase(new Chunk(dateUtil.getDateFormatDD_MOM_YY(invoice_due_dt),small_black_normal)));
	            att1_Table6.addCell(new Phrase(new Chunk(invoice_due_dt,black_bold)));
	
	            float[] att1_ContactAddrWidths7 = {0.80F,0.10F,0.50F,0.40F};
	   	     	PdfPTable att1_Table7 = new PdfPTable(att1_ContactAddrWidths7);
	            att1_Table7.setWidthPercentage(100);
	            att1_Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk("",black_bold)));
	
	            att1_Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk(company_abbr+" TAX Invoice Seq No:",black_bold)));
	
	            att1_Table7.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk(invoice_no,black_bold)));
	
	            float[] att1_ContactAddrWidths8 = {0.80F,0.20F,0.10F,0.20F};
	   	     	PdfPTable att1_Table8 = new PdfPTable(att1_ContactAddrWidths8);
	   	     	att1_Table8.setWidthPercentage(100);
	            att1_Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table8.addCell(new Phrase(new Chunk("Billing Period : ",black_bold)));
	
	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table8.addCell(new Phrase(new Chunk(""+period_start_dt,black_bold)));
	
	            att1_Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.addCell(new Phrase(new Chunk("to",black_bold)));
	
	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table8.addCell(new Phrase(new Chunk(""+period_end_dt,black_bold)));
	            
	            float[] att1_ContactAddrWidths10 = {0.15f, 0.25f, 0.20f, 0.20f, 0.20f, 0.20f};
	            PdfPTable att1_Table10 = new PdfPTable(att1_ContactAddrWidths10);
	            att1_Table10.setWidthPercentage(100);
	            att1_Table10.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
	            att1_Table10.addCell(new Phrase(new Chunk("Sr. No",small_black_bold)));
	            att1_Table10.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
	            att1_Table10.addCell(new Phrase(new Chunk("Supply Date",small_black_bold)));
	            att1_Table10.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
	            att1_Table10.addCell(new Phrase(new Chunk("Truck No.",small_black_bold)));
	            att1_Table10.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
	            att1_Table10.addCell(new Phrase(new Chunk("Truck Quantity\n(MMBTU)",small_black_bold)));
		        att1_Table10.getDefaultCell().setBorder(Rectangle.BOX);
		        att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		        att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
		        att1_Table10.addCell(new Phrase(new Chunk("Rate\n("+curr+"/"+unit_desc+")",small_black_bold)));
		        att1_Table10.getDefaultCell().setBorder(Rectangle.BOX);
		        att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		        att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
		        att1_Table10.addCell(new Phrase(new Chunk("Amount\n("+curr+")",small_black_bold)));
		        
		        int srNo=0;
		        double sumAmount =0;
		        double sumQty =0;
		        
		        queryString2="SELECT INVOICE_SEQ, INVOICE_NO, QTY_MMBTU, DISTANCE, MAPPING_ID, TRUCK_CD, TRUCK_TRANS_CD "
						+ "FROM FMS_DLNG_SVC_INVOICE_DTL "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? AND AGMT_NO=? AND BU_UNIT=? AND CONTRACT_TYPE=? "
						+ "AND BU_STATE_TIN=? AND FINANCIAL_YEAR=? AND SVC_INVOICE_SEQ=? ";
				stmt2=conn.prepareStatement(queryString2);
				stmt2.setString(1, comp_cd);
				stmt2.setString(2, counterparty_cd);
				stmt2.setString(3, cont_no);
				stmt2.setString(4, agmt_no);
				stmt2.setString(5, bu_plant_seq);
				stmt2.setString(6, contract_type);
				stmt2.setString(7, bu_state_tin);
				stmt2.setString(8, financial_year);
				stmt2.setString(9, inv_seq);
				rset2=stmt2.executeQuery();
				while(rset2.next())
				{
					String invSeq = rset2.getString(1)==null?"":rset2.getString(1);
					String invoiceNo = rset2.getString(2)==null?"":rset2.getString(2);
					String qtyMmbtu = rset2.getString(3)==null?"":rset2.getString(3);
					String distance = rset2.getString(4)==null?"":rset2.getString(4);
					String mapping_id = rset2.getString(5)==null?"":rset2.getString(5);
					String truck_cd = rset2.getString(6)==null?"":rset2.getString(6);
					String truck_trans_cd = rset2.getString(7)==null?"":rset2.getString(7);
					
					String qtyMt = ""+(Double.parseDouble(qtyMmbtu)/mmbtuToMtConv);
					
					queryString3 = "SELECT TO_CHAR(INVOICE_DT,'DD/MM/YYYY'), TRUCK_CD "
							+ "FROM FMS_DLNG_INVOICE_MST "
							+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND INVOICE_SEQ = ? AND INVOICE_NO = ? "
							+ "AND MAPPING_ID = ? AND TRUCK_CD = ? AND TRUCK_TRANS_CD = ? ";
					stmt3 = conn.prepareStatement(queryString3);
					stmt3.setString(1, comp_cd);
					stmt3.setString(2, counterparty_cd);
					stmt3.setString(3, invSeq);
					stmt3.setString(4, invoiceNo);
					stmt3.setString(5, mapping_id);
					stmt3.setString(6, truck_cd);
					stmt3.setString(7, truck_trans_cd);
					rset3 = stmt3.executeQuery();
					if(rset3.next()) 
					{
						srNo++;
						
						String invDate = rset3.getString(1) == null ? "": rset3.getString(1);
						String truckRegNo = dlng_util.getTruckRegNo(conn, rset3.getString(2));
						
						String amount = "";
						if(unit_desc.equals("TRUCK")) 
						{
							amount = ""+(Double.parseDouble(price));
						}
						else if(unit_desc.equals("MMBTU")) 
						{
							amount = ""+(Double.parseDouble(price) * Double.parseDouble(qtyMmbtu));
						}
						else if(unit_desc.equals("KM"))
						{
							amount = ""+(Double.parseDouble(price) * Double.parseDouble(distance));
						}
						else if(unit_desc.equals("MT"))
						{
							amount = ""+(Double.parseDouble(price) * Double.parseDouble(qtyMt));
						}
						sumAmount = sumAmount + (Double.parseDouble(amount));
						sumQty = sumQty + (Double.parseDouble(qtyMmbtu));
						
						att1_Table10.getDefaultCell().setBorder(Rectangle.BOX);
			            att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			            att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att1_Table10.addCell(new Phrase(new Chunk(""+srNo,small_black_normal)));
			            att1_Table10.getDefaultCell().setBorder(Rectangle.BOX);
			            att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att1_Table10.addCell(new Phrase(new Chunk(invDate,small_black_normal)));
			            att1_Table10.getDefaultCell().setBorder(Rectangle.BOX);
			            att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att1_Table10.addCell(new Phrase(new Chunk(truckRegNo,small_black_normal)));
			            att1_Table10.getDefaultCell().setBorder(Rectangle.BOX);
			            att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att1_Table10.addCell(new Phrase(new Chunk(qtyMmbtu,small_black_normal)));
				        att1_Table10.getDefaultCell().setBorder(Rectangle.BOX);
				        att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				        att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
				        att1_Table10.addCell(new Phrase(new Chunk(price,small_black_normal)));
				        att1_Table10.getDefaultCell().setBorder(Rectangle.BOX);
				        att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				        att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
				        att1_Table10.addCell(new Phrase(new Chunk(amount,small_black_normal)));
					}
					rset3.close();
					stmt3.close();
				}
				rset2.close();
				stmt2.close();
				
				att1_Table10.getDefaultCell().setColspan(3);
				att1_Table10.getDefaultCell().setBorder(Rectangle.BOX);
		        att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		        att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
				att1_Table10.addCell(new Phrase(new Chunk("Total ",small_black_bold2)));
		        att1_Table10.getDefaultCell().setBorder(Rectangle.BOX);
		        att1_Table10.getDefaultCell().setColspan(1);
		        att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		        att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
		        att1_Table10.addCell(new Phrase(new Chunk(""+sumQty,small_black_bold2)));
		        att1_Table10.getDefaultCell().setBorder(Rectangle.BOX);
		        att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		        att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
		        att1_Table10.addCell(new Phrase(new Chunk("",small_black_bold2)));
		        att1_Table10.getDefaultCell().setBorder(Rectangle.BOX);
		        att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		        att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
		        att1_Table10.addCell(new Phrase(new Chunk(""+sumAmount,small_black_bold2)));
	            
	            //////////////////////////////////
	            
		        document.add(LogoTable);
	            document.add(att1_Table1);  
	            document.add(att1_Table2);  
	            document.add(att1_Table3);  
	            document.add(att1_Table4);
	            document.add(new Paragraph("              "));
	            document.add(title_note_table);
	            document.add(new Paragraph("              "));
	            document.add(att1_Table5);  
	            document.add(att1_Table6);  
	            document.add(att1_Table7);  
	            document.add(att1_Table8);
	            document.add(new Paragraph("              "));
	            document.add(att1_Table10);
	            
	            //For Attachment 2
	            if(!invoice_raised_in.equals(price_cd))
	            {
					document.setPageSize(pageSize1);
		            document.newPage();
		            
		            String title_note1="ATTACHMENT 2 - Exchange Rate Applicable";
		            
		            PdfPTable title_note_table1 = new PdfPTable(1);
		            title_note_table1.setWidthPercentage(100);
		            title_note_table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            title_note_table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            title_note_table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            title_note_table1.addCell(new Phrase(new Chunk(title_note1,big_black_bold)));
		            
		            float[] att2_ContactAddrWidths1 = {0.40f, 0.10f, 0.50f};
		            PdfPTable att2_Table1 = new PdfPTable(att2_ContactAddrWidths1);
		            att2_Table1.setWidthPercentage(100);
		            if(exchang_rate_cd.equals("0"))
		            {
			            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att2_Table1.addCell(new Phrase(new Chunk("Fixed Exchange Rate Applicable(INR/USD)",small_black_bold2)));
			            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att2_Table1.addCell(new Phrase(new Chunk(""+exchang_rate,small_black_bold2)));
			            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att2_Table1.addCell(new Phrase(new Chunk("",small_black_bold2)));
		            }
		            else
		            {
		            	String component_flag="";
		            	String component1="";
		            	String component2="";
		            	String exchang_rate_nm="";
		            	String source="";
		            	String component1_rate_nm="";
		            	String component2_rate_nm="";
		            	String component1_rate="";
		            	String component2_rate="";
		            	
		            	queryString="SELECT COMPONENT_FLAG,COMPONENT1,COMPONENT2,EXC_RATE_NM,BANK_ABBR "
								+ "FROM FMS_EXCHG_RATE_MST "
								+ "WHERE EXC_RATE_CD=?";
		            	stmt=conn.prepareStatement(queryString);
		            	stmt.setString(1, exchang_rate_cd);
						rset=stmt.executeQuery();
						if(rset.next())
						{
							component_flag=rset.getString(1)==null?"":rset.getString(1);
							component1=rset.getString(2)==null?"":rset.getString(2);
							component2=rset.getString(3)==null?"":rset.getString(3);
							exchang_rate_nm=rset.getString(4)==null?"":rset.getString(4);
							source=rset.getString(5)==null?"":rset.getString(5);
						}
						rset.close();
						stmt.close();
						
						if(component_flag.equals("Y"))
						{
							queryString="SELECT EXC_RATE_NM "
									+ "FROM FMS_EXCHG_RATE_MST "
									+ "WHERE EXC_RATE_CD=?";
							stmt=conn.prepareStatement(queryString);
			            	stmt.setString(1, component1);
							rset=stmt.executeQuery();
							if(rset.next())
							{
								component1_rate_nm=rset.getString(1)==null?"":rset.getString(1);
							}
							rset.close();
							stmt.close();
							
							queryString="SELECT EXC_RATE_NM "
									+ "FROM FMS_EXCHG_RATE_MST "
									+ "WHERE EXC_RATE_CD=?";
							stmt=conn.prepareStatement(queryString);
			            	stmt.setString(1, component2);
							rset=stmt.executeQuery();
							if(rset.next())
							{
								component2_rate_nm=rset.getString(1)==null?"":rset.getString(1);
							}
							rset.close();
							stmt.close();
							
							queryString="SELECT EXCHG_VAL "
									+ "FROM FMS_EXCHG_RATE_ENTRY "
									+ "WHERE EXCHG_RATE_CD=? "
									+ "AND EFF_DT=TO_DATE(?,'DD-MON-YY')";
							stmt=conn.prepareStatement(queryString);
			            	stmt.setString(1, component1);
			            	stmt.setString(2, exchang_rate_dt);
							rset=stmt.executeQuery();
							if(rset.next())
							{
								component1_rate=nf2.format(rset.getDouble(1));
							}
							rset.close();
							stmt.close();
							
							queryString="SELECT EXCHG_VAL "
									+ "FROM FMS_EXCHG_RATE_ENTRY "
									+ "WHERE EXCHG_RATE_CD=? "
									+ "AND EFF_DT=TO_DATE(?,'DD-MON-YY')";
							stmt=conn.prepareStatement(queryString);
			            	stmt.setString(1, component2);
			            	stmt.setString(2, exchang_rate_dt);
							rset=stmt.executeQuery();
							if(rset.next())
							{
								component2_rate=nf2.format(rset.getDouble(1));
							}
							rset.close();
							stmt.close();
							
							att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
				            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
				            att2_Table1.addCell(new Phrase(new Chunk(component1_rate_nm+".. On "+exchang_rate_dt+" (INR/USD)",small_black_normal)));
				            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
				            att2_Table1.addCell(new Phrase(new Chunk(""+component1_rate,small_black_normal)));
				            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
				            att2_Table1.addCell(new Phrase(new Chunk("",small_black_normal)));
				            
				            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
				            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
				            att2_Table1.addCell(new Phrase(new Chunk(component2_rate_nm+".. On "+exchang_rate_dt+" (INR/USD)",small_black_normal)));
				            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
				            att2_Table1.addCell(new Phrase(new Chunk(""+component2_rate,small_black_normal)));
				            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
				            att2_Table1.addCell(new Phrase(new Chunk("",small_black_normal)));
						}
						else
						{
							att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
				            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
				            att2_Table1.addCell(new Phrase(new Chunk(exchang_rate_nm+".. On "+exchang_rate_dt+" (INR/USD)",small_black_normal)));
				            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
				            att2_Table1.addCell(new Phrase(new Chunk(""+exchang_rate,small_black_normal)));
				            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
				            att2_Table1.addCell(new Phrase(new Chunk("",small_black_normal)));
						}
			            
			            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att2_Table1.addCell(new Phrase(new Chunk("",small_black_normal)));
			            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att2_Table1.addCell(new Phrase(new Chunk("",small_black_normal)));
			            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att2_Table1.addCell(new Phrase(new Chunk("",small_black_normal)));
			            
			            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att2_Table1.addCell(new Phrase(new Chunk("Exchange Rate Applicable(INR/USD)",small_black_bold2)));
			            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att2_Table1.addCell(new Phrase(new Chunk(""+exchang_rate,small_black_bold2)));
			            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att2_Table1.addCell(new Phrase(new Chunk("",small_black_bold2)));
			            
			            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att2_Table1.addCell(new Phrase(new Chunk("",small_black_normal)));
			            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att2_Table1.addCell(new Phrase(new Chunk("",small_black_normal)));
			            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att2_Table1.addCell(new Phrase(new Chunk("",small_black_normal)));
			            
			            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att2_Table1.addCell(new Phrase(new Chunk("Source : "+source,small_black_normal)));
			            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att2_Table1.addCell(new Phrase(new Chunk("",small_black_bold2)));
			            att2_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			            att2_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			            att2_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
			            att2_Table1.addCell(new Phrase(new Chunk("",small_black_bold2)));
		            }
		            
		            document.add(LogoTable);
		            document.add(att1_Table1);  
		            document.add(att1_Table2);  
		            document.add(att1_Table3);  
		            document.add(att1_Table4);
		            document.add(new Paragraph("              "));
		            document.add(title_note_table1);
		            document.add(new Paragraph("              "));
		            document.add(att1_Table5);  
		            document.add(att1_Table6);  
		            document.add(att1_Table7);
		            document.add(att1_Table8);
		            document.add(new Paragraph("              "));
		            document.add(att2_Table1);	            
	            }    // JD - Fixed end closing
				
				///////////////////////////////////////////////////////
	            document.close();
	            
	            File isPDFexist = new File(path);
				if(isPDFexist.exists())
				{
					String invoice_title="";
					int update_flag=0;
					int pdf_entry=0;
					
					int cont=0;
					queryString="UPDATE FMS_DLNG_SVC_INVOICE_MST SET PDF_INV_DTL=? ";
						if(print_pdf_type.equals("O"))
						{
							queryString+= ",PRINT_BY_ORI=?,PRINT_DT_ORI=SYSDATE ";
						}
						else if(print_pdf_type.equals("T"))
						{
							queryString+= ",PRINT_BY_TRI=?,PRINT_DT_TRI=SYSDATE ";
						}
						else if(print_pdf_type.equals("D"))
						{
							queryString+= ",PRINT_BY_DUP=?,PRINT_DT_DUP=SYSDATE ";
						}
						queryString+= "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? "
							+ "AND AGMT_NO=? AND PLANT_SEQ=? AND BU_UNIT=? AND CONTRACT_TYPE=? "
							+ "AND FREQ=? AND PERIOD_START_DT=TO_DATE(?,'DD/MM/YYYY') "
							+ "AND PERIOD_END_DT=TO_DATE(?,'DD/MM/YYYY') AND FINANCIAL_YEAR=? "
							+ "AND INVOICE_SEQ=? AND BU_STATE_TIN=? AND INV_FLAG=? ";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(++cont, print_pdf_type);
					if(print_pdf_type.equals("O"))
					{
						stmt.setString(++cont, emp_cd);
					}
					else if(print_pdf_type.equals("T"))
					{
						stmt.setString(++cont, emp_cd);
					}
					else if(print_pdf_type.equals("D"))
					{
						stmt.setString(++cont, emp_cd);
					}
					stmt.setString(++cont, comp_cd);
					stmt.setString(++cont, counterparty_cd);
					stmt.setString(++cont, cont_no);
					stmt.setString(++cont, agmt_no);
					stmt.setString(++cont, plant_seq);
					stmt.setString(++cont, bu_plant_seq);
					stmt.setString(++cont, contract_type);
					stmt.setString(++cont, billing_cycle);
					stmt.setString(++cont, temp_period_start_dt);
					stmt.setString(++cont, temp_period_end_dt);
					stmt.setString(++cont, financial_year);
					stmt.setString(++cont, inv_seq);
					stmt.setString(++cont, bu_state_tin);
					stmt.setString(++cont, inv_flag);
					update_flag=stmt.executeUpdate();
					stmt.close();
					
					int count=0;
			        queryString1="SELECT COUNT(*) "
			        		+ "FROM FMS_DLNG_SVC_INV_FILE_DTL "
			        		+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
			        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE=?";
			        stmt1=conn.prepareStatement(queryString1);
			        stmt1.setString(1, comp_cd);
			        stmt1.setString(2, bu_state_tin);
			        stmt1.setString(3, inv_seq);
			        stmt1.setString(4, financial_year);
			        stmt1.setString(5, print_pdf_type);
			        rset1=stmt1.executeQuery();
			        if(rset1.next())
			        {
			        	count=rset1.getInt(1);
			        }
			        rset1.close();
			        stmt1.close();
			        
			        if(count > 0)
			        {
			        	queryString1="UPDATE FMS_DLNG_SVC_INV_FILE_DTL SET FILE_NAME=?,MODIFY_BY=?,MODIFY_DT=SYSDATE "
			        			+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
				        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE=?";
			        	stmt1=conn.prepareStatement(queryString1);
			        	stmt1.setString(1, file_nm);
			        	stmt1.setString(2, emp_cd);
			        	stmt1.setString(3, comp_cd);
			 	        stmt1.setString(4, bu_state_tin);
			 	        stmt1.setString(5, inv_seq);
			 	        stmt1.setString(6, financial_year);
			 	        stmt1.setString(7, print_pdf_type);
			 	        pdf_entry=stmt1.executeUpdate();
			        	
			        	stmt1.close();
			        }
			        else
			        {
			        	queryString1="INSERT INTO FMS_DLNG_SVC_INV_FILE_DTL(COMPANY_CD,BU_STATE_TIN,INVOICE_SEQ,FINANCIAL_YEAR,PDF_TYPE,"
			        			+ "FILE_NAME,ENT_BY,ENT_DT) "
			        			+ "VALUES(?,?,?,?,?,"
			        			+ "?,?,SYSDATE)";
			        	stmt1=conn.prepareStatement(queryString1);
			        	stmt1.setString(1, comp_cd);
			 	        stmt1.setString(2, bu_state_tin);
			 	        stmt1.setString(3, inv_seq);
			 	        stmt1.setString(4, financial_year);
			 	        stmt1.setString(5, print_pdf_type);
			 	        stmt1.setString(6, file_nm);
			        	stmt1.setString(7, emp_cd);
			        	pdf_entry=stmt1.executeUpdate();
			        	
			        	stmt1.close();
			        }
			        
					/*
					 * Auto pay and Hold amout section currently commented
					 * 
					 * if(update_flag > 0 && pdf_entry > 0 && print_pdf_type.equals("O"))
					{
						if((contract_type.equals("Q") || contract_type.equals("O")) && adv_count > 0 && adjted_amt > 0)
						{
							double short_received = adjted_amt;
					    	String payRecvAmt=nf.format(short_received);
					    	
					    	String remark="Auto Paid";
					    	queryString="UPDATE FMS_DLNG_SVC_INVOICE_MST SET PAY_RECV_AMT=?,"
									+ "PAY_RECV_DT=TO_DATE(?,'DD/MM/YYYY'),PAY_INSERT_BY=?,PAY_INSERT_DT=SYSDATE,"
									+ "PAY_REMARK=? "
									+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? "
									+ "AND AGMT_NO=? AND CONTRACT_TYPE=? AND INVOICE_SEQ=? "
									+ "AND BU_STATE_TIN=? AND FINANCIAL_YEAR=? AND CARGO_NO=? ";
							stmt = conn.prepareStatement(queryString);
							stmt.setString(1, payRecvAmt);
							stmt.setString(2, temp_invoice_dt);
							stmt.setString(3, emp_cd);
							stmt.setString(4, remark);
							stmt.setString(5, comp_cd);
							stmt.setString(6, counterparty_cd);
							stmt.setString(7, cont_no);
							stmt.setString(8, agmt_no);
							stmt.setString(9, contract_type);
							stmt.setString(10, inv_seq);
							stmt.setString(11, bu_state_tin);
							stmt.setString(12, financial_year);
							stmt.setString(13, cargo_no);
							stmt.executeUpdate();
							stmt.close();
							
							queryString1="SELECT NVL(MAX(SEQ_NO),0) "
									+ "FROM FMS_INV_PAY_RECV_DTL "
									+ "WHERE COMPANY_CD=? AND INVOICE_SEQ=? "
									+ "AND BU_STATE_TIN=? AND FINANCIAL_YEAR=?";
							stmt1 = conn.prepareStatement(queryString1);
							stmt1.setString(1, comp_cd);
							stmt1.setString(2, inv_seq);
							stmt1.setString(3, bu_state_tin);
							stmt1.setString(4, financial_year);
							rset1=stmt1.executeQuery();
							if(rset1.next())
							{
								String seq_no=""+(rset1.getInt(1)+1);
								
								queryString2="INSERT INTO FMS_INV_PAY_RECV_DTL(COMPANY_CD,BU_STATE_TIN,INVOICE_SEQ,FINANCIAL_YEAR,SEQ_NO,"
										+ "PAY_RECV_DT,PAY_RECV_AMT,PAY_REMARK,ENT_BY,ENT_DT,ADV_AMT,ADV_FLAG) "
										+ "VALUES(?,?,?,?,?,"
										+ "TO_DATE(?,'DD/MM/YYYY'),?,?,?,SYSDATE,?,?)";
								stmt2 = conn.prepareStatement(queryString2);
								stmt2.setString(1, comp_cd);
								stmt2.setString(2, bu_state_tin);
								stmt2.setString(3, inv_seq);
								stmt2.setString(4, financial_year);
								stmt2.setString(5, seq_no);
								stmt2.setString(6, temp_invoice_dt);
								stmt2.setString(7, payRecvAmt);
								stmt2.setString(8, remark);
								stmt2.setString(9, emp_cd);
								stmt2.setString(10, payRecvAmt);
								stmt2.setString(11, "Y");
								stmt2.executeUpdate();
								stmt2.close();
							}
							rset1.close();
							stmt1.close();
						}
						else
						{
					    	double hold_amt=utilBean.getInvoiceHoldAmount(conn,comp_cd,counterparty_cd,agmt_no,cont_no,contract_type,plant_seq,bu_plant_seq, 
									temp_period_end_dt,tax_struct_dtl,gross_amt1,bu_state_tin,temp_invoice_dt);
					    	if(hold_amt > 0)
					    	{
					    		queryString="UPDATE FMS_DLNG_SVC_INVOICE_MST SET HOLD_AMT=? "
									+ "WHERE COMPANY_CD=? AND FINANCIAL_YEAR=? "
									+ "AND INVOICE_SEQ=? AND BU_STATE_TIN=? ";
					    		cont=0;
								stmt=conn.prepareStatement(queryString);
								stmt.setString(++cont, nf.format(hold_amt));
								stmt.setString(++cont, comp_cd);
								stmt.setString(++cont, financial_year);
								stmt.setString(++cont, inv_seq);
								stmt.setString(++cont, bu_state_tin);
								stmt.executeUpdate();
								stmt.close();
					    	}
					    	
					    	if(auto_pay_flag.equals("Y"))
					    	{
					        	double tot_Adv_amt=utilBean.getAdvanceAmount(conn,comp_cd, counterparty_cd, agmt_no, cont_no, contract_type, "K", dateUtil.getSysdate());
					        	
					        	if(tot_Adv_amt>0)
					        	{
					        		netPayable=netPayable-tdsAmt;
						        	double short_received = netPayable;
						        	
						        	String payRecvAmt="";
						        	if(tot_Adv_amt >= short_received && tot_Adv_amt > 0)
						        	{
						        		payRecvAmt=nf.format(short_received);
						        	}
						        	else if(tot_Adv_amt < short_received && tot_Adv_amt > 0)
						        	{
						        		payRecvAmt=nf.format(tot_Adv_amt);
						        	}
						        	
						        	if(!payRecvAmt.equals(""))
						        	{	
							        	String remark="Auto Paid";
							        	queryString="UPDATE FMS_DLNG_SVC_INVOICE_MST SET PAY_RECV_AMT=?,"
												+ "PAY_RECV_DT=TO_DATE(?,'DD/MM/YYYY'),PAY_INSERT_BY=?,PAY_INSERT_DT=SYSDATE,"
												+ "PAY_REMARK=? "
												+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? "
												+ "AND AGMT_NO=? AND CONTRACT_TYPE=? AND INVOICE_SEQ=? "
												+ "AND BU_STATE_TIN=? AND FINANCIAL_YEAR=? AND CARGO_NO=? ";
										stmt = conn.prepareStatement(queryString);
										stmt.setString(1, payRecvAmt);
										stmt.setString(2, temp_invoice_dt);
										stmt.setString(3, emp_cd);
										stmt.setString(4, remark);
										stmt.setString(5, comp_cd);
										stmt.setString(6, counterparty_cd);
										stmt.setString(7, cont_no);
										stmt.setString(8, agmt_no);
										stmt.setString(9, contract_type);
										stmt.setString(10, inv_seq);
										stmt.setString(11, bu_state_tin);
										stmt.setString(12, financial_year);
										stmt.setString(13, cargo_no);
										stmt.executeUpdate();
										stmt.close();
										
										queryString1="SELECT NVL(MAX(SEQ_NO),0) "
												+ "FROM FMS_INV_PAY_RECV_DTL "
												+ "WHERE COMPANY_CD=? AND INVOICE_SEQ=? "
												+ "AND BU_STATE_TIN=? AND FINANCIAL_YEAR=?";
										stmt1 = conn.prepareStatement(queryString1);
										stmt1.setString(1, comp_cd);
										stmt1.setString(2, inv_seq);
										stmt1.setString(3, bu_state_tin);
										stmt1.setString(4, financial_year);
										rset1=stmt1.executeQuery();
										if(rset1.next())
										{
											String seq_no=""+(rset1.getInt(1)+1);
											
											queryString2="INSERT INTO FMS_INV_PAY_RECV_DTL(COMPANY_CD,BU_STATE_TIN,INVOICE_SEQ,FINANCIAL_YEAR,SEQ_NO,"
													+ "PAY_RECV_DT,PAY_RECV_AMT,PAY_REMARK,ENT_BY,ENT_DT,ADV_AMT,ADV_FLAG) "
													+ "VALUES(?,?,?,?,?,"
													+ "TO_DATE(?,'DD/MM/YYYY'),?,?,?,SYSDATE,?,?)";
											stmt2 = conn.prepareStatement(queryString2);
											stmt2.setString(1, comp_cd);
											stmt2.setString(2, bu_state_tin);
											stmt2.setString(3, inv_seq);
											stmt2.setString(4, financial_year);
											stmt2.setString(5, seq_no);
											stmt2.setString(6, temp_invoice_dt);
											stmt2.setString(7, payRecvAmt);
											stmt2.setString(8, remark);
											stmt2.setString(9, emp_cd);
											stmt2.setString(10, payRecvAmt);
											stmt2.setString(11, "Y");
											stmt2.executeUpdate();
											stmt2.close();
										}
										rset1.close();
										stmt1.close();
						        	}
					        	}
					    	}
						}
					}*/
			        
			        if(pdf_entry == 0 || update_flag == 0)
			        {
			        	conn.rollback();
			        	deletePdfFile(path);
			        	msg="Failed! - "+invdtl+" Invoice for "+counterparty_abbr+" PDF for "+dealMap+" Generation Failed!";
			        	msg_type="E";
			        }
			        else
			        {
			        	conn.commit();
			        	msg = "Successful! - "+invdtl+" Invoice for "+counterparty_abbr+" PDF "+file_nm+" for "+dealMap+" Generated Successfully!";
			        	msg_type="S";
			        }
				}
				else
				{
					msg="Failed! - "+invdtl+" Invoice for "+counterparty_abbr+" PDF for "+dealMap+" Generation Failed!";
					msg_type="E";
				}
			}
		}
		catch(Exception e)
		{
			conn.rollback();
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
			
			document.close();
			deletePdfFile(path);
			
			msg="Error in Exception! - "+invdtl+" Invoice for "+counterparty_abbr+" PDF Generation Failed!";
			msg_type="E";	
		}
		finally
		{
			document.close();
		}
		
		try
		{
			new com.etrm.fms.util.InfoLogger().InsertInfoLogger(emp_cd, comp_cd,emp_nm, ip, form_id, form_nm,mod_cd,mod_nm, "", "", msg);  	
		}
		catch(Exception infoLogger)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, infoLogger);
		}
	}
	
	public void deletePdfFile(String pdfFile)
	{
		String function_nm="deletePdfFile()";
		try
		{
			File file = new File(pdfFile);
			if(file.exists())
			{
				boolean deleted = file.delete();
				
				//HM20251111 : Added Below handler due to vulnerability : Do something with the "boolean" value returned by "delete".
				if (!deleted)
	            {
					Exception e = new Exception("Failed to delete file: " + pdfFile);
					
	                // Log failure to delete file
	                new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
	            }
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
			throw e;
		}
		
	}
	
	public void printPdfFileForLpDLNGInvoice() throws SQLException
	{
		String function_nm="printPdfFileForLpDLNGInvoice()";
		
		String emp_nm ="";
		String ip = "";
		msg="";
		//String msg_content="";
		String path ="";
		String counterparty_abbr="";
		String invdtl="DLNG Sales";
		
		Rectangle pageSize = new Rectangle(595, 842);
		Rectangle pageSize1=new Rectangle(842,595);
		
		pageSize.setBackgroundColor(new BaseColor(0xffffff));
		pageSize1.setBackgroundColor(new BaseColor(0xffffff));
		
		Document document = new Document(pageSize);
		try
		{
			HttpSession session = request.getSession();
			emp_nm = (String)session.getAttribute("emp_nm")==null?"":(String)session.getAttribute("emp_nm");
			ip = (String)session.getAttribute("ip")==null?"":(String)session.getAttribute("ip");
			
			String company_nm = ""+session.getAttribute("comp_nm")==null?"":""+session.getAttribute("comp_nm");
			String company_abbr = ""+session.getAttribute("comp_abbr")==null?"":""+session.getAttribute("comp_abbr");
			String counterparty_nm=""+utilBean.getCounterpartyName(conn,counterparty_cd);
			counterparty_abbr=""+utilBean.getCounterpartyABBR(conn,counterparty_cd);
			
			int pdfGenCount=0;
			queryString="SELECT COUNT(*) "
					+ "FROM FMS_DLNG_INVOICE_MST A ,FMS_DLNG_INV_FILE_DTL B "
					+ "WHERE A.COMPANY_CD=? AND A.FINANCIAL_YEAR=? AND A.INVOICE_SEQ=? AND A.BU_STATE_TIN=? ";
			if(print_pdf_type.equals("O"))
			{
				queryString+= "AND A.PRINT_BY_ORI IS NOT NULL AND A.PRINT_DT_ORI IS NOT NULL ";
			}
			else if(print_pdf_type.equals("T"))
			{
				queryString+= "AND A.PRINT_BY_TRI IS NOT NULL AND A.PRINT_DT_TRI IS NOT NULL ";
			}
			else if(print_pdf_type.equals("D"))
			{
				queryString+= "AND A.PRINT_BY_DUP IS NOT NULL AND A.PRINT_DT_DUP IS NOT NULL ";
			}
			queryString+= "AND B.PDF_TYPE=? AND B.FILE_NAME IS NOT NULL "
					+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.BU_STATE_TIN=B.BU_STATE_TIN AND A.INVOICE_SEQ=B.INVOICE_SEQ "
    		  		+ "AND A.FINANCIAL_YEAR=B.FINANCIAL_YEAR";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, financial_year);
			stmt.setString(3, inv_seq);
			stmt.setString(4, bu_state_tin);
			stmt.setString(5, print_pdf_type);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				pdfGenCount=rset.getInt(1);
			}
			rset.close();
			stmt.close();
			
			String dealMap = utilBean.NewDealMappingId(comp_cd, counterparty_cd, agmt_no, agmt_rev_no, cont_no, cont_rev_no, contract_type, cargo_no);
            
			if(pdfGenCount>0)
			{
				msg="Failed! - "+invdtl+" Late Payment Invoice for "+counterparty_abbr+" PDF for "+dealMap+" already Generated for "+period_end_dt+"!";
				msg_type="E";
			}
			else
			{
				String contRef="";
				String signingDt="";
				String agmtSigningDt="";
				String dcq="";
				String agmt_base="";
				String auto_pay_flag="";
				double mdcq_percentage=100;
				
				queryString="SELECT CONT_REF_NO,TO_CHAR(SIGNING_DT,'DD-MON-YY'),TRADE_REF_NO,DCQ,"
						+ "MDCQ_PERCENTAGE,AGMT_BASE,ADV_ADJUST  "
						+ "FROM FMS_SUPPLY_CONT_MST A "
						+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE=? "
						+ "AND CONT_NO=? AND AGMT_NO=? AND COUNTERPARTY_CD=? "
						+ "AND CONT_REV = (SELECT MAX(CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
						+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) ";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, contract_type);
				stmt.setString(3, cont_no);
				stmt.setString(4, agmt_no);
				stmt.setString(5, counterparty_cd);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					contRef=rset.getString(1)==null?"":rset.getString(1);
					signingDt=rset.getString(2)==null?"":rset.getString(2);
					
					String trade_ref=rset.getString(3)==null?"":rset.getString(3);
					if(contract_type.equals("W"))
					{
						contRef=trade_ref;
					}
					dcq=nf.format(rset.getDouble(4));
					mdcq_percentage=rset.getDouble(5);
					if(Double.doubleToRawLongBits(mdcq_percentage)==Double.doubleToRawLongBits(0))
					{
						mdcq_percentage=100;
					}
					agmt_base=rset.getString(6)==null?"":rset.getString(6);
					auto_pay_flag=rset.getString(7)==null?"":rset.getString(7);
				}
				rset.close();
				stmt.close();
				
				if(contract_type.equals("F"))
				{
					queryString="SELECT TO_CHAR(SIGNING_DT,'DD-MON-YY')  "
							+ "FROM FMS_AGMT_MST A "
							+ "WHERE COMPANY_CD=? AND AGMT_TYPE=? "
							+ "AND AGMT_NO=? AND COUNTERPARTY_CD=? "
							+ "AND AGMT_REV = (SELECT MAX(AGMT_REV) FROM FMS_AGMT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
							+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_TYPE=B.AGMT_TYPE) ";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(1, comp_cd);
					stmt.setString(2, "D");
					stmt.setString(3, agmt_no);
					stmt.setString(4, counterparty_cd);
					rset=stmt.executeQuery();
					if(rset.next())
					{
						agmtSigningDt=rset.getString(1)==null?"":rset.getString(1);
					}
					rset.close();
					stmt.close();
				}
				
				HashMap bu_plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "B", comp_cd, bu_plant_seq);
				String bu_plantAddress=""+bu_plant_detail.get("plant_address");
				String bu_plantCity=""+bu_plant_detail.get("plant_city");
				String bu_plantState=""+bu_plant_detail.get("plant_state");
				String bu_plantPin=""+bu_plant_detail.get("plant_pin");
				String bu_plantNm=""+bu_plant_detail.get("plant_name");
	
				HashMap plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "C", counterparty_cd, plant_seq);
				String plantAddress=""+plant_detail.get("plant_address");
				String plantCity=""+plant_detail.get("plant_city");
				String plantState=""+plant_detail.get("plant_state");
				String plantPin=""+plant_detail.get("plant_pin");
				
				String bu_contact_person_cd="";
				String contact_person_cd="";
				String invoice_dt="";
				String invoice_due_dt="";
				String remark_1="";
				String remark_2="";
				String qty_mmbtu="";
				String price="";
				String price_cd="";
				String gross_amt="";
				String exchang_rate_cd="";
				String exchang_rate_dt="";
				String exchang_rate="";
				String exchang_rate_type="";
				String gross_amt1="";
				String tax_amt="";
				String tax_struct_cd="";
				String tax_struct_dt="";
				String invoice_amt="";
				String net_payable="";
				String applicable_abbr="";
				String applicable_amt="";
				String TCS_factor="";
				String tax_struct_dtl="";
				String invoice_no="";
				String invoice_raised_in="";
				String temp_invoice_dt="";
				String transportation_charges = "";
				String transportation_amount = "";
				String gross_include_transport_tariff = "";
				String marketing_margin = "";
				String marketing_margin_amount = "";
				String other_charges = "";
				String other_charges_amount = "";
				String irn_no="";
				String qr_code="";
				String sug_qty="";
				String sug_percent="";
				boolean isGrossIncTriff=false;
				String discount_days="";
				String int_rate="";
				String ref_inv_no="";
				
				String ori_inv_due_dt="";
				String ori_inv_net_amt="";
				String ori_inv_payrecv_amt="";
				String ori_inv_payrecv_dt="";
				String ori_inv_dt="";
				
				double netPayable=0;
				double tdsAmt=0;
				
				String temp_period_start_dt=period_start_dt;
				String temp_period_end_dt=period_end_dt;
				
				String cont_map=counterparty_cd+"-"+contract_type+"-"+agmt_no+"-%-"+cont_no+"-%";
				String exit_point="C-"+counterparty_cd+"-"+plant_seq;
				
				
				queryString="SELECT BU_CONTACT_PERSON_CD,CONTACT_PERSON_CD,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD-MON-YY'),"
						+ "TO_CHAR(DUE_DT,'DD-MON-YY'),TO_CHAR(PERIOD_START_DT,'DD-MON-YY'),TO_CHAR(PERIOD_END_DT,'DD-MON-YY'),REMARK_1,REMARK_2,"
						+ "ALLOC_QTY,SALE_PRICE,SALE_PRICE_UNIT,SALE_AMT,EXCHG_RATE_VALUE,GROSS_AMT,TAX_AMT,TAX_STRUCT_CD,TO_CHAR(TAX_EFF_DT,'DD/MM/YYYY'),"
						+ "INVOICE_AMT,NET_PAYABLE_AMT,TCS_TDS,TCS_AMT,TCS_FACTOR,CHECKED_FLAG,APPROVED_FLAG, "
						+ "INVOICE_ID_SEQ,INVOICE_RAISED_IN,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),NULL,NULL,EXCHG_RATE_CD,"
						+ "TO_CHAR(EXCHG_RATE_DT,'DD-MON-YY'),EXCHG_RATE_TYPE,TDS_GROSS_AMT,DISCOUNT_DAYS,INT_RATE,REF_NO "
						+ "FROM FMS_DLNG_INVOICE_MST "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? "
						+ "AND AGMT_NO=? AND PLANT_SEQ=? AND BU_UNIT=? AND CONTRACT_TYPE=? "
						+ "AND BU_STATE_TIN=? AND PERIOD_START_DT=TO_DATE(?,'DD/MM/YYYY') "
						+ "AND PERIOD_END_DT=TO_DATE(?,'DD/MM/YYYY') AND FINANCIAL_YEAR=? "
						+ "AND INVOICE_SEQ=? AND MAPPING_ID=? AND INV_FLAG=? AND TRUCK_TRANS_CD=? AND TRUCK_CD=? AND REF_NO = ? ";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty_cd);
				stmt.setString(3, cont_no);
				stmt.setString(4, agmt_no);
				stmt.setString(5, plant_seq);
				stmt.setString(6, bu_plant_seq);
				stmt.setString(7, contract_type);
				stmt.setString(8, bu_state_tin);
				stmt.setString(9, cont_start_dt);
				stmt.setString(10, cont_end_dt);
				stmt.setString(11, financial_year);
				stmt.setString(12, inv_seq);
				stmt.setString(13, mapping_id);
				stmt.setString(14, inv_flag);
				stmt.setString(15, truck_trans_cd);
				stmt.setString(16, truck_cd);
				stmt.setString(17, ori_inv_no);
				
				rset=stmt.executeQuery();
				if(rset.next())
				{
					bu_contact_person_cd=rset.getString(1)==null?"0":rset.getString(1);
					contact_person_cd=rset.getString(2)==null?"0":rset.getString(2);
					
					//invoice_id_seq=rset.getString(26)==null?"":rset.getString(26);
					invoice_no=rset.getString(3)==null?"":rset.getString(3);
					invoice_dt=rset.getString(4)==null?"":rset.getString(4);
					invoice_due_dt=rset.getString(5)==null?"":rset.getString(5);
					//inv_period_start_dt=rset.getString(6)==null?"":rset.getString(6);
					//inv_period_end_dt=rset.getString(7)==null?"":rset.getString(7);
					
					remark_1=rset.getString(8)==null?"":rset.getString(8);
					remark_2=rset.getString(9)==null?"":rset.getString(9);
					
					qty_mmbtu=nf.format(rset.getDouble(10));
					price_cd=rset.getString(12)==null?"":rset.getString(12);
					price=utilBean.RateNumberFormat(rset.getDouble(11), price_cd);
					gross_amt=nf.format(rset.getDouble(13));
					exchang_rate=nf2.format(rset.getDouble(14));
					gross_amt1=nf.format(rset.getDouble(15));
					tax_amt=nf.format(rset.getDouble(16));
					tax_struct_cd=rset.getString(17)==null?"":rset.getString(17);
					tax_struct_dt=rset.getString(18)==null?"":rset.getString(18);
					invoice_amt=nf.format(rset.getDouble(19));
					net_payable=nf.format(rset.getDouble(20));
					netPayable=rset.getDouble(20);
					applicable_abbr=rset.getString(21)==null?"":rset.getString(21);
					applicable_amt=nf.format(rset.getDouble(22));
					TCS_factor=nf3.format(rset.getDouble(23));
					
					invoice_raised_in=rset.getString(27)==null?"":rset.getString(27);
					temp_invoice_dt=rset.getString(28)==null?"":rset.getString(28);
					
					transportation_charges=rset.getString(29)==null?"":nf2.format(rset.getDouble(29));
					transportation_amount=rset.getString(30)==null?"":nf.format(rset.getDouble(30));
					
					exchang_rate_cd=rset.getString(31)==null?"":rset.getString(31);
					exchang_rate_dt=rset.getString(32)==null?"":rset.getString(32);
					exchang_rate_type=rset.getString(33)==null?"":rset.getString(33);
					
					tdsAmt=rset.getDouble(34);

					discount_days=rset.getString(35)==null?"0":rset.getString(35);
					int_rate=rset.getString(36)==null?"0":nf.format(rset.getDouble(36));
					ref_inv_no=rset.getString(37)==null?"":rset.getString(37);
					
					gross_include_transport_tariff=nf.format(Double.parseDouble(gross_amt1));
					
					tax_struct_dtl=utilBean.getTaxDescr(conn, tax_struct_cd);
				}
				rset.close();
				stmt.close();
				
				//REFERENCE INVOICE DETAILS
				String queryString="SELECT TO_CHAR(DUE_DT,'DD/MM/YYYY'),NET_PAYABLE_AMT,PAY_RECV_AMT,TO_CHAR(PAY_RECV_DT,'DD/MM/YYYY'),TO_CHAR(INVOICE_DT,'DD-MON-YY') "
						+ "FROM FMS_DLNG_INVOICE_MST "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? "
						+ "AND AGMT_NO=? AND PLANT_SEQ=? AND BU_UNIT=? AND CONTRACT_TYPE=? "
						+ "AND BU_STATE_TIN=? AND PERIOD_START_DT=TO_DATE(?,'DD/MM/YYYY') "
						+ "AND PERIOD_END_DT=TO_DATE(?,'DD/MM/YYYY') AND FINANCIAL_YEAR=? AND INV_FLAG=? "
						+ "AND INVOICE_SEQ = ? AND TRUCK_CD = ? AND TRUCK_TRANS_CD = ? AND INVOICE_NO = ? ";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty_cd);
				stmt.setString(3, cont_no);
				stmt.setString(4, agmt_no);
				stmt.setString(5, plant_seq);
				stmt.setString(6, bu_plant_seq);
				stmt.setString(7, contract_type);
				stmt.setString(8, bu_state_tin);
				stmt.setString(9, period_start_dt);
				stmt.setString(10, period_end_dt);
				stmt.setString(11, exist_fin_yr);
				stmt.setString(12, ori_inv_flag);
				stmt.setString(13, ori_inv_seq);
				stmt.setString(14, truck_cd);
				stmt.setString(15, truck_trans_cd);
				stmt.setString(16, ref_inv_no);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					ori_inv_due_dt=rset.getString(1)==null?"":rset.getString(1);
					ori_inv_net_amt = rset.getString(2)==null?"":nf.format(rset.getDouble(2));
					ori_inv_payrecv_amt = rset.getString(3)==null?"":nf.format(rset.getDouble(3));
					ori_inv_payrecv_dt=rset.getString(4)==null?"":rset.getString(4);
					ori_inv_dt=rset.getString(5)==null?"":rset.getString(5);
				}
				rset.close();
				stmt.close();
				
 				float int_days = dateUtil.getDays(ori_inv_payrecv_dt, ori_inv_due_dt)-1 - Float.parseFloat(discount_days);
				
				/*if(contract_type.equals("O") || contract_type.equals("Q"))
				{
					queryString1="SELECT IRN_NO,SIGN_QR_CODE "
							+ "FROM FMS_INVOICE_IRN_DTL "
							+ "WHERE COMPANY_CD=? AND INVOICE_NO=? ";
					stmt1=conn.prepareStatement(queryString1);
					stmt1.setString(1, comp_cd);
					stmt1.setString(2, invoice_no);
					rset1=stmt1.executeQuery();
					if(rset1.next())
					{
						irn_no=rset1.getString(1)==null?"":rset1.getString(1);
						qr_code=rset1.getString(2)==null?"":rset1.getString(2);
					}
					rset1.close();
					stmt1.close();
				}*/
				
				String contact_person_nm="";
				String bu_contact_person_nm="";
				
				queryString="SELECT CONTACT_PERSON "
						+ "FROM FMS_ENTITY_CONTACT_MST A "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
						+ "AND ENTITY=? AND SEQ_NO=? AND ADDR_FLAG=? "
						+ "AND TYPE=? "
						+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO "
						+ "AND EFF_DT <= TO_DATE(?,'DD/MM/YYYY') AND A.TYPE=B.TYPE)";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty_cd);
				stmt.setString(3, "C");
				stmt.setString(4, contact_person_cd);
				stmt.setString(5, "P"+plant_seq);
				stmt.setString(6, "DLNG");
				stmt.setString(7, temp_invoice_dt);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					contact_person_nm=rset.getString(1)==null?"":rset.getString(1);
				}
				rset.close();
				stmt.close();
				
				queryString="SELECT CONTACT_PERSON "
						+ "FROM FMS_ENTITY_CONTACT_MST A "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
						+ "AND ENTITY=? AND SEQ_NO=? AND ADDR_FLAG=? "
						+ "AND TYPE=?"
						+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO "
						+ "AND EFF_DT <= TO_DATE(?,'DD/MM/YYYY') AND A.TYPE=B.TYPE)";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, comp_cd);
				stmt.setString(3, "B");
				stmt.setString(4, bu_contact_person_cd);
				stmt.setString(5, "P"+bu_plant_seq);
				stmt.setString(6, "DLNG");
				stmt.setString(7, temp_invoice_dt);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					bu_contact_person_nm=rset.getString(1)==null?"":rset.getString(1);
				}
				rset.close();
				stmt.close();
	
				String print_pdf_type_nm="ORIGINAL";
				if(print_pdf_type.equals("O"))
				{
					print_pdf_type_nm="ORIGINAL";
				}
				else if(print_pdf_type.equals("D"))
				{
					print_pdf_type_nm="DUPLICATE";
				}
				else if(print_pdf_type.equals("T"))
				{
					print_pdf_type_nm="TRIPLICATE";
				}
	
				String appPath = request.getServletContext().getRealPath("");
	
				String main_folder="";
				if(!comp_cd.equals(""))
				{
					main_folder=CommonVariable.work_dir+comp_cd;
				}
				
				String sub_folder="unsigned_pdf";
				String sub_folder2="dlng_sales_invoice";
				String temp_path=appPath+File.separator+main_folder+File.separator+sub_folder+File.separator+sub_folder2;
				File main_folderDir = new File(temp_path);
		        if(!main_folderDir.exists())
		        {
		        	main_folderDir.mkdirs();
		        }
	
		        String monthofinv = dateUtil.getMonthNameMON(period_end_dt);
		        String dtPeriod="";
		        if(!period_start_dt.equals("") && !period_end_dt.equals(""))
		        {
		        	dtPeriod=period_start_dt.substring(0,2);
		        	dtPeriod+="-";
		        	dtPeriod+=period_end_dt.substring(0,2);
		        }
	
		        String contNm="";
		        String invNm="";
		        if(contract_type.equals("W"))
		        {
		        	contNm="DLNG-IGX";
		        	invNm="DLNG_LP";
		        }
		        else if(contract_type.equals("E"))
		        {
		        	contNm="DLNG-LOA";
		        	invNm="DLNG_LP";
		        }
		        else if(contract_type.equals("F"))
		        {
		        	contNm="DLNG-SN";
		        	invNm="DLNG_LP";
		        }
		       
				//file_nm=print_pdf_type+"-"+company_abbr+"-"+invNm+"-"+contNm+""+bu_state_tin+"-"+inv_seq+"-"+counterparty_abbr+"_"+financial_year+"_"+monthofinv.trim()+"_"+dtPeriod+".pdf";
				file_nm=print_pdf_type+"-"+company_abbr+"-"+invNm+"-"+invoice_no.replace("/", "-")+".pdf";
				
				path = appPath+"/"+main_folder+"/"+sub_folder+"/"+sub_folder2+"/"+file_nm;
				PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream(path));
	
				document.open();
				document.setPageSize(pageSize);
	            document.newPage();
	
	            String context_nm = request.getContextPath();
				String server_nm = request.getServerName();
				String server_port = ""+request.getServerPort();
	
				file_url = CommonVariable.app_protocol+"://"+server_nm+":"+server_port+context_nm;
	
				Font small_black_normal = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
				Font small_black_normal_10 = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
				Font small_black_normal_14 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
				Font small_black_normal_12 = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL, BaseColor.BLACK);
	            Font small_black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
	            Font black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
	            Font black_bold1 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
	            
	            PdfPCell company_logo_cell = new PdfPCell();
	            if(!comp_logo.equals(""))
	            {
	            	String file_path = request.getRealPath("/"+CommonVariable.company_logo_path+"/"+comp_logo);
	            	Image company_logo = Image.getInstance(file_path);
		            company_logo.setBorder(Rectangle.NO_BORDER);
		            company_logo.scaleAbsolute(44,40);
		            company_logo_cell = new PdfPCell(company_logo,false);
		            company_logo_cell.setBorder(Rectangle.NO_BORDER);
		            company_logo_cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	            }
	            
	            float[] Contact1 = {0.50f};
	   	     	PdfPTable LogoTable = new PdfPTable(Contact1);
	   	     	LogoTable.setWidthPercentage(100);
	   	     	LogoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	LogoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	LogoTable.addCell(company_logo_cell);
	
				float[] ContactAddrWidths1 = {0.100f};
	   	     	PdfPTable HlplLogoTable = new PdfPTable(ContactAddrWidths1);
	            HlplLogoTable.setWidthPercentage(100);
	            HlplLogoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            HlplLogoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            HlplLogoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            HlplLogoTable.addCell(new Phrase(new Chunk(print_pdf_type_nm,small_black_normal_10)));
	
	            float[] ContactAddrWidths2 = {0.100f};
	   	     	PdfPTable Table = new PdfPTable(ContactAddrWidths2);
	            Table.setWidthPercentage(100);
	            Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table.addCell(new Phrase(new Chunk(company_nm,black_bold1)));
	
	            float[] ContactAddrWidths3 = {0.100f};
	   	     	PdfPTable Table1 = new PdfPTable(ContactAddrWidths3);
	            Table1.setWidthPercentage(100);
	            Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
            	Table1.addCell(new Phrase(new Chunk("DEBIT NOTE",small_black_normal_12)));
	            
	            period_start_dt=dateUtil.getDateFormatDD_MOM_YY(period_start_dt);
				period_end_dt=dateUtil.getDateFormatDD_MOM_YY(period_end_dt);
	
				String info ="In respect of "; 
				if(contract_type.equals("F")){
					info+="Supply Notice ("+contRef+") executed on "+signingDt+" pursuant to Framework LNG Sales Agreement executed on "+agmtSigningDt+"";
				}else if(contract_type.equals("E")){
					info+="Letter of Agreement ("+contRef+") executed on "+signingDt; 
				}else if(contract_type.equals("W")){ 
					info+="Exchange Transaction ("+contRef+") executed on "+signingDt;
				} 
				info+="\nbetween "+company_nm+" and "+counterparty_nm;
	
	            float[] ContactAddrWidths4 = {0.100f};
	   	     	PdfPTable Table2 = new PdfPTable(ContactAddrWidths4);
	            Table2.setWidthPercentage(100);
	            Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table2.addCell(new Phrase(new Chunk(info,small_black_normal)));
	
	            float[] ContactAddrWidths5 = {0.80f,0.10F,0.20F,0.80F};
	   	     	PdfPTable Table3 = new PdfPTable(ContactAddrWidths5);
	            Table3.setWidthPercentage(100);
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            //Table3.addCell(new Phrase(new Chunk("Business Unit: "+bu_plantNm,black_bold)));
	            Table3.addCell(new Phrase(new Chunk("Business Unit: ",black_bold)));
	            
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table3.addCell(new Phrase(new Chunk("",black_bold)));
	            
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table3.addCell(new Phrase(new Chunk("To:",black_bold)));
	
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table3.addCell(new Phrase(new Chunk(""+contact_person_nm+",",black_bold)));
	
	            
	
				float[] ContactAddrWidths6 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table4 = new PdfPTable(ContactAddrWidths6);
	            Table4.setWidthPercentage(100);
	            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table4.addCell(new Phrase(new Chunk(company_nm,small_black_normal)));
	            
	            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table4.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table4.addCell(new Phrase(new Chunk(counterparty_nm,small_black_normal)));
	
	            float[] ContactAddrWidths7 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table5 = new PdfPTable(ContactAddrWidths7);
	            Table5.setWidthPercentage(100);
	            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table5.addCell(new Phrase(new Chunk(bu_plantAddress+","+bu_plantCity,small_black_normal)));
	            
	            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table5.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
	            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table5.addCell(new Phrase(new Chunk(plantAddress+","+plantCity,small_black_normal)));
	            
	
	            float[] ContactAddrWidths8 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table6 = new PdfPTable(ContactAddrWidths8);
	            Table6.setWidthPercentage(100);
	            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table6.addCell(new Phrase(new Chunk(bu_plantState+" - "+bu_plantPin,small_black_normal)));
	
	            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table6.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
	            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table6.addCell(new Phrase(new Chunk(plantState+" - "+plantPin,small_black_normal)));
	
	            String tax_info="";
	            String bu_tax_info="";
				tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "C", counterparty_cd, plant_seq);
				bu_tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "B", comp_cd, bu_plant_seq);
				
	           float[] ContactAddrWidths9 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table7 = new PdfPTable(ContactAddrWidths9);
	            Table7.setWidthPercentage(100);
	            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table7.addCell(new Phrase(new Chunk(bu_tax_info,small_black_normal)));
	
	            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table7.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table7.addCell(new Phrase(new Chunk(tax_info,small_black_normal)));
	            
	            PdfPTable InvoiceDateInfoTable;
	            PdfPTable BillingPeriodInfoTable;
	            
	           /* float[] InvoiceDateInfoWidths_qr = {0.30f, 0.20f, 0.70f};
				PdfPTable InvoiceDateInfoTable_qr = new PdfPTable(InvoiceDateInfoWidths_qr);
				if(!irn_no.equals("") && !qr_code.equals("") && (contract_type.equals("Q") || contract_type.equals("O")))
				{
					float[] InvoiceDateInfoWidths = {0.60F,0.40F};
		            InvoiceDateInfoTable = new PdfPTable(InvoiceDateInfoWidths);
		            InvoiceDateInfoTable.setWidthPercentage(100);
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
					InvoiceDateInfoTable.addCell(new Phrase(new Chunk("Invoice Date :",black_bold)));
					InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
					InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(invoice_dt,black_bold)));
		            
		            //due date
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk("Payment Due Date :",black_bold)));
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(invoice_due_dt,black_bold)));
		            
		            //inv no
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(company_abbr+" TAX Invoice Seq No:",black_bold)));
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            InvoiceDateInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk(invoice_no,black_bold)));
		            
		            float[] BillingPeriodInfoWidths = {0.30F,0.20F,0.10F,0.20F};
		            BillingPeriodInfoTable = new PdfPTable(BillingPeriodInfoWidths);
		            BillingPeriodInfoTable.setWidthPercentage(100);
		            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.addCell(new Phrase(new Chunk("Billing Period : ",black_bold)));
		            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.addCell(new Phrase(new Chunk(""+period_start_dt,black_bold)));
		            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            BillingPeriodInfoTable.addCell(new Phrase(new Chunk("to",black_bold)));
		            BillingPeriodInfoTable.getDefaultCell().setBorder(Rectangle.BOX);
		            BillingPeriodInfoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            BillingPeriodInfoTable.addCell(new Phrase(new Chunk(""+period_end_dt,black_bold)));
		            
		            if(!inv_flag.equals("UG") && !inv_flag.equals("ST"))
		            {
		            	InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            	InvoiceDateInfoTable.getDefaultCell().setColspan(3);
		            	InvoiceDateInfoTable.addCell(BillingPeriodInfoTable);
		            }
		               
		            InvoiceDateInfoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		            InvoiceDateInfoTable.getDefaultCell().setColspan(3);
		            InvoiceDateInfoTable.addCell(new Phrase(new Chunk("",small_black_bold)));
					
					int width=90;
					int height=90;
					Hashtable<EncodeHintType, ErrorCorrectionLevel> hintMap = new Hashtable<>();
			        hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
	
			        QRCodeWriter qrCodeWriter = new QRCodeWriter();
			        BitMatrix matrix = qrCodeWriter.encode(qr_code, BarcodeFormat.QR_CODE, width, height, hintMap);
	
			        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			        for (int x = 0; x < width; x++) 
			        {
			            for (int y = 0; y < height; y++) 
			            {
			                image.setRGB(x, y, matrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
			            }
			        }
			        
			        BufferedImage qrImage = image;
			        
			        ByteArrayOutputStream baos = new ByteArrayOutputStream();
			        ImageIO.write(qrImage, "png", baos);
			        Image qr_codeimg = Image.getInstance(baos.toByteArray());
					qr_codeimg.setBorder(Rectangle.NO_BORDER);
	                qr_codeimg.setAlignment(Element.ALIGN_LEFT);
	                PdfPCell qrcode_cell = new PdfPCell(qr_codeimg,false);
	                qrcode_cell.setBorder(Rectangle.NO_BORDER);
	                qrcode_cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	                
	                String char_16= irn_no.substring(0,16);
	                String char_32= irn_no.substring(16,32);
	                String char_48= irn_no.substring(32,48);
	                String char_64= irn_no.substring(48,irn_no.length());
	                String final_irn_no=char_16+"\n"+char_32+"\n"+char_48+"\n"+char_64;
	                
	                PdfPTable InvoiceDateInfoTable_qr1 = new PdfPTable(1);
	       	        InvoiceDateInfoTable_qr1.setWidthPercentage(100);
	       	        InvoiceDateInfoTable_qr1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	       	        InvoiceDateInfoTable_qr1.getDefaultCell().setBorder(Rectangle.BOX);
	       	        InvoiceDateInfoTable_qr1.addCell(qrcode_cell);
	       	        
	       	        PdfPTable InvoiceDateInfoTable_qr11 = new PdfPTable(1);
	    	        InvoiceDateInfoTable_qr11.setWidthPercentage(100);
	    	        InvoiceDateInfoTable_qr11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	    	        InvoiceDateInfoTable_qr11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	    	        InvoiceDateInfoTable_qr11.addCell(new Phrase(new Chunk("IRN",black_bold)));
	    	        InvoiceDateInfoTable_qr11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	    	        InvoiceDateInfoTable_qr11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	    	        InvoiceDateInfoTable_qr11.addCell(new Phrase(new Chunk(final_irn_no,small_black_normal)));
	    	        
	    	        InvoiceDateInfoTable_qr.setWidthPercentage(100);
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	       	        InvoiceDateInfoTable_qr.addCell(InvoiceDateInfoTable_qr1);
	       	        
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setBorder(Rectangle.BOX);
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	       	        InvoiceDateInfoTable_qr.addCell(InvoiceDateInfoTable_qr11);
	       	        
	       	        InvoiceDateInfoTable_qr.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	       	        InvoiceDateInfoTable_qr.addCell(InvoiceDateInfoTable);
				}*/
	
	            float[] ContactAddrWidths10 = {0.80F,0.30F,0.30F,0.40F};
	   	     	PdfPTable Table8 = new PdfPTable(ContactAddrWidths10);
	            Table8.setWidthPercentage(100);
	            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table8.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table8.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table8.addCell(new Phrase(new Chunk("Debit Note Date :",black_bold)));
	
	            Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            //Table8.addCell(new Phrase(new Chunk(dateUtil.getDateFormatDD_MOM_YY(invoice_dt),small_black_normal)));
	            Table8.addCell(new Phrase(new Chunk(invoice_dt,black_bold)));
	
//	            float[] ContactAddrWidths11 = {0.80F,0.30F,0.30F,0.40F};
//	   	     	PdfPTable Table9 = new PdfPTable(ContactAddrWidths11);
//	            Table9.setWidthPercentage(100);
//	            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
//	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
//	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
//	            Table9.addCell(new Phrase(new Chunk("",small_black_normal)));
//	
//	            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
//	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
//	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
//	            Table9.addCell(new Phrase(new Chunk("",small_black_normal)));
//	
//	            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
//	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
//	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
//	            Table9.addCell(new Phrase(new Chunk("Payment Due Date :",black_bold)));
//	
//	            Table9.getDefaultCell().setBorder(Rectangle.BOX);
//	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
//	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
//	            //Table9.addCell(new Phrase(new Chunk(dateUtil.getDateFormatDD_MOM_YY(invoice_due_dt),small_black_normal)));
//	            Table9.addCell(new Phrase(new Chunk(invoice_dt,black_bold)));
	
	            float[] ContactAddrWidths12 = {0.80F,0.10F,0.50F,0.40F};
	   	     	PdfPTable Table10 = new PdfPTable(ContactAddrWidths12);
	            Table10.setWidthPercentage(100);
	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk(company_abbr+" Debit Note Seq No:",black_bold)));
	
	            Table10.getDefaultCell().setBorder(Rectangle.BOX);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk(invoice_no,black_bold)));
	
	            /*float[] ContactAddrWidths12_1 = {0.80F,0.20F,0.10F,0.20F};
	   	     	PdfPTable Table10_1 = new PdfPTable(ContactAddrWidths12_1);
	   	     	Table10_1.setWidthPercentage(100);
	            Table10_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.addCell(new Phrase(new Chunk("Billing Period : ",black_bold)));
	
	            Table10_1.getDefaultCell().setBorder(Rectangle.BOX);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.addCell(new Phrase(new Chunk(""+period_start_dt,black_bold)));
	
	            Table10_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table10_1.addCell(new Phrase(new Chunk("to",black_bold)));
	
	            Table10_1.getDefaultCell().setBorder(Rectangle.BOX);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.addCell(new Phrase(new Chunk(""+period_end_dt,black_bold)));
	            */
	
	            float[] ContactAddrWidths13 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F};
	   	     	PdfPTable Table11 = new PdfPTable(ContactAddrWidths13);
	            Table11.setWidthPercentage(100);
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Sr.No.",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Item",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Data",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Currency",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Rate",small_black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Amount",small_black_bold)));
	
	            String salesValue="";
	            salesValue=""+gross_amt;
	
	            String curr="";
	            String curr1="";
	            if(price_cd.equals("1"))
	            {
	            	curr="INR";
	            }
	            else if(price_cd.equals("2"))
	            {
	            	curr="USD";
	            }
	
	            if(invoice_raised_in.equals("1"))
	            {
	            	curr1="INR";
	            }
	            else if(invoice_raised_in.equals("2"))
	            {
	            	curr1="USD";
	            }
	
	            int sr=1;
	
	            //float[] ContactAddrWidths14 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	//PdfPTable Table12 = new PdfPTable(ContactAddrWidths14);
	            Table11.setWidthPercentage(100);
	            //Table12.getDefaultCell().setBorderWidthBottom(0);
	                      	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table11.addCell(new Phrase(new Chunk("Delayed Payment Invoice Generated Against Invoice No : "+ref_inv_no+" Dated "+ori_inv_dt,small_black_normal)));
				
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
//	            if(!invoice_raised_in.equals(price_cd))
//	            {
//	            	sr+=1;
//		            //float[] ContactAddrWidths15 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
//		   	     	//PdfPTable Table13 = new PdfPTable(ContactAddrWidths15);
//		            //Table13.setWidthPercentage(100);
//		            //Table13.getDefaultCell().setBorderWidthTop(0);
//		
//		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
//		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
//		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
//		            Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
//		
//		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
//		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
//		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
//		            Table11.addCell(new Phrase(new Chunk("Exchange Rate",small_black_normal)));
//		
//		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
//		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
//		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
//		            Table11.addCell(new Phrase(new Chunk("INR/USD",small_black_normal)));
//		
//		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
//		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
//		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
//		            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
//		
//		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
//		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
//		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
//		            Table11.addCell(new Phrase(new Chunk(exchang_rate,small_black_normal)));
//		
//		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
//		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
//		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
//		            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
//	            }
	
	            sr+=1;
	   	     	//float[] ContactAddrWidths16 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	//PdfPTable Table14 = new PdfPTable(ContactAddrWidths16);
	            //Table14.setWidthPercentage(100);
	            //Table14.getDefaultCell().setBorderWidthBottom(0);
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table11.addCell(new Phrase(new Chunk("Net Amount",small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk(ori_inv_net_amt,small_black_normal)));
	            
	            //float[] ContactAddrWidths26 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	    	    //PdfPTable Table24 = new PdfPTable(ContactAddrWidths26);
	    	    
	    	    //float[] ContactAddrWidths27 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	    	    //PdfPTable Table25 = new PdfPTable(ContactAddrWidths27);
	    	    
	            //if(agmt_base.equals("D"))
            	sr+=1;
            	
        	    Table11.setWidthPercentage(100);
                 
        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
        	    Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
        	    Table11.addCell(new Phrase(new Chunk("Due Date",small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
        	    Table11.addCell(new Phrase(new Chunk(ori_inv_due_dt,small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
            	sr+=1;
            	
        	    Table11.setWidthPercentage(100);
                 
        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
        	    Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
        	    Table11.addCell(new Phrase(new Chunk("Payment Received Date",small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
        	    Table11.addCell(new Phrase(new Chunk(ori_inv_payrecv_dt,small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
        	    Table11.addCell(new Phrase(new Chunk(ori_inv_payrecv_amt,small_black_normal)));
	            
            	sr+=1;
            	
        	    Table11.setWidthPercentage(100);
                 
        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
        	    Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
        	    Table11.addCell(new Phrase(new Chunk("No Of Days For Late Payment Invoice",small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
        	    Table11.addCell(new Phrase(new Chunk(nf.format(int_days)+" Days",small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));

        	    sr+=1;
            	
        	    Table11.setWidthPercentage(100);
                 
        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
        	    Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
        	    Table11.addCell(new Phrase(new Chunk("Interest Rate",small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
        	    Table11.addCell(new Phrase(new Chunk(int_rate+" %",small_black_normal)));

        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
        	    
        	    sr+=1;
        	    
        	    Table11.setWidthPercentage(100);
        	    
        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
        	    Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
        	    
        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
        	    Table11.addCell(new Phrase(new Chunk("Payable Amount",small_black_normal)));
        	    
        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
        	    
        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
        	    Table11.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
        	    
        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
        	    Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
        	    
        	    Table11.getDefaultCell().setBorder(Rectangle.BOX);
        	    Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
        	    Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
        	    Table11.addCell(new Phrase(new Chunk(invoice_amt,small_black_normal)));
	
	            
	            //float[] ContactAddrWidths17 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	//PdfPTable Table15 = new PdfPTable(ContactAddrWidths17);
	   	     	/*if(!contract_type.equals("I")) {
	   	     	Table15.getDefaultCell().setBorderWidthTop(0);
	   	     	}else {
	   	     	Table15.getDefaultCell().setBorderWidthTop(0);
	   	     	Table15.getDefaultCell().setBorderWidthBottom(0);
	   	     	}*/
	            
	            //FOR SERVICE ORDER ONLY
	            if(contract_type.equals("B") || contract_type.equals("M"))
	            {
	            	sr+=1;
		   	     	Table11.setWidthPercentage(100);
		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
		
		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		            Table11.addCell(new Phrase(new Chunk("Tax ("+tax_struct_dtl+")",small_black_normal)));
		            
		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
		
		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table11.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
		
		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
		
		            Table11.getDefaultCell().setBorder(Rectangle.BOX);
		            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            Table11.addCell(new Phrase(new Chunk(tax_amt,small_black_normal)));
		            
		            queryString1="SELECT COUNT(*) "
							+ "FROM FMS_DLNG_INV_TAX_DTL "
							+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
							+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
		            stmt1=conn.prepareStatement(queryString1);
		            stmt1.setString(1, comp_cd);
		            stmt1.setString(2, bu_state_tin);
		            stmt1.setString(3, financial_year);
		            stmt1.setString(4, inv_seq);
		            rset1=stmt1.executeQuery();
					if(rset1.next())
					{
						if(rset1.getInt(1)>1)
						{
							double temp_srno=sr;
							queryString="SELECT TAX_CODE,TAX_DESCR,TAX_AMT,TAX_BASE_AMT "
									+ "FROM FMS_DLNG_INV_TAX_DTL "
									+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
									+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
							stmt=conn.prepareStatement(queryString);
				            stmt.setString(1, comp_cd);
				            stmt.setString(2, bu_state_tin);
				            stmt.setString(3, financial_year);
				            stmt.setString(4, inv_seq);
				            rset=stmt.executeQuery();
							while(rset.next())
							{
								temp_srno=temp_srno+0.1;
								
								String tax_descr=rset.getString(2)==null?"":rset.getString(2);
								String taxAmt=rset.getString(3)==null?"":nf.format(rset.getDouble(3));
								
								Table11.setWidthPercentage(100);
					            Table11.getDefaultCell().setBorder(Rectangle.BOX);
					            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
					            Table11.addCell(new Phrase(new Chunk(""+nf0.format(temp_srno),small_black_normal)));
		
					            Table11.getDefaultCell().setBorder(Rectangle.BOX);
					            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
					            Table11.addCell(new Phrase(new Chunk(""+tax_descr+"",small_black_normal)));
					            
					            Table11.getDefaultCell().setBorder(Rectangle.BOX);
					            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
					            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
		
					            Table11.getDefaultCell().setBorder(Rectangle.BOX);
					            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
					            Table11.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
		
					            Table11.getDefaultCell().setBorder(Rectangle.BOX);
					            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
					            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
		
					            Table11.getDefaultCell().setBorder(Rectangle.BOX);
					            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
					            Table11.addCell(new Phrase(new Chunk(taxAmt,small_black_normal)));
							}
							rset.close();
							stmt.close();
						}
					}
					rset1.close();
					stmt1.close();
	            }
	            
//				String invAmtLbl="Net Amount Payable";
//	            sr+=1;
//	            //float[] ContactAddrWidths18 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
//	   	     	//PdfPTable Table16 = new PdfPTable(ContactAddrWidths18);
//	   	     	//Table16.getDefaultCell().setBorderWidthBottom(0);
//	
//	   	     	Table11.setWidthPercentage(100);
//	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
//	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
//	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
//	            Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
//	
//	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
//	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
//	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
//	            Table11.addCell(new Phrase(new Chunk(invAmtLbl,small_black_normal)));
//	
//	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
//	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
//	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
//	            Table11.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
//	
//	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
//	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
//	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
//	            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
//	
//	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
//	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
//	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
//	            Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
//	
//	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
//	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
//	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
//	            Table11.addCell(new Phrase(new Chunk(net_payable,small_black_normal)));
	            
	            if(applicable_abbr.equals("TCS"))
	            {
	            	sr+=1;
	            	
	            	Table11.setWidthPercentage(100);
	                Table11.getDefaultCell().setBorder(Rectangle.BOX);
	                Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table11.addCell(new Phrase(new Chunk(""+sr,small_black_normal)));
	
	                Table11.getDefaultCell().setBorder(Rectangle.BOX);
	                Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	                Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	                Table11.addCell(new Phrase(new Chunk("TCS",small_black_normal)));
	
	                Table11.getDefaultCell().setBorder(Rectangle.BOX);
	                Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table11.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	                Table11.getDefaultCell().setBorder(Rectangle.BOX);
	                Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	                Table11.addCell(new Phrase(new Chunk(""+curr1,small_black_normal)));
	
	                Table11.getDefaultCell().setBorder(Rectangle.BOX);
	                Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table11.addCell(new Phrase(new Chunk(TCS_factor+"%",small_black_normal)));
	
	                Table11.getDefaultCell().setBorder(Rectangle.BOX);
	                Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	                Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	                Table11.addCell(new Phrase(new Chunk(applicable_amt,small_black_normal)));
	            }
	            
	            sr+=1;
	            //float[] ContactAddrWidths20 = {0.08F,0.60F,0.20F,0.20F,0.20F,0.20F,0.20F};
	   	     	//PdfPTable Table18 = new PdfPTable(ContactAddrWidths20);
	
	   	     	Table11.setWidthPercentage(100);
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk(""+sr,black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table11.addCell(new Phrase(new Chunk("Net Amount Payable",black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("",black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk(""+curr1,black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk("",black_bold)));
	
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table11.addCell(new Phrase(new Chunk(net_payable,black_bold)));
	
	            float[] ContactAddrWidths21 = {0.100F};
	   	     	PdfPTable Table19 = new PdfPTable(ContactAddrWidths21);
	   	     	Table19.setWidthPercentage(100);
	   	     	Table19.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	Table19.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	Table19.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	     	Table19.addCell(new Phrase(new Chunk(remark_1,small_black_normal)));
	
	   	     	float[] ContactAddrWidths22 = {0.100F};
		     	PdfPTable Table20 = new PdfPTable(ContactAddrWidths22);
		     	Table20.setWidthPercentage(100);
		     	Table20.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		     	Table20.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		     	Table20.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		     	Table20.addCell(new Phrase(new Chunk(remark_2,small_black_normal)));
		     	
		     	float[] ContactAddrWidths23 = {0.100F};
	   	     	PdfPTable Table21 = new PdfPTable(ContactAddrWidths21);
	   	     	Table21.setWidthPercentage(100);
	   	     	Table21.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	Table21.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	  		Table21.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	  		Table21.addCell(new Phrase(new Chunk("For "+company_nm,black_bold)));
	   	  		
	   	  		// create a signature form field
	   	     	PdfPTable BillingFieldsInfoTable81 = new PdfPTable(1);
	   	     	BillingFieldsInfoTable81.setWidthPercentage(20);
	   	     	BillingFieldsInfoTable81.setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	BillingFieldsInfoTable81.getDefaultCell().setBorder(Rectangle.BOX);
	   	     	BillingFieldsInfoTable81.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	BillingFieldsInfoTable81.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	        
	   	     	PdfFormField field = PdfFormField.createSignature(writer);
	   	     	field.setFieldName(SIGNAME);
	   	     	// set the widget properties
	   	     	field.setPage();
	   	     	field.setWidget(new Rectangle(72, 732, 144, 780), PdfAnnotation.HIGHLIGHT_NONE);
	   	     	field.setFlags(PdfAnnotation.FLAGS_PRINT);
	   	     	writer.addAnnotation(field);
	         
	   	     	PdfPCell sigCell = new PdfPCell();
	   	     	FieldPositioningEvents events = new FieldPositioningEvents(writer, field);
	   	     	sigCell.setCellEvent(events);
	   	     	sigCell.setFixedHeight(50f);
	   	     	BillingFieldsInfoTable81.addCell(sigCell);
	
	   	     	float[] ContactAddrWidths24 = {0.100F};
		     	PdfPTable Table22 = new PdfPTable(ContactAddrWidths22);
	
		     	Table22.setWidthPercentage(100);
		     	Table22.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		     	Table22.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		     	Table22.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		     	Table22.addCell(new Phrase(new Chunk("Authorised Signatory",black_bold)));
		     	
		     	document.add(LogoTable);
				document.add(HlplLogoTable);
				document.add(Table);
				document.add(Table1);
				document.add(Table2);
				document.add(new Paragraph("  "));
				document.add(Table3);
				document.add(Table4);
				document.add(Table5);
				document.add(Table6);
				document.add(Table7);
				document.add(new Paragraph("  "));
				document.add(new Paragraph("  "));
				/*if(!irn_no.equals("") && !qr_code.equals("") && (contract_type.equals("Q") || contract_type.equals("O")))
				{
					document.add(InvoiceDateInfoTable_qr);
				}
				else*/
				{
					document.add(Table8);
//					document.add(Table9);
					document.add(Table10);
					/*if(!inv_flag.equals("UG") && !inv_flag.equals("ST"))
		            {
						document.add(Table10_1);
		            }*/
				}
				document.add(new Paragraph("  "));
				document.add(Table11);
				document.add(new Paragraph("  "));
				document.add(Table19);
				document.add(Table20);
				document.add(new Paragraph("  "));
				document.add(new Paragraph("  "));
				document.add(Table21);
				document.add(BillingFieldsInfoTable81);
				document.add(Table22);
				
	            document.close();
	            
	            File isPDFexist = new File(path);
				if(isPDFexist.exists())
				{
					String invoice_title="";
					int update_flag=0;
					int pdf_entry=0;
					
					int cont=0;
					queryString="UPDATE FMS_DLNG_INVOICE_MST SET PDF_INV_DTL=? ";
						if(print_pdf_type.equals("O"))
						{
							queryString+= ",PRINT_BY_ORI=?,PRINT_DT_ORI=SYSDATE ";
						}
						else if(print_pdf_type.equals("T"))
						{
							queryString+= ",PRINT_BY_TRI=?,PRINT_DT_TRI=SYSDATE ";
						}
						else if(print_pdf_type.equals("D"))
						{
							queryString+= ",PRINT_BY_DUP=?,PRINT_DT_DUP=SYSDATE ";
						}
						queryString+= "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? "
							+ "AND AGMT_NO=? AND PLANT_SEQ=? AND BU_UNIT=? AND CONTRACT_TYPE=? "
							+ "AND PERIOD_START_DT=TO_DATE(?,'DD/MM/YYYY') AND PERIOD_END_DT=TO_DATE(?,'DD/MM/YYYY') "
							+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? AND MAPPING_ID=? AND INV_FLAG=? "
							+ "AND TRUCK_TRANS_CD=? AND TRUCK_CD=? AND REF_NO =? ";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(++cont, print_pdf_type);
					if(print_pdf_type.equals("O"))
					{
						stmt.setString(++cont, emp_cd);
					}
					else if(print_pdf_type.equals("T"))
					{
						stmt.setString(++cont, emp_cd);
					}
					else if(print_pdf_type.equals("D"))
					{
						stmt.setString(++cont, emp_cd);
					}
					stmt.setString(++cont, comp_cd);
					stmt.setString(++cont, counterparty_cd);
					stmt.setString(++cont, cont_no);
					stmt.setString(++cont, agmt_no);
					stmt.setString(++cont, plant_seq);
					stmt.setString(++cont, bu_plant_seq);
					stmt.setString(++cont, contract_type);
					stmt.setString(++cont, cont_start_dt);
					stmt.setString(++cont, cont_end_dt);
					stmt.setString(++cont, financial_year);
					stmt.setString(++cont, inv_seq);
					stmt.setString(++cont, bu_state_tin);
					stmt.setString(++cont, mapping_id);
					stmt.setString(++cont, inv_flag);
					stmt.setString(++cont, truck_trans_cd);
					stmt.setString(++cont, truck_cd);
					stmt.setString(++cont, ref_inv_no);
					update_flag=stmt.executeUpdate();
					stmt.close();
					
					int count=0;
			        queryString1="SELECT COUNT(*) "
			        		+ "FROM FMS_DLNG_INV_FILE_DTL "
			        		+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
			        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE=?";
			        stmt1=conn.prepareStatement(queryString1);
			        stmt1.setString(1, comp_cd);
			        stmt1.setString(2, bu_state_tin);
			        stmt1.setString(3, inv_seq);
			        stmt1.setString(4, financial_year);
			        stmt1.setString(5, print_pdf_type);
			        rset1=stmt1.executeQuery();
			        if(rset1.next())
			        {
			        	count=rset1.getInt(1);
			        }
			        rset1.close();
			        stmt1.close();
			        
			        if(count > 0)
			        {
			        	queryString1="UPDATE FMS_DLNG_INV_FILE_DTL SET FILE_NAME=?,MODIFY_BY=?,MODIFY_DT=SYSDATE "
			        			+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
				        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE=?";
			        	stmt1=conn.prepareStatement(queryString1);
			        	stmt1.setString(1, file_nm);
			        	stmt1.setString(2, emp_cd);
			        	stmt1.setString(3, comp_cd);
			 	        stmt1.setString(4, bu_state_tin);
			 	        stmt1.setString(5, inv_seq);
			 	        stmt1.setString(6, financial_year);
			 	        stmt1.setString(7, print_pdf_type);
			 	        pdf_entry=stmt1.executeUpdate();
			        	
			        	stmt1.close();
			        }
			        else
			        {
			        	queryString1="INSERT INTO FMS_DLNG_INV_FILE_DTL(COMPANY_CD,BU_STATE_TIN,INVOICE_SEQ,FINANCIAL_YEAR,PDF_TYPE,"
			        			+ "FILE_NAME,ENT_BY,ENT_DT) "
			        			+ "VALUES(?,?,?,?,?,"
			        			+ "?,?,SYSDATE)";
			        	stmt1=conn.prepareStatement(queryString1);
			        	stmt1.setString(1, comp_cd);
			 	        stmt1.setString(2, bu_state_tin);
			 	        stmt1.setString(3, inv_seq);
			 	        stmt1.setString(4, financial_year);
			 	        stmt1.setString(5, print_pdf_type);
			 	        stmt1.setString(6, file_nm);
			        	stmt1.setString(7, emp_cd);
			        	pdf_entry=stmt1.executeUpdate();
			        	
			        	stmt1.close();
			        }
			        
			        String tempRePrintMsg="";
			        String re_printFlag="";
			        String re_print_Seq_No="";
			        queryString2="SELECT FLAG,SEQ_NO "
			        		+ "FROM FMS_INVOICE_CHANGE_DTL A "
			        		+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
							+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND SEGMENT=? AND CHANGE_TYPE=? "
							+ "AND SEQ_NO=(SELECT MAX(B.SEQ_NO) FROM FMS_INVOICE_CHANGE_DTL B WHERE A.COMPANY_CD=B.COMPANY_CD "
							+ "AND A.BU_STATE_TIN=B.BU_STATE_TIN AND A.INVOICE_SEQ=B.INVOICE_SEQ AND A.FINANCIAL_YEAR=B.FINANCIAL_YEAR "
							+ "AND A.SEGMENT=B.SEGMENT AND A.CHANGE_TYPE=B.CHANGE_TYPE)";
			        stmt2=conn.prepareStatement(queryString2);
			        stmt2.setString(1, comp_cd);
			        stmt2.setString(2, bu_state_tin);
			        stmt2.setString(3, inv_seq);
			        stmt2.setString(4, financial_year);
			        stmt2.setString(5, "DLNG");
			        stmt2.setString(6, "REPRINT_PDF");
			        rset2=stmt2.executeQuery();
			        if(rset2.next())
			        {
			        	re_printFlag=rset2.getString(1)==null?"":rset2.getString(1);
			        	re_print_Seq_No=rset2.getString(2)==null?"":rset2.getString(2);
			        }
			        rset2.close();
			        stmt2.close();
			        
			        if(re_printFlag.equals("A"))
			        {
			        	tempRePrintMsg="Re-Printed ";
			        	int reprint_pdf_count=0;
			        	queryString2="SELECT COUNT(*) "
				        		+ "FROM FMS_DLNG_INV_FILE_DTL "
				        		+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
				        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE IN ('O','D','T')";
				        stmt2=conn.prepareStatement(queryString2);
				        stmt2.setString(1, comp_cd);
				        stmt2.setString(2, bu_state_tin);
				        stmt2.setString(3, inv_seq);
				        stmt2.setString(4, financial_year);
				        rset2=stmt2.executeQuery();
				        if(rset2.next())
				        {
				        	reprint_pdf_count=rset2.getInt(1);
				        }
				        rset2.close();
				        stmt2.close();
				        
				        if(reprint_pdf_count==3)
				        {
				        	queryString2="UPDATE FMS_INVOICE_CHANGE_DTL SET FLAG=? "
				    				+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
									+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
									+ "AND SEGMENT=? AND CHANGE_TYPE=? AND FLAG=? AND SEQ_NO=? ";
				    		stmt2=conn.prepareStatement(queryString2);
				    		stmt2.setString(1, "P");
					        stmt2.setString(2, comp_cd);
					        stmt2.setString(3, bu_state_tin);
					        stmt2.setString(4, inv_seq);
					        stmt2.setString(5, financial_year);
					        stmt2.setString(6, "DLNG");
					        stmt2.setString(7, "REPRINT_PDF");
					        stmt2.setString(8, re_printFlag);
					        stmt2.setString(9, re_print_Seq_No);
					        stmt2.executeUpdate();
							
							stmt2.close();
				        }
			        }
			        
			        if(pdf_entry == 0 || update_flag == 0)
			        {
			        	conn.rollback();
			        	deletePdfFile(path);
			        	msg="Failed! - "+invdtl+" Late Payment Invoice for "+counterparty_abbr+" PDF for "+dealMap+" Generation Failed for "+cont_end_dt+"!";
			        	msg_type="E";
			        }
			        else
			        {
			        	conn.commit();
			        	msg = "Successful! - "+invdtl+" Late Payment Invoice for "+counterparty_abbr+" PDF "+file_nm+" for "+dealMap+" Generated Successfully for "+cont_end_dt+"!";
			        	msg_type="S";
			        }
				}
				else
				{
					msg="Failed! - "+invdtl+" Late Payment Invoice for "+counterparty_abbr+" PDF for "+dealMap+" Generation Failed for "+cont_end_dt+"!";
					msg_type="E";
				}
			}
		}
		catch(Exception e)
		{
			conn.rollback();
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
			
			document.close();
			deletePdfFile(path);
			
			msg="Error in Exception! - "+invdtl+" Late Payment Invoice for "+counterparty_abbr+" PDF Generation Failed!";
			msg_type="E";	
		}
		finally
		{
			document.close();
		}
		
		try
		{
			new com.etrm.fms.util.InfoLogger().InsertInfoLogger(emp_cd, comp_cd,emp_nm, ip, form_id, form_nm,mod_cd,mod_nm, "", "", msg);  	
		}
		catch(Exception infoLogger)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, infoLogger);
		}
	}
	
	public void printPdfFileForDervCRDRInvoice() throws SQLException
	{
		String function_nm="printPdfFileForDervCRDRInvoice()";
		
		String emp_nm ="";
		String ip = "";
		msg="";
		//String msg_content="";
		String path ="";
		String counterparty_abbr="";
		String invdtl="Derivatives";
		String crdrdtl="";
		String crdrNm="";
		
		Rectangle pageSize = new Rectangle(595, 842);
		//Rectangle pageSize1=new Rectangle(842,595);
		Rectangle pageSize1 = new Rectangle(595, 842);
		Rectangle pageSize2=new Rectangle(842,595);
		
		pageSize.setBackgroundColor(BaseColor.WHITE);
		pageSize1.setBackgroundColor(BaseColor.WHITE);
		
		Document document = new Document(pageSize);
		try
		{
			HttpSession session = request.getSession();
			emp_nm = (String)session.getAttribute("emp_nm")==null?"":(String)session.getAttribute("emp_nm");
			ip = (String)session.getAttribute("ip")==null?"":(String)session.getAttribute("ip");
			
			String company_nm = ""+session.getAttribute("comp_nm")==null?"":""+session.getAttribute("comp_nm");
			String company_abbr = ""+session.getAttribute("comp_abbr")==null?"":""+session.getAttribute("comp_abbr");
			String counterparty_nm=""+utilBean.getCounterpartyName(conn,counterparty_cd);
			counterparty_abbr=""+utilBean.getCounterpartyABBR(conn,counterparty_cd);
			
			
			if(crdr_type.equals("DR"))
			{
				crdrdtl="Debit Note";
				crdrNm="DEBIT NOTE";
			}
			else if(crdr_type.equals("CR"))
			{
				crdrdtl="Credit Note";
				crdrNm="CREDIT NOTE";
			}
			
			if(invoice_type.equals("I"))
			{
				invdtl="Invoice";
			}
			else if(invoice_type.equals("R"))
			{
				invdtl="Remittance";
			}
			
			int pdfGenCount=0;
			queryString="SELECT COUNT(*) "
					+ "FROM FMS_DERV_INVOICE_MST A ,FMS_DERV_INV_FILE_DTL B "
					+ "WHERE A.COMPANY_CD=? AND A.FINANCIAL_YEAR=? AND A.INVOICE_SEQ=? AND A.BU_STATE_TIN=? AND A.INV_FLAG=? ";
			if(print_pdf_type.equals("O"))
			{
				queryString+= "AND A.PRINT_BY_ORI IS NOT NULL AND A.PRINT_DT_ORI IS NOT NULL ";
			}
			else if(print_pdf_type.equals("T"))
			{
				queryString+= "AND A.PRINT_BY_TRI IS NOT NULL AND A.PRINT_DT_TRI IS NOT NULL ";
			}
			else if(print_pdf_type.equals("D"))
			{
				queryString+= "AND A.PRINT_BY_DUP IS NOT NULL AND A.PRINT_DT_DUP IS NOT NULL ";
			}
			queryString+= "AND B.PDF_TYPE=? AND B.FILE_NAME IS NOT NULL "
					+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.BU_STATE_TIN=B.BU_STATE_TIN AND A.INVOICE_SEQ=B.INVOICE_SEQ "
    		  		+ "AND A.FINANCIAL_YEAR=B.FINANCIAL_YEAR";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, financial_year);
			stmt.setString(3, inv_seq);
			stmt.setString(4, bu_state_tin);
			stmt.setString(5, crdr_type);
			stmt.setString(6, print_pdf_type);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				pdfGenCount=rset.getInt(1);
			}
			rset.close();
			stmt.close();
			
			if(pdfGenCount>0)
			{
				msg="Failed! - "+invdtl+" "+crdrdtl+" for "+counterparty_abbr+" PDF for "+crdr_inv_no+" already Generated!";
	        	msg_type="E";
	        }
			else
			{
				getDervInvoiceDetailCrDr();
				getSelectedInvInstrumentDtl();
				getNewInvInstrumentDtl();
				
				String print_pdf_type_nm="ORIGINAL";
				if(print_pdf_type.equals("O"))
				{
					print_pdf_type_nm="ORIGINAL";
				}
				else if(print_pdf_type.equals("D"))
				{
					print_pdf_type_nm="DUPLICATE";
				}
				else if(print_pdf_type.equals("T"))
				{
					print_pdf_type_nm="TRIPLICATE";
				}
	
				String appPath = request.getServletContext().getRealPath("");

				String main_folder="";
				if(!comp_cd.equals(""))
				{
					main_folder=CommonVariable.work_dir+comp_cd;
				}
				
				String sub_folder="unsigned_pdf";
				String sub_folder2="derivatives_invoice";
				if(invoice_type.equals("R"))
				{
					sub_folder="derivatives";
					sub_folder2="remittance";
				}
				String temp_path=appPath+File.separator+main_folder+File.separator+sub_folder+File.separator+sub_folder2;
				File main_folderDir = new File(temp_path);
		        if(!main_folderDir.exists())
		        {
		        	main_folderDir.mkdirs();
		        }
				
				String monthofinv = dateUtil.getMonthNameMON(period_end_dt);
		        String dtPeriod="";
		        if(!period_start_dt.equals("") && !period_end_dt.equals(""))
		        {
		        	dtPeriod=period_start_dt.substring(0,2);
		        	dtPeriod+="-";
		        	dtPeriod+=period_end_dt.substring(0,2);
		        }

		        String contNm="";
		        String invNm="";
		        String invTp="";
		        if(invoice_type.equals("I"))
		        {
		        	contNm="Derivatives";
		        	invNm="INVOICE";
		        	invTp="Invoice";
		        }
		        else if(invoice_type.equals("R"))
		        {
		        	contNm="Derivatives";
		        	invNm="REMITTANCE";
		        	invTp="Remittance";
		        	print_pdf_type_nm="Remittance Advice";
		        }
		        
		        file_nm=print_pdf_type+"-"+company_abbr+"-"+contNm+"_"+crdrNm+"-"+crdr_inv_no.replace("/", "-")+".pdf";

		        path = appPath+"/"+main_folder+"/"+sub_folder+"/"+sub_folder2+"/"+file_nm;
				PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream(path));

				document.open();
				document.setPageSize(pageSize);
	            document.newPage();

	            String context_nm = request.getContextPath();
				String server_nm = request.getServerName();
				String server_port = ""+request.getServerPort();

				file_url = CommonVariable.app_protocol+"://"+server_nm+":"+server_port+context_nm;

				Font small_black_normal = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
				Font small_black_normal_10 = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
				Font small_black_normal_14 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
				Font small_black_normal_12 = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL, new BaseColor(0x00, 0x00, 0x00));
	            Font small_black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
	            Font black_bold = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
	            Font black_bold1 = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.BOLD, new BaseColor(0x00, 0x00, 0x00));
	            
	            PdfPCell company_logo_cell = new PdfPCell();
	            if(!comp_logo.equals(""))
	            {
	            	String file_path = request.getRealPath("/"+CommonVariable.company_logo_path+"/"+comp_logo);
	            	Image company_logo = Image.getInstance(file_path);
		            company_logo.setBorder(Rectangle.NO_BORDER);
		            company_logo.scaleAbsolute(44,40);
		            company_logo_cell = new PdfPCell(company_logo,false);
		            company_logo_cell.setBorder(Rectangle.NO_BORDER);
		            company_logo_cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	            }
	            
	            float[] Contact1 = {0.50f};
	   	     	PdfPTable LogoTable = new PdfPTable(Contact1);
	   	     	LogoTable.setWidthPercentage(100);
	   	     	LogoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	LogoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	LogoTable.addCell(company_logo_cell);
	            
	            float[] mainWidths = {10f, 70f, 10f};  
	            PdfPTable mainTable = new PdfPTable(mainWidths);
	            mainTable.setWidthPercentage(100);
	            mainTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            
	            PdfPCell logoCell = new PdfPCell(company_logo_cell);
	            logoCell.setBorder(Rectangle.NO_BORDER);
	            logoCell.setHorizontalAlignment(Element.ALIGN_LEFT);
	            logoCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            logoCell.setPaddingLeft(10);
	            mainTable.addCell(logoCell);
	            
	            PdfPTable centerTable = new PdfPTable(1);
	            centerTable.setWidthPercentage(100);
	            centerTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            centerTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            centerTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            centerTable.addCell(new Phrase(new Chunk(print_pdf_type_nm, small_black_normal_10)));
	            centerTable.addCell(new Phrase(new Chunk(company_nm, black_bold1)));
	            centerTable.addCell(new Phrase(new Chunk(crdrNm, small_black_normal_12)));

	            PdfPCell centerCell = new PdfPCell(centerTable);
	            centerCell.setBorder(Rectangle.NO_BORDER);
	            centerCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            mainTable.addCell(centerCell);

	            PdfPCell emptyCell = new PdfPCell(new Phrase(""));
	            emptyCell.setBorder(Rectangle.NO_BORDER);
	            mainTable.addCell(emptyCell);

				/*float[] ContactAddrWidths1 = {0.100f};
	   	     	PdfPTable HlplLogoTable = new PdfPTable(ContactAddrWidths1);
	            HlplLogoTable.setWidthPercentage(100);
	            HlplLogoTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            HlplLogoTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            HlplLogoTable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            HlplLogoTable.addCell(new Phrase(new Chunk(print_pdf_type_nm,small_black_normal_10)));

	            float[] ContactAddrWidths2 = {0.100f};
	   	     	PdfPTable Table = new PdfPTable(ContactAddrWidths2);
	            Table.setWidthPercentage(100);
	            Table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table.addCell(new Phrase(new Chunk(company_nm,black_bold1)));

	            float[] ContactAddrWidths3 = {0.100f};
	   	     	PdfPTable Table1 = new PdfPTable(ContactAddrWidths3);
	            Table1.setWidthPercentage(100);
	            Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	        	Table1.addCell(new Phrase(new Chunk(""+crdrNm,small_black_normal_12)));*/
	            
				period_start_dt=dateUtil.getDateFormatDD_MOM_YY(period_start_dt);
				period_end_dt=dateUtil.getDateFormatDD_MOM_YY(period_end_dt);


	            float[] ContactAddrWidths4 = {0.100f};
	   	     	PdfPTable Table2 = new PdfPTable(ContactAddrWidths4);
	            Table2.setWidthPercentage(100);
	            Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table2.addCell(new Phrase(new Chunk("",small_black_normal)));

	            float[] ContactAddrWidths5 = {0.80f,0.10F,0.20F,0.80F};
	   	     	PdfPTable Table3 = new PdfPTable(ContactAddrWidths5);
	            Table3.setWidthPercentage(100);
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            //Table3.addCell(new Phrase(new Chunk("Business Unit: "+bu_plantNm,black_bold)));
	            Table3.addCell(new Phrase(new Chunk("Registered Office: ",black_bold)));
	            
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table3.addCell(new Phrase(new Chunk("",black_bold)));
	            
	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table3.addCell(new Phrase(new Chunk("To:",black_bold)));

	            Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table3.addCell(new Phrase(new Chunk("",black_bold)));

	            

				float[] ContactAddrWidths6 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table4 = new PdfPTable(ContactAddrWidths6);
	            Table4.setWidthPercentage(100);
	            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            	Table4.addCell(new Phrase(new Chunk(company_nm,small_black_normal)));
	            
	            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table4.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            	Table4.addCell(new Phrase(new Chunk(counterparty_nm,small_black_normal)));

	            float[] ContactAddrWidths7 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table5 = new PdfPTable(ContactAddrWidths7);
	            Table5.setWidthPercentage(100);
	            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            	Table5.addCell(new Phrase(new Chunk(bu_plantAddress+","+bu_plantCity,small_black_normal)));
	            
	            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table5.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
	            Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            	Table5.addCell(new Phrase(new Chunk(plantAddress+","+plantCity,small_black_normal)));
	            
	            float[] ContactAddrWidths8 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table6 = new PdfPTable(ContactAddrWidths8);
	            Table6.setWidthPercentage(100);
	            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            	Table6.addCell(new Phrase(new Chunk(bu_plantState+" - "+bu_plantPin,small_black_normal)));

	            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table6.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
	            Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            	Table6.addCell(new Phrase(new Chunk(plantState+" - "+plantPin,small_black_normal)));

	            String tax_info="";
	            String bu_tax_info="";
	            
				tax_info=getCounterpartyPlantTaxInfo(comp_cd, "T", counterparty_cd, plant_seq);
				
				bu_tax_info=getCounterpartyPlantTaxInfo(comp_cd, "B", comp_cd, bu_plant_seq);
	            
	            float[] ContactAddrWidths9 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable Table7 = new PdfPTable(ContactAddrWidths9);
	            Table7.setWidthPercentage(100);
	            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            	Table7.addCell(new Phrase(new Chunk(bu_tax_info,small_black_normal)));

	            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            Table7.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            	Table7.addCell(new Phrase(new Chunk(tax_info,small_black_normal)));
	            
	            PdfPTable InvoiceDateInfoTable;
	            PdfPTable BillingPeriodInfoTable;
	            
	            float[] ContactAddrWidths10 = {0.80F,0.10F,0.50F,0.40F};
	   	     	PdfPTable Table8 = new PdfPTable(ContactAddrWidths10);
	            Table8.setWidthPercentage(100);
	            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table8.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table8.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table8.addCell(new Phrase(new Chunk(crdrdtl+" Date :",black_bold)));

	            Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            //Table8.addCell(new Phrase(new Chunk(dateUtil.getDateFormatDD_MOM_YY(invoice_dt),small_black_normal)));
	            Table8.addCell(new Phrase(new Chunk(crdr_dt,black_bold)));

	            float[] ContactAddrWidths11 = {0.80F,0.10F,0.50F,0.40F};
	   	     	PdfPTable Table9 = new PdfPTable(ContactAddrWidths11);
	            Table9.setWidthPercentage(100);
	            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table9.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table9.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table9.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table9.addCell(new Phrase(new Chunk(crdrdtl+" Due Date :",black_bold)));

	            Table9.getDefaultCell().setBorder(Rectangle.BOX);
	            Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            //Table9.addCell(new Phrase(new Chunk(dateUtil.getDateFormatDD_MOM_YY(invoice_due_dt),small_black_normal)));
	            Table9.addCell(new Phrase(new Chunk(crdr_due_dt,black_bold)));
	            
	            float[] ContactAddrWidths11_1 = {0.80F,0.10F,0.50F,0.40F};
	   	     	PdfPTable Table9_1 = new PdfPTable(ContactAddrWidths11_1);
	   	     	Table9_1.setWidthPercentage(100);
	   	     	Table9_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	Table9_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	   	     	Table9_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	   	     	Table9_1.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table9_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table9_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table9_1.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table9_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table9_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table9_1.addCell(new Phrase(new Chunk("Vendor Invoice No.",black_bold)));

	            Table9_1.getDefaultCell().setBorder(Rectangle.BOX);
	            Table9_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table9_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table9_1.addCell(new Phrase(new Chunk(inv_ref,black_bold)));

	            float[] ContactAddrWidths12 = {0.80F,0.10F,0.50F,0.40F};
	   	     	PdfPTable Table10 = new PdfPTable(ContactAddrWidths12);
	            Table10.setWidthPercentage(100);
	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            if(invoice_type.equals("I"))
	            {
	            	Table10.addCell(new Phrase(new Chunk(company_abbr+" "+crdrdtl+" Seq No:",black_bold)));
	            }
	            else
	            {
	            	Table10.addCell(new Phrase(new Chunk(company_abbr+" "+invTp+" Seq No:",black_bold)));
	            }

	            Table10.getDefaultCell().setBorder(Rectangle.BOX);
	            Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10.addCell(new Phrase(new Chunk(crdr_inv_no,black_bold)));
	            
	            float[] ContactAddrWidths12_1 = {0.80F,0.10F,0.50F,0.40F};
	   	     	PdfPTable Table10_1 = new PdfPTable(ContactAddrWidths12_1);
	            Table10_1.setWidthPercentage(100);
	            Table10_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table10_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.addCell(new Phrase(new Chunk("",small_black_normal)));

	            Table10_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.addCell(new Phrase(new Chunk("Invoice Ref:",black_bold)));

	            Table10_1.getDefaultCell().setBorder(Rectangle.BOX);
	            Table10_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            Table10_1.addCell(new Phrase(new Chunk(sel_inv_no,black_bold)));
	            
	            float[] ContactAddrWidths13 = {0.08F,0.25F,0.50F,0.25f,0.35f,0.30f,0.30f,0.30F};
	   	     	PdfPTable Table11 = new PdfPTable(ContactAddrWidths13);
	            Table11.setWidthPercentage(100);
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Sr.No",small_black_bold)));

	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Trade Date",small_black_bold)));

	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Deal No.",small_black_bold)));
	            
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Item",small_black_bold)));
	            
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Index",small_black_bold)));
	            
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Trade Term",small_black_bold)));
	            
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Attachment Reference",small_black_bold)));

	            /*Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Currency",small_black_bold)));

	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Quantity",small_black_bold)));

	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Rate (BUY)",small_black_bold)));
	            
	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Rate (SELL)",small_black_bold)));*/

	            Table11.getDefaultCell().setBorder(Rectangle.BOX);
	            Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            Table11.addCell(new Phrase(new Chunk("Amount (USD)",small_black_bold)));

	            float[] ContactAddrWidths20 = {0.08F,0.25F,0.50F,0.25f,0.35f,0.30f,0.30f,0.30F};
	   	     	PdfPTable Table18 = new PdfPTable(ContactAddrWidths20);
	   	     	
	   	     	int k=0;
	   	     	for(int i=0; i<VDEAL_MAPPING.size(); i++)
				{
	   	     		k+=1;
	   	     		Table18.setWidthPercentage(100);
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table18.addCell(new Phrase(new Chunk(""+k,small_black_normal)));
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table18.addCell(new Phrase(new Chunk(""+VTRADE_DT.elementAt(i),small_black_normal)));
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table18.addCell(new Phrase(new Chunk(""+VDEAL_MAPPING.elementAt(i)+" ("+VCONT_REF.elementAt(i)+")",small_black_normal)));
		            
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table18.addCell(new Phrase(new Chunk(""+VINSTRUMENT_TYPE.elementAt(i),small_black_normal)));
		            
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table18.addCell(new Phrase(new Chunk(""+VCURVE_NM.elementAt(i),small_black_normal)));
		            
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table18.addCell(new Phrase(new Chunk(""+VINSTRUMENT_DURATION.elementAt(i),small_black_normal)));
		            
		            if (i == 0)
		            {
		                PdfPCell attCell = new PdfPCell(new Phrase("Att 1", small_black_normal));
		                attCell.setBorder(Rectangle.BOX);
		                attCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		                attCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		                attCell.setRowspan(VDEAL_MAPPING.size());
		                Table18.addCell(attCell);
		            }
		            /*Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            Table18.addCell(new Phrase(new Chunk("USD",small_black_normal)));
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            Table18.addCell(new Phrase(new Chunk(""+VBOOKED_MMBTU.elementAt(i)+" "+VQTY_UNIT.elementAt(i),small_black_normal)));
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            Table18.addCell(new Phrase(new Chunk(""+VBUY_RATE.elementAt(i),small_black_normal)));
		            
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            Table18.addCell(new Phrase(new Chunk(""+VSELL_RATE.elementAt(i),small_black_normal)));*/
		
		            Table18.getDefaultCell().setBorder(Rectangle.BOX);
		            Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            Table18.addCell(new Phrase(new Chunk(""+VINVOICE_AMT.elementAt(i),small_black_normal)));
				}
	   	     	
		   	    Table18.getDefaultCell().setBorder(Rectangle.LEFT | Rectangle.BOTTOM| Rectangle.TOP);
		   	    Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		   	    Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		   	    Table18.getDefaultCell().setColspan(7);
		   	    Table18.addCell(new Phrase(new Chunk("Total Invoice Amount (USD)", small_black_normal)));
		
		   	    Table18.getDefaultCell().setBorder(Rectangle.BOX);
		   	    Table18.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		   	    Table18.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		   	    Table18.addCell(new Phrase(new Chunk(total_inv_amt, small_black_normal)));


	            float[] ContactAddrWidths21 = {0.100F};
	   	     	PdfPTable Table19 = new PdfPTable(ContactAddrWidths21);
	   	     	Table19.setWidthPercentage(100);
	   	     	Table19.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	Table19.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	Table19.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	     	Table19.addCell(new Phrase(new Chunk(crdr_remark,small_black_normal)));

		     	//document.add(LogoTable);
				//document.add(HlplLogoTable);
				//document.add(Table);
				document.add(mainTable);
				document.add(Table2);
				document.add(new Paragraph("  "));
				document.add(Table3);
				document.add(Table4);
				document.add(Table5);
				document.add(Table6);
				document.add(Table7);
				document.add(new Paragraph("  "));
				document.add(new Paragraph("  "));
				document.add(Table8);
				document.add(Table9);
				if(invoice_type.endsWith("R"))
				{
					document.add(Table9_1);
				}
				document.add(Table10);
				document.add(Table10_1);
				document.add(new Paragraph("  "));
				document.add(Table11);
				document.add(Table18);
				document.add(new Paragraph("  "));
				document.add(Table19);
				document.add(new Paragraph("  "));
				document.add(new Paragraph("  "));
				
				if(invoice_type.endsWith("I"))
		     	{
			     	float[] ContactAddrWidths23 = {0.100F};
		   	     	PdfPTable Table21 = new PdfPTable(ContactAddrWidths21);
		   	     	Table21.setWidthPercentage(100);
		   	     	Table21.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		   	     	Table21.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		   	  		Table21.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		   	  		Table21.addCell(new Phrase(new Chunk("For "+company_nm,black_bold)));
		   	  		
		   	  		// create a signature form field
		   	     	PdfPTable BillingFieldsInfoTable81 = new PdfPTable(1);
		   	     	BillingFieldsInfoTable81.setWidthPercentage(20);
		   	     	BillingFieldsInfoTable81.setHorizontalAlignment(Element.ALIGN_LEFT);
		   	     	BillingFieldsInfoTable81.getDefaultCell().setBorder(Rectangle.BOX);
		   	     	BillingFieldsInfoTable81.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		   	     	BillingFieldsInfoTable81.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		        
		   	     	PdfFormField field = PdfFormField.createSignature(writer);
		   	     	field.setFieldName(SIGNAME);
		   	     	// set the widget properties
		   	     	field.setPage();
		   	     	field.setWidget(new Rectangle(72, 732, 144, 780), PdfAnnotation.HIGHLIGHT_NONE);
		   	     	field.setFlags(PdfAnnotation.FLAGS_PRINT);
		   	     	writer.addAnnotation(field);
		         
		   	     	PdfPCell sigCell = new PdfPCell();
		   	     	FieldPositioningEvents events = new FieldPositioningEvents(writer, field);
		   	     	sigCell.setCellEvent(events);
		   	     	sigCell.setFixedHeight(50f);
		   	     	BillingFieldsInfoTable81.addCell(sigCell);
		
		   	     	float[] ContactAddrWidths24 = {0.100F};
			     	PdfPTable Table22 = new PdfPTable(ContactAddrWidths24);
		
			     	Table22.setWidthPercentage(100);
			     	Table22.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			     	Table22.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			     	Table22.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
			     	Table22.addCell(new Phrase(new Chunk("Authorised Signatory",black_bold)));
			     	document.add(Table21);
					document.add(BillingFieldsInfoTable81);
					document.add(Table22);
		     	}
				if(invoice_type.equals("R"))
	            {
					document.add(new Paragraph("  "));
					document.add(new Paragraph("  "));
					float[] footer = {0.100f};
			     	PdfPTable footer_tab = new PdfPTable(footer);
			     	footer_tab.setWidthPercentage(100);
			     	footer_tab.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				   	footer_tab.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				   	footer_tab.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
				   	footer_tab.addCell(new Phrase(new Chunk("*** This is Computer Generated Report and No Signature Required ***",small_black_normal)));
		
				    document.add(footer_tab);
	            }
				
				//For Attachment 1
				Font big_black_bold = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD, BaseColor.BLACK);
				Font small_black_bold2 = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD, BaseColor.BLACK);
				
				document.setPageSize(pageSize1);
	            document.newPage();
	            

	            float[] att1_ContactAddrWidths1 = {0.80f,0.10F,0.20F,0.80F};
	   	     	PdfPTable att1_Table1 = new PdfPTable(att1_ContactAddrWidths1);
	            att1_Table1.setWidthPercentage(100);
	            att1_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.addCell(new Phrase(new Chunk("Registered Office: ",black_bold)));
	            
	            att1_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.addCell(new Phrase(new Chunk("",black_bold)));
	            
	            att1_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.addCell(new Phrase(new Chunk("To:",black_bold)));
	
	            att1_Table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table1.addCell(new Phrase(new Chunk("",black_bold)));
	
				float[] att1_ContactAddrWidths2 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable att1_Table2 = new PdfPTable(att1_ContactAddrWidths2);
	   	     	att1_Table2.setWidthPercentage(100);
	            att1_Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            	att1_Table2.addCell(new Phrase(new Chunk(company_nm,small_black_normal)));
	            
	            att1_Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table2.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table2.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            	att1_Table2.addCell(new Phrase(new Chunk(counterparty_nm,small_black_normal)));
	
	            float[] att1_ContactAddrWidths3 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable att1_Table3 = new PdfPTable(att1_ContactAddrWidths3);
	            att1_Table3.setWidthPercentage(100);
	            att1_Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            	att1_Table3.addCell(new Phrase(new Chunk(bu_plantAddress+","+bu_plantCity,small_black_normal)));
	            
	            att1_Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table3.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
	            att1_Table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table3.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            	att1_Table3.addCell(new Phrase(new Chunk(plantAddress+","+plantCity,small_black_normal)));
	
	            float[] att1_ContactAddrWidths4 = {0.80f,0.30F,0.80F};
	   	     	PdfPTable att1_Table4 = new PdfPTable(att1_ContactAddrWidths4);
	            att1_Table4.setWidthPercentage(100);
	            att1_Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            	att1_Table4.addCell(new Phrase(new Chunk(bu_plantState+" - "+bu_plantPin,small_black_normal)));
	
	            att1_Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	            att1_Table4.addCell(new Phrase(new Chunk("",small_black_normal)));
	            
	            att1_Table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	            att1_Table4.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            	att1_Table4.addCell(new Phrase(new Chunk(plantState+" - "+plantPin,small_black_normal)));
	            
	            String title_note="ATTACHMENT 1 - "+crdrdtl+" Detail";
	            
	            PdfPTable title_note_table = new PdfPTable(1);
	            title_note_table.setWidthPercentage(100);
	            title_note_table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            title_note_table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            title_note_table.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            title_note_table.addCell(new Phrase(new Chunk(title_note,big_black_bold)));
	            
	            float[] att1_ContactAddrWidths5 = {0.80F,0.10F,0.50F,0.40F};
	   	     	PdfPTable att1_Table5 = new PdfPTable(att1_ContactAddrWidths5);
	            att1_Table5.setWidthPercentage(100);
	            att1_Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.addCell(new Phrase(new Chunk(crdrdtl+" Date :",black_bold)));
	
	            att1_Table5.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table5.addCell(new Phrase(new Chunk(crdr_dt,black_bold)));
	
	            float[] att1_ContactAddrWidths6 = {0.80F,0.10F,0.50F,0.40F};
	   	     	PdfPTable att1_Table6 = new PdfPTable(att1_ContactAddrWidths6);
	            att1_Table6.setWidthPercentage(100);
	            att1_Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.addCell(new Phrase(new Chunk(crdrdtl+" Due Date :",black_bold)));
	
	            att1_Table6.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table6.addCell(new Phrase(new Chunk(crdr_due_dt,black_bold)));
	
	            float[] att1_ContactAddrWidths7 = {0.80F,0.10F,0.50F,0.40F};
	   	     	PdfPTable att1_Table7 = new PdfPTable(att1_ContactAddrWidths7);
	            att1_Table7.setWidthPercentage(100);
	            att1_Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk("",black_bold)));
	
	            att1_Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            if(invoice_type.equals("I"))
	            {
	            	att1_Table7.addCell(new Phrase(new Chunk(company_abbr+" "+crdrdtl+" Seq No:",black_bold)));
	            }
	            else
	            {
	            	att1_Table7.addCell(new Phrase(new Chunk(company_abbr+" "+invTp+" Seq No :",black_bold)));
	            }
	
	            att1_Table7.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk(crdr_inv_no,black_bold)));
	            
	            att1_Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk("",black_bold)));
	
	            att1_Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk("",small_black_normal)));
	
	            att1_Table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk("Invoice Ref :",black_bold)));
	
	            att1_Table7.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
	            att1_Table7.addCell(new Phrase(new Chunk(sel_inv_no,black_bold)));
	            
	            float[] att1_ContactAddrWidths8 = {0.10F,0.30F,0.30f,0.30f,0.25f,0.25f,0.35F,0.25F,0.30F,0.25F,0.30F,0.30F};
	   	     	PdfPTable att1_Table8 = new PdfPTable(att1_ContactAddrWidths8);
	            att1_Table8.setWidthPercentage(100);
	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.addCell(new Phrase(new Chunk("Sr.No",small_black_bold)));

	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.addCell(new Phrase(new Chunk("Instrument No",small_black_bold)));

//	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
//	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
//	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
//	            att1_Table8.addCell(new Phrase(new Chunk("Item",small_black_bold)));
	            
	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.addCell(new Phrase(new Chunk("Index",small_black_bold)));
	            
	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.addCell(new Phrase(new Chunk("Trade Term",small_black_bold)));

	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.addCell(new Phrase(new Chunk("Quantity Unit",small_black_bold)));
	            
	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.addCell(new Phrase(new Chunk("",small_black_bold)));

	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.addCell(new Phrase(new Chunk("Quantity",small_black_bold)));
	            
//	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
//	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
//	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
//	            att1_Table8.addCell(new Phrase(new Chunk("Currency",small_black_bold)));

	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.addCell(new Phrase(new Chunk("Rate (BUY)",small_black_bold)));
	            
	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.addCell(new Phrase(new Chunk("Amount (BUY)",small_black_bold)));
	            
	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.addCell(new Phrase(new Chunk("Rate (SELL)",small_black_bold)));
	            
	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.addCell(new Phrase(new Chunk("Amount (SELL)",small_black_bold)));

	            att1_Table8.getDefaultCell().setBorder(Rectangle.BOX);
	            att1_Table8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	            att1_Table8.addCell(new Phrase(new Chunk("Total Amount",small_black_bold)));
	            
	            float[] att1_ContactAddrWidths9 = {0.10F,0.30F,0.30f,0.30f,0.25f,0.25f,0.35F,0.25F,0.30F,0.25F,0.30F,0.30F};
	   	     	PdfPTable att1_Table9 = new PdfPTable(att1_ContactAddrWidths9);
	   	     	PdfPTable att1_Table9_1 = new PdfPTable(att1_ContactAddrWidths9);
	   	     	
	   	     	int l=0;
	   	     	for(int i=0; i<VDEAL_MAPPING.size(); i++)
				{
	   	     		l+=1;
	   	     		att1_Table9.setWidthPercentage(100);
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.addCell(new Phrase(new Chunk(""+l,small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.addCell(new Phrase(new Chunk(""+VDEAL_MAPPING.elementAt(i),small_black_normal)));
		
//		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
//		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
//		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
//		            att1_Table9.addCell(new Phrase(new Chunk(""+VINSTRUMENT_TYPE.elementAt(i),small_black_normal)));
		            
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.addCell(new Phrase(new Chunk(""+VCURVE_NM.elementAt(i),small_black_normal)));
		            
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.addCell(new Phrase(new Chunk(""+VINSTRUMENT_DURATION.elementAt(i),small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.addCell(new Phrase(new Chunk(""+VQTY_UNIT.elementAt(i),small_black_normal)));
		            
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		            att1_Table9.addCell(new Phrase(new Chunk("(B-A)",small_black_normal)));
		            
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(""+VBOOKED_MMBTU.elementAt(i),small_black_bold)));
		            
//		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
//		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
//		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
//		            att1_Table9.addCell(new Phrase(new Chunk("USD",small_black_normal)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(""+VBUY_RATE.elementAt(i),small_black_bold)));
		            
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(""+VBUY_AMT.elementAt(i),small_black_bold)));
		            
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(""+VSELL_RATE.elementAt(i),small_black_bold)));
		            
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(""+VSELL_AMT.elementAt(i),small_black_bold)));
		
		            att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		            att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(new Phrase(new Chunk(""+VINVOICE_AMT.elementAt(i),small_black_bold)));
		            
		            PdfPCell cell;

		            cell = new PdfPCell(new Phrase("Invoiced Value (A)", small_black_normal));
		            cell.setColspan(6);  // spans SrNo to Quantity Unit
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(cell);

		            cell = new PdfPCell(new Phrase(""+VMAIN_BOOKED_MMBTU.elementAt(i), small_black_normal));
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(cell);
		            
//		            cell = new PdfPCell(new Phrase("USD", small_black_normal));
//		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
//		            att1_Table9.addCell(cell);

		            cell = new PdfPCell(new Phrase(""+VMAIN_BUY_RATE.elementAt(i), small_black_normal));
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(cell);

		            cell = new PdfPCell(new Phrase(""+VMAIN_BUY_AMT.elementAt(i), small_black_normal));
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(cell);

		            cell = new PdfPCell(new Phrase(""+VMAIN_SELL_RATE.elementAt(i), small_black_normal));
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(cell);

		            cell = new PdfPCell(new Phrase(""+VMAIN_SELL_AMT.elementAt(i), small_black_normal));
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(cell);

		            cell = new PdfPCell(new Phrase("", small_black_normal));
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setRowspan(2);
		            att1_Table9.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("Revised Value (B)", small_black_normal));
		            cell.setColspan(6);
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(cell);

		            cell = new PdfPCell(new Phrase(""+VNEW_QTY.elementAt(i), small_black_normal));
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(cell);
		            
//		            cell = new PdfPCell(new Phrase("USD", small_black_normal));
//		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
//		            att1_Table9.addCell(cell);

		            cell = new PdfPCell(new Phrase(""+VNEW_BUY_RATE.elementAt(i), small_black_normal));
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(cell);

		            cell = new PdfPCell(new Phrase(""+VNEW_BUY_AMT.elementAt(i), small_black_normal));
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(cell);

		            cell = new PdfPCell(new Phrase(""+VNEW_SELL_RATE.elementAt(i), small_black_normal));
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(cell);

		            cell = new PdfPCell(new Phrase(""+VNEW_SELL_AMT.elementAt(i), small_black_normal));
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            att1_Table9.addCell(cell);

		            //cell = new PdfPCell(new Phrase(""+VNEW_TOTAL_AMT.elementAt(i), small_black_normal));
		            //cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            //att1_Table9.addCell(cell);
				}
	   	     	
		   	    att1_Table9.getDefaultCell().setBorder(Rectangle.LEFT | Rectangle.BOTTOM| Rectangle.TOP);
		   	    att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		   	    att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		   	    att1_Table9.getDefaultCell().setColspan(11);
		   	    att1_Table9.addCell(new Phrase(new Chunk("Total Invoice Amount (USD)", small_black_bold)));
		
		   	    att1_Table9.getDefaultCell().setBorder(Rectangle.BOX);
		   	    att1_Table9.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		   	    att1_Table9.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		   	    att1_Table9.addCell(new Phrase(new Chunk(attach_total_inv_amt, small_black_bold)));
		   	    
		   	    float[] att1_ContactAddrWidths10 = {0.30F,0.75F};
	   	     	PdfPTable att1_Table10 = new PdfPTable(att1_ContactAddrWidths10);
	   	     	att1_Table10.setWidthPercentage(100);
	   	     	att1_Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	     	att1_Table10.addCell(new Phrase(new Chunk("Reason for "+invdtl+" "+crdrdtl+" : ",small_black_bold)));
	   	     	
	   	     	att1_Table10.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	att1_Table10.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	att1_Table10.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	     	att1_Table10.addCell(new Phrase(new Chunk(reason,small_black_normal)));
	   	     	
	   	     	float[] att1_ContactAddrWidths11 = {0.07F,0.93F};
	   	     	PdfPTable att1_Table11 = new PdfPTable(att1_ContactAddrWidths11);
	   	     	att1_Table11.setWidthPercentage(100);
	   	     	att1_Table11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	att1_Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	att1_Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	     	att1_Table11.addCell(new Phrase(new Chunk("Note : ",small_black_bold)));
	   	     	
	   	     	att1_Table11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	   	     	att1_Table11.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	   	     	att1_Table11.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	   	     	att1_Table11.addCell(new Phrase(new Chunk("Negative(-) Value indicate Credit and Postive(+) Value indicate Debit.",small_black_normal)));
				
	            document.add(LogoTable);
	            document.add(att1_Table1);  
	            document.add(att1_Table2);  
	            document.add(att1_Table3);  
	            document.add(att1_Table4);
	            document.add(new Paragraph("              "));
	            document.add(title_note_table);
	            document.add(new Paragraph("              "));
	            document.add(att1_Table5);  
	            document.add(att1_Table6);  
	            document.add(att1_Table7);  
	            document.add(new Paragraph("              "));
	            document.add(att1_Table8);
	            document.add(att1_Table9);
	            document.add(new Paragraph("              "));
	            document.add(att1_Table10);
	            document.add(att1_Table11);
	            
	            document.close();
	            
	            File isPDFexist = new File(path);
				if(isPDFexist.exists())
				{
					String invoice_title="";
					int update_flag=0;
					int pdf_entry=0;
					
					int cont=0;
					queryString="UPDATE FMS_DERV_INVOICE_MST SET PDF_INV_DTL=? ";
						if(print_pdf_type.equals("O"))
						{
							queryString+= ",PRINT_BY_ORI=?,PRINT_DT_ORI=SYSDATE ";
						}
						else if(print_pdf_type.equals("T"))
						{
							queryString+= ",PRINT_BY_TRI=?,PRINT_DT_TRI=SYSDATE ";
						}
						else if(print_pdf_type.equals("D"))
						{
							queryString+= ",PRINT_BY_DUP=?,PRINT_DT_DUP=SYSDATE ";
						}
						queryString+= "WHERE COMPANY_CD=? AND FINANCIAL_YEAR=? "
							+ "AND INVOICE_SEQ=? AND BU_STATE_TIN=? AND INV_FLAG=? "
							+ "AND INVOICE_NO=? AND INV_TYPE=? ";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(++cont, print_pdf_type);
					if(print_pdf_type.equals("O"))
					{
						stmt.setString(++cont, emp_cd);
					}
					else if(print_pdf_type.equals("T"))
					{
						stmt.setString(++cont, emp_cd);
					}
					else if(print_pdf_type.equals("D"))
					{
						stmt.setString(++cont, emp_cd);
					}
					stmt.setString(++cont, comp_cd);
					stmt.setString(++cont, financial_year);
					stmt.setString(++cont, inv_seq);
					stmt.setString(++cont, bu_state_tin);
					stmt.setString(++cont, crdr_type);
					stmt.setString(++cont, crdr_inv_no);
					stmt.setString(++cont, invoice_type);
					update_flag=stmt.executeUpdate();
					stmt.close();
					
					int count=0;
			        queryString1="SELECT COUNT(*) "
			        		+ "FROM FMS_DERV_INV_FILE_DTL "
			        		+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
			        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE=? "
			        		+ "AND INV_TYPE=?";
			        stmt1=conn.prepareStatement(queryString1);
			        stmt1.setString(1, comp_cd);
			        stmt1.setString(2, bu_state_tin);
			        stmt1.setString(3, inv_seq);
			        stmt1.setString(4, financial_year);
			        stmt1.setString(5, print_pdf_type);
			        stmt1.setString(6, invoice_type);
			        rset1=stmt1.executeQuery();
			        if(rset1.next())
			        {
			        	count=rset1.getInt(1);
			        }
			        rset1.close();
			        stmt1.close();
			        
			        if(count > 0)
			        {
			        	queryString1="UPDATE FMS_DERV_INV_FILE_DTL SET FILE_NAME=?,MODIFY_BY=?,MODIFY_DT=SYSDATE "
			        			+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
				        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE=? AND INV_TYPE=?";
			        	stmt1=conn.prepareStatement(queryString1);
			        	stmt1.setString(1, file_nm);
			        	stmt1.setString(2, emp_cd);
			        	stmt1.setString(3, comp_cd);
			 	        stmt1.setString(4, bu_state_tin);
			 	        stmt1.setString(5, inv_seq);
			 	        stmt1.setString(6, financial_year);
			 	        stmt1.setString(7, print_pdf_type);
			 	        stmt1.setString(8, invoice_type);
			 	        pdf_entry=stmt1.executeUpdate();
			        	
			        	stmt1.close();
			        }
			        else
			        {
			        	queryString1="INSERT INTO FMS_DERV_INV_FILE_DTL(COMPANY_CD,BU_STATE_TIN,INVOICE_SEQ,FINANCIAL_YEAR,PDF_TYPE,"
			        			+ "FILE_NAME,ENT_BY,ENT_DT,INV_TYPE) "
			        			+ "VALUES(?,?,?,?,?,"
			        			+ "?,?,SYSDATE,?)";
			        	stmt1=conn.prepareStatement(queryString1);
			        	stmt1.setString(1, comp_cd);
			 	        stmt1.setString(2, bu_state_tin);
			 	        stmt1.setString(3, inv_seq);
			 	        stmt1.setString(4, financial_year);
			 	        stmt1.setString(5, print_pdf_type);
			 	        stmt1.setString(6, file_nm);
			        	stmt1.setString(7, emp_cd);
			        	stmt1.setString(8, invoice_type);
			        	pdf_entry=stmt1.executeUpdate();
			        	
			        	stmt1.close();
			        }
			        
			        if(pdf_entry == 0 || update_flag == 0)
			        {
			        	conn.rollback();
			        	deletePdfFile(path);
			        	msg="Failed! - "+invdtl+" "+crdrdtl+" for "+counterparty_abbr+" PDF for "+crdr_inv_no+" Generation Failed!";
			        	msg_type="E";
			        }
			        else
			        {
			        	conn.commit();
			        	msg = "Successful! - "+invdtl+" "+crdrdtl+" for "+counterparty_abbr+" PDF "+file_nm+" for "+crdr_inv_no+" Generated Successfully!";
			        	msg_type="S";
			        }
				}
				else
				{
					msg="Failed! - "+invdtl+" "+crdrdtl+" for "+counterparty_abbr+" PDF for "+crdr_inv_no+" Generation Failed!";
					msg_type="E";
				}
			}
		}
		catch(Exception e)
		{
			conn.rollback();
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
			
			document.close();
			deletePdfFile(path);
			
			msg="Error in Exception! - "+invdtl+" for "+counterparty_abbr+" PDF Generation Failed!";
			msg_type="E";	
		}
		finally
		{
			document.close();
		}
		
		try
		{
			new com.etrm.fms.util.InfoLogger().InsertInfoLogger(emp_cd, comp_cd,emp_nm, ip, form_id, form_nm,mod_cd,mod_nm, "", "", msg);  	
		}
		catch(Exception infoLogger)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, infoLogger);
		}
	}
	
	public void getDervInvoiceDetailCrDr()
	{
		String function_nm="getDervInvoiceDetailCrDr()";
		try
		{
			queryString="SELECT INVOICE_SEQ,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),"
					+ "TO_CHAR(DUE_DT,'DD/MM/YYYY'),ALLOC_QTY,SALE_PRICE,SALE_PRICE_UNIT,SALE_AMT,BUY_PRICE,BUY_PRICE_UNIT,BUY_AMT,"
					+ "INVOICE_RAISED_IN,INVOICE_AMT,NET_PAYABLE_AMT,"
					+ "REMARK_1,REMARK_2,FINANCIAL_YEAR,TO_CHAR(PERIOD_START_DT,'DD/MM/YYYY'),TO_CHAR(PERIOD_END_DT,'DD/MM/YYYY'),INVOICE_REF_NO,CHECKED_FLAG,"
					+ "INSTRUMENT_NO,AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,CONTRACT_TYPE,CRITERIA,INV_FLAG,REF_NO,INV_TYPE,INVOICE_ID_SEQ,INVOICE_NO "
					+ "FROM FMS_DERV_INVOICE_MST "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND INVOICE_NO=? AND INV_FLAG IN ('CR','DR')";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, crdr_inv_no);
			rset=stmt.executeQuery();
			while(rset.next())
			{
				crdr_seq=rset.getString(1)==null?"":rset.getString(1);
				crdr_dt=rset.getString(3)==null?"":rset.getString(3);
				crdr_due_dt=rset.getString(4)==null?"":rset.getString(4);
				double alloc_qty=rset.getDouble(5);
				String sell_price=rset.getString(6)==null?"":rset.getString(6);
				String sell_price_unit=rset.getString(7)==null?"":rset.getString(7);
				String sell_amt=nf.format(rset.getDouble(8));
				String buy_price=rset.getString(9)==null?"":rset.getString(9);
				String buy_price_unit=rset.getString(10)==null?"":rset.getString(10);
				String buy_amt=nf.format(rset.getDouble(11));
				String inv_raised_in=rset.getString(12)==null?"":rset.getString(12);
				String invoice_amt=rset.getString(13)==null?"":rset.getString(13);
				String net_payable_amt=rset.getString(14)==null?"":rset.getString(14);
				crdr_remark=rset.getString(15)==null?"":rset.getString(15);
				String financial_year=rset.getString(17)==null?"":rset.getString(17);
				String tmp_period_start_dt=rset.getString(18)==null?"":rset.getString(18);
				String tmp_period_end_dt=rset.getString(19)==null?"":rset.getString(19);
				
				String instrument_no = rset.getString(22)==null?"":rset.getString(22);
				String agmt_no = rset.getString(23)==null?"":rset.getString(23);
				String agmt_rev_no = rset.getString(24)==null?"":rset.getString(24);
				String cont_no = rset.getString(25)==null?"":rset.getString(25);
				String cont_rev_no = rset.getString(26)==null?"":rset.getString(26);
				String cont_type = rset.getString(27)==null?"":rset.getString(27);
				criteri_formula = rset.getString(28)==null?"":rset.getString(28);
				crdr_type = rset.getString(29)==null?"":rset.getString(29);
				sel_inv_no = rset.getString(30)==null?"":rset.getString(30);
				inv_ref = rset.getString(20)==null?"":rset.getString(20);
				if(!invoice_amt.equals(""))
				{
					temp_tot_inv_amt+=Double.parseDouble(invoice_amt);
				}
				invoice_type = rset.getString(31)==null?"":rset.getString(31);
				invoice_id_seq=rset.getString(32)==null?"":rset.getString(32);
				invoice_no=rset.getString(33)==null?"":rset.getString(33);
				String deal_no=utilBean.NewDealMappingId(comp_cd, counterparty_cd, agmt_no, agmt_rev_no, cont_no, cont_rev_no, cont_type, instrument_no);
				
				VAGMT_NO.add(agmt_no);
				VAGMT_REV.add(agmt_rev_no);
				VCONT_TYPE.add(cont_type);
				VCONT_NO.add(cont_no);
				VCONT_REV.add(cont_rev_no);
				VINSTRUMENT_NO.add(instrument_no);
				VBOOKED_MMBTU.add(nf.format(alloc_qty));
				VPERIOD_START_DT.add(tmp_period_start_dt);
				VPERIOD_END_DT.add(tmp_period_end_dt);
			  	
			  	int cnt2=0;
			  	String cont_ref="";
			  	String trade_dt="";
			  	String instrument_volume_unit="";
			  	String buySell="";
			  	String instrument_type="";
			  	String curve_nm="";
			  	String instru_duration="";
			  	String instru_qty="";
			  	String fixed_price="";
			  	queryString2="SELECT A.COMPANY_CD,A.COUNTERPARTY_CD,A.AGMT_TYPE,A.AGMT_NO,A.AGMT_REV,A.CONTRACT_TYPE,A.CONT_NO,A.CONT_REV,A.CONT_NAME,A.CONT_REF_NO,"
						+ "B.INSTRUMENT_NO,B.INSTRUMENT_TYPE,B.BUY_SELL,B.STATUS,B.QTY,B.QTY_UNIT,B.RATE,B.RATE_UNIT,"
						+ "B.PRODUCT_NM,B.CURVE_NM,B.PROJ_METHOD,TO_CHAR(B.CONT_DD_MM_YR,'DD/MM/YYYY'),"
						+ "TO_CHAR(B.PRICE_START_DT,'DD/MM/YYYY'),TO_CHAR(B.PRICE_END_DT,'DD/MM/YYYY'),B.CONV_FACTOR,TO_CHAR(A.TRADE_DT,'DD/MM/YYYY') "
						+ "FROM FMS_DERV_CONT_MST A,FMS_DERV_INSTRUMENT_MST B "
						+ "WHERE A.COMPANY_CD=? AND A.COUNTERPARTY_CD=? AND A.AGMT_NO=? AND A.CONT_NO=? AND A.CONTRACT_TYPE=? "
						+ "AND B.STATUS='Y' AND B.INSTRUMENT_NO=? "
						+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_TYPE=B.AGMT_TYPE AND A.AGMT_NO=B.AGMT_NO "
						+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE AND A.CONT_NO=B.CONT_NO";
			  	stmt2 = conn.prepareStatement(queryString2);
				stmt2.setString(++cnt2, comp_cd);
				stmt2.setString(++cnt2, counterparty_cd);
				stmt2.setString(++cnt2, agmt_no);
				stmt2.setString(++cnt2, cont_no);
				stmt2.setString(++cnt2, cont_type);
				//stmt2.setString(++cnt2, buy_sell);
				stmt2.setString(++cnt2, instrument_no);
				rset2=stmt2.executeQuery();
				while(rset2.next())
				{
					instru_qty = rset2.getString(15)==null?"":rset2.getString(15);
					fixed_price = rset2.getString(17)==null?"":rset2.getString(17);
					cont_ref=rset2.getString(10)==null?"":rset2.getString(10);
					trade_dt=rset2.getString(26)==null?"":rset2.getString(26);
					String instrument_volume_unit_cd = rset2.getString(16)==null?"":rset2.getString(16);
					instrument_volume_unit = utilBean.getEnergyUnitNm(conn, instrument_volume_unit_cd);
					buySell = rset2.getString(13)==null?"":rset2.getString(13);
					instrument_type = rset2.getString(12)==null?"":rset2.getString(12);
					curve_nm = rset2.getString(20)==null?"":rset2.getString(20);
					String start_dt = rset2.getString(23)==null?"":rset2.getString(23);
					String end_dt = rset2.getString(24)==null?"":rset2.getString(24);
					instru_duration = start_dt+"-"+end_dt;
				}
				rset2.close();
				stmt2.close();
				VBUY_SELL.add(buySell);
				VTRADE_DT.add(trade_dt);
				VDEAL_MAPPING.add(deal_no);
				VCONT_REF.add(cont_ref);
				VINSTRUMENT_TYPE.add(instrument_type);
				VCURVE_NM.add(curve_nm);
				VINSTRUMENT_DURATION.add(instru_duration);
				VQTY_UNIT.add(instrument_volume_unit);
				
				if(!sell_price.equals(""))
				{
					if(buySell.equals("BUY"))
					{
						BigDecimal float_val=new BigDecimal(sell_price);
						VSELL_RATE.add(df3.format(float_val));
					}
					else
					{
						VSELL_RATE.add(nf2.format(Double.parseDouble(sell_price)));
					}
				}
				else
				{
					VSELL_RATE.add("");
				}
			  	VSELL_AMT.add(sell_amt);
			  	
			  	if(!buy_price.equals(""))
			  	{
				  	if(buySell.equals("SELL"))
					{
				  		BigDecimal float_val=new BigDecimal(buy_price);
				  		VBUY_RATE.add(df3.format(float_val));
					}
				  	else
				  	{
				  		VBUY_RATE.add(nf2.format(Double.parseDouble(buy_price)));
				  	}
			  	}
			  	else
			  	{
			  		VBUY_RATE.add("");
			  	}
			  	
			  	VBUY_AMT.add(buy_amt);
			  	if(!invoice_amt.equals(""))
			  	{
			  		VINVOICE_AMT.add(nf.format(Double.parseDouble(invoice_amt)));
			  	}
			  	else
			  	{
			  		VINVOICE_AMT.add("");
			  	}
			  	
			  	IS_CRDR_SUBMITTED.add("Y");
			}
			
			HashMap bu_plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "B", comp_cd, bu_plant_seq);
			bu_plantAddress=""+bu_plant_detail.get("plant_address");
			bu_plantCity=""+bu_plant_detail.get("plant_city");
			bu_plantState=""+bu_plant_detail.get("plant_state");
			bu_plantPin=""+bu_plant_detail.get("plant_pin");
			bu_plantNm=""+bu_plant_detail.get("plant_name");
			
			HashMap plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "T", counterparty_cd, plant_seq);
			plantAddress=""+plant_detail.get("plant_address");
			plantCity=""+plant_detail.get("plant_city");
			plantState=""+plant_detail.get("plant_state");
			plantPin=""+plant_detail.get("plant_pin");
			
			attach_total_inv_amt = nf.format(temp_tot_inv_amt);
			if(temp_tot_inv_amt<0)
			{
				temp_tot_inv_amt=temp_tot_inv_amt*(-1);
			}
			total_inv_amt=nf.format(temp_tot_inv_amt);
			
			tax_info=getCounterpartyPlantTaxInfo(comp_cd, "T", counterparty_cd, plant_seq);
			tax_info=tax_info.replaceAll("\n", "<br>");
			
			bu_tax_info=getCounterpartyPlantTaxInfo(comp_cd, "B", comp_cd, bu_plant_seq);
			bu_tax_info=bu_tax_info.replaceAll("\n", "<br>");
			
			reason="Change in ";
			if(!criteri_formula.equals(""))
			{
				String[] split_criteri_formula = criteri_formula.split("#");
				for(int i=0; i<split_criteri_formula.length; i++)
				{
					if(i!=0)
					{
						if((i+1) == split_criteri_formula.length)
						{
							reason+=" and ";
						}
						else
						{
							reason+=", ";
						}
					}
					
					if(split_criteri_formula[i].toString().equals("QTY"))
					{
						reason+="Quantity";
					}
					else if(split_criteri_formula[i].toString().equals("FIXEDPRICE"))
					{
						reason+="Fixed Price";
					}
					else if(split_criteri_formula[i].toString().equals("FLOATPRICE"))
					{
						reason+="Float Price";
					}
				}
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getSelectedInvInstrumentDtl()
	{
		String function_nm="getSelectedInvInstrumentDtl()";
		try
		{
			for(int i=0; i<VDEAL_MAPPING.size(); i++)
			{
				queryString="SELECT INVOICE_SEQ,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),"
						+ "TO_CHAR(DUE_DT,'DD/MM/YYYY'),ALLOC_QTY,SALE_PRICE,SALE_PRICE_UNIT,SALE_AMT,BUY_PRICE,BUY_PRICE_UNIT,BUY_AMT,"
						+ "INVOICE_RAISED_IN,INVOICE_AMT,NET_PAYABLE_AMT,"
						+ "REMARK_1,REMARK_2,FINANCIAL_YEAR,TO_CHAR(PERIOD_START_DT,'DD/MM/YYYY'),TO_CHAR(PERIOD_END_DT,'DD/MM/YYYY'),INVOICE_REF_NO,CHECKED_FLAG,"
						+ "INSTRUMENT_NO,AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,CONTRACT_TYPE,INV_TYPE "
						+ "FROM FMS_DERV_INVOICE_MST "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
						+ "AND INVOICE_NO=? AND INV_FLAG='F' AND CONT_NO=? AND AGMT_NO=? AND CONTRACT_TYPE=? AND INSTRUMENT_NO=?";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty_cd);
				stmt.setString(3, sel_inv_no);
				stmt.setString(4, ""+VCONT_NO.elementAt(i));
				stmt.setString(5, ""+VAGMT_NO.elementAt(i));
				stmt.setString(6, ""+VCONT_TYPE.elementAt(i));
				stmt.setString(7, ""+VINSTRUMENT_NO.elementAt(i));
				rset=stmt.executeQuery();
				while(rset.next())
				{
					invoice_seq=rset.getString(1)==null?"":rset.getString(1);
					String inv_no=rset.getString(2)==null?"":rset.getString(2);
					inv_dt=rset.getString(3)==null?"":rset.getString(3);
					inv_due_dt=rset.getString(4)==null?"":rset.getString(4);
					double alloc_qty=rset.getDouble(5);
					String sell_price=rset.getString(6)==null?"":rset.getString(6);
					String sell_price_unit=rset.getString(7)==null?"":rset.getString(7);
					double sell_amt=rset.getDouble(8);
					String buy_price=rset.getString(9)==null?"":rset.getString(9);
					String buy_price_unit=rset.getString(10)==null?"":rset.getString(10);
					double buy_amt=rset.getDouble(11);
					String inv_raised_in=rset.getString(12)==null?"":rset.getString(12);
					String invoice_amt=rset.getString(13)==null?"":rset.getString(13);
					String net_payable_amt=rset.getString(14)==null?"":rset.getString(14);
					String financial_year=rset.getString(17)==null?"":rset.getString(17);
					period_start_dt=rset.getString(18)==null?"":rset.getString(18);
					period_end_dt=rset.getString(19)==null?"":rset.getString(19);
					//inv_ref=rset.getString(20)==null?"":rset.getString(20);
					chk_flg=rset.getString(21)==null?"":rset.getString(21);
					
					String instrument_no = rset.getString(22)==null?"":rset.getString(22);
					String agmt_no = rset.getString(23)==null?"":rset.getString(23);
					String agmt_rev_no = rset.getString(24)==null?"":rset.getString(24);
					String cont_no = rset.getString(25)==null?"":rset.getString(25);
					String cont_rev_no = rset.getString(26)==null?"":rset.getString(26);
					String cont_type = rset.getString(27)==null?"":rset.getString(27);
					invoice_type = rset.getString(28)==null?"":rset.getString(28);
					
					VPERIOD_START_DT.add(period_start_dt);
					VPERIOD_END_DT.add(period_end_dt);
					VCOUNTERPARTY_CD.add(counterparty_cd);
					VCOUNTERPARTY_NM.add(""+utilBean.getCounterpartyName(conn, counterparty_cd));
					VINVOICE_NO.add(inv_no);
					VMAIN_BOOKED_MMBTU.add(nf.format(alloc_qty));
				  	VCONT_START_DT.add(period_start_dt);
				  	VCONT_END_DT.add(period_end_dt);
				  	//VDEAL_PRICE_CURVE.add(financial_curve);
				  	
				  	int cnt2=0;
				  	String cont_ref="";
				  	String trade_dt="";
				  	String instrument_volume_unit="";
				  	String buySell="";
				  	String instrument_type="";
				  	String curve_nm="";
				  	String instru_duration="";
				  	queryString2="SELECT A.COMPANY_CD,A.COUNTERPARTY_CD,A.AGMT_TYPE,A.AGMT_NO,A.AGMT_REV,A.CONTRACT_TYPE,A.CONT_NO,A.CONT_REV,A.CONT_NAME,A.CONT_REF_NO,"
							+ "B.INSTRUMENT_NO,B.INSTRUMENT_TYPE,B.BUY_SELL,B.STATUS,B.QTY,B.QTY_UNIT,B.RATE,B.RATE_UNIT,"
							+ "B.PRODUCT_NM,B.CURVE_NM,B.PROJ_METHOD,TO_CHAR(B.CONT_DD_MM_YR,'DD/MM/YYYY'),"
							+ "TO_CHAR(B.PRICE_START_DT,'DD/MM/YYYY'),TO_CHAR(B.PRICE_END_DT,'DD/MM/YYYY'),B.CONV_FACTOR,TO_CHAR(A.TRADE_DT,'DD/MM/YYYY') "
							+ "FROM FMS_DERV_CONT_MST A,FMS_DERV_INSTRUMENT_MST B "
							+ "WHERE A.COMPANY_CD=? AND A.COUNTERPARTY_CD=? AND A.AGMT_NO=? AND A.CONT_NO=? AND A.CONTRACT_TYPE=? "
							+ "AND B.STATUS='Y' AND B.INSTRUMENT_NO=? "
							+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_TYPE=B.AGMT_TYPE AND A.AGMT_NO=B.AGMT_NO "
							+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE AND A.CONT_NO=B.CONT_NO";
				  	stmt2 = conn.prepareStatement(queryString2);
					stmt2.setString(++cnt2, comp_cd);
					stmt2.setString(++cnt2, counterparty_cd);
					stmt2.setString(++cnt2, agmt_no);
					stmt2.setString(++cnt2, cont_no);
					stmt2.setString(++cnt2, cont_type);
					//stmt2.setString(++cnt2, buy_sell);
					stmt2.setString(++cnt2, instrument_no);
					rset2=stmt2.executeQuery();
					while(rset2.next())
					{
						cont_ref=rset2.getString(10)==null?"":rset2.getString(10);
						trade_dt=rset2.getString(26)==null?"":rset2.getString(26);
						String instrument_volume_unit_cd = rset2.getString(16)==null?"":rset2.getString(16);
						instrument_volume_unit = utilBean.getEnergyUnitNm(conn, instrument_volume_unit_cd);
						buySell = rset2.getString(13)==null?"":rset2.getString(13);
						instrument_type = rset2.getString(12)==null?"":rset2.getString(12);
						curve_nm = rset2.getString(20)==null?"":rset2.getString(20);
						String start_dt = rset2.getString(23)==null?"":rset2.getString(23);
						String end_dt = rset2.getString(24)==null?"":rset2.getString(24);
						instru_duration = start_dt+"-"+end_dt;
					}
					rset2.close();
					stmt2.close();
					VCONT_REF.add(cont_ref);
					VTRADE_DT.add(trade_dt);
					VQTY_UNIT.add(instrument_volume_unit);
					VMAIN_BUY_SELL.add(buySell);
					
					if(buySell.equals("BUY"))
					{
						BigDecimal float_val=new BigDecimal(sell_price);
						VMAIN_SELL_RATE.add(df3.format(float_val));
					}
					else
					{
						VMAIN_SELL_RATE.add(nf2.format(Double.parseDouble(sell_price)));
					}
					
					if(Double.doubleToRawLongBits(sell_amt)<Double.doubleToRawLongBits(0))
					{
						sell_amt=(-1)*sell_amt;
					}
				  	VMAIN_SELL_AMT.add(nf.format(sell_amt));
				  	if(buySell.equals("SELL"))
					{
				  		BigDecimal float_val=new BigDecimal(buy_price);
				  		VMAIN_BUY_RATE.add(df3.format(float_val));
					}
				  	else
				  	{
				  		VMAIN_BUY_RATE.add(nf2.format(Double.parseDouble(buy_price)));
				  	}
				  	
				  	if(Double.doubleToRawLongBits(buy_amt)<Double.doubleToRawLongBits(0))
					{
				  		buy_amt=(-1)*buy_amt;
					}
				  	VMAIN_BUY_AMT.add(nf.format(buy_amt));
				  	VINSTRUMENT_TYPE.add(instrument_type);
				  	VCURVE_NM.add(curve_nm);
				  	VINSTRUMENT_DURATION.add(instru_duration);
				  	VMAIN_TOTAL_AMT.add(nf.format(sell_amt-buy_amt));
				
				}
				rset.close();
				stmt.close();
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getNewInvInstrumentDtl()
	{
		String function_nm="getNewInvInstrumentDtl()";
		try
		{
			for(int i=0; i<VDEAL_MAPPING.size(); i++)
			{
				queryString="SELECT INVOICE_AMT,BUY_AMT,BUY_PRICE,SALE_AMT,SALE_PRICE,ALLOC_QTY,"
						+ "INSTRUMENT_NO,AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,CONTRACT_TYPE "
						+ "FROM FMS_DERV_INV_CRDR_REF "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND FINANCIAL_YEAR=? AND BU_STATE_TIN=? "
						+ "AND INV_TYPE=? "
						+ "AND INVOICE_SEQ=? AND CONT_NO=? AND AGMT_NO=? AND CONTRACT_TYPE=? AND INSTRUMENT_NO=?";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty_cd);
				stmt.setString(3, financial_year);
				stmt.setString(4, bu_state_tin);
				stmt.setString(5, invoice_type);
				stmt.setString(6, crdr_seq);
				stmt.setString(7, ""+VCONT_NO.elementAt(i));
				stmt.setString(8, ""+VAGMT_NO.elementAt(i));
				stmt.setString(9, ""+VCONT_TYPE.elementAt(i));
				stmt.setString(10, ""+VINSTRUMENT_NO.elementAt(i));
				rset=stmt.executeQuery();
				while(rset.next())
				{
					String new_tot_amt = rset.getString(1)==null?"":rset.getString(1);
					String new_buy_amt = nf.format(rset.getDouble(2));
					String new_buy_price = rset.getString(3)==null?"":rset.getString(3);
					String new_sell_amt = nf.format(rset.getDouble(4));
					String new_sell_price = rset.getString(5)==null?"":rset.getString(5);
					String new_alloc_qty = nf.format(rset.getDouble(6));
					String instrument_no = rset.getString(7)==null?"":rset.getString(7);
					String agmt_no = rset.getString(8)==null?"":rset.getString(8);
					String agmt_rev_no = rset.getString(9)==null?"":rset.getString(9);
					String cont_no = rset.getString(10)==null?"":rset.getString(10);
					String cont_rev_no = rset.getString(11)==null?"":rset.getString(11);
					String cont_type = rset.getString(12)==null?"":rset.getString(12);
					
					int cnt2=0;
					String buySell="";
					queryString2="SELECT A.COMPANY_CD,A.COUNTERPARTY_CD,A.AGMT_TYPE,A.AGMT_NO,A.AGMT_REV,A.CONTRACT_TYPE,A.CONT_NO,A.CONT_REV,A.CONT_NAME,A.CONT_REF_NO,"
							+ "B.INSTRUMENT_NO,B.INSTRUMENT_TYPE,B.BUY_SELL,B.STATUS,B.QTY,B.QTY_UNIT,B.RATE,B.RATE_UNIT,"
							+ "B.PRODUCT_NM,B.CURVE_NM,B.PROJ_METHOD,TO_CHAR(B.CONT_DD_MM_YR,'DD/MM/YYYY'),"
							+ "TO_CHAR(B.PRICE_START_DT,'DD/MM/YYYY'),TO_CHAR(B.PRICE_END_DT,'DD/MM/YYYY'),B.CONV_FACTOR,TO_CHAR(A.TRADE_DT,'DD/MM/YYYY') "
							+ "FROM FMS_DERV_CONT_MST A,FMS_DERV_INSTRUMENT_MST B "
							+ "WHERE A.COMPANY_CD=? AND A.COUNTERPARTY_CD=? AND A.AGMT_NO=? AND A.CONT_NO=? AND A.CONTRACT_TYPE=? "
							+ "AND B.STATUS='Y' AND B.INSTRUMENT_NO=? "
							+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_TYPE=B.AGMT_TYPE AND A.AGMT_NO=B.AGMT_NO "
							+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE AND A.CONT_NO=B.CONT_NO";
				  	stmt2 = conn.prepareStatement(queryString2);
					stmt2.setString(++cnt2, comp_cd);
					stmt2.setString(++cnt2, counterparty_cd);
					stmt2.setString(++cnt2, agmt_no);
					stmt2.setString(++cnt2, cont_no);
					stmt2.setString(++cnt2, cont_type);
					stmt2.setString(++cnt2, instrument_no);
					rset2=stmt2.executeQuery();
					while(rset2.next())
					{
						buySell = rset2.getString(13)==null?"":rset2.getString(13);
					}
					rset2.close();
					stmt2.close();
					
					VNEW_QTY.add(new_alloc_qty);
					
					if(!new_sell_price.equals(""))
					{
						if(buySell.equals("BUY"))
						{
							BigDecimal float_val=new BigDecimal(new_sell_price);
							VNEW_SELL_RATE.add(df3.format(float_val));
						}
						else
						{
							VNEW_SELL_RATE.add(nf2.format(Double.parseDouble(new_sell_price)));
						}
					}
					else
					{
						VNEW_SELL_RATE.add("");
					}
				  	VNEW_SELL_AMT.add(new_sell_amt);
				  	
				  	if(!new_buy_price.equals(""))
				  	{
					  	if(buySell.equals("SELL"))
						{
					  		BigDecimal float_val=new BigDecimal(new_buy_price);
					  		VNEW_BUY_RATE.add(df3.format(float_val));
						}
					  	else
					  	{
					  		VNEW_BUY_RATE.add(nf2.format(Double.parseDouble(new_buy_price)));
					  	}
				  	}
				  	else
				  	{
				  		VNEW_BUY_RATE.add("");
				  	}
				  	
				  	VNEW_BUY_AMT.add(new_buy_amt);
				  	
				  	if(!new_tot_amt.equals(""))
				  	{
				  		VNEW_TOTAL_AMT.add(nf.format(Double.parseDouble(new_tot_amt)));
				  	}
				  	else
				  	{
				  		VNEW_TOTAL_AMT.add("");
				  	}
				}
				rset.close();
				stmt.close();
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void doClear()
	{
		VNEW_QTY.clear();
		VNEW_SELL_RATE.clear();
		VNEW_SELL_AMT.clear();
		VNEW_BUY_RATE.clear();
		VNEW_BUY_AMT.clear();
		VNEW_TOTAL_AMT.clear();
		VCONT_REF.clear();
		VTRADE_DT.clear();
		VQTY_UNIT.clear();
		VMAIN_BUY_SELL.clear();
		VMAIN_SELL_RATE.clear();
		VMAIN_SELL_AMT.clear();
		VMAIN_BUY_RATE.clear();
		VMAIN_BUY_AMT.clear();
		VINSTRUMENT_TYPE.clear();
		VCURVE_NM.clear();
		VINSTRUMENT_DURATION.clear();
		VMAIN_TOTAL_AMT.clear();
		VCONT_END_DT.clear();
		VCONT_START_DT.clear();
		VMAIN_BOOKED_MMBTU.clear();
		VINSTRUMENT_NO.clear();
		VALL_INSTRUMENT_NO.clear();
		VINVOICE_NO.clear();
		VCONT_REV.clear();
		VCONT_NO.clear();
		VCONT_TYPE.clear();
		VAGMT_REV.clear();
		VAGMT_NO.clear();
		VCOUNTERPARTY_NM.clear();
		VCOUNTERPARTY_CD.clear();
		VPERIOD_END_DT.clear();
		VPERIOD_START_DT.clear();
		IS_CRDR_SUBMITTED.clear();
		VINVOICE_AMT.clear();
		VBUY_AMT.clear();
		VBUY_RATE.clear();
		VSELL_AMT.clear();
		VSELL_RATE.clear();
		VDEAL_MAPPING.clear();
		VBUY_SELL.clear();
		VBOOKED_MMBTU.clear();
		
		invoice_type="";
		chk_flg="";
		inv_ref="";
		period_end_dt="";
		period_start_dt="";
		inv_due_dt="";
		inv_dt="";
		invoice_seq="";
		invoice_no="";
		invoice_id_seq="";
		invoice_type="";
		temp_tot_inv_amt=0;
		sel_inv_no="";
		crdr_type="";
		criteri_formula="";
		crdr_remark="";
		crdr_due_dt="";
		crdr_dt="";
		crdr_seq="";
	}
	

	String callFlag = "";
	public void setCallFlag(String callFlag) {this.callFlag = callFlag;}
	String comp_cd = "";
	public void setComp_cd(String comp_cd) {this.comp_cd = comp_cd;}
	String comp_nm = "";
	public void setComp_nm(String comp_nm) {this.comp_nm = comp_nm;}
	String comp_logo = "";
	public void setComp_logo(String comp_logo) {this.comp_logo = comp_logo;}

	String file_url = "";
	String file_nm = "";
	public String getFile_url() {return file_url;}
	public String getFile_nm() {return file_nm;}

	double temp_tot_inv_amt=0;
	
	String clearance = "";
	String counterparty_cd = "";
	String gx_counterparty_cd = "";
	String cont_no = "";
	String cont_rev_no = "";
	String agmt_no = "";
	String agmt_rev_no = "";
	String contract_type = "";
	String gas_dt="";
	String from_date = "";
	String to_date = "";
	String report_dt = "";
	String plant_seq = "";
	String bu_plant_seq = "";
	String gx_bu_plant_seq = "";
	String to_contact = "";
	String from_contact = "";
	String remark = "";
	String frq_type = "";
	String bu_state_tin = "";

	String inv_type = "";
	String inv_seq = "";
	String inv_no = "";
	String financial_year = "";
	String mapping_id = "";
	String period_start_dt="";
	String period_end_dt="";
	
	String is_print="";
	
	String print_pdf_type="";
	String invoice_type="";
	String trans_bu_seq="";
	
	String seq_no="";
	String seq_rev_no="";
	String gx="";
	String isReversal="";
	String emp_cd="";
	
	String cargo_no="";
	String instrument_no="";
	String boe_no="";
	String inv_flag="";
	String billing_cycle="";
	
	String form_id="";
	String form_nm="";
	String mod_cd="";
	String mod_nm="";
	
	String entity="";
	String countpty_name="";
	String contact_person_cd="";
	
	String tot_mmscm="";
	String tot_mmbtu="";
	String tot_obl_mcm="";
	String ask_nom_mcm="";
	String ask_obl_mcm="";
	String ask_nom_mmbtu="";
	String chk_oblig="";
	String chk_exp="";
	String tot_exp_mmscm="";
	String ask_exp_mmscm="";
	
	String truck_cd="";
	
	String eligibleLimit="";
	String totalPrevMonthBal="";
	String totalQty="";
	String totalQtySell="";
	String totalQtySettle="";
	String totalMonthOutstanding="";
	String year = "";
	String month = "";
	String comp_registered_addr = "";
	String month_name = "";
	String comp_cin_no = "";
	
	String truck_trans_cd="";
	
	String ori_inv_flag="";
	String exist_fin_yr="";
	String ori_inv_seq="";
	String ori_inv_no="";
	String cont_start_dt="";
	String cont_end_dt="";
	
	String sel_inv_no="";
	String crdr_type="";
	String crdr_inv_no="";
	String criteri_formula="";
	String crdr_dt="";
	String crdr_due_dt="";
	String crdr_remark="";
	String reason="";
	String crdr_seq="";
	String invoice_id_seq="";
	String invoice_no="";
	String total_inv_amt="";
	String attach_total_inv_amt="";
	String tax_info="";
	String bu_tax_info="";
	String plantAddress="";
	String plantCity="";
	String plantState="";
	String plantPin="";
	String plantNm="";
	String bu_plantAddress="";
	String bu_plantCity="";
	String bu_plantState="";
	String bu_plantPin="";
	String bu_plantNm="";
	String invoice_seq="";
	String inv_dt="";
	String inv_due_dt="";
	String inv_ref="";
	String chk_flg="";
	
	public void setYear(String year) {this.year = year;}
	public void setMonth(String month) {this.month = month;}
	public void setEligibleLimit(String eligibleLimit) {this.eligibleLimit = eligibleLimit;}
	public void setTotalPrevMonthBal(String totalPrevMonthBal) {this.totalPrevMonthBal = totalPrevMonthBal;}
	public void setTotalQty(String totalQty) {this.totalQty = totalQty;}
	public void setTotalQtySell(String totalQtySell) {this.totalQtySell = totalQtySell;}
	public void setTotalQtySettle(String totalQtySettle) {this.totalQtySettle = totalQtySettle;}
	public void setTotalMonthOutstanding(String totalMonthOutstanding) {this.totalMonthOutstanding = totalMonthOutstanding;}
	public void setComp_registered_addr(String comp_registered_addr) {this.comp_registered_addr = comp_registered_addr;}
	public void setMonth_name(String month_name) {this.month_name = month_name;}
	public void setComp_cin_no(String comp_cin_no) {this.comp_cin_no = comp_cin_no;}
	
	public void setClearance(String clearance) {this.clearance = clearance;}
	public void setCounterparty_cd(String counterparty_cd) {this.counterparty_cd = counterparty_cd;}
	public void setGx_counterparty_cd(String gx_counterparty_cd) {this.gx_counterparty_cd = gx_counterparty_cd;}
	public void setCont_no(String cont_no) {this.cont_no = cont_no;}
	public void setCont_rev_no(String cont_rev_no) {this.cont_rev_no = cont_rev_no;}
	public void setAgmt_no(String agmt_no) {this.agmt_no = agmt_no;}
	public void setAgmt_rev_no(String agmt_rev_no) {this.agmt_rev_no = agmt_rev_no;}
	public void setContract_type(String contract_type) {this.contract_type = contract_type;}
	public void setGas_dt(String gas_dt) {this.gas_dt = gas_dt;}
	public void setFrom_date(String from_date) {this.from_date = from_date;}
	public void setTo_date(String to_date) {this.to_date = to_date;}
	public void setReport_dt(String report_dt) {this.report_dt = report_dt;}
	public void setPlant_seq(String plant_seq) {this.plant_seq = plant_seq;}
	public void setBu_plant_seq(String bu_plant_seq) {this.bu_plant_seq = bu_plant_seq;}
	public void setGx_bu_plant_seq(String gx_bu_plant_seq) {this.gx_bu_plant_seq = gx_bu_plant_seq;}
	public void setTo_contact(String to_contact) {this.to_contact = to_contact;}
	public void setFrom_contact(String from_contact) {this.from_contact = from_contact;}
	public void setRemark(String remark) {this.remark = remark;}
	public void setFrq_type(String frq_type) {this.frq_type = frq_type;}

	public void setInv_type(String inv_type) {this.inv_type = inv_type;}
	public void setInv_seq(String inv_seq) {this.inv_seq = inv_seq;}
	public void setInv_no(String inv_no) {this.inv_no = inv_no;}
	public void setFinancial_year(String financial_year) {this.financial_year = financial_year;}
	public void setMapping_id(String mapping_id) {this.mapping_id = mapping_id;}
	public void setPeriod_start_dt(String period_start_dt) {this.period_start_dt = period_start_dt;}
	public void setPeriod_end_dt(String period_end_dt) {this.period_end_dt = period_end_dt;}
	
	public void setIs_print(String is_print) {this.is_print = is_print;}
	
	public void setPrint_pdf_type(String print_pdf_type) {this.print_pdf_type = print_pdf_type;}
	public void setBu_state_tin(String bu_state_tin) {this.bu_state_tin = bu_state_tin;}

	public void setInvoice_type(String invoice_type) {this.invoice_type = invoice_type;}
	public void setTrans_bu_seq(String trans_bu_seq) {this.trans_bu_seq = trans_bu_seq;}
	
	public void setSeq_no(String seq_no) {this.seq_no = seq_no;}
	public void setSeq_rev_no(String seq_rev_no) {this.seq_rev_no = seq_rev_no;}
	public void setGx(String gx) {this.gx = gx;}
	public void setIsReversal(String isReversal) {this.isReversal = isReversal;}
	public void setEmp_cd(String emp_cd) {this.emp_cd = emp_cd;}
	
	public void setCargo_no(String cargo_no) {this.cargo_no = cargo_no;}
	public void setInstrument_no(String instrument_no) {this.instrument_no = instrument_no;}
	public void setBoe_no(String boe_no) {this.boe_no = boe_no;}
	public void setInv_flag(String inv_flag) {this.inv_flag = inv_flag;}
	public void setBilling_cycle(String billing_cycle) {this.billing_cycle = billing_cycle;}
	
	public void setForm_id(String form_id) {this.form_id = form_id;}
	public void setForm_nm(String form_nm) {this.form_nm = form_nm;}
	public void setMod_cd(String mod_cd) {this.mod_cd = mod_cd;}
	public void setMod_nm(String mod_nm) {this.mod_nm = mod_nm;}
	
	public void setEntity(String entity) {this.entity = entity;}
	public void setContact_person_cd(String contact_person_cd) {this.contact_person_cd = contact_person_cd;}
	
	public void setTot_mmscm(String tot_mmscm) {this.tot_mmscm = tot_mmscm;}
	public void setTot_mmbtu(String tot_mmbtu) {this.tot_mmbtu = tot_mmbtu;}
	public void setTot_obl_mcm(String tot_obl_mcm) {this.tot_obl_mcm = tot_obl_mcm;}
	public void setAsk_nom_mcm(String ask_nom_mcm) {this.ask_nom_mcm = ask_nom_mcm;}
	public void setAsk_obl_mcm(String ask_obl_mcm) {this.ask_obl_mcm = ask_obl_mcm;}
	public void setAsk_nom_mmbtu(String ask_nom_mmbtu) {this.ask_nom_mmbtu = ask_nom_mmbtu;}
	public void setChk_oblig(String chk_oblig) {this.chk_oblig = chk_oblig;}
	public void setChk_exp(String chk_exp) {this.chk_exp = chk_exp;}
	public void setTot_exp_mmscm(String tot_exp_mmscm) {this.tot_exp_mmscm = tot_exp_mmscm;}
	public void setAsk_exp_mmscm(String ask_exp_mmscm) {this.ask_exp_mmscm = ask_exp_mmscm;}
	
	public void setTruck_cd(String truck_cd) {this.truck_cd = truck_cd;}
	public void setTruck_trans_cd(String truck_trans_cd) {this.truck_trans_cd = truck_trans_cd;}
	
	public void setOri_inv_flag(String ori_inv_flag) {this.ori_inv_flag = ori_inv_flag;}
	public void setExist_fin_yr(String exist_fin_yr) {this.exist_fin_yr = exist_fin_yr;}
	public void setOri_inv_seq(String ori_inv_seq) {this.ori_inv_seq = ori_inv_seq;}
	public void setOri_inv_no(String ori_inv_no) {this.ori_inv_no = ori_inv_no;}
	public void setCont_start_dt(String cont_start_dt) {this.cont_start_dt = cont_start_dt;}
	public void setCont_end_dt(String cont_end_dt) {this.cont_end_dt = cont_end_dt;}
	
	public void setSel_inv_no(String sel_inv_no) {this.sel_inv_no = sel_inv_no;}
	public void setCrdr_type(String crdr_type) {this.crdr_type = crdr_type;}
	public void setCrdr_inv_no(String crdr_inv_no) {this.crdr_inv_no = crdr_inv_no;}

	HashMap<String, String> invoice_data = new HashMap<String, String>();
	HashMap<String, HashMap<String, String>> view_join_ticket_data = new HashMap();
	HashMap<String, String> view_join_ticket_info = new HashMap();
	HashMap<String, HashMap<String, String>> view_seller_alloc_to_trans_data = new HashMap();
	HashMap<String, String> view_seller_alloc_to_trans_info = new HashMap();
	HashMap<String, HashMap<String, String>> view_seller_nomination_to_customer_data = new HashMap();
	HashMap<String, String> view_seller_nomination_to_customer_info = new HashMap();
	
	HashMap<String, String> view_ltcora_info = new HashMap();		//20250604
	HashMap<String, String> view_ltcora_customer_info = new HashMap();	//20250604
	
	HashMap<String, HashMap<String, String>> view_data = new HashMap();
	HashMap<String, String> view_info = new HashMap();
	HashMap<String, String> view_hedge_info = new HashMap();

	public void setView_ltcora_info(HashMap<String, String> view_ltcora_info) {this.view_ltcora_info=view_ltcora_info;}	//20250604
	public void setview_ltcora_customer_info(HashMap<String, String> view_ltcora_customer_info) {this.view_ltcora_customer_info=view_ltcora_customer_info;}	//20250604
	
	public HashMap<String, String> getInvoice_data() {return invoice_data;}
	
	public void setInvoice_data(HashMap<String, String> invoice_data) {this.invoice_data = invoice_data;}
	public void setView_join_ticket_data(HashMap<String, HashMap<String, String>> view_join_ticket_data) {this.view_join_ticket_data = view_join_ticket_data;}
	public void setView_join_ticket_info(HashMap<String, String> view_join_ticket_info) {this.view_join_ticket_info = view_join_ticket_info;}
	public void setView_seller_alloc_to_trans_data(HashMap<String, HashMap<String, String>> view_seller_alloc_to_trans_data) {this.view_seller_alloc_to_trans_data = view_seller_alloc_to_trans_data;}
	public void setView_seller_alloc_to_trans_info(HashMap<String, String> view_seller_alloc_to_trans_info) {this.view_seller_alloc_to_trans_info = view_seller_alloc_to_trans_info;}
	public void setView_seller_nomination_to_customer_data(HashMap<String, HashMap<String, String>> view_seller_nomination_to_customer_data) {this.view_seller_nomination_to_customer_data = view_seller_nomination_to_customer_data;}
	public void setView_seller_nomination_to_customer_info(HashMap<String, String> view_seller_nomination_to_customer_info) {this.view_seller_nomination_to_customer_info = view_seller_nomination_to_customer_info;}
	
	public void setView_data(HashMap<String, HashMap<String, String>> view_data) {this.view_data = view_data;}
	public void setView_info(HashMap<String, String> view_info) {this.view_info = view_info;}
	public void setView_hedge_info(HashMap<String, String> view_hedge_info) {this.view_hedge_info = view_hedge_info;}
	
	String msg="";
	String msg_type="";
	String all_pdf_print="";
	
	public String getMsg() {return msg;}
	public String getMsg_type() {return msg_type;}
	public String getCountpty_name() {return countpty_name;}
	public String getAll_pdf_print() {return all_pdf_print;}
	
	Vector VCATEGORY = new Vector();
	Vector VTRANSPORTER_CD = new Vector();
	Vector VTRANSPORTER_NM = new Vector();
	Vector VTRANSPORTER_ABBR = new Vector();
	
	Vector VCOUNTERPARTY_CD = new Vector();
	Vector VCOUNTERPARTY_NM = new Vector();
	Vector VCOUNTERPARTY_ABBR = new Vector();
	Vector VCUST_WISE_MMSCM = new Vector();
	Vector VCUST_WISE_MMBTU = new Vector();
	Vector VQTY_MMSCM = new Vector();
	Vector VQTY_MMBTU = new Vector();
	Vector VTOT_MMSCM = new Vector();
	Vector VTOT_MMBTU = new Vector();
	Vector VOBLG_MMSCM = new Vector();
	Vector VCUST_WISE_OBLG = new Vector();
	Vector VTOT_OBLG_MMSCM = new Vector();
	Vector VTEMP_TRANS_CD = new Vector();
	Vector VTEMP_COUNTERPARTY_CD = new Vector();
	Vector VEXP_MMSCM = new Vector();
	Vector VPLANT_NM = new Vector();
	Vector VPLANT_SEQ = new Vector();
	Vector VTRANSPORTER_PLANT_SEQ = new Vector();
	Vector VTRANSPORTER_PLANT_ABBR = new Vector();
	Vector VTEMP_TRANS_PLANT_SEQ = new Vector();
	
	Vector VDISP_DEAL_ID = new Vector();
	Vector VQTY_SELL = new Vector();
	Vector VQTY = new Vector();
	Vector VQTY_BBL = new Vector();
	Vector VQTYSELL_BBL = new Vector();
	Vector VQTY_SETTLE = new Vector();
	Vector VDEAL_RMK = new Vector();
	Vector VTRADE_DT = new Vector();
	Vector VBUY_SELL = new Vector();
	Vector VPROD_NM = new Vector();
	Vector VCURV_NM = new Vector();
	Vector VQTY_UNIT = new Vector();
	Vector VRATE = new Vector();
	Vector VRATE_UNIT = new Vector();
	Vector VCONT_MONTH_YEAR = new Vector();
	Vector VPRICE_START_DT = new Vector();
	Vector VPRICE_END_DT = new Vector();
	Vector VPROJ_METHOD = new Vector();
	Vector VCONT_REF = new Vector();
	Vector VQTYCURV_NM = new Vector();
	Vector VBUY_RATE = new Vector();
	Vector VSELL_RATE = new Vector();
	Vector VINV_AMT = new Vector();
	Vector VINSTRUMENT_TYPE = new Vector();
	Vector VCURVE_NM = new Vector();
	Vector VINSTRUMENT_DURATION = new Vector();
	
	Vector VMAIN_BOOKED_MMBTU = new Vector();
	Vector VMAIN_BUY_SELL = new Vector();
	Vector VMAIN_BUY_RATE = new Vector();
	Vector VMAIN_SELL_RATE = new Vector();
	Vector VMAIN_SELL_AMT = new Vector();
	Vector VMAIN_BUY_AMT = new Vector();
	Vector VMAIN_TOTAL_AMT = new Vector();
	Vector VNEW_QTY = new Vector();
	Vector VNEW_QTY_UNIT = new Vector();
	Vector VNEW_SELL_RATE = new Vector();
	Vector VNEW_SELL_AMT = new Vector();
	Vector VNEW_BUY_RATE = new Vector();
	Vector VNEW_BUY_AMT = new Vector();
	Vector VNEW_TOTAL_AMT = new Vector();
	
	Vector VAGMT_NO = new Vector();
	Vector VAGMT_REV = new Vector();
	Vector VCONT_TYPE = new Vector();
	Vector VCONT_NO = new Vector();
	Vector VCONT_REV = new Vector();
	Vector VINSTRUMENT_NO = new Vector();
	Vector VBOOKED_MMBTU = new Vector();
	Vector VPERIOD_START_DT = new Vector();
	Vector VPERIOD_END_DT = new Vector();
	Vector VDEAL_MAPPING = new Vector();
	Vector VSELL_AMT = new Vector();
	Vector VBUY_AMT = new Vector();
	Vector VINVOICE_AMT = new Vector();
	Vector IS_CRDR_SUBMITTED = new Vector();
	Vector VINVOICE_NO = new Vector();
	Vector VALL_INSTRUMENT_NO = new Vector();
	Vector VCONT_START_DT = new Vector();
	Vector VCONT_END_DT = new Vector();
	
	public void setVCATEGORY(Vector VCATEGORY) {this.VCATEGORY = VCATEGORY;}
	public void setVTRANSPORTER_CD(Vector VTRANSPORTER_CD) {this.VTRANSPORTER_CD = VTRANSPORTER_CD;}
	public void setVTRANSPORTER_NM(Vector VTRANSPORTER_NM) {this.VTRANSPORTER_NM = VTRANSPORTER_NM;}
	public void setVTRANSPORTER_ABBR(Vector VTRANSPORTER_ABBR) {this.VTRANSPORTER_ABBR = VTRANSPORTER_ABBR;}
	
	public void setVCOUNTERPARTY_CD(Vector VCOUNTERPARTY_CD) {this.VCOUNTERPARTY_CD = VCOUNTERPARTY_CD;}
	public void setVCOUNTERPARTY_NM(Vector VCOUNTERPARTY_NM) {this.VCOUNTERPARTY_NM = VCOUNTERPARTY_NM;}
	public void setVCOUNTERPARTY_ABBR(Vector VCOUNTERPARTY_ABBR) {this.VCOUNTERPARTY_ABBR = VCOUNTERPARTY_ABBR;}

	public void setVCUST_WISE_MMSCM(Vector VCUST_WISE_MMSCM) {this.VCUST_WISE_MMSCM = VCUST_WISE_MMSCM;}
	public void setVCUST_WISE_MMBTU(Vector VCUST_WISE_MMBTU) {this.VCUST_WISE_MMBTU = VCUST_WISE_MMBTU;}
	public void setVQTY_MMSCM(Vector VQTY_MMSCM) {this.VQTY_MMSCM = VQTY_MMSCM;}
	public void setVQTY_MMBTU(Vector VQTY_MMBTU) {this.VQTY_MMBTU = VQTY_MMBTU;}
	public void setVTOT_MMSCM(Vector VTOT_MMSCM) {this.VTOT_MMSCM = VTOT_MMSCM;}
	public void setVTOT_MMBTU(Vector VTOT_MMBTU) {this.VTOT_MMBTU = VTOT_MMBTU;}
	public void setVOBLG_MMSCM(Vector VOBLG_MMSCM) {this.VOBLG_MMSCM = VOBLG_MMSCM;}
	public void setVCUST_WISE_OBLG(Vector VCUST_WISE_OBLG) {this.VCUST_WISE_OBLG = VCUST_WISE_OBLG;}
	public void setVTOT_OBLG_MMSCM(Vector VTOT_OBLG_MMSCM) {this.VTOT_OBLG_MMSCM = VTOT_OBLG_MMSCM;}
	public void setVTEMP_TRANS_CD(Vector VTEMP_TRANS_CD) {this.VTEMP_TRANS_CD = VTEMP_TRANS_CD;}
	public void setVTEMP_COUNTERPARTY_CD(Vector VTEMP_COUNTERPARTY_CD) {this.VTEMP_COUNTERPARTY_CD = VTEMP_COUNTERPARTY_CD;}
	public void setVEXP_MMSCM(Vector VEXP_MMSCM) {this.VEXP_MMSCM = VEXP_MMSCM;}
	public void setVPLANT_NM(Vector VPLANT_NM) {this.VPLANT_NM = VPLANT_NM;}
	public void setVPLANT_SEQ(Vector VPLANT_SEQ) {this.VPLANT_SEQ = VPLANT_SEQ;}
	public void setVTRANSPORTER_PLANT_SEQ(Vector VTRANSPORTER_PLANT_SEQ) {this.VTRANSPORTER_PLANT_SEQ = VTRANSPORTER_PLANT_SEQ;}
	public void setVTRANSPORTER_PLANT_ABBR(Vector VTRANSPORTER_PLANT_ABBR) {this.VTRANSPORTER_PLANT_ABBR = VTRANSPORTER_PLANT_ABBR;}
	public void setVTEMP_TRANS_PLANT_SEQ(Vector VTEMP_TRANS_PLANT_SEQ) {this.VTEMP_TRANS_PLANT_SEQ = VTEMP_TRANS_PLANT_SEQ;}

	public void setVDISP_DEAL_ID(Vector VDISP_DEAL_ID) {this.VDISP_DEAL_ID = VDISP_DEAL_ID;}
	public void setVQTY_SELL(Vector VQTY_SELL) {this.VQTY_SELL = VQTY_SELL;}
	public void setVQTY(Vector VQTY) {this.VQTY = VQTY;}
	public void setVQTY_BBL(Vector VQTY_BBL) {this.VQTY_BBL = VQTY_BBL;}
	public void setVQTYSELL_BBL(Vector VQTYSELL_BBL) {this.VQTYSELL_BBL = VQTYSELL_BBL;}
	public void setVQTY_SETTLE(Vector VQTY_SETTLE) {this.VQTY_SETTLE = VQTY_SETTLE;}
	public void setVDEAL_RMK(Vector VDEAL_RMK) {this.VDEAL_RMK = VDEAL_RMK;}
	public void setVTRADE_DT(Vector VTRADE_DT) {this.VTRADE_DT = VTRADE_DT;}
	public void setVBUY_SELL(Vector VBUY_SELL) {this.VBUY_SELL = VBUY_SELL;}
	public void setVPROD_NM(Vector VPROD_NM) {this.VPROD_NM = VPROD_NM;}
	public void setVCURV_NM(Vector VCURV_NM) {this.VCURV_NM = VCURV_NM;}
	public void setVQTY_UNIT(Vector VQTY_UNIT) {this.VQTY_UNIT = VQTY_UNIT;}
	public void setVRATE(Vector VRATE) {this.VRATE = VRATE;}
	public void setVRATE_UNIT(Vector VRATE_UNIT) {this.VRATE_UNIT = VRATE_UNIT;}
	public void setVCONT_MONTH_YEAR(Vector VCONT_MONTH_YEAR) {this.VCONT_MONTH_YEAR = VCONT_MONTH_YEAR;}
	public void setVPRICE_START_DT(Vector VPRICE_START_DT) {this.VPRICE_START_DT = VPRICE_START_DT;}
	public void setVPRICE_END_DT(Vector VPRICE_END_DT) {this.VPRICE_END_DT = VPRICE_END_DT;}
	public void setVPROJ_METHOD(Vector VPROJ_METHOD) {this.VPROJ_METHOD = VPROJ_METHOD;}
	public void setVCONT_REF(Vector VCONT_REF) {this.VCONT_REF = VCONT_REF;}
	public void setVQTYCURV_NM(Vector VQTYCURV_NM) {this.VQTYCURV_NM = VQTYCURV_NM;}
}
