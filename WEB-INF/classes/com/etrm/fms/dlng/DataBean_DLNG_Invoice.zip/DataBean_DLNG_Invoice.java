package com.etrm.fms.dlng;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Vector;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.IndexedColorMap;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.etrm.fms.util.CommonVariable;
import com.etrm.fms.util.DB_AllocationUtil;
import com.etrm.fms.util.DateUtil;
import com.etrm.fms.util.RuntimeConf;
import com.etrm.fms.util.SystemErrorLogger;
import com.etrm.fms.util.TaxCalculator;
import com.etrm.fms.util.UtilBean;
import com.etrm.fms.util.XmlUtilBean;

//Coded By          : Harsh Patel
//Code Reviewed by	:  
//CR Date			: 03/06/2025 
//Status	  		: Developing
public class DataBean_DLNG_Invoice 
{
	String db_src_file_name="DataBean_DLNG_Invoice.java";
	
	Connection conn; 
	PreparedStatement stmt;
	PreparedStatement stmt0;
	PreparedStatement stmt1;
	PreparedStatement stmt2;
	PreparedStatement stmt3;
	PreparedStatement stmt4;
	PreparedStatement stmt5;
	PreparedStatement stmt6;
	PreparedStatement stmt7;
	ResultSet rset;
	ResultSet rset0;
	ResultSet rset1;
	ResultSet rset2;
	ResultSet rset3;
	ResultSet rset4;
	ResultSet rset5;
	ResultSet rset6;
	ResultSet rset7;
	String queryString="";
	String queryString0="";
	String queryString1="";
	String queryString2="";
	String queryString3="";
	String queryString4="";
	String queryString5="";
	String queryString6="";
	String queryString7="";
	
	static UtilBean utilBean = new UtilBean();
	static DateUtil utilDate = new DateUtil();
	static TaxCalculator TaxCalc = new TaxCalculator(); 
	static DB_AllocationUtil utilAlloc = new DB_AllocationUtil();
	static UtilBean_DLNG dlng_util = new UtilBean_DLNG();
	static XmlUtilBean xmlUtil = new XmlUtilBean();
	
	static NumberFormat nf = new DecimalFormat("###########0.00");
	static NumberFormat nf2 = new DecimalFormat("###########0.0000");
	static NumberFormat nf3 = new DecimalFormat("###########0.000");
	static NumberFormat nf0 = new DecimalFormat("###########0.0");
	
	public static XSSFWorkbook workbook = new XSSFWorkbook();
	public static XSSFWorkbook workbook402 = new XSSFWorkbook();
	
	double transaction_limit=5000000;
	//double tcs_factor=0.075;
	double tcs_factor=0;
	public double getTcs_factor() {return tcs_factor;}
	
	public void init()
	{
		String function_nm="init()";
		try
		{
			Context initContext = new InitialContext();
	    	Context envContext  = (Context)initContext.lookup("java:/comp/env");
	    	DataSource ds = (DataSource)envContext.lookup(RuntimeConf.security_database);
	    	if(ds != null) 
	    	{
	    		conn = ds.getConnection(); 
	    		if(conn != null)  
	    		{
	    		
	    			if(callFlag.equalsIgnoreCase("DLNG_SALES_INVOICE_PREPARATION_LIST"))
	    			{
	    				getDlngSalesInvoicePreparationList();
	    				//getDlngFFlowInvoiceList();
	    			}
	    			else if(callFlag.equalsIgnoreCase("DLNG_FFLOW_INVOICE_PREPARATION_LIST"))
	    			{
	    				getDlngFFlowInvoiceList();
	    			}
	    			else if(callFlag.equalsIgnoreCase("DLNG_F_FLOW_INVOICE"))
	    			{
	    				couterpty_abbr=""+utilBean.getCounterpartyABBR(conn,counterparty_cd);
	    				//getBillingCyclePeriod();
	    				getFilterContractList();
	    				getCustomerCounterpartyList();
	    				getContractList();
	    				getPlantDetail();
	    				getAddressType();
	    				getOtherInvoiceContactPerson();
	    				getBuUnit();
	    				getBuContactPerson();
	    				getSacCodeDtl();
	    				if(opration.equalsIgnoreCase("MODIFY"))
	    				{
	    					getExixtingF_FLowInvoice();
	    					//getF_FlowAnnexureDetail();
	    				}
	    				else
	    				{
	    					getF_FlowInvoice();
	    				}
	    				getInvoiceNo();
	    			}
	    			else if(callFlag.equalsIgnoreCase("DLNG_FFLOW_INVOICE_REPORT"))
	    			{
	    				getF_FlowInvoiceDetail();
	    				if(activityFlag.equals("APPROVE"))
	    				{
	    					getF_FlowInvoiceNumber();
	    				}
	    			}
	    			else if(callFlag.equalsIgnoreCase("DLNG_SALES_INVOICE_GENERATION"))
	    			{
	    				getContractDetail();
	    				getContractBillingDetail();
	    				getContactPerson();
	    				getBuContactPerson();
	    				getExistingInvoiceDtl();
	    				getInvoiceDateCalc();
	    				getInvoiceCalculation();
	    				getChekPostandDriverMst();
	    				if(!operation.equals("MODIFY") && !submission_chk)
	    				{
	    					getRemarks();
	    				}
	    				
	    				getTurnoverDetail();
	    				if((operation.equals("INSERT") && !submission_chk) || operation.equals("MODIFY"))
	    				{
	    					checkTCS_TDSApplicable();
	    				}
	    				
	    				if(contract_type.equals("F") || contract_type.equals("E"))
	    				{
	    					getTcsTdsInvDtl();
	    				}
	    			}
	    			else if(callFlag.equalsIgnoreCase("DLNG_SALES_INVOICE_DETAIL"))
	    			{
	    				getInvoiceDetailForViewBeforeSub();
	    			}
	    			else if(callFlag.equalsIgnoreCase("DLNG_SALES_INVOICE_REPORT"))
	    			{
	    				getInvoiceDetail();
	    				if(activityFlag.equals("APPROVE"))
	    				{
	    					getInvoiceNumber();
	    				}
	    			}
	    			else if(callFlag.equalsIgnoreCase("DLNG_SALES_SAP_XML"))
	    			{
	    				generateSalesInvoiceXML();
	    				parseSAP_XMLfile();
	    			}
	    			else if(callFlag.equalsIgnoreCase("GENERATE_DLNG_SALES_SAP_XML"))
	    			{
	    				generateSalesInvoiceXML();
	    			}
	    			else if(callFlag.equalsIgnoreCase("PARSE_SAP_XML"))
	    			{
	    				getSapInvoiceApprovalDetail();
	    				parseSAP_XMLfile();
	    				getPostingDetail();
	    				//checkSunApproved();
	    			}
	    			else if(callFlag.equalsIgnoreCase("DLNG_SEND_INVOICE_MAIL"))
	    			{
	    				getSendInvoiceMailDetail();
	    			}
	    			else if(callFlag.equalsIgnoreCase("DLNG_VIEW_ALL_PDF"))
	    			{
	    				getAllPdfFileName();
	    			}
	    			else if(callFlag.equalsIgnoreCase("GET_FORM-402_DETAIL"))
	    			{
	    				getTransporterDetail();
	    				getDriverDetailForForm402();
	    			}
	    			else if(callFlag.equalsIgnoreCase("GENERATE_FORM-402_EXCEL"))
	    			{
	    				GenerateExcelForForm402();
	    			}
	    			else if(callFlag.equalsIgnoreCase("CFORM_ENTRY_MST"))
	    			{
	    				getFinancialYearList();
	    				getCustomerList();
	    				getStateMst();
	    				getCFormDtl();
	    				getCFormMst();
	    			}
	    			else if(callFlag.equalsIgnoreCase("DLNG_RECEIVABLE_TRACKING"))
	    			{
	    				getReceivableTracking();
	    			}
	    			else if(callFlag.equalsIgnoreCase("DLNG_INVOICE_FO_APPROVAL"))
	    			{
	    				getSegment();
	    				getDlngInvoiceActualRptDtl();
	    			}
	    	
	    			conn.close();
	    		}
				conn = null;
	    	}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
		finally
	    {
	    	if(rset != null){try{rset.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(rset0 != null){try{rset0.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(rset1 != null){try{rset1.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(rset2 != null){try{rset2.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(rset3 != null){try{rset3.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(rset4 != null){try{rset4.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(rset5 != null){try{rset5.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(rset6 != null){try{rset6.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(rset7 != null){try{rset7.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt != null){try{stmt.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt0 != null){try{stmt0.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt1 != null){try{stmt1.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt2 != null){try{stmt2.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt3 != null){try{stmt3.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt4 != null){try{stmt4.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt5 != null){try{stmt5.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt6 != null){try{stmt6.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(stmt7 != null){try{stmt7.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(conn != null){try{conn.close();}catch(SQLException e){new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);}}
	    	if(workbook != null){try {workbook.close();}catch(IOException  e){System.out.println("XSSFWorkbook is not close " + e);}}
	    	if(workbook402 != null){try {workbook402.close();}catch(IOException  e){System.out.println("XSSFWorkbook402 is not close " + e);}}
	    }
	}
	
	public String getBillingPeriodEndDate(String billing_freq,String date,String bill_days,String inv_dt)
	{
		String function_nm="getBillingCyclePeriod()";
		String freq_end_dt="";
		try
		{
			String day="";
			String month="";
			String year="";
			if(!date.equals(""))
			{
				String split[]=date.split("/");
				day=split[0];
				month=split[1];
				year=split[2];
			}
			
			if(billing_freq.equals("F"))
			{
				
				if(Integer.parseInt(day) > 15)
				{
					freq_end_dt=""+utilDate.getLastDateOfMonth(month, year);
				}
				else
				{
					freq_end_dt="15/"+month+"/"+year;
				}
			}
			else if(billing_freq.equals("W"))
			{
				if(Integer.parseInt(day) > 28)
				{
					freq_end_dt=""+utilDate.getLastDateOfMonth(month, year);
				}
				else if(Integer.parseInt(day) > 21)
				{
					freq_end_dt="28/"+month+"/"+year;
				}
				else if(Integer.parseInt(day) > 14)
				{
					freq_end_dt="21/"+month+"/"+year;
				}
				else if(Integer.parseInt(day) > 7)
				{
					freq_end_dt="14/"+month+"/"+year;
				}
				else
				{
					freq_end_dt="07/"+month+"/"+year;
				}
			}
			else if(billing_freq.equals("M"))
			{
				freq_end_dt=""+utilDate.getLastDateOfMonth(month, year);
			}
			else if(billing_freq.equals("O"))
			{
				freq_end_dt=""+utilDate.getDate(inv_dt, bill_days);
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
		
		return freq_end_dt;
	}
	
	public void getDlngSalesInvoicePreparationList()
	{
		String function_nm="getDlngSalesInvoicePreparationList()";

		try
		{
			String billing_flag="B";
			
			queryString="SELECT A.COMPANY_CD,A.COUNTERPARTY_CD,A.AGMT_NO,A.AGMT_REV,A.CONT_NO,A.CONT_REV,"
					+ "TO_CHAR(A.START_DT,'DD/MM/YYYY'),TO_CHAR(A.END_DT,'DD/MM/YYYY'),A.CONT_NAME,A.CONT_REF_NO,A.CONTRACT_TYPE,"
					+ "A.TRADE_REF_NO,TO_CHAR(C.EFF_DT,'DD/MM/YYYY'),A.AGMT_BASE,A.FCC_FLAG,D.PLANT_SEQ_NO,E.PLANT_SEQ_NO,"
					+ "F.TRUCK_TRANS_CD,F.TRUCK_CD,F.FILL_STATION_CD,F.BAY_CD,F.SLOT_START_TIME,F.SLOT_END_TIME "
					+ "FROM FMS_SUPPLY_CONT_MST A, "
						+ "FMS_SUPPLY_BILLING_DTL C, "
						+ "FMS_SUPPLY_CONT_PLANT D, "
						+ "FMS_SUPPLY_CONT_BU E,"
						+ "FMS_DLNG_ALLOC_MST F "
					+ "WHERE A.COMPANY_CD=? AND A.IS_ALLOCATED=? " //AND A.FCC_FLAG='Y' " REMOVED AS DISCUSSED WITH MAM
					+ "AND A.START_DT<=TO_DATE(?,'DD/MM/YYYY') AND A.END_DT>=TO_DATE(?,'DD/MM/YYYY') AND A.CONTRACT_TYPE IN ('E','F','W') "
					+ "AND A.CONT_REV = (SELECT MAX(B.CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
						+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) "
					+ ""
					+ "AND A.COMPANY_CD=C.COMPANY_CD AND A.COUNTERPARTY_CD=C.COUNTERPARTY_CD AND A.CONT_NO=C.CONT_NO "
					+ "AND A.AGMT_NO=C.AGMT_NO AND A.CONTRACT_TYPE=C.CONTRACT_TYPE AND D.PLANT_SEQ_NO=C.PLANT_SEQ_NO AND C.BILLING_FLAG=? "
					+ "AND C.EFF_DT=(SELECT MAX(E.EFF_DT) FROM FMS_SUPPLY_BILLING_DTL E WHERE C.COMPANY_CD=E.COMPANY_CD "
						+ "AND C.COUNTERPARTY_CD=E.COUNTERPARTY_CD AND C.AGMT_NO=E.AGMT_NO AND C.CONT_NO=E.CONT_NO "
						+ "AND C.CONTRACT_TYPE=E.CONTRACT_TYPE AND E.PLANT_SEQ_NO=C.PLANT_SEQ_NO AND E.EFF_DT<=TO_DATE(?,'DD/MM/YYYY')) "
					+ ""
					+ "AND A.COMPANY_CD=D.COMPANY_CD AND A.COUNTERPARTY_CD=D.COUNTERPARTY_CD AND A.CONT_NO=D.CONT_NO AND A.CONT_REV=D.CONT_REV "
					+ "AND A.AGMT_NO=D.AGMT_NO AND A.AGMT_REV=D.AGMT_REV AND A.CONTRACT_TYPE=D.CONTRACT_TYPE "
					+ ""
					+ "AND A.COMPANY_CD=E.COMPANY_CD AND A.COUNTERPARTY_CD=E.COUNTERPARTY_CD AND A.CONT_NO=E.CONT_NO AND A.CONT_REV=E.CONT_REV "
					+ "AND A.AGMT_NO=E.AGMT_NO AND A.AGMT_REV=E.AGMT_REV AND A.CONTRACT_TYPE=E.CONTRACT_TYPE "
					+ ""
					+ "AND F.QTY_MMBTU > 0 AND  A.COMPANY_CD=F.COMPANY_CD AND A.COUNTERPARTY_CD=F.COUNTERPARTY_CD "
					+ "AND A.CONT_NO=F.CONT_NO AND A.AGMT_NO=F.AGMT_NO AND A.CONTRACT_TYPE=F.CONTRACT_TYPE AND D.PLANT_SEQ_NO=F.PLANT_SEQ AND E.PLANT_SEQ_NO=F.BU_SEQ "
					+ "AND F.GAS_DT =TO_DATE(?,'DD/MM/YYYY') "
					+ "AND F.NOM_REV_NO=(SELECT MAX(NOM_REV_NO) FROM FMS_DLNG_ALLOC_MST C "
						+ "WHERE F.CONT_NO=C.CONT_NO AND F.AGMT_NO=C.AGMT_NO AND F.COMPANY_CD=C.COMPANY_CD AND F.COUNTERPARTY_CD=C.COUNTERPARTY_CD "
						+ "AND F.PLANT_SEQ=C.PLANT_SEQ AND F.CONTRACT_TYPE=C.CONTRACT_TYPE AND F.BU_SEQ=C.BU_SEQ AND F.GAS_DT=C.GAS_DT) ";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, "Y");
			stmt.setString(3, gas_dt);
			stmt.setString(4, gas_dt);
			stmt.setString(5, billing_flag);
			stmt.setString(6, gas_dt);
			stmt.setString(7, gas_dt);
			rset=stmt.executeQuery();
			while(rset.next())
			{
				String own_cd=rset.getString(1)==null?"":rset.getString(1);
				String countpty_cd=rset.getString(2)==null?"":rset.getString(2);
				String countpty_abbr=""+utilBean.getCounterpartyABBR(conn,countpty_cd);
				String countpty_nm=""+utilBean.getCounterpartyName(conn,countpty_cd);
				String agmtno=rset.getString(3)==null?"0":rset.getString(3);
				String agmtrev=rset.getString(4)==null?"0":rset.getString(4);
				String contno=rset.getString(5)==null?"0":rset.getString(5);
				String contrev=rset.getString(6)==null?"0":rset.getString(6);
				String cargo_no="0";
				String end_dt=rset.getString(8)==null?"":rset.getString(8);
				String contRef=rset.getString(10)==null?"":rset.getString(10);
				String cont_type=rset.getString(11)==null?"":rset.getString(11);
				String tradeRef=rset.getString(12)==null?"":rset.getString(12);
				String deal_no=utilBean.NewDealMappingId(own_cd, countpty_cd, agmtno, agmtrev, contno, contrev, cont_type, cargo_no);
				
				if(cont_type.equals("W"))
				{
					contRef=tradeRef;
				}
				
				String billing_eff_dt=rset.getString(13)==null?"":rset.getString(13);
				String agmt_base=rset.getString(14)==null?"":rset.getString(14);
				String fcc=rset.getString(15)==null?"":rset.getString(15);
				
				String plant_seq = rset.getString(16)==null?"":rset.getString(16);
				String plant_abbr=utilBean.getCounterpartyPlantABBR(conn,countpty_cd, own_cd, plant_seq, "C");
				
				String bu_plant_seq = rset.getString(17)==null?"":rset.getString(17);
				String bu_plant_abbr=utilBean.getCounterpartyPlantABBR(conn,own_cd, own_cd, bu_plant_seq, "B");
				
				String state_code=utilBean.getState_TIN(conn, own_cd, own_cd, "B", bu_plant_seq);
				
				String truckTransCd=rset.getString(18)==null?"":rset.getString(18);
				String truckCd=rset.getString(19)==null?"":rset.getString(19);
				String filling_station_cd=rset.getString(20)==null?"":rset.getString(20);
				String bay_cd=rset.getString(21)==null?"":rset.getString(21);
				String slot_start_time=rset.getString(22)==null?"":rset.getString(22);
				String slot_end_time=rset.getString(23)==null?"":rset.getString(23);
				
				String mapping_id = filling_station_cd+"-"+bay_cd+"-"+slot_start_time+"-"+slot_end_time;
					
				VBU_STATE_TIN.add(state_code);							
				VCOUNTERPTY_CD.add(countpty_cd);
				VCOUNTERPTY_ABBR.add(countpty_abbr);
				VCOUNTERPTY_NM.add(countpty_nm);
				VAGMT_NO.add(agmtno);
				VAGMT_REV_NO.add(agmtrev);
				VCONT_NO.add(contno);
				VCONT_REV_NO.add(contrev);
				VCARGO_NO.add(cargo_no);
				VSTART_DT.add(rset.getString(7)==null?"":rset.getString(7));
				VEND_DT.add(rset.getString(8)==null?"":rset.getString(8));
				VCONT_REF_NO.add(contRef);
				VCONTRACT_TYPE.add(cont_type);
				VDEAL_NO.add(deal_no);
				VPERIOD_START_DT.add(gas_dt);
				VPERIOD_END_DT.add(gas_dt);
				
				VPLANT_SEQ.add(plant_seq);
				VPLANT_ABBR.add(plant_abbr);
				VBU_PLANT_SEQ.add(bu_plant_seq);
				VBU_PLANT_ABBR.add(bu_plant_abbr);
				//VALLOC_QTY.add(nf.format(qtyMMBTU));
				VAGMT_BASE.add(agmt_base);
				
				VTRUCK_CD.add(truckCd);
				VTRUCK_NO.add(dlng_util.getTruckRegNo(conn, truckCd));
				VTRUCK_TRANS_CD.add(truckTransCd);
				VMAPPING_ID.add(mapping_id);
				
				String inv_flag="F";
				VINV_FLAG.add(inv_flag);
				getInvDetailForPreparationList(own_cd,countpty_cd,contno, agmtno,cont_type, plant_seq, 
						bu_plant_seq, truckCd, truckTransCd, gas_dt, gas_dt,state_code,inv_flag, mapping_id);
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getDlngFFlowInvoiceList()
	{
		String function_nm="getDlngFFlowInvoiceList()";
		try
		{
			String temp_period_start_dt=""+utilDate.getFirstDateOfMonth(month, year);
			String temp_period_end_dt=""+utilDate.getLastDateOfMonth(month, year);
			
			queryString="SELECT COMPANY_CD,COUNTERPARTY_CD,AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,CONTRACT_TYPE, "
					+ "ADDR_FLAG,BU_UNIT,TO_CHAR(PERIOD_START_DT,'DD/MM/YYYY'),TO_CHAR(PERIOD_END_DT,'DD/MM/YYYY'),"
					+ "INVOICE_NO,CHECKED_FLAG,APPROVED_FLAG,INVOICE_SEQ,FINANCIAL_YEAR,INVOICE_TYPE,"
					+ "PDF_INV_DTL,BU_STATE_TIN, "
					+ "PRINT_BY_ORI,PRINT_BY_TRI,PRINT_BY_DUP,SAP_APPROVAL,CARGO_NO,INVOICE_CATEGORY,TAX_STRUCT_CD "
					+ "FROM FMS_DLNG_FFLOW_INV_MST "
					+ "WHERE COMPANY_CD=? ";//AND FREQ=? ";
			/*if(billing_cycle.equals("8"))
			{*/
				queryString+=" AND TO_DATE(?,'DD/MM/YYYY') <=INVOICE_DT AND TO_DATE(?,'DD/MM/YYYY') >= INVOICE_DT ";
			/*}
			else
			{
				queryString+=" AND PERIOD_START_DT =TO_DATE('"+period_start_dt+"','DD/MM/YYYY') AND PERIOD_END_DT =TO_DATE('"+period_end_dt+"','DD/MM/YYYY') ";
			}*/
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			//stmt.setString(2, billing_cycle);
			stmt.setString(2, temp_period_start_dt);
			stmt.setString(3, temp_period_end_dt);
			rset=stmt.executeQuery();
			while(rset.next())
			{
				String own_cd=rset.getString(1)==null?"":rset.getString(1);
				String countpty_cd=rset.getString(2)==null?"":rset.getString(2);
				String agmtno=rset.getString(3)==null?"0":rset.getString(3);
				String agmtrev=rset.getString(4)==null?"0":rset.getString(4);
				String contno=rset.getString(5)==null?"0":rset.getString(5);
				String contrev=rset.getString(6)==null?"0":rset.getString(6);
				String cont_type=rset.getString(7)==null?"":rset.getString(7);
				String cargo_no=rset.getString(24)==null?"":rset.getString(24);
				String deal_no=utilBean.NewDealMappingId(own_cd, countpty_cd, agmtno, agmtrev, contno, contrev, cont_type, cargo_no);
				
				String address_flag=rset.getString(8)==null?"":rset.getString(8);
				String plant_seq = "";
				String plant_abbr = "";
				if(address_flag.equals("R"))
				{
					plant_seq=address_flag;
					plant_abbr="Registered";
				}
				else if(address_flag.equals("C"))
				{
					plant_seq=address_flag;
					plant_abbr="Correspondence";
				}
				else if(address_flag.equals("B"))
				{
					plant_seq=address_flag;
					plant_abbr="Billing";
				}
				else if(!address_flag.equals("") && address_flag.startsWith("P"))
				{
					plant_seq=address_flag.substring(1,address_flag.length());
					plant_abbr=utilBean.getCounterpartyPlantABBR(conn,countpty_cd, own_cd, plant_seq, "C");
				}

				String bu_plant_seq = rset.getString(9)==null?"":rset.getString(9);
				String bu_plant_abbr=utilBean.getCounterpartyPlantABBR(conn,own_cd, own_cd, bu_plant_seq, "B");

				String p_st_dt=rset.getString(10)==null?"":rset.getString(10);
				String p_end_dt=rset.getString(11)==null?"":rset.getString(11);

				VOTH_COUNTERPTY_CD.add(countpty_cd);
				VOTH_COUNTERPTY_NM.add(""+utilBean.getCounterpartyName(conn,countpty_cd));
				VOTH_COUNTERPTY_ABBR.add(""+utilBean.getCounterpartyABBR(conn,countpty_cd));
				VOTH_AGMT_NO.add(agmtno);
				VOTH_AGMT_REV_NO.add(agmtrev);
				VOTH_CONT_NO.add(contno);
				VOTH_CONT_REV_NO.add(contrev);

				VOTH_CONTRACT_TYPE.add(cont_type);
				VOTH_DEAL_NO.add(deal_no);
				VCARGO_NO.add(cargo_no);

				VOTH_PLANT_SEQ.add(address_flag);
				VOTH_PLANT_ABBR.add(plant_abbr);
				VOTH_BU_PLANT_SEQ.add(bu_plant_seq);
				VOTH_BU_PLANT_ABBR.add(bu_plant_abbr);
				VOTH_PERIOD_START_DT.add(p_st_dt);
				VOTH_PERIOD_END_DT.add(p_end_dt);
				VOTH_BILLING_FREQ_FLAG.add(billing_cycle);
				VOTH_BILLING_FREQ_NM.add(billing_freq_nm);

				String max_contrev="0";

				queryString1="SELECT TO_CHAR(START_DT,'DD/MM/YYYY'),TO_CHAR(END_DT,'DD/MM/YYYY'),CONT_NAME,CONT_REF_NO,TRADE_REF_NO,CONT_REV "
						+ "FROM FMS_SUPPLY_CONT_MST A "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND AGMT_NO=? "
						+ "AND AGMT_REV=? AND CONT_NO=? AND CONTRACT_TYPE=? "
						+ "AND CONT_REV=(SELECT MAX(B.CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE B.COMPANY_CD=A.COMPANY_CD "
						+ "AND B.COUNTERPARTY_CD=A.COUNTERPARTY_CD AND B.AGMT_NO=A.AGMT_NO AND B.AGMT_REV=A.AGMT_REV "
						+ "AND B.CONT_NO=A.CONT_NO AND B.CONTRACT_TYPE=A.CONTRACT_TYPE) ";
				queryString1+="UNION ALL ";
				queryString1+="SELECT TO_CHAR(B.ACTUAL_RECPT_DT,'DD/MM/YYYY'),TO_CHAR(TO_DATE(B.ACTUAL_RECPT_DT,'DD/MM/YY')+NVL(STORAGE_DAYS-1,0)+NVL(STORAGE_EXT_DAYS,0),'DD/MM/YYYY'),"
						+ "A.CONT_NAME,B.CARGO_REF,NULL,A.CONT_REV "
						+ "FROM FMS_LTCORA_CONT_MST A,"
							+ "FMS_LTCORA_CONT_CARGO_DTL B "
						+ "WHERE A.COMPANY_CD=? AND A.COUNTERPARTY_CD=? AND A.AGMT_NO=? AND A.AGMT_REV=? AND A.CONT_NO=? AND A.CONTRACT_TYPE=? "
						+ "AND B.CARGO_NO=? AND A.BUY_SALE=? AND A.AGMT_TYPE=? "
						+ "AND A.CONT_REV = (SELECT MAX(B.CONT_REV) FROM FMS_LTCORA_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
						+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE AND A.BUY_SALE=B.BUY_SALE AND A.AGMT_TYPE=B.AGMT_TYPE) "
						+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO "
						+ "AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV AND A.CONTRACT_TYPE=B.CONTRACT_TYPE AND A.BUY_SALE=B.BUY_SALE AND A.AGMT_TYPE=B.AGMT_TYPE ";
				stmt1=conn.prepareStatement(queryString1);
				stmt1.setString(1, own_cd);
				stmt1.setString(2, countpty_cd);
				stmt1.setString(3, agmtno);
				stmt1.setString(4, agmtrev);
				stmt1.setString(5, contno);
				stmt1.setString(6, cont_type);
				stmt1.setString(7, own_cd);
				stmt1.setString(8, countpty_cd);
				stmt1.setString(9, agmtno);
				stmt1.setString(10, agmtrev);
				stmt1.setString(11, contno);
				stmt1.setString(12, cont_type);
				stmt1.setString(13, cargo_no);
				stmt1.setString(14, "C");
				stmt1.setString(15, "A");
				rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					VOTH_START_DT.add(rset1.getString(1)==null?"":rset1.getString(1));
					VOTH_END_DT.add(rset1.getString(2)==null?"":rset1.getString(2));
					VOTH_CONT_NAME.add(rset1.getString(3)==null?"":rset1.getString(3));
					
					String cont_ref_no=rset1.getString(4)==null?"":rset1.getString(4);
					String trade_ref_no=rset1.getString(5)==null?"":rset1.getString(5);
					max_contrev =rset1.getString(6)==null?"0":rset1.getString(6);
					
					if(cont_type.equals("W"))
					{
						cont_ref_no=trade_ref_no;
					}
					VOTH_CONT_REF_NO.add(cont_ref_no);
				}
				else
				{
					VOTH_START_DT.add("");
					VOTH_END_DT.add("");
					VOTH_CONT_NAME.add("");
					VOTH_CONT_REF_NO.add("");
				}
				rset1.close();
				stmt1.close();
								
				String mapping_id=cont_type+"-"+agmtno+"-"+agmtrev+"-"+contno+"-"+max_contrev;
				VMAPPING_ID.add(mapping_id);

				String inv_no="";
				String inv_seq="";
				String checked_flag="";
				String approved_flag="";
				String pdf_flg="";
				String pdf_ori="";
				String pdf_tri="";
				String pdf_dup="";
				String sap_approved_flag="";
				String irn_no="";
				String inv_cetegory=rset.getString(24)==null?"":rset.getString(24);
				String tax_struct_cd=rset.getString(25)==null?"":rset.getString(25);

				inv_no=rset.getString(12)==null?"":rset.getString(12);
				checked_flag = rset.getString(13)==null?"":rset.getString(13);
				approved_flag = rset.getString(14)==null?"":rset.getString(14);
				inv_seq = rset.getString(15)==null?"":rset.getString(15);
				String fin_yr=rset.getString(16)==null?"":rset.getString(16);
				String inv_type=rset.getString(17)==null?"":rset.getString(17);
				pdf_flg=rset.getString(18)==null?"":rset.getString(18);
				String bu_state_tin=rset.getString(19)==null?"":rset.getString(19);
				pdf_ori=rset.getString(20)==null?"":rset.getString(20);
				pdf_tri=rset.getString(21)==null?"":rset.getString(21);
				pdf_dup=rset.getString(22)==null?"":rset.getString(22);
				sap_approved_flag=rset.getString(23)==null?"":rset.getString(23);
				
				VOTH_INVOICE_NO.add(inv_no);
				VOTH_STATUS.add("");
				VOTH_INVOICE_EXIST.add("Y");
				VOTH_INVOICE_TYPE.add(inv_type);
				
				VOTH_INVOICE_SEQ.add(inv_seq);
				VOTH_FINANCIAL_YEAR.add(fin_yr);
				VOTH_INV_CHECKED_FLAG.add(checked_flag);
				VOTH_INV_APPROVED_FLAG.add(approved_flag);
				VOTH_PDF_INV_FLAG.add(pdf_flg);
				VOTH_BU_STATE_TIN.add(bu_state_tin);
				VOTH_SAP_APPROVAL_FLAG.add(sap_approved_flag);
				
				//VOTH_IS_IRN_GENERATED.add("NA");//IRN only for LTCORA
				
				if(cont_type.equals("O") || cont_type.equals("Q"))
				{
					if(inv_cetegory.equals("S") && !tax_struct_cd.equals(""))
					{
						if(Integer.parseInt(tax_struct_cd) > 0)
						{
							queryString5="SELECT IRN_NO "
									+ "FROM FMS_INVOICE_IRN_DTL "
									+ "WHERE COMPANY_CD=? AND INVOICE_NO=? ";
							stmt5=conn.prepareStatement(queryString5);
							stmt5.setString(1, comp_cd);
							stmt5.setString(2, inv_no);
							rset5=stmt5.executeQuery();
							if(rset5.next())
							{
								irn_no=rset5.getString(1)==null?"":rset5.getString(1);
							}
							rset5.close();
							stmt5.close();
							
							VOTH_IS_IRN_GENERATED.add(irn_no.equals("")?"N":"Y");
						}
						else
						{
							VOTH_IS_IRN_GENERATED.add("NA");
						}
					}
					else
					{
						VOTH_IS_IRN_GENERATED.add("NA");
					}
				}
				else
				{
					VOTH_IS_IRN_GENERATED.add("NA");
				}
				
				if(ff_print_pdf_type.equals("O") && !pdf_ori.equals(""))
				{
					VOTH_PDF_TYPE.add(ff_print_pdf_type);
				}
				else if(ff_print_pdf_type.equals("D") && !pdf_dup.equals(""))
				{
					VOTH_PDF_TYPE.add(ff_print_pdf_type);
				}
				else if(ff_print_pdf_type.equals("T") && !pdf_tri.equals(""))
				{
					VOTH_PDF_TYPE.add(ff_print_pdf_type);
				}
				else if(ff_print_pdf_type.equals("All"))
				{
					String allPdfType="";
					if(pdf_ori.equals(""))
					{
						if(allPdfType.equals(""))
						{
							allPdfType+="O";
						}
						else
						{
							allPdfType+=",O";
						}
					}
					if(pdf_dup.equals(""))
					{
						if(allPdfType.equals(""))
						{
							allPdfType+="D";
						}
						else
						{
							allPdfType+=",D";
						}
					}
					if(pdf_tri.equals(""))
					{
						if(allPdfType.equals(""))
						{
							allPdfType+="T";
						}
						else
						{
							allPdfType+=",T";
						}
					}
					if(allPdfType.equals(""))
					{
						allPdfType="All";
					}
					VOTH_PDF_TYPE.add(allPdfType);
				}
				else
				{
					VOTH_PDF_TYPE.add("");
				}
				
				if(ff_view_pdf_type.equals("All"))
				{
					queryString3="SELECT COUNT(*) "
							+ "FROM FMS_DLNG_FFLOW_INV_FILE_DTL "
							+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
		 	        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
		 	        		+ "AND INVOICE_TYPE=? AND PDF_TYPE!=?";
					stmt3=conn.prepareStatement(queryString3);
					stmt3.setString(1, own_cd);
					stmt3.setString(2, bu_state_tin);
					stmt3.setString(3, inv_seq);
					stmt3.setString(4, fin_yr);
					stmt3.setString(5, inv_type);
					stmt3.setString(6, "X");
					rset3=stmt3.executeQuery();
					if(rset3.next())
					{
						if(rset3.getInt(1)>0)
						{
							VOTH_PDF_FILE_NAME.add("All");
							VOTH_PDF_FILE_PATH.add("");
						}
						else
						{
							VOTH_PDF_FILE_NAME.add("");
							VOTH_PDF_FILE_PATH.add("");
						}
					}
					else
					{
						VOTH_PDF_FILE_NAME.add("");
						VOTH_PDF_FILE_PATH.add("");
					}
					rset3.close();
					stmt3.close();
				}
				else
				{
					queryString3="SELECT FILE_NAME,PDF_SIGNED "
							+ "FROM FMS_DLNG_FFLOW_INV_FILE_DTL "
							+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
		 	        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
		 	        		+ "AND PDF_TYPE=? AND INVOICE_TYPE=?";
					stmt3=conn.prepareStatement(queryString3);
					stmt3.setString(1, own_cd);
					stmt3.setString(2, bu_state_tin);
					stmt3.setString(3, inv_seq);
					stmt3.setString(4, fin_yr);
					stmt3.setString(5, ff_view_pdf_type);
					stmt3.setString(6, inv_type);
					rset3=stmt3.executeQuery();
					if(rset3.next())
					{
						String pdf_signed=rset3.getString(2)==null?"":rset3.getString(2);
						
						VOTH_PDF_FILE_NAME.add(rset3.getString(1)==null?"":rset3.getString(1));
						
						if(pdf_signed.equals("Y"))
						{
							VOTH_PDF_FILE_PATH.add(CommonVariable.signed_freeflow_inv_path);
						}
						else
						{
							VOTH_PDF_FILE_PATH.add(CommonVariable.freeflow_inv_path);
						}
					}
					else
					{
						VOTH_PDF_FILE_NAME.add("");
						VOTH_PDF_FILE_PATH.add("");
					}
					rset3.close();
					stmt3.close();
				}
				
				if(ff_mail_pdf_type.equals("All"))
				{
					String AllMailPdf="";
					queryString3="SELECT PDF_TYPE "
							+ "FROM FMS_DLNG_FFLOW_INV_FILE_DTL "
							+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
		 	        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
		 	        		+ "AND INVOICE_TYPE=? AND PDF_SIGNED=? AND PDF_TYPE!=?";
					stmt3=conn.prepareStatement(queryString3);
					stmt3.setString(1, own_cd);
					stmt3.setString(2, bu_state_tin);
					stmt3.setString(3, inv_seq);
					stmt3.setString(4, fin_yr);
					stmt3.setString(5, inv_type);
					stmt3.setString(6, "Y");
					stmt3.setString(7, "X");
					rset3=stmt3.executeQuery();
					while(rset3.next())
					{
						String temp=rset3.getString(1)==null?"":rset3.getString(1);
						if(AllMailPdf.equals(""))
						{
							AllMailPdf=temp;
						}
						else
						{
							AllMailPdf+=","+temp;
						}
					}
					rset3.close();
					stmt3.close();
					
					VOTH_PDF_SIGNED_FLAG.add("All");
					VOTH_SIGN_PDF_TYPE.add(AllMailPdf);
				}
				else
				{
					queryString3="SELECT FILE_NAME,PDF_SIGNED "
							+ "FROM FMS_DLNG_FFLOW_INV_FILE_DTL "
							+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
		 	        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
		 	        		+ "AND PDF_TYPE=? AND INVOICE_TYPE=? ";
					stmt3=conn.prepareStatement(queryString3);
					stmt3.setString(1, own_cd);
					stmt3.setString(2, bu_state_tin);
					stmt3.setString(3, inv_seq);
					stmt3.setString(4, fin_yr);
					stmt3.setString(5, ff_mail_pdf_type);
					stmt3.setString(6, inv_type);
					rset3=stmt3.executeQuery();
					if(rset3.next())
					{
						String pdf_signed=rset3.getString(2)==null?"":rset3.getString(2);
						VOTH_PDF_SIGNED_FLAG.add(pdf_signed);
						if(pdf_signed.equals("Y"))
						{
							VOTH_SIGN_PDF_TYPE.add(ff_mail_pdf_type);
						}
						else
						{
							VOTH_SIGN_PDF_TYPE.add("");
						}
					}
					else
					{
						VOTH_PDF_SIGNED_FLAG.add("");
						VOTH_SIGN_PDF_TYPE.add("");
					}
					rset3.close();
					stmt3.close();
				}
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	
	public void getInvDetailForPreparationList(String own_cd,String countpty_cd, String contno, String agmtno,String cont_type, String plant_seq, 
			String bu_plant_seq, String truckCd, String track_trans_cd, String period_start_dt, String period_end_dt,String state_code, String inv_flag, String mapping_id)
	{
		String function_nm="getInvDetailForPreparationList()";
		try
		{
			String inv_no="";
			String inv_seq="";
			String checked_flag="";
			String approved_flag="";
			String pdf_flg="";
			String pdf_ori="";
			String pdf_tri="";
			String pdf_dup="";
			String sap_approved_flag="";
			String fiscal_yr="";
			String irn_no="";
			String truckNo=dlng_util.getTruckRegNo(conn, truckCd);
			
			queryString5="SELECT INVOICE_NO,CHECKED_FLAG,APPROVED_FLAG,INVOICE_SEQ,PDF_INV_DTL,"
					+ "PRINT_BY_ORI,PRINT_BY_TRI,PRINT_BY_DUP,SAP_APPROVAL,FINANCIAL_YEAR "
					+ "FROM FMS_DLNG_INVOICE_MST "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? AND AGMT_NO=? AND CONTRACT_TYPE=? "
					+ "AND PLANT_SEQ=? AND BU_UNIT=? AND TRUCK_CD=? AND TRUCK_TRANS_CD=? "
					+ "AND PERIOD_START_DT=TO_DATE(?,'DD/MM/YYYY') AND PERIOD_END_DT=TO_DATE(?,'DD/MM/YYYY') "
					+ "AND BU_STATE_TIN=? AND INV_FLAG=? AND MAPPING_ID=? ";
					//+ "AND FINANCIAL_YEAR=?";
			int stcount=0;
			stmt5=conn.prepareStatement(queryString5);
			stmt5.setString(++stcount, own_cd);
			stmt5.setString(++stcount, countpty_cd);
			stmt5.setString(++stcount, contno);
			stmt5.setString(++stcount, agmtno);
			stmt5.setString(++stcount, cont_type);
			stmt5.setString(++stcount, plant_seq);
			stmt5.setString(++stcount, bu_plant_seq);
			stmt5.setString(++stcount, truckCd);
			stmt5.setString(++stcount, track_trans_cd);
			stmt5.setString(++stcount, period_start_dt);
			stmt5.setString(++stcount, period_end_dt);
			stmt5.setString(++stcount, state_code);
			stmt5.setString(++stcount, inv_flag);
			stmt5.setString(++stcount, mapping_id);
			//stmt5.setString(12, financial_year);
			rset5=stmt5.executeQuery();
			if(rset5.next())
			{
				inv_no=rset5.getString(1)==null?"":rset5.getString(1);
				checked_flag=rset5.getString(2)==null?"":rset5.getString(2);
				approved_flag=rset5.getString(3)==null?"":rset5.getString(3);
				inv_seq=rset5.getString(4)==null?"":rset5.getString(4);
				pdf_flg=rset5.getString(5)==null?"":rset5.getString(5);
				pdf_ori=rset5.getString(6)==null?"":rset5.getString(6);
				pdf_tri=rset5.getString(7)==null?"":rset5.getString(7);
				pdf_dup=rset5.getString(8)==null?"":rset5.getString(8);
				sap_approved_flag=rset5.getString(9)==null?"":rset5.getString(9);
				fiscal_yr=rset5.getString(10)==null?"":rset5.getString(10);
				
				VINVOICE_EXIST.add("Y");
			}
			else
			{
				VINVOICE_EXIST.add("N");
			}
			rset5.close();
			stmt5.close();
			
			//if(cont_type.equals("O") || cont_type.equals("Q"))
			{
				/*queryString5="SELECT IRN_NO "
						+ "FROM FMS_INVOICE_IRN_DTL "
						+ "WHERE COMPANY_CD=? AND INVOICE_NO=? ";
				stmt5=conn.prepareStatement(queryString5);
				stmt5.setString(1, comp_cd);
				stmt5.setString(2, inv_no);
				rset5=stmt5.executeQuery();
				if(rset5.next())
				{
					irn_no=rset5.getString(1)==null?"":rset5.getString(1);
				}
				rset5.close();
				stmt5.close();
				
				VIS_IRN_GENERATED.add(irn_no.equals("")?"N":"Y");*/
			}
			//else
			{
				VIS_IRN_GENERATED.add("Y"); //other then LTCORA, Default 'Y'
			}
			
			//FOR FORM 402
			String work_data=utilBean.getAutomationKeyDetail(conn, "WORK_DATA_"+comp_cd);
			String file_path=work_data+File.separator+CommonVariable.form_402_dir;
			String form402_fileNm=inv_no.replace("/", "-")+"_"+truckNo+".xlsx";
			if(new File(file_path+File.separator+form402_fileNm).exists())
			{
				VGENERATED_FORM_402_PATH.add(CommonVariable.work_dir+comp_cd+File.separator+CommonVariable.form_402_dir+File.separator+form402_fileNm);
			}
			else
			{
				VGENERATED_FORM_402_PATH.add("");
			}
			
			
			VINVOICE_NO.add(inv_no);
			VINVOICE_SEQ.add(inv_seq);
			VINV_CHECKED_FLAG.add(checked_flag);
			VINV_APPROVED_FLAG.add(approved_flag);
			VPDF_INV_FLAG.add(pdf_flg);
			VSAP_APPROVAL_FLAG.add(sap_approved_flag);
			VFINANCIAL_YEAR.add(fiscal_yr);
			
			if(print_pdf_type.equals("O") && !pdf_ori.equals(""))
			{
				VPDF_TYPE.add(print_pdf_type);
			}
			else if(print_pdf_type.equals("D") && !pdf_dup.equals(""))
			{
				VPDF_TYPE.add(print_pdf_type);
			}
			else if(print_pdf_type.equals("T") && !pdf_tri.equals(""))
			{
				VPDF_TYPE.add(print_pdf_type);
			}
			else if(print_pdf_type.equals("All"))
			{
				String allPdfType="";
				allPdfType+=pdf_ori.equals("")?allPdfType.equals("")?"O":",O":"";
				allPdfType+=pdf_dup.equals("")?allPdfType.equals("")?"D":",D":"";
				allPdfType+=pdf_tri.equals("")?allPdfType.equals("")?"T":",T":"";
				
				if(allPdfType.equals(""))
				{
					allPdfType="All";
				}
				VPDF_TYPE.add(allPdfType);
			}
			else
			{
				VPDF_TYPE.add("");
			}
			
			if(view_pdf_type.equals("All"))
			{
				queryString6="SELECT COUNT(*) "
						+ "FROM FMS_DLNG_INV_FILE_DTL "
						+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
	 	        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
	 	        		+ "AND PDF_TYPE!=?";
				stmt6=conn.prepareStatement(queryString6);
				stmt6.setString(1, own_cd);
				stmt6.setString(2, state_code);
				stmt6.setString(3, inv_seq);
				//stmt6.setString(4, financial_year);
				stmt6.setString(4, fiscal_yr);
				stmt6.setString(5, "X");
				rset6=stmt6.executeQuery();
				if(rset6.next())
				{
					if(rset6.getInt(1)>0)
					{
						VPDF_FILE_NAME.add("All");
						VPDF_FILE_PATH.add("");
					}
					else
					{
						VPDF_FILE_NAME.add("");
						VPDF_FILE_PATH.add("");
					}
				}
				else
				{
					VPDF_FILE_NAME.add("");
					VPDF_FILE_PATH.add("");
				}
				rset6.close();
				stmt6.close();
			}
			else
			{
				queryString6="SELECT FILE_NAME,PDF_SIGNED "
						+ "FROM FMS_DLNG_INV_FILE_DTL "
						+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
	 	        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
	 	        		+ "AND PDF_TYPE=?";
				stmt6=conn.prepareStatement(queryString6);
				stmt6.setString(1, own_cd);
				stmt6.setString(2, state_code);
				stmt6.setString(3, inv_seq);
				//stmt6.setString(4, financial_year);
				stmt6.setString(4, fiscal_yr);
				stmt6.setString(5, view_pdf_type);
				rset6=stmt6.executeQuery();
				if(rset6.next())
				{
					String pdf_signed=rset6.getString(2)==null?"":rset6.getString(2);
					
					VPDF_FILE_NAME.add(rset6.getString(1)==null?"":rset6.getString(1));
					if(pdf_signed.equals("Y"))
					{
						VPDF_FILE_PATH.add(CommonVariable.signed_dlng_sales_inv_path);
					}
					else
					{
						VPDF_FILE_PATH.add(CommonVariable.dlng_sales_inv_path);
					}
				}
				else
				{
					VPDF_FILE_NAME.add("");
					VPDF_FILE_PATH.add("");
				}
				rset6.close();
				stmt6.close();
			}
			
			if(mail_pdf_type.equals("All"))
			{
				String AllMailPdf="";
				queryString6="SELECT PDF_TYPE "
						+ "FROM FMS_DLNG_INV_FILE_DTL "
						+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
	 	        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
	 	        		+ "AND PDF_SIGNED=? AND PDF_TYPE!=?";
				stmt6=conn.prepareStatement(queryString6);
				stmt6.setString(1, own_cd);
				stmt6.setString(2, state_code);
				stmt6.setString(3, inv_seq);
				//stmt6.setString(4, financial_year);
				stmt6.setString(4, fiscal_yr);
				stmt6.setString(5, "Y");
				stmt6.setString(6, "X");
				rset6=stmt6.executeQuery();
				while(rset6.next())
				{
					String temp=rset6.getString(1)==null?"":rset6.getString(1);
					if(AllMailPdf.equals(""))
					{
						AllMailPdf=temp;
					}
					else
					{
						AllMailPdf+=","+temp;
					}
					
				}
				rset6.close();
				stmt6.close();
				
				VPDF_SIGNED_FLAG.add("All");
				VSIGN_PDF_TYPE.add(AllMailPdf);
			}
			else
			{
				queryString6="SELECT FILE_NAME,PDF_SIGNED "
						+ "FROM FMS_DLNG_INV_FILE_DTL "
						+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
	 	        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
	 	        		+ "AND PDF_TYPE=?";
				stmt6=conn.prepareStatement(queryString6);
				stmt6.setString(1, own_cd);
				stmt6.setString(2, state_code);
				stmt6.setString(3, inv_seq);
				//stmt6.setString(4, financial_year);
				stmt6.setString(4, fiscal_yr);
				stmt6.setString(5, view_pdf_type);
				rset6=stmt6.executeQuery();
				if(rset6.next())
				{
					String pdf_signed=rset6.getString(2)==null?"":rset6.getString(2);
					VPDF_SIGNED_FLAG.add(pdf_signed);
					if(pdf_signed.equals("Y"))
					{
						VSIGN_PDF_TYPE.add(mail_pdf_type);
					}
					else
					{
						VSIGN_PDF_TYPE.add("");
					}
				}
				else
				{
					VPDF_SIGNED_FLAG.add("");
					VSIGN_PDF_TYPE.add("");
				}
				rset6.close();
				stmt6.close();
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getContractDetail()
	{
		String function_nm="getContractDetail()";
		try
		{
			couterpty_abbr=""+utilBean.getCounterpartyABBR(conn,counterparty_cd);
			couterpty_nm=""+utilBean.getCounterpartyName(conn,counterparty_cd);
			plant_abbr=utilBean.getCounterpartyPlantABBR(conn,counterparty_cd, comp_cd, plant_seq, "C");
			bu_plant_abbr=utilBean.getCounterpartyPlantABBR(conn,comp_cd, comp_cd, bu_unit, "B");
			
			queryString="SELECT COMPANY_CD,COUNTERPARTY_CD,AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,"
					+ "TO_CHAR(START_DT,'DD/MM/YYYY'),TO_CHAR(END_DT,'DD/MM/YYYY'),CONT_NAME,CONT_REF_NO,CONTRACT_TYPE,"
					+ "RATE,RATE_UNIT,TRADE_REF_NO,AGMT_BASE "
					+ "FROM FMS_SUPPLY_CONT_MST "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND AGMT_NO=? AND AGMT_REV=? "
					+ "AND CONT_NO=? AND CONT_REV=? "
					+ "AND CONTRACT_TYPE=?";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, agmt_no);
			stmt.setString(4, agmt_rev_no);
			stmt.setString(5, cont_no);
			stmt.setString(6, cont_rev_no);
			stmt.setString(7, contract_type);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				String agmtno=rset.getString(3)==null?"0":rset.getString(3);
				String agmtrev=rset.getString(4)==null?"0":rset.getString(4);
				String contno=rset.getString(5)==null?"0":rset.getString(5);
				String contrev=rset.getString(6)==null?"0":rset.getString(6);
				cont_start_dt = rset.getString(7)==null?"":rset.getString(7);
				String cont_type=rset.getString(11)==null?"":rset.getString(11);
				String contRef=rset.getString(10)==null?"":rset.getString(10);
				String tradeRef=rset.getString(14)==null?"":rset.getString(14);
				agmt_base=rset.getString(15)==null?"":rset.getString(15);
				
				if(cont_type.equals("X"))
				{
					contRef=tradeRef;
				}
				contract_ref=contRef;
				deal_no=utilBean.NewDealMappingId(comp_cd, counterparty_cd, agmtno, agmtrev, contno, contrev, cont_type, "")+" ["+contRef+"]";
				
				price_cd = rset.getString(13)==null?"2":rset.getString(13);
				price = utilBean.RateNumberFormat(rset.getDouble(12), price_cd);
				price_cd_nm=""+utilBean.getRateUnitNm(conn,price_cd);
			}
			else
			{
				price="0.00";
				price_cd="2";
				price_cd_nm=""+utilBean.getRateUnitNm(conn,price_cd);
			}
			rset.close();
			stmt.close();	
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getContractBillingDetail()
	{
		String function_nm="getContractBillingDetail()";
		try
		{
			queryString="SELECT INVOICE_CUR_CD,PAYMENT_CUR_CD,DUE_DATE,EXCHNG_RATE_CD,EXCHNG_CRITERIA,EXCHNG_RATE_CAL,DUE_DT_IN,"
					+ "EXCL_SAT_MAP,EXCHG_VAL,HOLIDAY_STATE,BILLING_FREQ,BILLING_DAYS "
					+ "FROM FMS_SUPPLY_BILLING_DTL A "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND AGMT_NO=? "//AND AGMT_REV='"+agmt_rev_no+"' "
					+ "AND CONT_NO=? "//AND CONT_REV='"+cont_rev_no+"' "
					+ "AND CONTRACT_TYPE=? AND PLANT_SEQ_NO=? "
					+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_SUPPLY_BILLING_DTL B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_NO=B.AGMT_NO AND A.CONT_NO=B.CONT_NO AND A.PLANT_SEQ_NO=B.PLANT_SEQ_NO "
					+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE AND B.EFF_DT<=TO_DATE(?,'DD/MM/YYYY')) ";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, agmt_no);
			stmt.setString(4, cont_no);
			stmt.setString(5, contract_type);
			stmt.setString(6, plant_seq);
			stmt.setString(7, period_end_dt);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				invoice_raised_in = rset.getString(1)==null?"2":rset.getString(1);
				invoice_raised_in_nm=""+utilBean.getRateUnitNm(conn,invoice_raised_in);
				//payment_done_in = rset.getString(2)==null?"2":rset.getString(2);
				//payment_done_in_nm=""+utilBean.getRateUnitNm(payment_done_in);
				due_days = rset.getString(3)==null?"0":rset.getString(3);
				exchng_rate_cd = rset.getString(4)==null?"":rset.getString(4);
				exchang_criteria = rset.getString(5)==null?"":rset.getString(5);
				exchng_rate_cal = rset.getString(6)==null?"":rset.getString(6);
				
				consider_due_dt_in=rset.getString(7)==null?"C":rset.getString(7);
				exclude_sat=rset.getString(8)==null?"":rset.getString(8);
				
				fixed_exchng_val=nf2.format(rset.getDouble(9));
				
				holiday_state=rset.getString(10)==null?"":rset.getString(10);
				billing_freq=rset.getString(11)==null?"":rset.getString(11);
				billing_days=rset.getString(12)==null?"":rset.getString(12);
				
			}
			else
			{	
				invoice_raised_in="2";
				invoice_raised_in_nm=""+utilBean.getRateUnitNm(conn,invoice_raised_in);
				
				consider_due_dt_in="C";
				exclude_sat="";
				holiday_state="";
				
				fixed_exchng_val=nf2.format(0);
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getContactPerson()
	{
		String function_nm="getContactPerson()";
		try
		{
			queryString="SELECT CONTACT_PERSON, SEQ_NO "
					+ "FROM FMS_ENTITY_CONTACT_MST A "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND ENTITY=? AND ADDR_FLAG=? AND INV_FLAG=? "
					+ "AND ACTIVE_FLAG=? AND ADDR_IS_ACTIVE=? AND TYPE=? "
					+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO AND A.TYPE=B.TYPE "
					+ "AND EFF_DT <= TO_DATE(TO_CHAR(SYSDATE,'DD/MM/YYYY'),'DD/MM/YYYY'))";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, "C");
			stmt.setString(4, "P"+plant_seq);
			stmt.setString(5, "Y");
			stmt.setString(6, "Y");
			stmt.setString(7, "Y");
			stmt.setString(8, "DLNG");
			rset=stmt.executeQuery();
			while(rset.next())
			{
				VCONTACT_PERSON.add(rset.getString(1)==null?"":rset.getString(1));
				VCONTACT_PERSON_CD.add(rset.getString(2)==null?"":rset.getString(2));
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getBuContactPerson()
	{
		String function_nm="getBuContactPerson()";
		try
		{
			queryString="SELECT CONTACT_PERSON, SEQ_NO "
					+ "FROM FMS_ENTITY_CONTACT_MST A "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND ENTITY=? AND ADDR_FLAG=? AND INV_FLAG=? "
					+ "AND ACTIVE_FLAG=? AND ADDR_IS_ACTIVE=? AND TYPE=? "
					+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO AND A.TYPE=B.TYPE "
					+ "AND EFF_DT <= TO_DATE(TO_CHAR(SYSDATE,'DD/MM/YYYY'),'DD/MM/YYYY'))";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, comp_cd);
			stmt.setString(3, "B");
			stmt.setString(4, "P"+bu_unit);
			stmt.setString(5, "Y");
			stmt.setString(6, "Y");
			stmt.setString(7, "Y");
			stmt.setString(8, "DLNG");
			rset=stmt.executeQuery();
			while(rset.next())
			{
				VBU_CONTACT_PERSON.add(rset.getString(1)==null?"":rset.getString(1));
				VBU_CONTACT_PERSON_CD.add(rset.getString(2)==null?"":rset.getString(2));
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getExistingInvoiceDtl()
	{
		String function_nm="getExistingInvoiceDtl()";
		try
		{
			queryString="SELECT BU_CONTACT_PERSON_CD,CONTACT_PERSON_CD,INVOICE_SEQ,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),"
					+ "TO_CHAR(DUE_DT,'DD/MM/YYYY'),ALLOC_QTY,SALE_PRICE,SALE_PRICE_UNIT,SALE_AMT,EXCHG_RATE_CD,TO_CHAR(EXCHG_RATE_DT,'DD/MM/YYYY'),"
					+ "EXCHG_RATE_VALUE,INVOICE_RAISED_IN,GROSS_AMT,TAX_AMT,TAX_STRUCT_CD,TO_CHAR(TAX_EFF_DT,'DD/MM/YYYY'),INVOICE_AMT,NET_PAYABLE_AMT,"
					+ "REMARK_1,REMARK_2,TCS_TDS,TCS_AMT,TCS_FACTOR,NULL,NULL,TCS_STRUCT_CD,TO_CHAR(TCS_EFF_DT,'DD/MM/YYYY'),"
					+ "TDS_GROSS_AMT,TDS_GROSS_PERCENT,TDS_STRUCT_CD,TO_CHAR(TDS_EFF_DT,'DD/MM/YYYY'),NULL,NULL,NULL,NULL,"
					+ "TO_CHAR(ENT_DT,'DD/MM/YYYY HH24:MI:SS'),TO_CHAR(APPROVED_DT,'DD/MM/YYYY HH24:MI:SS'),FINANCIAL_YEAR,CHKPOST_CD,DRIVER_CD "
					+ "FROM FMS_DLNG_INVOICE_MST "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? "
					+ "AND AGMT_NO=? AND PLANT_SEQ=? AND BU_UNIT=? AND CONTRACT_TYPE=? AND BU_STATE_TIN=? "
					+ "AND PERIOD_START_DT=TO_DATE(?,'DD/MM/YYYY') AND PERIOD_END_DT=TO_DATE(?,'DD/MM/YYYY') AND FINANCIAL_YEAR=? "
					+ "AND MAPPING_ID=? AND INV_FLAG=? AND TRUCK_TRANS_CD=? AND TRUCK_CD=? ";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, cont_no);
			stmt.setString(4, agmt_no);
			stmt.setString(5, plant_seq);
			stmt.setString(6, bu_unit);
			stmt.setString(7, contract_type);
			stmt.setString(8, bu_state_tin);
			stmt.setString(9, period_start_dt);
			stmt.setString(10, period_end_dt);
			stmt.setString(11, exist_financial_year);
			stmt.setString(12, mapping_id);
			stmt.setString(13, inv_flag);
			stmt.setString(14, truck_trans_cd);
			stmt.setString(15, truck_cd);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				submission_chk=true;
				
				bu_contact_person_cd=rset.getString(1)==null?"0":rset.getString(1);
				contact_person_cd=rset.getString(2)==null?"0":rset.getString(2);
				invoice_seq=rset.getString(3)==null?"":rset.getString(3);
				invoice_no=rset.getString(4)==null?"":rset.getString(4);
				invoice_dt=rset.getString(5)==null?"":rset.getString(5);
				invoice_due_dt=rset.getString(6)==null?"":rset.getString(6);
				
				exchng_rate_cd=rset.getString(11)==null?"":rset.getString(11);
				exchang_rate_dt=rset.getString(12)==null?"":rset.getString(12);
				exchang_rate=rset.getString(13)==null?"":nf2.format(rset.getDouble(13));
				
				if(operation.equals("INSERT"))
				{
					qty_mmbtu=rset.getString(7)==null?"":nf.format(rset.getDouble(7));
					price=rset.getString(8)==null?"":nf.format(rset.getDouble(8));
					price_cd=rset.getString(9)==null?"":rset.getString(9);
					if(!price.equals(""))
					{
						price=utilBean.RateNumberFormat(rset.getDouble(8), price_cd);
					}
					gross_amt=rset.getString(10)==null?"":nf.format(rset.getDouble(10));
					
					invoice_raised_in=rset.getString(14)==null?"":rset.getString(14);
					gross_amt1=rset.getString(15)==null?"":nf.format(rset.getDouble(15));
					tax_amt=rset.getString(16)==null?"":nf.format(rset.getDouble(16));
					tax_struct_cd=rset.getString(17)==null?"":rset.getString(17);
					tax_struct_dt=rset.getString(18)==null?"":rset.getString(18);
					invoice_amt=rset.getString(19)==null?"":nf.format(rset.getDouble(19));
					net_payable=rset.getString(20)==null?"":nf.format(rset.getDouble(20));
					
					applicable_abbr=rset.getString(23)==null?"":rset.getString(23);
					applicable_amt=rset.getString(24)==null?"":rset.getString(24);
					TCS_factor=rset.getString(25)==null?"":rset.getString(25);
					
					//tax_struct_dtl=utilBean.getEntityTaxStructureDtl(conn,comp_cd, counterparty_cd, "C", plant_seq, bu_unit, period_start_dt);
					tax_struct_dtl=utilBean.getTaxDescr(conn, tax_struct_cd);
					
					/*queryString1="SELECT TAX_STRUCT_DTL "
							+ "FROM FMS_ENTITY_TAX_STRUCT_DTL A "
							+ "WHERE A.COMPANY_CD='"+comp_cd+"' AND A.TAX_STRUCT_CD='"+tax_struct_cd+"' "
							+ "AND A.ENTITY='C' AND A.COUNTERPARTY_CD='"+counterparty_cd+"' AND A.PLANT_SEQ_NO='"+plant_seq+"' AND A.BU_UNIT='"+bu_unit+"' "
							+ "AND A.TAX_STRUCT_DT=(SELECT MAX(D.TAX_STRUCT_DT) FROM FMS_ENTITY_TAX_STRUCT_DTL D WHERE A.COMPANY_CD=D.COMPANY_CD "
							+ "AND A.ENTITY=D.ENTITY AND A.COUNTERPARTY_CD=D.COUNTERPARTY_CD AND A.PLANT_SEQ_NO=D.PLANT_SEQ_NO "
							+ "AND D.TAX_STRUCT_DT <= TO_DATE('"+tax_struct_dt+"','DD/MM/YYYY') AND A.BU_UNIT=D.BU_UNIT) ";
					rset1=stmt1.executeQuery(queryString1);
					if(rset1.next())
					{
						tax_struct_dtl=rset1.getString(1)==null?"":rset1.getString(1);
					}*/
					
					transportation_charges=rset.getString(26)==null?"":nf2.format(rset.getDouble(26));
					transportation_amount=rset.getString(27)==null?"":nf.format(rset.getDouble(27));
					
					tcs_struct_cd=rset.getString(28)==null?"":rset.getString(28);
					tcs_struct_dt=rset.getString(29)==null?"":rset.getString(29);
					
					tds_amt=rset.getString(30)==null?"":nf.format(rset.getDouble(30));
					tds_factor=rset.getString(31)==null?"":nf.format(rset.getDouble(31));
					tds_struct_cd=rset.getString(32)==null?"":rset.getString(32);
					tds_struct_dt=rset.getString(33)==null?"":rset.getString(33);
					
					marketing_margin=rset.getString(34)==null?"":nf.format(rset.getDouble(34));
					marketing_margin_amount=rset.getString(35)==null?"":nf.format(rset.getDouble(35));
					other_charges=rset.getString(36)==null?"":nf.format(rset.getDouble(36));
					other_charges_amount=rset.getString(37)==null?"":nf.format(rset.getDouble(37));
					inv_entered_on = rset.getString(38)==null?"":rset.getString(38);
					inv_approved_on = rset.getString(39)==null?"":rset.getString(39);
					
					String fiscal_yr=rset.getString(40)==null?"":rset.getString(40);
					linked_checkpost_cd=rset.getString(41)==null?"":rset.getString(41);
					linked_driver_cd=rset.getString(42)==null?"":rset.getString(42);
					
					gross_include_transport_tariff=nf.format(Double.parseDouble(gross_amt1));
					if(!transportation_amount.equals(""))
					{
						gross_include_transport_tariff=nf.format(Double.parseDouble(gross_include_transport_tariff) + Double.parseDouble(transportation_amount));
						//isGrossIncTriff=true;
					}
					if(!marketing_margin_amount.equals(""))
					{
						gross_include_transport_tariff=nf.format(Double.parseDouble(gross_include_transport_tariff) + Double.parseDouble(marketing_margin_amount));
						//isGrossIncTriff=true;
					}
					if(!other_charges_amount.equals(""))
					{
						gross_include_transport_tariff=nf.format(Double.parseDouble(gross_include_transport_tariff) + Double.parseDouble(other_charges_amount));
						//isGrossIncTriff=true;
					}
					
					Vector VTAX_CODE = new Vector();
					Vector VTAX_DESCR = new Vector();
					Vector VTAX_AMT = new Vector();
					Vector VTAX_BASE_AMT = new Vector();
					Vector VTAX_FACTOR = new Vector();
					queryString1="SELECT TAX_CODE,TAX_DESCR,TAX_AMT,TAX_BASE_AMT "
							+ "FROM FMS_DLNG_INV_TAX_DTL "
							+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
							+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
					stmt1=conn.prepareStatement(queryString1);
					stmt1.setString(1, comp_cd);
					stmt1.setString(2, bu_state_tin);
					//stmt1.setString(3, financial_year);
					stmt1.setString(3, fiscal_yr);
					stmt1.setString(4, invoice_seq);
					rset1=stmt1.executeQuery();
					while(rset1.next())
					{
						VTAX_CODE.add(rset1.getString(1)==null?"":rset1.getString(1));
						VTAX_DESCR.add(rset1.getString(2)==null?"":rset1.getString(2));
						VTAX_AMT.add(rset1.getString(3)==null?"":nf.format(rset1.getDouble(3)));
						VTAX_BASE_AMT.add(rset1.getString(4)==null?"":nf.format(rset1.getDouble(4)));
						VTAX_FACTOR.add("");
					}
					rset1.close();
					stmt1.close();
					
					Vector VTEMP_TAX_DTL = new Vector();
					
					VTEMP_TAX_DTL.add(VTAX_CODE);
					VTEMP_TAX_DTL.add(VTAX_DESCR);
					VTEMP_TAX_DTL.add(VTAX_AMT);
					VTEMP_TAX_DTL.add(VTAX_BASE_AMT);
					VTEMP_TAX_DTL.add(VTAX_FACTOR);
					
					VMULTI_TAX_STRUCT.add(VTEMP_TAX_DTL);
				}
				
				remark_1=rset.getString(21)==null?"":rset.getString(21);
				remark_2=rset.getString(22)==null?"":rset.getString(22);
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getInvoiceDateCalc()
	{
		String function_nm="getInvoiceDateCalc()";
		try
		{
			if((operation.equals("INSERT") && !submission_chk) || operation.equals("MODIFY"))
			{
				if(inv_dt.equals(""))
				{
					if(operation.equals("INSERT"))
					{
						invoice_dt=period_end_dt;
					}
				}
				else
				{
					invoice_dt=inv_dt;
				}
				
				financial_year=utilDate.getFinancialYear(invoice_dt);
				
				String freq_date=getBillingPeriodEndDate(billing_freq, period_end_dt, billing_days, invoice_dt);
				
				//HP202301011 AS DISCUSSED WITH VIJAY, INVOICE DUE DATE SHOULD BE CALCULATED BASED ON SYSTEM DATE
				//String systemDt=utilDate.getSysdate();
				invoice_due_dt=""+utilBean.DueDateCalculation(conn,freq_date, due_days,consider_due_dt_in,exclude_sat,comp_cd,holiday_state);
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}

	public void getInvoiceCalculation()
	{
		String function_nm="getInvoiceCalculation()";
		try
		{
			if((operation.equals("INSERT") && !submission_chk))// || operation.equals("MODIFY"))
			{
				String temp_contact_person_cd=utilBean.getEntityContactPersonCd(conn,comp_cd,counterparty_cd,"C","P"+plant_seq, "INV", "DLNG","Y");
				contact_person_cd=temp_contact_person_cd.equals("")?"0":temp_contact_person_cd;
				
				String temp_bu_contact_person_cd=utilBean.getEntityContactPersonCd(conn,comp_cd,comp_cd,"B","P"+bu_unit, "INV", "DLNG","Y");
				bu_contact_person_cd=temp_bu_contact_person_cd.equals("")?"0":temp_bu_contact_person_cd;
			}
			
			if((operation.equals("INSERT") && !submission_chk) || operation.equals("MODIFY"))
			{
				//GET SALES PRICE
				String new_price="";
				queryString = "SELECT DISTINCT NEW_SALE_PRICE "
						+ "FROM FMS_SUPPLY_ALLOC_REVISED A "
						+ "WHERE COMPANY_CD=? AND AGMT_NO=? AND CONT_NO=? "
						+ "AND COUNTERPARTY_CD=? AND FLAG=? AND CONTRACT_TYPE=? "
						+ "AND MODIFICATION_SEQ_NO = (SELECT MAX(MODIFICATION_SEQ_NO) FROM FMS_SUPPLY_ALLOC_REVISED B "
						+ "WHERE A.COMPANY_CD=B.COMPANY_CD AND A.AGMT_NO=B.AGMT_NO AND A.CONT_NO=B.CONT_NO "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.FLAG=B.FLAG AND A.CONTRACT_TYPE=B.CONTRACT_TYPE "
						+ "AND B.NEW_PRICE_EFF_DT <=TO_DATE(?,'DD/MM/YYYY'))";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, agmt_no);
				stmt.setString(3, cont_no);
				stmt.setString(4, counterparty_cd);
				stmt.setString(5, "A");
				stmt.setString(6, contract_type);
				stmt.setString(7, period_end_dt);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					new_price=rset.getString(1)==null?"":rset.getString(1);
					if(!new_price.equals(""))
					{
						price=utilBean.RateNumberFormat(rset.getDouble(1), price_cd);
					}
				}
				rset.close();
				stmt.close();
				
				int selCnt=0;
				String fill_station_cd="";
				String bay_cd="";
				String slot_start_time="";
				String slot_end_time="";
				
				if(!mapping_id.equals(""))
				{
					String split[]=mapping_id.split("-");
					fill_station_cd=split[0];
					bay_cd=split[1];
					slot_start_time=split[2];
					slot_end_time=split[3];
				}
				queryString1="SELECT SUM(QTY_MMBTU) "
						+ "FROM FMS_DLNG_ALLOC_MST A "
						+ "WHERE CONT_NO=? AND AGMT_NO=? "
						+ "AND COMPANY_CD=? AND COUNTERPARTY_CD=? "
						+ "AND PLANT_SEQ=? AND CONTRACT_TYPE=? AND BU_SEQ=? "
						+ "AND GAS_DT=TO_DATE(?,'DD/MM/YYYY') AND TRUCK_TRANS_CD=? AND TRUCK_CD=? "
						+ "AND FILL_STATION_CD=? AND BAY_CD=? "
						+ "AND SLOT_START_TIME=? AND SLOT_END_TIME=? "
						+ "AND NOM_REV_NO=(SELECT MAX(NOM_REV_NO) FROM FMS_DLNG_ALLOC_MST B "
						+ "WHERE B.CONT_NO=A.CONT_NO AND B.AGMT_NO=A.AGMT_NO "
						+ "AND B.COMPANY_CD=A.COMPANY_CD AND B.COUNTERPARTY_CD=A.COUNTERPARTY_CD "
						+ "AND B.BU_SEQ=A.BU_SEQ "
						+ "AND B.PLANT_SEQ=A.PLANT_SEQ AND B.CONTRACT_TYPE=A.CONTRACT_TYPE "
						+ "AND B.GAS_DT=A.GAS_DT AND B.TRUCK_TRANS_CD=A.TRUCK_TRANS_CD AND A.TRUCK_CD=B.TRUCK_CD "
						+ "AND B.FILL_STATION_CD=A.FILL_STATION_CD AND B.BAY_CD=A.BAY_CD "
						+ "AND B.SLOT_START_TIME=A.SLOT_START_TIME AND B.SLOT_END_TIME=A.SLOT_END_TIME) "
						+ "ORDER BY TRUCK_CD";
				stmt1 = conn.prepareStatement(queryString1);
				stmt1.setString(++selCnt, cont_no);
				stmt1.setString(++selCnt, agmt_no);
				stmt1.setString(++selCnt, comp_cd);
				stmt1.setString(++selCnt, counterparty_cd);
				stmt1.setString(++selCnt, plant_seq);
				stmt1.setString(++selCnt, contract_type);
				stmt1.setString(++selCnt, bu_unit);
				stmt1.setString(++selCnt, period_end_dt); //gas date
				stmt1.setString(++selCnt, truck_trans_cd);
				stmt1.setString(++selCnt, truck_cd);
				stmt1.setString(++selCnt, fill_station_cd);
				stmt1.setString(++selCnt, bay_cd);
				stmt1.setString(++selCnt, slot_start_time);
				stmt1.setString(++selCnt, slot_end_time);
				rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					qty_mmbtu=nf.format(rset1.getDouble(1));
				}
				rset1.close();
				stmt1.close();
			}
			
			if(price_cd.equals("2") && exchng_rate_cd.equals("0")) //FOR FIXED EXCHANGE RATE //JD20230929 00:47
			{
				double exchng_rate=Double.parseDouble(fixed_exchng_val);
				exchang_rate_dt="";
				exchang_rate=nf2.format(exchng_rate);
			}
			
			//if(Double.parseDouble(qty_mmbtu) > 0)
			{
				if((operation.equals("INSERT") && !submission_chk) || operation.equals("MODIFY"))
				{
					gross_amt = nf.format(Double.parseDouble(qty_mmbtu) * Double.parseDouble(price));
				}
				
				if(price_cd.equals("2"))
				{
					if(exchng_rate_cal.equals("A")) //AS THIS FUNCTIONALITY IS NOT SUPPORTED IN FMS8 DLNG, SO PASSING 'D' DEFAULT VALUE
					{
						exchng_rate_cal="D";
						exchang_criteria="INV";
					}
					getExchangeRateMaster();
					getExchangeRateCalculation();
				}
				else
				{
					gross_amt1 = gross_amt;
				}
				
				if((operation.equals("INSERT") && !submission_chk) || operation.equals("MODIFY"))
				{
					Vector temp = new Vector();
					gross_include_transport_tariff=gross_amt1;	
					temp=TaxCalc.TaxAmountCalculationWithInfo(conn, comp_cd, counterparty_cd, "C", plant_seq, bu_unit, period_start_dt, gross_include_transport_tariff);
					
					tax_amt = nf.format(Double.parseDouble(""+temp.elementAt(0)));
					tax_struct_cd = ""+temp.elementAt(1);
					tax_struct_dt = ""+temp.elementAt(2);
					tax_info = ""+temp.elementAt(3);
					tax_struct_dtl = ""+temp.elementAt(4);
					tax_factor = ""+temp.elementAt(5);
					
					VMULTI_TAX_STRUCT.add(temp.elementAt(6));
				}
				
				if(tax_struct_cd.equals(""))
				{
					tax_amt="";
					invoice_amt = nf.format(Double.parseDouble(gross_include_transport_tariff));
				}
				else
				{
					//invoice_amt = nf.format(Double.parseDouble(gross_amt1) + Double.parseDouble(tax_amt));
					invoice_amt = nf.format(Double.parseDouble(gross_include_transport_tariff) + Double.parseDouble(tax_amt)); //20230911 THIS IS NOT TESTED ERLIER BUT I THINK IT SHOULDE BE PLUSE WITH GROSS_INCLUDE_TRANS_TARIFF
				}
				
				if((operation.equals("INSERT") && !submission_chk) || operation.equals("MODIFY"))
				{
					net_payable=invoice_amt;
				}
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getChekPostandDriverMst()
	{
		String function_nm="getChekPostandDriverMst()";
		try
		{
			if((operation.equals("INSERT") && !submission_chk) || operation.equals("MODIFY"))
			{
				//AVAILABLE DRIVERS FOR LINKED TRANSPORTER
				queryString1 = "SELECT DRIVER_CD "
						+ "FROM FMS_TRUCK_DRIVER_TRANS_LINK A "
						+ "WHERE A.TRUCK_TRANS_CD=? AND A.LINK_SEQ=(SELECT MAX(B.LINK_SEQ) FROM FMS_TRUCK_DRIVER_TRANS_LINK B WHERE A.DRIVER_CD=B.DRIVER_CD ) "
						+ "ORDER BY DRIVER_CD";
				stmt1=conn.prepareStatement(queryString1);
				stmt1.setString(1, truck_trans_cd);
				rset1 = stmt1.executeQuery();
				while(rset1.next())
				{
					String driver_cd = rset1.getString(1)==null?"":rset1.getString(1);
					String driver_nm=dlng_util.getDriverName(conn, driver_cd);
					
					VDRIVER_CD.add(driver_cd);
					VDRIVER_NM.add(driver_nm);
				}
				rset1.close();
				stmt1.close();
				
				//SELECTED DRIVER DETAIL
				queryString1="SELECT DRIVER_CD "
						+ "FROM FMS_TRUCK_DRIVER_LINK A "
						+ "WHERE TRUCK_CD=? "
						+ "AND EFF_DT=(SELECT MAX(EFF_DT) FROM FMS_TRUCK_DRIVER_LINK B WHERE A.TRUCK_CD=B.TRUCK_CD "
						+ "AND A.LINK_SEQ=B.LINK_SEQ AND A.DRIVER_CD=B.DRIVER_CD AND B.EFF_DT <= TO_DATE(?,'DD/MM/YYYY')) "
						+ "AND LINK_SEQ=(SELECT MAX(LINK_SEQ) FROM FMS_TRUCK_DRIVER_LINK B WHERE A.DRIVER_CD=B.DRIVER_CD) ";
				stmt1=conn.prepareStatement(queryString1);
				stmt1.setString(1, truck_cd);
				stmt1.setString(2, period_end_dt);
				rset1 = stmt1.executeQuery();
				if(rset1.next())
				{
					linked_driver_cd = rset1.getString(1)==null?"":rset1.getString(1);
				}
				rset1.close();
				stmt1.close();
				
				//////////////////////////////////////////////////////////////////////////////////////////////////////////
				
				//CHECK POST MASTER
				queryString = "SELECT CHKPOST_CD,CHKPOST_NAME "
						+ "FROM FMS_CHECKPOST_MST "
						+ "WHERE ACTIVE_FLAG=? "
						+ "ORDER BY CHKPOST_CD";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, "Y");
				rset = stmt.executeQuery();
				while(rset.next())
				{
					VCHECKPOST_CD.add(rset.getString(1)==null?"":rset.getString(1));
					VCHECKPOST_NAME.add(rset.getString(2)==null?"":rset.getString(2));
				}
				rset.close();
				stmt.close();
				
				//SELECTED CHECK POST DETAIL
				queryString = "SELECT CHKPOST_CD "
						+ "FROM FMS_LINK_CHECKPOST_PLANT A "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND ENTITY_TYPE=? AND PLANT_SEQ_NO=? "
						+ "AND A.EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_LINK_CHECKPOST_PLANT B WHERE A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY_TYPE=B.ENTITY_TYPE "
						+ "AND A.PLANT_SEQ_NO=B.PLANT_SEQ_NO AND A.CHKPOST_CD=B.CHKPOST_CD AND B.EFF_DT<=TO_DATE(?,'DD/MM/YYYY')) "
						+ "AND A.REV_SEQ=(SELECT MAX(B.REV_SEQ) FROM FMS_LINK_CHECKPOST_PLANT B WHERE "
						+ "	A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY_TYPE=B.ENTITY_TYPE "
						+ "	AND A.PLANT_SEQ_NO=B.PLANT_SEQ_NO AND A.EFF_DT=B.EFF_DT) ";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty_cd);
				stmt.setString(3, "C");
				stmt.setString(4, plant_seq);
				stmt.setString(5, period_end_dt);
				rset = stmt.executeQuery();
				if(rset.next())
				{
					linked_checkpost_cd=rset.getString(1)==null?"":rset.getString(1);
				}
				rset.close();
				stmt.close();
			}
			else
			{
				VCHECKPOST_CD.add(linked_checkpost_cd);
				VCHECKPOST_NAME.add(dlng_util.getCheckPostName(conn, linked_checkpost_cd));
				
				VDRIVER_CD.add(linked_driver_cd);
				VDRIVER_NM.add(dlng_util.getDriverName(conn, linked_driver_cd));
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getExchangeRateMaster()
	{
		String function_nm="getExchangeRateMaster()";
		try
		{
			queryString = "SELECT EXC_RATE_CD,EXC_RATE_NM,FLAG "
					+ "FROM FMS_EXCHG_RATE_MST "
					+ "WHERE EXC_RATE_CD=? "
					+ "ORDER BY EXC_RATE_NM";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, exchng_rate_cd);
			rset=stmt.executeQuery();
			while(rset.next())
			{
				VEXCHNG_RATE_CD.add(rset.getString(1)==null?"":rset.getString(1));
				VEXCHNG_RATE_NM.add(rset.getString(2)==null?"":rset.getString(2));
				VEXCHNG_RATE_FLAG.add(rset.getString(3)==null?"":rset.getString(3));
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getExchangeRateCalculation()
	{
		String function_nm="getExchangeRateCalculation()";
		try
		{
			double exchng_rate=0;
			if(exchng_rate_cd.equals("0")) //FOR FIXED EXCHANGE RATE
			{
				exchng_rate=Double.parseDouble(fixed_exchng_val);
				exchang_rate_dt="";
				exchang_rate=nf2.format(exchng_rate);
				gross_amt1 = nf.format(Double.parseDouble(gross_amt) * exchng_rate);
			}
			else
			{
				if(exchng_rate_cal.equals("A"))
				{/*
					if(!sel_exchng_cd.equals(""))
					{
						exchng_rate_cd=sel_exchng_cd;
					}
					String tot_qty="0.00";
					String tot_gross_amt_inr="0.00";
					String tot_gross_amt_usd="0.00";
					String temp_dates="";
					//queryString="SELECT TO_CHAR(TO_DATE(TD.END_DATE + 1 - ROWNUM),'DD/MM/YYYY') MONTH_DATE "
					//		+ "FROM ALL_OBJECTS,(SELECT TO_DATE('"+period_start_dt+"','DD/MM/YYYY')-1 START_DATE,TO_DATE('"+period_end_dt+"','DD/MM/YYYY') END_DATE FROM DUAL) TD "
					//		+ "WHERE TO_DATE(TD.END_DATE - ROWNUM, 'DD/MM/YYYY') >= TO_DATE(TD.START_DATE,'DD/MM/YYYY') "
					//		+ "ORDER BY TO_DATE(MONTH_DATE,'DD/MM/YYYY')";
					
					String fill_station_cd="";
					String bay_cd="";
					String slot_start_time="";
					String slot_end_time="";
					
					if(!mapping_id.equals(""))
					{
						String split[]=mapping_id.split("-");
						fill_station_cd=split[0];
						bay_cd=split[1];
						slot_start_time=split[2];
						slot_end_time=split[3];
					}
					queryString="SELECT TO_CHAR(TO_DATE(TD.END_DATE + 1 - ROWNUM),'DD/MM/YYYY') MONTH_DATE "
							+ "FROM ALL_OBJECTS,(SELECT TO_DATE(?,'DD/MM/YYYY')-1 START_DATE,TO_DATE(?,'DD/MM/YYYY') END_DATE FROM DUAL) TD "
							+ "WHERE TO_DATE(TD.END_DATE - ROWNUM, 'DD/MM/YYYY') >= TO_DATE(TD.START_DATE,'DD/MM/YYYY') "
							+ "ORDER BY TO_DATE(MONTH_DATE,'DD/MM/YYYY')";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(1, temp_period_start_dt);
					stmt.setString(2, temp_period_end_dt);
					rset=stmt.executeQuery();
					while(rset.next())
					{
						String date = rset.getString(1)==null?"":rset.getString(1);
						VALLOCATION_DT.add(date);
						
						int selCnt=0;
						String qtyMMBTU="0.00";
						queryString1="SELECT SUM(QTY_MMBTU) "
								+ "FROM FMS_DLNG_ALLOC_MST A "
								+ "WHERE CONT_NO=? AND AGMT_NO=? "
								+ "AND COMPANY_CD=? AND COUNTERPARTY_CD=? "
								+ "AND PLANT_SEQ=? AND CONTRACT_TYPE=? AND BU_SEQ=? "
								+ "AND GAS_DT=TO_DATE(?,'DD/MM/YYYY') AND TRUCK_TRANS_CD=? AND TRUCK_CD=? "
								+ "AND FILL_STATION_CD=? AND BAY_CD=? "
								+ "AND SLOT_START_TIME=? AND SLOT_END_TIME=? "
								+ "AND NOM_REV_NO=(SELECT MAX(NOM_REV_NO) FROM FMS_DLNG_ALLOC_MST B "
								+ "WHERE B.CONT_NO=A.CONT_NO AND B.AGMT_NO=A.AGMT_NO "
								+ "AND B.COMPANY_CD=A.COMPANY_CD AND B.COUNTERPARTY_CD=A.COUNTERPARTY_CD "
								+ "AND B.BU_SEQ=A.BU_SEQ "
								+ "AND B.PLANT_SEQ=A.PLANT_SEQ AND B.CONTRACT_TYPE=A.CONTRACT_TYPE "
								+ "AND B.GAS_DT=A.GAS_DT AND B.TRUCK_TRANS_CD=A.TRUCK_TRANS_CD AND A.TRUCK_CD=B.TRUCK_CD "
								+ "AND B.FILL_STATION_CD=A.FILL_STATION_CD AND B.BAY_CD=A.BAY_CD "
								+ "AND B.SLOT_START_TIME=A.SLOT_START_TIME AND B.SLOT_END_TIME=A.SLOT_END_TIME) "
								+ "ORDER BY TRUCK_CD";
						stmt1 = conn.prepareStatement(queryString1);
						stmt1.setString(++selCnt, cont_no);
						stmt1.setString(++selCnt, agmt_no);
						stmt1.setString(++selCnt, comp_cd);
						stmt1.setString(++selCnt, counterparty_cd);
						stmt1.setString(++selCnt, plant_seq);
						stmt1.setString(++selCnt, contract_type);
						stmt1.setString(++selCnt, bu_unit);
						stmt1.setString(++selCnt, date); //gas date
						stmt1.setString(++selCnt, truck_trans_cd);
						stmt1.setString(++selCnt, truck_cd);
						stmt1.setString(++selCnt, fill_station_cd);
						stmt1.setString(++selCnt, bay_cd);
						stmt1.setString(++selCnt, slot_start_time);
						stmt1.setString(++selCnt, slot_end_time);
						rset1=stmt1.executeQuery();
						if(rset1.next())
						{
							qtyMMBTU=nf.format(rset1.getDouble(1));
						}
						rset1.close();
						stmt1.close();
						
						double temp_exchng=0;
						String sel_exchngRateCd=exchng_rate_cd;
						boolean exist_exchng_rate=false;
						for(int i=0; i<VEXCHNG_RATE_CD.size(); i++)
						{
							String exchng_rate_cd=""+VEXCHNG_RATE_CD.elementAt(i);
							String daily_exchng_rate="";
							
							if(exchng_rate_cd.equals(sel_exchngRateCd) && operation.equals("INSERT") && submission_chk)
							{
								queryString1="SELECT EXCHG_RATE_VALUE "
										+ "FROM FMS_INVOICE_DTL "
										+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
										+ "AND CONT_NO=? AND AGMT_NO=? "
										+ "AND PLANT_SEQ=? AND BU_UNIT=? AND CONTRACT_TYPE=? "
										+ "AND BU_STATE_TIN=? AND ALLOCATION_DT=TO_DATE(?,'DD/MM/YYYY') "
										+ "AND EXCHG_RATE_CD=? AND FINANCIAL_YEAR=? AND CARGO_NO=? ";
								stmt1=conn.prepareStatement(queryString1);
								stmt1.setString(1, comp_cd);
								stmt1.setString(2, counterparty_cd);
								stmt1.setString(3, cont_no);
								stmt1.setString(4, agmt_no);
								stmt1.setString(5, plant_seq);
								stmt1.setString(6, bu_unit);
								stmt1.setString(7, contract_type);
								stmt1.setString(8, bu_state_tin);
								stmt1.setString(9, date);
								stmt1.setString(10, sel_exchngRateCd);
								stmt1.setString(11, financial_year);
								stmt1.setString(12, cargo_no);
								rset1=stmt1.executeQuery();
								if(rset1.next())
								{
									daily_exchng_rate=nf2.format(rset1.getDouble(1));
									exist_exchng_rate=true;
									if(daily_exchng_rate.equals(""))
									{
										VEXCHNG_RATE_CAL_COLOR.add("#cccccc");
									}
									else
									{
										VEXCHNG_RATE_CAL_COLOR.add("#ccffff");
									}
								}
								rset1.close();
								stmt1.close();
							}
							else
							{
								queryString1="SELECT EXCHG_VAL "
										+ "FROM FMS_EXCHG_RATE_ENTRY A "
										+ "WHERE EXCHG_RATE_CD=? "
										+ "AND EFF_DT= TO_DATE(?,'DD/MM/YYYY')";
								stmt1=conn.prepareStatement(queryString1);
								stmt1.setString(1, exchng_rate_cd);
								stmt1.setString(2, date);
								rset1=stmt1.executeQuery();
								if(rset1.next())
								{
									daily_exchng_rate=nf2.format(rset1.getDouble(1));
									exist_exchng_rate=true;
									if(daily_exchng_rate.equals(""))
									{
										VEXCHNG_RATE_CAL_COLOR.add("#cccccc");
									}
									else
									{
										VEXCHNG_RATE_CAL_COLOR.add("#99ffcc");
									}
								}
								else
								{
									queryString2="SELECT EXCHG_VAL "
											+ "FROM FMS_EXCHG_RATE_ENTRY A "
											+ "WHERE EXCHG_RATE_CD=? "
											+ "AND EFF_DT=(SELECT MAX(EFF_DT) FROM FMS_EXCHG_RATE_ENTRY B "
											+ "WHERE A.EXCHG_RATE_CD=B.EXCHG_RATE_CD AND B.EFF_DT <= TO_DATE(?,'DD/MM/YYYY'))";
									stmt2=conn.prepareStatement(queryString2);
									stmt2.setString(1, exchng_rate_cd);
									stmt2.setString(2, date);
									rset2=stmt2.executeQuery();
									if(rset2.next())
									{
										daily_exchng_rate=nf2.format(rset2.getDouble(1));
									}
									rset2.close();
									stmt2.close();
									exist_exchng_rate=false;
									VEXCHNG_RATE_CAL_COLOR.add("#cccccc");
								}
								rset1.close();
								stmt1.close();
							}
							
							VEXCHNG_RATE_CAL_CD.add(exchng_rate_cd);
							VEXCHNG_RATE_CAL_VAL.add(daily_exchng_rate);
							
							if(sel_exchngRateCd.equals(exchng_rate_cd))
							{
								if(!daily_exchng_rate.equals(""))
								{
									temp_exchng=Double.parseDouble(daily_exchng_rate);
								}
							}
						}
						
						VPRICE.add(price);
						VALLOCATION_QTY.add(qtyMMBTU);
						
						String temp_gross_amt = nf.format(Double.parseDouble(qtyMMBTU) * Double.parseDouble(price));
						VAMOUNT_USD.add(temp_gross_amt);
						String temp_gross_amt1 = "0.00";
						if(price_cd.equals("2"))
						{	
							if(temp_exchng > 0)
							{
								temp_gross_amt1 = nf.format(Double.parseDouble(temp_gross_amt) * temp_exchng);
								VAMOUNT_INR.add(temp_gross_amt1);
							}
							else if(temp_exchng <= 0 && Double.parseDouble(qtyMMBTU) > 0 && Double.parseDouble(temp_gross_amt1)<=0)
							{
								correction_needed=true;
								VAMOUNT_INR.add(temp_gross_amt1);
								
								if(temp_dates.equals(""))
								{
									temp_dates+=date;
								}
								else
								{
									temp_dates+=", "+date;
								}
							}
							else
							{
								VAMOUNT_INR.add(temp_gross_amt1);
							}
						}
						tot_gross_amt_inr = nf.format(Double.parseDouble(tot_gross_amt_inr)+Double.parseDouble(temp_gross_amt1));
						tot_qty = nf.format(Double.parseDouble(qtyMMBTU)+Double.parseDouble(tot_qty));
						
					}
					rset.close();
					stmt.close();
					
					tot_gross_amt_usd=nf.format(Double.parseDouble(qty_mmbtu) * Double.parseDouble(price));
					gross_amt1=tot_gross_amt_inr;
					
					daily_tot_amt_inr=tot_gross_amt_inr;
					daily_tot_amt_usd=tot_gross_amt_usd;
					daily_tot_qty=tot_qty;
					
					if(correction_needed)
					{
						correction_msg="Correction Needed! For non-zero Daily Qty, Daily Gross zero(0) on "+temp_dates+"";
					}
					
					exchang_rate=nf2.format(Double.parseDouble(gross_amt1)/Double.parseDouble(gross_amt));
					*/
				}
				else if(exchng_rate_cal.equals("D"))
				{
					if(submission_chk && exchange_rate_mapping.equals(""))
					{
						user_defined_dt=exchang_rate_dt;
						exchange_rate_mapping="U-"+exchng_rate_cd;
					}
					else if(user_defined_dt.equals(""))
					{
						user_defined_dt=period_end_dt;
					}
					queryString="SELECT TO_CHAR(EFF_DT,'DD/MM/YYYY') "
							+ "FROM FMS_EXCHG_RATE_ENTRY A "
							+ "WHERE EXCHG_RATE_CD=? "
							+ "AND EFF_DT=(SELECT MAX(EFF_DT) FROM FMS_EXCHG_RATE_ENTRY B "
							//+ "WHERE A.EXCHG_RATE_CD=B.EXCHG_RATE_CD AND B.EFF_DT<TO_DATE(?,'DD/MM/YYYY')) ";
							+ "WHERE A.EXCHG_RATE_CD=B.EXCHG_RATE_CD AND B.EFF_DT<=TO_DATE(?,'DD/MM/YYYY')) "; //AS DISCUSSED WITH VIJAY ON 20250702
					stmt=conn.prepareStatement(queryString); 
					stmt.setString(1, exchng_rate_cd);
					stmt.setString(2, invoice_dt);
					rset=stmt.executeQuery();
					if(rset.next())
					{
						last_avlb_exchng_dt=rset.getString(1)==null?"":rset.getString(1);
					}
					rset.close();
					stmt.close();
					
					getExchangeRateEntry("P", last_avlb_exchng_dt);
					
					/*if(exchang_criteria.equals("INV")) //AS DISCUSSED WITH VIJAY ON 20250702
					{
						getExchangeRateEntry("B", invoice_dt);
						lable_inv_criteria="Invoice Day";
						lable_inv_date=invoice_dt;
					}
					else if(exchang_criteria.equals("LST"))
					{
						getExchangeRateEntry("B", period_end_dt);
						lable_inv_criteria="Last Day of Billing Cycle";
						lable_inv_date=period_end_dt;
					}
					else if(exchang_criteria.equals("PRE"))
					{
						lable_inv_date=""+utilDate.getDate(period_end_dt, "-1");
						getExchangeRateEntry("B", lable_inv_date);
						lable_inv_criteria="Previous Day of Billing Cycle";
					}*/
					getExchangeRateEntry("U", user_defined_dt);
					
					if(!exchange_rate_mapping.equals(""))
					{
						String temp[] = exchange_rate_mapping.split("-");
						
						String dateType=temp[0];
						String exc_cd=temp[1];
						String exc_dt="";
						if(dateType.equals("P"))
						{
							exc_dt=last_avlb_exchng_dt;
						}
						/*else if(dateType.equals("B")) //AS DISCUSSED WITH VIJAY ON 20250702
						{
							exc_dt=lable_inv_date;
						}*/
						else if(dateType.equals("U"))
						{
							exc_dt=user_defined_dt;
						}
						
						queryString1="SELECT NVL(EXCHG_VAL,0),TO_CHAR(EFF_DT,'DD/MM/YYYY') "
								+ "FROM FMS_EXCHG_RATE_ENTRY A "
								+ "WHERE EXCHG_RATE_CD=? "
								+ "AND EFF_DT = TO_DATE(?,'DD/MM/YYYY')";
						stmt1=conn.prepareStatement(queryString1);
						stmt1.setString(1, exc_cd);
						stmt1.setString(2, exc_dt);
						rset1=stmt1.executeQuery();
						if(rset1.next())
						{
							exchng_rate_cd=exc_cd;
							exchng_rate=rset1.getDouble(1);
							exchang_rate_dt=rset1.getString(2)==null?"":rset1.getString(2);
						}
						rset1.close();
						stmt1.close();
					}
					else
					{
						if(!submission_chk)
						{
							queryString1="SELECT NVL(EXCHG_VAL,0),TO_CHAR(EFF_DT,'DD/MM/YYYY') "
									+ "FROM FMS_EXCHG_RATE_ENTRY A "
									+ "WHERE EXCHG_RATE_CD=? "
									+ "AND EFF_DT = TO_DATE(?,'DD/MM/YYYY')";
							stmt1=conn.prepareStatement(queryString1);
							stmt1.setString(1, exchng_rate_cd);
							//stmt1.setString(2, invoice_dt);
							stmt1.setString(2, last_avlb_exchng_dt); //AS DISCUSSED WITH VIJAY ON 20250702
							rset1=stmt1.executeQuery();
							if(rset1.next())
							{
								exchng_rate=rset1.getDouble(1);
								exchang_rate_dt=rset1.getString(2)==null?"":rset1.getString(2);
							}
							rset1.close();
							stmt1.close();
						}
						else
						{
							exchng_rate=Double.parseDouble(exchang_rate);
						}
						
						//exchange_rate_mapping="B-"+exchng_rate_cd;
						exchange_rate_mapping="P-"+exchng_rate_cd; //AS DISCUSSED WITH VIJAY ON 20250702
					}
					
					exchang_rate=nf2.format(exchng_rate);
					if((operation.equals("INSERT") && !submission_chk) || operation.equals("MODIFY"))
					{
						gross_amt1 = nf.format(Double.parseDouble(gross_amt) * exchng_rate);
					}
				}
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getExchangeRateEntry(String dateType, String date)
	{
		String function_nm="getExchangeRateEntry()";
		try
		{
			for(int i=0; i<VEXCHNG_RATE_CD.size(); i++)
			{
				String exchng_rate_cd=""+VEXCHNG_RATE_CD.elementAt(i);
				String exchng_rate="";
				queryString="SELECT EXCHG_VAL "
						+ "FROM FMS_EXCHG_RATE_ENTRY A "
						+ "WHERE EXCHG_RATE_CD=? "
						+ "AND EFF_DT=TO_DATE(?,'DD/MM/YYYY') ";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, exchng_rate_cd);
				stmt.setString(2, date);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					exchng_rate=nf2.format(rset.getDouble(1)); 
				}
				rset.close();
				stmt.close();
				
				if(dateType.equals("P"))
				{
					if(!exchng_rate.equals(""))
					{
						VP_EXCHNG_RATE_CD.add(exchng_rate_cd);
						VP_EXCHNG_RATE_VALUE.add(exchng_rate);
						VP_BG_COLOR.add("#99ffcc");
					}
					else
					{
						VP_EXCHNG_RATE_CD.add(exchng_rate_cd);
						VP_EXCHNG_RATE_VALUE.add("");
						VP_BG_COLOR.add("#cccccc");
					}
				}
				if(dateType.equals("B"))
				{
					if(!exchng_rate.equals(""))
					{
						VB_EXCHNG_RATE_CD.add(exchng_rate_cd);
						VB_EXCHNG_RATE_VALUE.add(exchng_rate);
						VB_BG_COLOR.add("#99ffcc");
					}
					else
					{
						VB_EXCHNG_RATE_CD.add(exchng_rate_cd);
						VB_EXCHNG_RATE_VALUE.add("");
						VB_BG_COLOR.add("#cccccc");
					}
				}
				if(dateType.equals("U"))
				{
					if(!exchng_rate.equals(""))
					{
						VU_EXCHNG_RATE_CD.add(exchng_rate_cd);
						VU_EXCHNG_RATE_VALUE.add(exchng_rate);
						VU_BG_COLOR.add("#99ffcc");
					}
					else
					{
						VU_EXCHNG_RATE_CD.add(exchng_rate_cd);
						VU_EXCHNG_RATE_VALUE.add("");
						VU_BG_COLOR.add("#cccccc");
					}
				}
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getRemarks()
	{
		String function_nm="getRemarks()";
		try
		{
			/*
			String signing_dt="";
			String agmt_signing_dt="";
			queryString="SELECT TO_CHAR(SIGNING_DT,'ddth Month, yyyy') "
					+ "FROM FMS_SUPPLY_CONT_MST "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND AGMT_NO=? "
					+ "AND AGMT_REV=? AND CONT_NO=? AND CONT_REV=? AND CONTRACT_TYPE=?";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, agmt_no);
			stmt.setString(4, agmt_rev_no);
			stmt.setString(5, cont_no);
			stmt.setString(6, cont_rev_no);
			stmt.setString(7, contract_type);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				signing_dt=rset.getString(1)==null?"":rset.getString(1);
			}
			rset.close();
			stmt.close();
			
			String rmk = "";
			
			if(contract_type.equals("S"))
			{
				
				queryString1="SELECT TO_CHAR(SIGNING_DT,'ddth Month, yyyy') "
						+ "FROM FMS_AGMT_MST "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND AGMT_NO=? "
						+ "AND AGMT_REV=? AND AGMT_TYPE=?";
				stmt1=conn.prepareStatement(queryString1);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, counterparty_cd);
				stmt1.setString(3, agmt_no);
				stmt1.setString(4, agmt_rev_no);
				stmt1.setString(5, "F");
				rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					agmt_signing_dt=rset1.getString(1)==null?"":rset1.getString(1);
				}
				rset1.close();
				stmt1.close();
				rmk = "Framework Gas Sales Agreement executed on "+agmt_signing_dt+" and Supply Notice executed on "+signing_dt+"";
			}
			else if(contract_type.equals("L"))
			{
				rmk = "Latter Of Agreement executed on "+signing_dt+"";
			}
			else if(contract_type.equals("X"))
			{
				rmk = "IGX Gas Sales Contract executed on "+signing_dt+"";
			}
			*/
			
			String bank_formula="";
			queryString2="SELECT COUNTERPARTY_CD,ENTITY,TO_CHAR(EFF_DT,'DD/MM/YYYY'),BANK_NAME,ACCOUNT_ID,IFSC_CODE,BRANCH_NAME,"
					+ "STATE_NM  "
					+ "FROM FMS_ENTITY_BANK_MST A "
					+ "WHERE ENTITY=? AND COUNTERPARTY_CD=? AND COMPANY_CD=? AND CATEGORY=? "
					+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_BANK_MST B WHERE A.COUNTERPARTY_CD=B.COUNTERPARTY_CD "
					+ "AND A.ENTITY=B.ENTITY AND A.COMPANY_CD=B.COMPANY_CD AND B.EFF_DT<=TO_DATE(?,'DD/MM/YYYY') AND A.CATEGORY=B.CATEGORY)";
			stmt2=conn.prepareStatement(queryString2);
			stmt2.setString(1, "B");
			stmt2.setString(2, comp_cd);
			stmt2.setString(3, comp_cd);
			stmt2.setString(4, "DLNG");
			stmt2.setString(5, invoice_dt);
			rset2=stmt2.executeQuery();
			if(rset2.next())
			{
				String bank_eff_dt = rset2.getString(3)==null?"":rset2.getString(3);
				String bank_name=rset2.getString(4)==null?"":rset2.getString(4);
				String bank_account_no=rset2.getString(5)==null?"":rset2.getString(5);
				String ifsc_code=rset2.getString(6)==null?"":rset2.getString(6);
				String bank_branch=rset2.getString(7)==null?"":rset2.getString(7);
				String bank_state=rset2.getString(8)==null?"":rset2.getString(8);
				
				bank_formula=bank_name+", "+bank_branch+", "+bank_state+", A/C No : "+bank_account_no+", IFSC Code : "+ifsc_code;
			}
			rset2.close();
			stmt2.close();
			
			remark_1 ="Please pay the invoiced amount by wire transfer at our Bank Account : "+bank_formula;
			remark_2="NOTE : Bank Account changes should not be made without re-confirmation with your usual SHELL Contact.\n\nUnless communicated by your usual Shell Contact/Authorized Representative, Bank Account changes should not be made. Any proposed change should always be confirmed initially by Phone and then Electronically (Email) with your usual SHELL Contact. Most Importantly check for valid Domain Name (@SHELL.COM) in the E-mail Address.";
			//COMMENTED AS REQUESTED BY VIJAY ON 31/102023 
			//remark_2 ="Subject to the terms and conditions of the "+rmk+" between "+utilBean.getCompanyName(comp_cd)+" and "+utilBean.getCounterpartyName(counterparty_cd, comp_cd);
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getTurnoverDetail()
	{
		String function_nm="getTurnoverDetail()";
		try
		{
			//previousFinancialYear=""+utilDate.getPreviousFinancialYear(period_end_dt);
			previousFinancialYear=""+utilDate.getPreviousFinancialYear(invoice_dt);
			
			queryString="SELECT TURNOVER_FLAG "
					+ "FROM FMS_ENTITY_TURNOVER_DTL "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND ENTITY=? AND FINANCIAL_YEAR=? AND TURNOVER_CD=? ";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, "C");
			stmt.setString(4, previousFinancialYear);
			stmt.setString(5, "1");
			rset=stmt.executeQuery();
			if(rset.next())
			{
				buyerTurnoverFlag=rset.getString(1)==null?"":rset.getString(1);
			}
			rset.close();
			stmt.close();
			
			queryString1="SELECT TURNOVER_FLAG "
					+ "FROM FMS_ENTITY_TURNOVER_DTL "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND ENTITY=? AND FINANCIAL_YEAR=? AND TURNOVER_CD=? ";
			stmt1=conn.prepareStatement(queryString1);
			stmt1.setString(1, comp_cd);
			stmt1.setString(2, comp_cd);
			stmt1.setString(3, "B");
			stmt1.setString(4, previousFinancialYear);
			stmt1.setString(5, "1");
			rset1=stmt1.executeQuery();
			if(rset1.next())
			{
				sellerTurnoverFlag=rset1.getString(1)==null?"":rset1.getString(1);
			}
			rset1.close();
			stmt1.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void checkTCS_TDSApplicable()
	{
		String function_nm="checkTCS_TDSApplicable()";
		try
		{
			//Trunover_prev_finantial_yr(Seller<10cr, Buyer<10cr) && Trans_current_finantial_yr > 50L ==> TCS/TDS Applicable : NA
			//Trunover_prev_finantial_yr(S>10cr, B<10cr) && Trans_current_finantial_yr > 50L ==> TCS/TDS Applicable : TCS
			//Trunover_prev_finantial_yr(S<10cr, B>10cr) && Trans_current_finantial_yr > 50L ==> TCS/TDS Applicable : TDS
			//Trunover_prev_finantial_yr(S>10cr, B>10cr) && Trans_current_finantial_yr > 50L ==> TCS/TDS Applicable : TDS
			
			if(contract_type.equals("W")) //FOR DLNG IGX
			{
				applicable_abbr="NA";
				
				applicable_amt ="";
				tcs_struct_cd = "";
				tcs_struct_dt = "";
				TCS_factor="";
				
				tds_amt = "";
				tds_struct_cd = "";
				tds_struct_dt = "";
				tds_factor = "";
			}
			else
			{			
				total_transaction_amt=""+getTransactionAmount(comp_cd, counterparty_cd, financial_year);
				//System.out.println("total_transaction_amt="+total_transaction_amt);
				//System.out.println("invoice_amt="+invoice_amt);
				if(sellerTurnoverFlag.equals("Y") && buyerTurnoverFlag.equals("Y"))
				{
					applicable_abbr="TDS";
				}
				else if(sellerTurnoverFlag.equals("N") && buyerTurnoverFlag.equals("Y"))
				{
					applicable_abbr="TDS";
				}
				else if(sellerTurnoverFlag.equals("Y") && buyerTurnoverFlag.equals("N"))
				{
					applicable_abbr="TCS";
				}
				else
				{
					applicable_abbr="NA";
				}
				
				//System.out.println(applicable_abbr);
				double total_difference=0;
				if(applicable_abbr.equals("TCS"))
				{
					if(Double.parseDouble(total_transaction_amt)>transaction_limit)
					{
						applicable_flag="Y";
						if(!invoice_amt.equals(""))
						{
							total_difference=Double.parseDouble(invoice_amt);
						}
					}
					else if(!invoice_amt.equals(""))
					{
						total_transaction_amt=""+(Double.parseDouble(total_transaction_amt)+Double.parseDouble(invoice_amt));
						if(Double.parseDouble(total_transaction_amt)>transaction_limit)
						{
							applicable_flag="Y";
							total_difference=Double.parseDouble(total_transaction_amt)-transaction_limit;
						}
						else
						{
							total_difference=0;
							applicable_abbr="NA";
						}
					}
					else
					{
						total_difference=0;
						applicable_abbr="NA";
					}
					//System.out.println(total_difference);
					if(total_difference>0)
					{
						Vector temp_tcs = new Vector();
						temp_tcs=TaxCalc.TCS_TDSAmountCalculationWithInfo(conn, comp_cd, counterparty_cd, "C", "TCS", "S","P",period_end_dt, nf.format(total_difference));
		
						applicable_amt = nf.format(Double.parseDouble(""+temp_tcs.elementAt(0)));
						tcs_struct_cd = ""+temp_tcs.elementAt(1);
						tcs_struct_dt = ""+temp_tcs.elementAt(2);
						//tax_info = ""+temp_tcs.elementAt(3);
						//tax_struct_dtl = ""+temp_tcs.elementAt(4);
						tcs_factor = Double.parseDouble(""+temp_tcs.elementAt(5));
						
						net_payable=nf.format(Double.parseDouble(net_payable)+Double.parseDouble(applicable_amt));
						
						/*if(Double.parseDouble(applicable_amt)==0)
						{
							applicable_amt="";
						}*/
					}
					
					/*if(tcs_factor==0)
					{
						TCS_factor="";
					}
					else*/
					{
						TCS_factor=nf3.format(tcs_factor);
					}
				}
				else if(applicable_abbr.equals("TDS"))
				{
					if(Double.parseDouble(total_transaction_amt)>transaction_limit)
					{
						//20230911 FOLLOWING IS NOT TESTED ERLIER, AMOUNT SHOULD BE CONSIDERED INCLUDING CHARGES
						/*if(!gross_amt1.equals(""))
						{
							total_difference=Double.parseDouble(gross_amt1);
						}*/
						
						if(!gross_include_transport_tariff.equals(""))
						{
							total_difference=Double.parseDouble(gross_include_transport_tariff);
						}
					}
					else if(!gross_amt1.equals(""))
					{
						//20230911 total_transaction_amt=""+(Double.parseDouble(total_transaction_amt)+Double.parseDouble(gross_amt1));
						
						total_transaction_amt=""+(Double.parseDouble(total_transaction_amt)+Double.parseDouble(gross_include_transport_tariff));
						
						if(Double.parseDouble(total_transaction_amt)>transaction_limit)
						{
							total_difference=Double.parseDouble(total_transaction_amt)-transaction_limit;
						}
						else
						{
							total_difference=0;
							applicable_abbr="NA";
						}
					}
					else
					{
						total_difference=0;
						applicable_abbr="NA";
					}
					
					if(total_difference>0)
					{
						Vector temp_tcs = new Vector();
						temp_tcs=TaxCalc.TCS_TDSAmountCalculationWithInfo(conn, comp_cd, counterparty_cd, "C", "TDS", "S","P",period_end_dt, nf.format(total_difference));
		
						tds_amt = nf.format(Double.parseDouble(""+temp_tcs.elementAt(0)));
						tds_struct_cd = ""+temp_tcs.elementAt(1);
						tds_struct_dt = ""+temp_tcs.elementAt(2);
						//tax_info = ""+temp_tcs.elementAt(3);
						//tax_struct_dtl = ""+temp_tcs.elementAt(4);
						tds_factor = ""+temp_tcs.elementAt(5);
						
						if(Double.doubleToRawLongBits(Double.parseDouble(tds_amt))==Double.doubleToRawLongBits(0))
						{
							tds_amt="";
						}
						if(!tds_factor.equals(""))
						{
							if(Double.doubleToRawLongBits(Double.parseDouble(tds_factor))==Double.doubleToRawLongBits(0))
							{
								tds_factor="";
							}
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getTcsTdsInvDtl()
	{
		String function_nm="getTcsTdsInvDtl()";
		try
		{
			double total=0;
			queryString="SELECT AGMT_NO,CONT_NO,CONTRACT_TYPE,INVOICE_AMT,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY') "
					+ "FROM FMS_INVOICE_MST "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONTRACT_TYPE IN (?,?) "
					+ "AND FINANCIAL_YEAR=? AND APPROVED_FLAG=? AND INVOICE_DT <=TO_DATE(?,'DD/MM/YYYY') "
					+ "UNION ALL "
					+ "SELECT AGMT_NO,CONT_NO,CONTRACT_TYPE,INVOICE_AMT,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY') "
					+ "FROM FMS_DLNG_INVOICE_MST "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONTRACT_TYPE IN (?,?) "
					+ "AND FINANCIAL_YEAR=? AND APPROVED_FLAG=? AND INVOICE_DT <=TO_DATE(?,'DD/MM/YYYY') ";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, "S");
			stmt.setString(4, "L");
			stmt.setString(5, financial_year);
			stmt.setString(6, "Y");
			stmt.setString(7, invoice_dt);
			stmt.setString(8, comp_cd);
			stmt.setString(9, counterparty_cd);
			stmt.setString(10, "F");
			stmt.setString(11, "E");
			stmt.setString(12, financial_year);
			stmt.setString(13, "Y");
			stmt.setString(14, invoice_dt);
			rset=stmt.executeQuery();
			while(rset.next())
			{
				String agmtno=rset.getString(1)==null?"":rset.getString(1);
				String contno=rset.getString(2)==null?"":rset.getString(2);
				String cont_type=rset.getString(3)==null?"":rset.getString(3);
				double inv_amt=rset.getDouble(4);
				String inv_no=rset.getString(5)==null?"":rset.getString(5);
				String inv_dt=rset.getString(6)==null?"":rset.getString(6);
				
				String deal_no=utilBean.NewDealMappingId(comp_cd, counterparty_cd, agmtno, "", contno, "",cont_type, "");
				
				String contRef="";
				queryString1="SELECT CONT_REF_NO  "
						+ "FROM FMS_SUPPLY_CONT_MST A "
						+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE=? "
						+ "AND CONT_NO=? AND AGMT_NO=? AND COUNTERPARTY_CD=? "
						+ "AND CONT_REV = (SELECT MAX(CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
						+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) ";
				stmt1=conn.prepareStatement(queryString1);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, cont_type);
				stmt1.setString(3, contno);
				stmt1.setString(4, agmtno);
				stmt1.setString(5, counterparty_cd);
				rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					contRef=rset1.getString(1)==null?"":rset1.getString(1);
				}
				rset1.close();
				stmt1.close();
				
				VDEAL_NO.add(deal_no);
				VCONT_REF_NO.add(contRef);
				VINVOICE_AMT.add(nf.format(inv_amt));
				VINVOICE_NO.add(inv_no);
				VINVOICE_DT.add(inv_dt);
				
				total+=inv_amt;
			}
			rset.close();
			stmt.close();
			
			queryString2="SELECT AGMT_NO,CONT_NO,CONTRACT_TYPE,INVOICE_AMT,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY') "
					+ "FROM FMS_DLNG_FFLOW_INV_MST "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONTRACT_TYPE IN (?,?) "
					+ "AND FINANCIAL_YEAR=? AND APPROVED_FLAG=? AND INVOICE_DT <=TO_DATE(?,'DD/MM/YYYY') "
					+ "AND INVOICE_TYPE IN (?,?,?)";
			stmt2=conn.prepareStatement(queryString2);
			stmt2.setString(1, comp_cd);
			stmt2.setString(2, counterparty_cd);
			stmt2.setString(3, "E");
			stmt2.setString(4, "F");
			stmt2.setString(5, financial_year);
			stmt2.setString(6, "Y");
			stmt2.setString(7, invoice_dt);
			stmt2.setString(8, "CDR");
			stmt2.setString(9, "DR");
			stmt2.setString(10, "S");
			rset2=stmt2.executeQuery();
			while(rset2.next())
			{
				String agmtno=rset2.getString(1)==null?"":rset2.getString(1);
				String contno=rset2.getString(2)==null?"":rset2.getString(2);
				String cont_type=rset2.getString(3)==null?"0":rset2.getString(3);
				double inv_amt=rset2.getDouble(4);
				String inv_no=rset2.getString(5)==null?"":rset2.getString(5);
				String inv_dt=rset2.getString(6)==null?"":rset2.getString(6);
				
				String deal_no=utilBean.NewDealMappingId(comp_cd, counterparty_cd, agmtno, "", contno, "",cont_type, "");
				
				String contRef="";
				queryString1="SELECT CONT_REF_NO  "
						+ "FROM FMS_SUPPLY_CONT_MST A "
						+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE=? "
						+ "AND CONT_NO=? AND AGMT_NO=? AND COUNTERPARTY_CD=? "
						+ "AND CONT_REV = (SELECT MAX(CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
						+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) ";
				stmt1=conn.prepareStatement(queryString1);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, cont_type);
				stmt1.setString(3, contno);
				stmt1.setString(4, agmtno);
				stmt1.setString(5, counterparty_cd);
				rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					contRef=rset1.getString(1)==null?"":rset1.getString(1);
				}
				rset1.close();
				stmt1.close();
				
				VDEAL_NO.add(deal_no);
				VCONT_REF_NO.add(contRef);
				VINVOICE_AMT.add(nf.format(inv_amt));
				VINVOICE_NO.add(inv_no);
				VINVOICE_DT.add(inv_dt);
				
				total+=inv_amt;
			}
			rset2.close();
			stmt2.close();
			
			total_InvoiceAmt=nf.format(total);
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}

	public Double getTransactionAmount(String comp_cd,String counterparty_cd, String financial_year)
	{
		String function_nm="getTransactionAmount()";
		double transc_fee=0;
		try
		{
			//RLNG INVOICE
			queryString="SELECT NVL(SUM(INVOICE_AMT),0) "
					+ "FROM FMS_INVOICE_MST "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONTRACT_TYPE IN (?,?) "
					+ "AND FINANCIAL_YEAR=? AND APPROVED_FLAG=? AND INVOICE_DT <=TO_DATE(?,'DD/MM/YYYY')";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, "S");
			stmt.setString(4, "L");
			stmt.setString(5, financial_year);
			stmt.setString(6, "Y");
			stmt.setString(7, invoice_dt);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				transc_fee=rset.getDouble(1);
			}
			rset.close();
			stmt.close();
			
			queryString1="SELECT NVL(SUM(INVOICE_AMT),0) "
					+ "FROM FMS_DLNG_FFLOW_INV_MST "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONTRACT_TYPE IN (?,?) "
					+ "AND FINANCIAL_YEAR=? AND APPROVED_FLAG=? AND INVOICE_DT <=TO_DATE(?,'DD/MM/YYYY') "
					+ "AND INVOICE_TYPE IN (?,?,?)";
			stmt1=conn.prepareStatement(queryString1);
			stmt1.setString(1, comp_cd);
			stmt1.setString(2, counterparty_cd);
			stmt1.setString(3, "E");
			stmt1.setString(4, "F");
			stmt1.setString(5, financial_year);
			stmt1.setString(6, "Y");
			stmt1.setString(7, invoice_dt);
			stmt1.setString(8, "CDR");
			stmt1.setString(9, "DR");
			stmt1.setString(10, "S");
			rset1=stmt1.executeQuery();
			if(rset1.next())
			{
				transc_fee+=rset1.getDouble(1);
			}
			rset1.close();
			stmt1.close();
			
			//DLNG INVOICE
			queryString="SELECT NVL(SUM(INVOICE_AMT),0) "
					+ "FROM FMS_DLNG_INVOICE_MST "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONTRACT_TYPE IN (?,?) "
					+ "AND FINANCIAL_YEAR=? AND APPROVED_FLAG=? AND INVOICE_DT <=TO_DATE(?,'DD/MM/YYYY')";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, "F");
			stmt.setString(4, "E");
			stmt.setString(5, financial_year);
			stmt.setString(6, "Y");
			stmt.setString(7, invoice_dt);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				transc_fee+=rset.getDouble(1);
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
		return transc_fee;
	}
	
	public void getInvoiceDetailForViewBeforeSub()
	{
		String function_nm="getInvoiceDetailForViewBeforeSub()";
		try
		{
			couterpty_nm=""+utilBean.getCounterpartyName(conn,counterparty_cd);
			price_cd_nm=""+utilBean.getRateUnitNm(conn,price_cd);
			invoice_raised_in_nm=""+utilBean.getRateUnitNm(conn,invoice_raised_in);
			
			queryString="SELECT CONT_REF_NO,TO_CHAR(DDA_DT,'DD-MON-YY'),TRADE_REF_NO,TO_CHAR(SIGNING_DT,'DD-MON-YY')  "
					+ "FROM FMS_SUPPLY_CONT_MST A "
					+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE=? "
					+ "AND CONT_NO=? AND AGMT_NO=? AND COUNTERPARTY_CD=? "
					+ "AND CONT_REV = (SELECT MAX(CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
					+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) ";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, contract_type);
			stmt.setString(3, cont_no);
			stmt.setString(4, agmt_no);
			stmt.setString(5, counterparty_cd);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				contRef=rset.getString(1)==null?"":rset.getString(1);
				dda_dt=rset.getString(2)==null?"":rset.getString(2);
				String tradeRef=rset.getString(3)==null?"":rset.getString(3);
				signingDt=rset.getString(4)==null?"":rset.getString(4);
				
				if(contract_type.equals("W"))
				{
					contRef=tradeRef;
				}
			}
			rset.close();
			stmt.close();
			
			if(contract_type.equals("F"))
			{
				queryString1="SELECT TO_CHAR(SIGNING_DT,'DD-MON-YY')  "
						+ "FROM FMS_AGMT_MST A "
						+ "WHERE COMPANY_CD=? AND AGMT_TYPE=? "
						+ "AND AGMT_NO=? AND COUNTERPARTY_CD=? "
						+ "AND AGMT_REV = (SELECT MAX(AGMT_REV) FROM FMS_AGMT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_TYPE=B.AGMT_TYPE) ";
				stmt1=conn.prepareStatement(queryString1);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, "D");
				stmt1.setString(3, agmt_no);
				stmt1.setString(4, counterparty_cd);
				rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					agmtSigningDt=rset1.getString(1)==null?"":rset1.getString(1);
				}
				rset1.close();
				stmt1.close();
			}
			
			queryString1="SELECT CONTACT_PERSON "
					+ "FROM FMS_ENTITY_CONTACT_MST A "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND ENTITY=? AND SEQ_NO=? AND ADDR_FLAG=? AND TYPE=? "
					+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO AND A.TYPE=B.TYPE "
					+ "AND EFF_DT <= TO_DATE(?,'DD/MM/YYYY'))";
			stmt1=conn.prepareStatement(queryString1);
			stmt1.setString(1, comp_cd);
			stmt1.setString(2, counterparty_cd);
			stmt1.setString(3, "C");
			stmt1.setString(4, contact_person_cd);
			stmt1.setString(5, "P"+plant_seq);
			stmt1.setString(6, "DLNG");
			stmt1.setString(7, invoice_dt);
			rset1=stmt1.executeQuery();
			if(rset1.next())
			{
				contact_person_nm=rset1.getString(1)==null?"":rset1.getString(1);
			}
			rset1.close();
			stmt1.close();
			
			queryString2="SELECT CONTACT_PERSON "
					+ "FROM FMS_ENTITY_CONTACT_MST A "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND ENTITY=? AND SEQ_NO=? AND ADDR_FLAG=? AND TYPE=? "
					+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO AND A.TYPE=B.TYPE "
					+ "AND EFF_DT <= TO_DATE(?,'DD/MM/YYYY'))";
			stmt2=conn.prepareStatement(queryString2);
			stmt2.setString(1, comp_cd);
			stmt2.setString(2, comp_cd);
			stmt2.setString(3, "B");
			stmt2.setString(4, bu_contact_person_cd);
			stmt2.setString(5, "P"+bu_unit);
			stmt2.setString(6, "DLNG");
			stmt2.setString(7, invoice_dt);
			rset2=stmt2.executeQuery();
			if(rset2.next())
			{
				bu_contact_person_nm=rset2.getString(1)==null?"":rset2.getString(1);
			}
			rset2.close();
			stmt2.close();
			
			HashMap bu_plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "B", comp_cd, bu_unit);
            bu_plantAddress=""+bu_plant_detail.get("plant_address");
			bu_plantCity=""+bu_plant_detail.get("plant_city");
			bu_plantState=""+bu_plant_detail.get("plant_state");
			bu_plantPin=""+bu_plant_detail.get("plant_pin");
			bu_plantNm=""+bu_plant_detail.get("plant_name");
			
			HashMap plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "C", counterparty_cd, plant_seq);
            plantAddress=""+plant_detail.get("plant_address");
			plantCity=""+plant_detail.get("plant_city");
			plantState=""+plant_detail.get("plant_state");
			plantPin=""+plant_detail.get("plant_pin");
			plantNm=""+plant_detail.get("plant_name");
			
			tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "C", counterparty_cd, plant_seq);
			tax_info=tax_info.replaceAll("\n", "<br>");
			
			bu_tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "B", comp_cd, bu_unit);
			bu_tax_info=bu_tax_info.replaceAll("\n", "<br>");	
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getInvoiceDetail()
	{
		String function_nm="getInvoiceDetail()";
		try
		{
			queryString="SELECT BU_CONTACT_PERSON_CD,CONTACT_PERSON_CD,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD-MON-YY'),"
					+ "TO_CHAR(DUE_DT,'DD-MON-YY'),TO_CHAR(PERIOD_START_DT,'DD-MON-YY'),TO_CHAR(PERIOD_END_DT,'DD-MON-YY'),REMARK_1,REMARK_2,"
					+ "ALLOC_QTY,SALE_PRICE,SALE_PRICE_UNIT,SALE_AMT,EXCHG_RATE_VALUE,GROSS_AMT,TAX_AMT,TAX_STRUCT_CD,TO_CHAR(TAX_EFF_DT,'DD/MM/YYYY'),"
					+ "INVOICE_AMT,NET_PAYABLE_AMT,TCS_TDS,TCS_AMT,TCS_FACTOR,CHECKED_FLAG,APPROVED_FLAG, "
					+ "INVOICE_ID_SEQ,NULL,NULL,EXCHG_RATE_CD,TO_CHAR(EXCHG_RATE_DT,'DD/MM/YYYY'),EXCHG_RATE_TYPE,"
					+ "INVOICE_RAISED_IN "
					+ "FROM FMS_DLNG_INVOICE_MST "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? AND AGMT_NO=? AND PLANT_SEQ=? AND BU_UNIT=? AND CONTRACT_TYPE=? "
					+ "AND BU_STATE_TIN=? AND PERIOD_START_DT=TO_DATE(?,'DD/MM/YYYY') AND PERIOD_END_DT=TO_DATE(?,'DD/MM/YYYY') "
					+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? AND TRUCK_TRANS_CD=? AND INV_FLAG=? AND TRUCK_CD=? AND MAPPING_ID=? ";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, cont_no);
			stmt.setString(4, agmt_no);
			stmt.setString(5, plant_seq);
			stmt.setString(6, bu_unit);
			stmt.setString(7, contract_type);
			stmt.setString(8, bu_state_tin);
			stmt.setString(9, period_start_dt);
			stmt.setString(10, period_end_dt);
			stmt.setString(11, financial_year);
			stmt.setString(12, invoice_seq);
			stmt.setString(13, truck_trans_cd);
			stmt.setString(14, inv_flag);
			stmt.setString(15, truck_cd);
			stmt.setString(16, mapping_id);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				bu_contact_person_cd=rset.getString(1)==null?"0":rset.getString(1);
				contact_person_cd=rset.getString(2)==null?"0":rset.getString(2);
				
				invoice_id_seq=rset.getString(26)==null?"":rset.getString(26);
				invoice_no=rset.getString(3)==null?"":rset.getString(3);
				invoice_dt=rset.getString(4)==null?"":rset.getString(4);
				invoice_due_dt=rset.getString(5)==null?"":rset.getString(5);
				inv_period_start_dt=rset.getString(6)==null?"":rset.getString(6);
				inv_period_end_dt=rset.getString(7)==null?"":rset.getString(7);
				
				remark_1=rset.getString(8)==null?"":rset.getString(8);
				remark_2=rset.getString(9)==null?"":rset.getString(9);
				
				qty_mmbtu=nf.format(rset.getDouble(10));
				price_cd=rset.getString(12)==null?"":rset.getString(12);
				price=utilBean.RateNumberFormat(rset.getDouble(11), price_cd);
				gross_amt=nf.format(rset.getDouble(13));
				exchang_rate=nf2.format(rset.getDouble(14));
				gross_amt1=nf.format(rset.getDouble(15));
				tax_amt=nf.format(rset.getDouble(16));
				tax_struct_cd=rset.getString(17)==null?"":rset.getString(17);
				tax_struct_dt=rset.getString(18)==null?"":rset.getString(18);
				invoice_amt=nf.format(rset.getDouble(19));
				net_payable=nf.format(rset.getDouble(20));
				applicable_abbr=rset.getString(21)==null?"":rset.getString(21);
				applicable_amt=rset.getString(22)==null?"":rset.getString(22);
				TCS_factor=rset.getString(23)==null?"":rset.getString(23);
				if(!TCS_factor.equals(""))
				{
					TCS_factor=nf3.format(rset.getDouble(23));
				}
				
				if(activityFlag.equals("CHECK")) {
					activity_value=rset.getString(24)==null?"":rset.getString(24);
				}else if(activityFlag.equals("APPROVE")) {
					activity_value=rset.getString(25)==null?"":rset.getString(25);
				}
				
				//tax_struct_dtl=utilBean.getEntityTaxStructureDtl(conn,comp_cd, counterparty_cd, "C", plant_seq, bu_unit, period_start_dt);
				tax_struct_dtl=utilBean.getTaxDescr(conn, tax_struct_cd);
				
				transportation_charges=rset.getString(27)==null?"":nf2.format(rset.getDouble(27));
				transportation_amount=rset.getString(28)==null?"":nf.format(rset.getDouble(28));
				
				exchng_rate_cd=rset.getString(29)==null?"":rset.getString(29);
				exchang_rate_dt=rset.getString(30)==null?"":rset.getString(30);
				exchang_rate_type=rset.getString(31)==null?"":rset.getString(31);
				invoice_raised_in=rset.getString(32)==null?"":rset.getString(32);
				
				gross_include_transport_tariff=nf.format(Double.parseDouble(gross_amt1));
			}
			rset.close();
			stmt.close();
			
			
			queryString1="SELECT CONT_REF_NO,TO_CHAR(DDA_DT,'DD-MON-YY'),TRADE_REF_NO,TO_CHAR(SIGNING_DT,'DD-MON-YY'),AGMT_BASE,DCQ,MDCQ_PERCENTAGE  "
					+ "FROM FMS_SUPPLY_CONT_MST A "
					+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE=? "
					+ "AND CONT_NO=? AND AGMT_NO=? AND COUNTERPARTY_CD=? "
					+ "AND CONT_REV = (SELECT MAX(CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
					+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) ";
			stmt1=conn.prepareStatement(queryString1);
			stmt1.setString(1, comp_cd);
			stmt1.setString(2, contract_type);
			stmt1.setString(3, cont_no);
			stmt1.setString(4, agmt_no);
			stmt1.setString(5, counterparty_cd);
			rset1=stmt1.executeQuery();
			if(rset1.next())
			{
				contRef=rset1.getString(1)==null?"":rset1.getString(1);
				dda_dt=rset1.getString(2)==null?"":rset1.getString(2);
				String tradeRef=rset1.getString(3)==null?"":rset1.getString(3);
				signingDt=rset1.getString(4)==null?"":rset1.getString(4);
				agmt_base=rset1.getString(5)==null?"":rset1.getString(5);
				dcq=rset1.getString(6)==null?"":rset1.getString(6);
				
				mdcq_percentage=rset1.getDouble(7);
				if(Double.doubleToRawLongBits(mdcq_percentage)==Double.doubleToRawLongBits(0))
				{
					mdcq_percentage=100;
				}
				
				if(contract_type.equals("W"))
				{
					contRef=tradeRef;
				}
			}
			rset1.close();
			stmt1.close();
			
			if(contract_type.equals("F"))
			{
				queryString2="SELECT TO_CHAR(SIGNING_DT,'DD-MON-YY')  "
						+ "FROM FMS_AGMT_MST A "
						+ "WHERE COMPANY_CD=? AND AGMT_TYPE=? "
						+ "AND AGMT_NO=? AND COUNTERPARTY_CD=? "
						+ "AND AGMT_REV = (SELECT MAX(AGMT_REV) FROM FMS_AGMT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_TYPE=B.AGMT_TYPE) ";
				stmt2=conn.prepareStatement(queryString2);
				stmt2.setString(1, comp_cd);
				stmt2.setString(2, "D");
				stmt2.setString(3, agmt_no);
				stmt2.setString(4, counterparty_cd);
				rset2=stmt2.executeQuery();
				if(rset2.next())
				{
					agmtSigningDt=rset2.getString(1)==null?"":rset2.getString(1);
				}
				rset2.close();
				stmt2.close();
			}
			
			queryString2="SELECT CONTACT_PERSON "
					+ "FROM FMS_ENTITY_CONTACT_MST A "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND ENTITY=? AND SEQ_NO=? AND ADDR_FLAG=? AND TYPE=? "
					+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO AND A.TYPE=B.TYPE "
					+ "AND EFF_DT <= TO_DATE(?,'DD-MON-YY'))";
			stmt2=conn.prepareStatement(queryString2);
			stmt2.setString(1, comp_cd);
			stmt2.setString(2, counterparty_cd);
			stmt2.setString(3, "C");
			stmt2.setString(4, contact_person_cd);
			stmt2.setString(5, "P"+plant_seq);
			stmt2.setString(6, "DLNG");
			stmt2.setString(7, invoice_dt);
			rset2=stmt2.executeQuery();
			if(rset2.next())
			{
				contact_person_nm=rset2.getString(1)==null?"":rset2.getString(1);
			}
			rset2.close();
			stmt2.close();
			
			queryString3="SELECT CONTACT_PERSON "
					+ "FROM FMS_ENTITY_CONTACT_MST A "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND ENTITY=? AND SEQ_NO=? AND ADDR_FLAG=? AND TYPE=? "
					+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO AND A.TYPE=B.TYPE "
					+ "AND EFF_DT <= TO_DATE(?,'DD-MON-YY'))";
			stmt3=conn.prepareStatement(queryString3);
			stmt3.setString(1, comp_cd);
			stmt3.setString(2, comp_cd);
			stmt3.setString(3, "B");
			stmt3.setString(4, bu_contact_person_cd);
			stmt3.setString(5, "P"+bu_unit);
			stmt3.setString(6, "DLNG");
			stmt3.setString(7, invoice_dt);
			rset3=stmt3.executeQuery();
			if(rset3.next())
			{
				bu_contact_person_nm=rset3.getString(1)==null?"":rset3.getString(1);
			}
			rset3.close();
			stmt3.close();
			
			HashMap bu_plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "B", comp_cd, bu_unit);
			bu_plantAddress=""+bu_plant_detail.get("plant_address");
			bu_plantCity=""+bu_plant_detail.get("plant_city");
			bu_plantState=""+bu_plant_detail.get("plant_state");
			bu_plantPin=""+bu_plant_detail.get("plant_pin");
			bu_plantNm=""+bu_plant_detail.get("plant_name");
			
			HashMap plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "C", counterparty_cd, plant_seq);
			plantAddress=""+plant_detail.get("plant_address");
			plantCity=""+plant_detail.get("plant_city");
			plantState=""+plant_detail.get("plant_state");
			plantPin=""+plant_detail.get("plant_pin");
			
			
			tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "C", counterparty_cd, plant_seq);
			tax_info=tax_info.replaceAll("\n", "<br>");
			
			bu_tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "B", comp_cd, bu_unit);
			bu_tax_info=bu_tax_info.replaceAll("\n", "<br>");
			
			couterpty_nm=""+utilBean.getCounterpartyName(conn,counterparty_cd);
			int srno=0;
			
			String parameter="counterparty_cd="+counterparty_cd+"&contract_type="+contract_type+"&cont_no="+cont_no+""
					+ "&cont_rev="+cont_rev_no+"&agmt_no="+agmt_no+"&agmt_rev="+agmt_rev_no+"&plant_seq="+plant_seq+"&billing_cycle="+billing_cycle+""
					+ "&period_start_dt="+period_start_dt+"&period_end_dt="+period_end_dt+"&bu_unit="+bu_unit+"&financial_year="+financial_year+""
					+ "&bu_state_tin="+bu_state_tin+"&invoice_seq="+invoice_seq+"&activityFlag="+activityFlag+"&cargo_no="+cargo_no+"&inv_flag="+inv_flag;

			price_cd_nm=""+utilBean.getRateUnitNm(conn,price_cd);
			

			srno+=1;
			VPDF_COL1.add(srno);
			VPDF_COL2.add("LNG Delivered");
			VPDF_COL3.add("<a onclick=openAtt1('rpt_view_attachment1.jsp?"+parameter+"')>Att1</a>");
			VPDF_COL4.add(""+utilBean.getRateUnitNm(conn,price_cd));
			VPDF_COL5.add(qty_mmbtu);
			VPDF_COL6.add(price);
			VPDF_COL7.add(gross_amt);
			
			if(price_cd.equals("2"))
			{
				/*srno+=1;
				VPDF_COL1.add(srno);
				VPDF_COL2.add("Gross Amount");
				VPDF_COL3.add("");
				VPDF_COL4.add("USD");
				VPDF_COL5.add("");
				VPDF_COL6.add("");
				VPDF_COL7.add(gross_amt);
				*/
				srno+=1;
				VPDF_COL1.add(srno);
				VPDF_COL2.add("Exchange Rate");
				VPDF_COL3.add("<a onclick=openAtt2('rpt_view_attachment2.jsp?"+parameter+"')>Att2</a>");
				VPDF_COL4.add("INR/USD");
				VPDF_COL5.add("");
				VPDF_COL6.add(exchang_rate);
				VPDF_COL7.add("");
			}
			
			srno+=1;
			VPDF_COL1.add(srno);
			VPDF_COL2.add("Gross Amount");
			VPDF_COL3.add("");
			VPDF_COL4.add("INR");
			VPDF_COL5.add("");
			VPDF_COL6.add("");
			VPDF_COL7.add(gross_amt1);
			
			if(!transportation_charges.equals(""))
			{
				if(Double.parseDouble(transportation_amount) > 0)
				{
					srno+=1;
					VPDF_COL1.add(srno);
					VPDF_COL2.add("Transportation Tariff");
					VPDF_COL3.add("");
					VPDF_COL4.add("INR");
					VPDF_COL5.add("");
					VPDF_COL6.add(transportation_charges);
					VPDF_COL7.add(transportation_amount);
				}
			}
			
			if(!marketing_margin.equals(""))
			{
				if(Double.parseDouble(marketing_margin_amount) > 0)
				{
					srno+=1;
					VPDF_COL1.add(srno);
					VPDF_COL2.add("Marketing Margin");
					VPDF_COL3.add("");
					VPDF_COL4.add("INR");
					VPDF_COL5.add("");
					VPDF_COL6.add(marketing_margin);
					VPDF_COL7.add(marketing_margin_amount);
				}
			}
			
			if(!other_charges.equals(""))
			{
				if(Double.parseDouble(other_charges_amount) > 0)
				{
					srno+=1;
					VPDF_COL1.add(srno);
					VPDF_COL2.add("Other Charges");
					VPDF_COL3.add("");
					VPDF_COL4.add("INR");
					VPDF_COL5.add("");
					VPDF_COL6.add(other_charges);
					VPDF_COL7.add(other_charges_amount);
				}
			}
			
			/*if(isGrossIncTriff)
			{
				srno+=1;
				VPDF_COL1.add(srno);
				VPDF_COL2.add("Total Gross Amount");
				VPDF_COL3.add("");
				VPDF_COL4.add("INR");
				VPDF_COL5.add("");
				VPDF_COL6.add("");
				VPDF_COL7.add(gross_include_transport_tariff);
			}*/
			
			srno+=1;
			VPDF_COL1.add(srno);
			VPDF_COL2.add("Tax ("+tax_struct_dtl+")");
			VPDF_COL3.add("");
			VPDF_COL4.add("INR");
			VPDF_COL5.add("");
			VPDF_COL6.add("");
			VPDF_COL7.add(tax_amt);
			
			double temp_srno=srno;
			queryString1="SELECT COUNT(*) "
					+ "FROM FMS_DLNG_INV_TAX_DTL "
					+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
					+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
			stmt1=conn.prepareStatement(queryString1);
			stmt1.setString(1, comp_cd);
			stmt1.setString(2, bu_state_tin);
			stmt1.setString(3, financial_year);
			stmt1.setString(4, invoice_seq);
			rset1=stmt1.executeQuery();
			if(rset1.next())
			{
				if(rset1.getInt(1)>1)
				{
					queryString="SELECT TAX_CODE,TAX_DESCR,TAX_AMT,TAX_BASE_AMT "
							+ "FROM FMS_DLNG_INV_TAX_DTL "
							+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
							+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(1, comp_cd);
					stmt.setString(2, bu_state_tin);
					stmt.setString(3, financial_year);
					stmt.setString(4, invoice_seq);
					rset=stmt.executeQuery();
					while(rset.next())
					{
						temp_srno=temp_srno+0.1;
						VPDF_COL1.add(nf0.format(temp_srno));
						VPDF_COL2.add(rset.getString(2)==null?"":rset.getString(2));
						VPDF_COL3.add("");
						VPDF_COL4.add("INR");
						VPDF_COL5.add("");
						VPDF_COL6.add("");
						VPDF_COL7.add(rset.getString(3)==null?"":nf.format(rset.getDouble(3)));
					}
					rset.close();
					stmt.close();
				}
			}
			rset1.close();
			stmt1.close();
			
			String invAmtLbl="Invoice Amount";
			srno+=1;
			VPDF_COL1.add(srno);
			VPDF_COL2.add(invAmtLbl);
			VPDF_COL3.add("");
			VPDF_COL4.add("INR");
			VPDF_COL5.add("");
			VPDF_COL6.add("");
			VPDF_COL7.add(invoice_amt);
			
			if(applicable_abbr.equals("TCS"))
			{
				srno+=1;
				VPDF_COL1.add(srno);
				VPDF_COL2.add("TCS");
				VPDF_COL3.add("");
				VPDF_COL4.add("INR");
				VPDF_COL5.add("");
				VPDF_COL6.add(TCS_factor+"%");
				VPDF_COL7.add(applicable_amt);
			}
			
			srno+=1;
			VPDF_COL1.add(srno);
			VPDF_COL2.add("Net Amount Payable");
			VPDF_COL3.add("");
			VPDF_COL4.add("INR");
			VPDF_COL5.add("");
			VPDF_COL6.add("");
			VPDF_COL7.add(net_payable);
			
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getInvoiceNumber()
	{
		String function_nm="getInvoiceNumber()";
		try
		{
			String invoice_prefix=utilBean.getInvoicePrefix(conn,comp_cd);
			
			String fin_yr="";
			if(!financial_year.equals(""))
			{
				String[] temp = financial_year.split("-");
				fin_yr=temp[0].substring(2,temp[0].length())+"-"+temp[1].substring(2,temp[1].length());
			}
			
			String state_abbr="";
			String state_code=bu_state_tin;
			if(state_code.length()<=1)
			{
				state_code="0"+state_code;
			}
			
			if(!invoice_id_seq.equals(""))
			{
				VINVOICE_ID_SEQ.add(invoice_id_seq);
				VINVOICE_NO.add(invoice_no);
			}
			
			String contType="";
			String invSeries="";
			
			contType="'F','E','W'";
			invSeries="T";
			
			if(!invoice_prefix.equals(""))
			{
				int no_inv_no=10;
				for(int i=1;i<=no_inv_no;i++)
				{
					String invoice_id_seq=""+i;
					int count=0;
					queryString="SELECT COUNT(*) "
							+ "FROM FMS_DLNG_INVOICE_MST "
							+ "WHERE COMPANY_CD=? AND FINANCIAL_YEAR=? "
							+ "AND BU_STATE_TIN=? AND INVOICE_ID_SEQ=? AND CONTRACT_TYPE IN ("+contType+") ";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(1, comp_cd);
					stmt.setString(2, financial_year);
					stmt.setString(3, bu_state_tin);
					stmt.setString(4, invoice_id_seq);
					rset=stmt.executeQuery();
					if(rset.next())
					{
						count += rset.getInt(1);
					}
					rset.close();
					stmt.close();
					
					/*if(invSeries.equals("S"))
					{
						queryString1="SELECT COUNT(*) "
								+ "FROM FMS_FFLOW_INV_MST "
								+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
								+ "AND FINANCIAL_YEAR=? AND INVOICE_TYPE=? "
								+ "AND INVOICE_ID_SEQ=? ";
						stmt1=conn.prepareStatement(queryString1);
						stmt1.setString(1, comp_cd);
						stmt1.setString(2, bu_state_tin);
						stmt1.setString(3, financial_year);
						stmt1.setString(4, "S");
						stmt1.setString(5, invoice_id_seq);
						rset1=stmt1.executeQuery();
						if(rset1.next())
						{
							count += rset1.getInt(1);
						}
						rset1.close();
						stmt1.close();
					}*/
					
					if(count==0)
					{	
						queryString2="SELECT STATE_CODE "
								+ "FROM FMS_STATE_MST "
								+ "WHERE TIN=?";
						stmt2=conn.prepareStatement(queryString2);
						stmt2.setString(1, state_code);
						rset2=stmt2.executeQuery();
						if(rset2.next())
						{
							state_abbr=rset2.getString(1)==null?"":rset2.getString(1);
						}
						rset2.close();
						stmt2.close();
						String invoice_no="";
						invoice_no=invoice_prefix+""+invSeries+""+state_abbr+""+utilBean.PrePaddingZero(invoice_id_seq, 4)+"/"+fin_yr;
						
						VINVOICE_ID_SEQ.add(invoice_id_seq);
						VINVOICE_NO.add(invoice_no);
					}
					else
					{
						no_inv_no+=1;
					}
				}
			}
			
			if(invoice_id_seq.equals(""))
			{
				if(VINVOICE_ID_SEQ.size()>0)
				{
					invoice_id_seq=""+VINVOICE_ID_SEQ.elementAt(0);
				}
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void generateSalesInvoiceXML()
	{
		String function_nm="generateSalesInvoiceXML()";
		
		try
		{
			String sysdate=utilDate.getSysdate();
			String sysdateWithTime=utilDate.getSysdateWithTime24hr();
			String xml_sysdate="";
			String postingMonth="";
			String[] split=sysdate.split("/");
			xml_sysdate=split[2]+""+split[1]+""+split[0];
			postingMonth=split[2]+""+split[1];
			
			String[] splitSys = sysdateWithTime.split(" ");
			String date_timestamp=xml_sysdate+" "+splitSys[1];
			
			String counterparty_abbr=utilBean.getCounterpartyABBR(conn,counterparty_cd);
			
			String accountingPeriodMonth=split[1];
			String accountingPeriodYear=split[2];
			String productionPeriodMonth="";
			String productionPeriodYear="";
			String docHeaderText="";
			String refNum="";
			String exchangeRate="";
			String account=utilBean.getCounterpartySAPcode(conn,counterparty_cd);
			String taxCode="";
			String monthNm="";
			String paymentDueDt="";
			
			String netPayable="";
			String taxStructCd="";
			String taxStructDt="";
			String cont_no="";
			String agmt_no="";
			String cargo_no="";
			String gross_amt="";
			String qty="";
			String tcs_tds="";
			String tcsStructCd="";
			String tcsStructDt="";
			String tdsStructCd="";
			String tdsStructDt="";
			String tcs_amt="";
			String tds_amt="";
			String tax_amt="";
			String invoiceAmt="";
			
			String fms_MessageId="";
			
			String plant_seq="";
		    String plantAddress="";
		    String plantCity="";
		    String plantState="";
		    String plantPin="";
		    String plantNm="";
		    
		    String cash_flow="";
		    
		    String tcs_factor="";
		    String tds_factor="";
		    
		    String sub_inv_type="";
		    String documentDate="";
			String postingDate=xml_sysdate; //AS DISCUSSED WITH VIJAY AND DIVYA ON 20250811 IN WORKSHOP CHENNAI, POSTING DATE WILL BE XML APPROVAL DATE
			String inv_flag="";
			String invDt="";
		    
		    if(type_flag.equals("FFLOW"))
			{
				queryString="SELECT TO_CHAR(PERIOD_END_DT,'DD/MM/YYYY'),BU_UNIT,INVOICE_NO,EXCHG_RATE_VALUE,NET_PAYABLE_AMT,"
						+ "TAX_STRUCT_CD,TO_CHAR(TAX_EFF_DT,'DD/MM/YYYY'),CONT_NO,GROSS_AMT_INR,ALLOC_QTY,TCS_TDS,"
						+ "TCS_STRUCT_CD,TO_CHAR(TCS_EFF_DT,'DD/MM/YYYY'),TDS_STRUCT_CD,TO_CHAR(TDS_EFF_DT,'DD/MM/YYYY'),"
						+ "TCS_AMT,TDS_GROSS_AMT,TAX_AMT,INVOICE_RAISED_IN,GROSS_AMT_USD,TO_CHAR(DUE_DT,'DD/MM/YYYY'),INVOICE_AMT,ADDR_FLAG,"
						+ "AGMT_NO,INVOICE_CATEGORY,SUB_INV_TYPE,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),TO_CHAR(APPROVED_DT,'DD/MM/YYYY') "
						+ "FROM FMS_DLNG_FFLOW_INV_MST A "
						+ "WHERE COMPANY_CD=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
						+ "AND FINANCIAL_YEAR=? AND INVOICE_TYPE=?";
				stmt = conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, invoice_seq);
				stmt.setString(3, bu_state_tin);
				stmt.setString(4, financial_year);
				stmt.setString(5, invoice_type);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					String period_end=rset.getString(1)==null?"":rset.getString(1);
					if(!period_end.equals(""))
					{
						String[] temp_split=period_end.split("/");
						productionPeriodMonth=temp_split[1];
						productionPeriodYear=temp_split[2];		
					}
					monthNm=""+utilDate.getShortMonthName(period_end);
					
					String buUnit=rset.getString(2)==null?"":rset.getString(2);
					
					String buStateNm="";
					String buAbbr="";
					queryString1 = "SELECT PLANT_STATE,PLANT_ABBR "
							+ "FROM FMS_COUNTERPARTY_PLANT_DTL A "
							+ "WHERE COUNTERPARTY_CD=? AND ENTITY=? AND COMPANY_CD=? AND SEQ_NO=? "
							+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_COUNTERPARTY_PLANT_DTL B WHERE A.COUNTERPARTY_CD=B.COUNTERPARTY_CD "
							+ "AND A.SEQ_NO=B.SEQ_NO AND A.COMPANY_CD=B.COMPANY_CD AND B.EFF_DT<=TO_DATE(TO_CHAR(SYSDATE,'DD/MM/YYYY'),'DD/MM/YYYY') AND A.ENTITY=B.ENTITY) ";
					stmt1 = conn.prepareStatement(queryString1);
					stmt1.setString(1, comp_cd);
					stmt1.setString(2, "B");
					stmt1.setString(3, comp_cd);
					stmt1.setString(4, buUnit);
					rset1=stmt1.executeQuery();
					if(rset1.next())
					{
						buStateNm=rset1.getString(1)==null?"":rset1.getString(1);
						buAbbr=rset1.getString(2)==null?"":rset1.getString(2);
					}
					rset1.close();
					stmt1.close();
					docHeaderText=buStateNm+"/"+buAbbr+" - BU";
					
					refNum=rset.getString(3)==null?"":rset.getString(3);
					exchangeRate=rset.getString(4)==null?"":nf.format(rset.getDouble(4));
					netPayable=rset.getString(5)==null?"":nf.format(rset.getDouble(5));
					
					taxStructCd=rset.getString(6)==null?"":rset.getString(6);
					taxStructDt=rset.getString(7)==null?"":rset.getString(7);
					
					taxCode=utilBean.getTaxSAPcode(conn,taxStructCd);
					cont_no=rset.getString(8)==null?"":rset.getString(8);
					gross_amt=rset.getString(9)==null?"":nf.format(rset.getDouble(9));
					qty=rset.getString(10)==null?"":nf.format(rset.getDouble(10));
					tcs_tds=rset.getString(11)==null?"":rset.getString(11);
					
					tcsStructCd=rset.getString(12)==null?"":rset.getString(12);
					tcsStructDt=rset.getString(13)==null?"":rset.getString(13);
					tdsStructCd=rset.getString(14)==null?"":rset.getString(14);
					tdsStructDt=rset.getString(15)==null?"":rset.getString(15);
					
					tcs_amt=rset.getString(16)==null?"":nf.format(rset.getDouble(16));
					tds_amt=rset.getString(17)==null?"":nf.format(rset.getDouble(17));
					tax_amt=rset.getString(18)==null?"":nf.format(rset.getDouble(18));
					
					String inv_raised_in=rset.getString(19)==null?"":rset.getString(19);
					if(inv_raised_in.equals("2") && !exchangeRate.equals(""))
					{
						netPayable=rset.getString(5)==null?"":nf.format(rset.getDouble(5) * Double.parseDouble(exchangeRate));
						
						gross_amt=rset.getString(20)==null?"":nf.format(rset.getDouble(20) * Double.parseDouble(exchangeRate));
						
						tcs_amt=rset.getString(16)==null?"":nf.format(rset.getDouble(16) * Double.parseDouble(exchangeRate));
						tds_amt=rset.getString(17)==null?"":nf.format(rset.getDouble(17) * Double.parseDouble(exchangeRate));
						tax_amt=rset.getString(18)==null?"":nf.format(rset.getDouble(18) * Double.parseDouble(exchangeRate));
					}
					
					paymentDueDt=rset.getString(21)==null?"":rset.getString(21);
					if(!paymentDueDt.equals(""))
					{
						String splitPayDt[]=paymentDueDt.split("/");
						paymentDueDt=splitPayDt[2]+""+splitPayDt[1]+""+splitPayDt[0];
					}
					
					invoiceAmt=rset.getString(22)==null?"":nf.format(rset.getDouble(22));
					String addressType=rset.getString(23)==null?"":rset.getString(23);
					if(!addressType.equals("R") && !addressType.equals("B") && !addressType.equals("C"))
					{
						plant_seq=addressType.substring(1,addressType.length());
					}
					agmt_no=rset.getString(24)==null?"":rset.getString(24);
					
					String inv_category=rset.getString(25)==null?"":rset.getString(25);
					if(inv_category.equals("P"))
					{
						cash_flow="Commodity";
					}
					else if(inv_category.equals("S"))
					{
						cash_flow="Service";
					}
					
					sub_inv_type=rset.getString(26)==null?"":rset.getString(26);
					
					String invoiceDt=rset.getString(27)==null?"":rset.getString(27);
					invDt=invoiceDt;
					if(!invoiceDt.equals(""))
					{
						String[] temp_split=invoiceDt.split("/");
						documentDate=temp_split[2]+""+temp_split[1]+""+temp_split[0];
					}
					
					String approve_dt=rset.getString(28)==null?"":rset.getString(28);
					/*if(!approve_dt.equals(""))
					{
						String[] temp_split=approve_dt.split("/");
						postingDate=temp_split[2]+""+temp_split[1]+""+temp_split[0];
					}*/
					
					queryString1="SELECT FACTOR "
							+ "FROM FMS_TAX_STRUCTURE_DTL A "
							+ "WHERE TAX_STR_CD=? ";
							//+ "AND APP_DATE=TO_DATE(?,'DD/MM/YYYY') ";
					stmt2 = conn.prepareStatement(queryString1);
					stmt2.setString(1, tcsStructCd);
					//stmt2.setString(2, tcsStructDt);
					rset2=stmt2.executeQuery();
					if(rset2.next())
					{
						tcs_factor=rset2.getString(1)==null?"":nf.format(rset2.getDouble(1));
					}
					rset2.close();
					stmt2.close();
					
					queryString1="SELECT FACTOR "
							+ "FROM FMS_TAX_STRUCTURE_DTL A "
							+ "WHERE TAX_STR_CD=? ";
							//+ "AND APP_DATE=TO_DATE(?,'DD/MM/YYYY') ";
					stmt3 = conn.prepareStatement(queryString1);
					stmt3.setString(1, tdsStructCd);
					//stmt3.setString(2, tdsStructDt);
					rset3=stmt3.executeQuery();
					if(rset3.next())
					{
						tds_factor=rset3.getString(1)==null?"":nf.format(rset3.getDouble(1));
					}
					rset3.close();
					stmt3.close();
				}
				rset.close();
				stmt.close();
			}
			else
			{
				queryString="SELECT TO_CHAR(PERIOD_END_DT,'DD/MM/YYYY'),BU_UNIT,INVOICE_NO,EXCHG_RATE_VALUE,NET_PAYABLE_AMT,"
						+ "TAX_STRUCT_CD,TO_CHAR(TAX_EFF_DT,'DD/MM/YYYY'),CONT_NO,GROSS_AMT,ALLOC_QTY,TCS_TDS,"
						+ "TCS_STRUCT_CD,TO_CHAR(TCS_EFF_DT,'DD/MM/YYYY'),TDS_STRUCT_CD,TO_CHAR(TDS_EFF_DT,'DD/MM/YYYY'),"
						+ "TCS_AMT,TDS_GROSS_AMT,TAX_AMT,INVOICE_RAISED_IN,TO_CHAR(DUE_DT,'DD/MM/YYYY'),INVOICE_AMT,PLANT_SEQ,"
						+ "AGMT_NO,NULL,NULL,NULL,TCS_FACTOR,TDS_GROSS_PERCENT,"
						+ "TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),TO_CHAR(APPROVED_DT,'DD/MM/YYYY'),INV_FLAG "
						+ "FROM FMS_DLNG_INVOICE_MST A "
						+ "WHERE COMPANY_CD=? AND FINANCIAL_YEAR=? "
						+ "AND INVOICE_SEQ=? AND BU_STATE_TIN=?";
				stmt = conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, financial_year);
				stmt.setString(3, invoice_seq);
				stmt.setString(4, bu_state_tin);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					String period_end=rset.getString(1)==null?"":rset.getString(1);
					if(!period_end.equals(""))
					{
						String[] temp_split=period_end.split("/");
						productionPeriodMonth=temp_split[1];
						productionPeriodYear=temp_split[2];		
					}
					monthNm=""+utilDate.getShortMonthName(period_end);
					
					String buUnit=rset.getString(2)==null?"":rset.getString(2);
					
					String buStateNm="";
					String buAbbr="";
					queryString1 = "SELECT PLANT_STATE,PLANT_ABBR "
							+ "FROM FMS_COUNTERPARTY_PLANT_DTL A "
							+ "WHERE COUNTERPARTY_CD=? AND ENTITY=? AND COMPANY_CD=? AND SEQ_NO=? "
							+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_COUNTERPARTY_PLANT_DTL B WHERE A.COUNTERPARTY_CD=B.COUNTERPARTY_CD "
							+ "AND A.SEQ_NO=B.SEQ_NO AND A.COMPANY_CD=B.COMPANY_CD AND B.EFF_DT<=TO_DATE(TO_CHAR(SYSDATE,'DD/MM/YYYY'),'DD/MM/YYYY') AND A.ENTITY=B.ENTITY) ";
					stmt1 = conn.prepareStatement(queryString1);
					stmt1.setString(1, comp_cd);
					stmt1.setString(2, "B");
					stmt1.setString(3, comp_cd);
					stmt1.setString(4, buUnit);
					rset1=stmt1.executeQuery();
					if(rset1.next())
					{
						buStateNm=rset1.getString(1)==null?"":rset1.getString(1);
						buAbbr=rset1.getString(2)==null?"":rset1.getString(2);
					}
					rset1.close();
					stmt1.close();
					docHeaderText=buStateNm+"/"+buAbbr+" - BU";
					
					refNum=rset.getString(3)==null?"":rset.getString(3);
					exchangeRate=rset.getString(4)==null?"":nf.format(rset.getDouble(4));
					netPayable=rset.getString(5)==null?"":nf.format(rset.getDouble(5));
					
					taxStructCd=rset.getString(6)==null?"":rset.getString(6);
					taxStructDt=rset.getString(7)==null?"":rset.getString(7);
					
					taxCode=utilBean.getTaxSAPcode(conn,taxStructCd);
					cont_no=rset.getString(8)==null?"":rset.getString(8);
					gross_amt=rset.getString(9)==null?"":nf.format(rset.getDouble(9));
					
					/*String transportation_amount=rset.getString(24)==null?"":nf.format(rset.getDouble(24));
					String marketing_margin_amount=rset.getString(25)==null?"":nf.format(rset.getDouble(25));
					String other_charges_amount=rset.getString(26)==null?"":nf.format(rset.getDouble(26));
					
					if(!transportation_amount.equals("") && !gross_amt.equals(""))
					{
						gross_amt=nf.format(Double.parseDouble(gross_amt)+Double.parseDouble(transportation_amount));
					}

					if(!marketing_margin_amount.equals("") && !gross_amt.equals(""))
					{
						gross_amt=nf.format(Double.parseDouble(gross_amt)+Double.parseDouble(marketing_margin_amount));
					}
					
					if(!other_charges_amount.equals("") && !gross_amt.equals(""))
					{
						gross_amt=nf.format(Double.parseDouble(gross_amt)+Double.parseDouble(other_charges_amount));
					}*/
					
					qty=rset.getString(10)==null?"":nf.format(rset.getDouble(10));
					tcs_tds=rset.getString(11)==null?"":rset.getString(11);
					
					tcsStructCd=rset.getString(12)==null?"":rset.getString(12);
					tcsStructDt=rset.getString(13)==null?"":rset.getString(13);
					tdsStructCd=rset.getString(14)==null?"":rset.getString(14);
					tdsStructDt=rset.getString(15)==null?"":rset.getString(15);
					
					tcs_amt=rset.getString(16)==null?"":nf.format(rset.getDouble(16));
					tds_amt=rset.getString(17)==null?"":nf.format(rset.getDouble(17));
					tax_amt=rset.getString(18)==null?"":nf.format(rset.getDouble(18));
					
					String inv_raised_in=rset.getString(19)==null?"":rset.getString(19);
					if(inv_raised_in.equals("2") && !exchangeRate.equals(""))
					{
						netPayable=rset.getString(5)==null?"":nf.format(rset.getDouble(5) * Double.parseDouble(exchangeRate));
						
						gross_amt=rset.getString(9)==null?"":nf.format(rset.getDouble(9) * Double.parseDouble(exchangeRate));
						
						tcs_amt=rset.getString(16)==null?"":nf.format(rset.getDouble(16) * Double.parseDouble(exchangeRate));
						tds_amt=rset.getString(17)==null?"":nf.format(rset.getDouble(17) * Double.parseDouble(exchangeRate));
						tax_amt=rset.getString(18)==null?"":nf.format(rset.getDouble(18) * Double.parseDouble(exchangeRate));
					}
					
					paymentDueDt=rset.getString(20)==null?"":rset.getString(20);
					if(!paymentDueDt.equals(""))
					{
						String splitPayDt[]=paymentDueDt.split("/");
						paymentDueDt=splitPayDt[2]+""+splitPayDt[1]+""+splitPayDt[0];
					}
					
					invoiceAmt=rset.getString(21)==null?"":nf.format(rset.getDouble(21));
					plant_seq=rset.getString(22)==null?"":rset.getString(22);
					agmt_no=rset.getString(23)==null?"":rset.getString(23);
					
					cash_flow="Commodity";
					if(contract_type.equals("O") || contract_type.equals("Q")) {
						cash_flow="Re-Gas Capacity";
					}
					
					tcs_factor=rset.getString(27)==null?"":nf.format(rset.getDouble(27));
					tds_factor=rset.getString(28)==null?"":nf.format(rset.getDouble(28));
					
					String invoiceDt=rset.getString(29)==null?"":rset.getString(29);
					invDt=invoiceDt;
					if(!invoiceDt.equals(""))
					{
						String[] temp_split=invoiceDt.split("/");
						documentDate=temp_split[2]+""+temp_split[1]+""+temp_split[0];
					}
					
					String approve_dt=rset.getString(30)==null?"":rset.getString(30);
					/*if(!approve_dt.equals(""))
					{
						String[] temp_split=approve_dt.split("/");
						postingDate=temp_split[2]+""+temp_split[1]+""+temp_split[0];
					}*/
					
					inv_flag=rset.getString(31)==null?"":rset.getString(31);
				}
				rset.close();
				stmt.close();
			}
			
			HashMap plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "C", counterparty_cd, plant_seq);
            plantAddress=""+plant_detail.get("plant_address");
			plantCity=""+plant_detail.get("plant_city");
			plantState=""+plant_detail.get("plant_state");
			plantPin=""+plant_detail.get("plant_pin");
			plantNm=""+plant_detail.get("plant_name");
			
			String assignmentNo=utilBean.NewDealMappingId(comp_cd, counterparty_cd, agmt_no, "", cont_no, "", contract_type, cargo_no);
			String material_code="1168001";
			fms_MessageId=refNum.replaceAll("/", "-");
	    	
	    	String UserID = ""+utilBean.getUserName(conn,emp_cd);
	    	String businessAreaCode=utilBean.getBusinessAreaSAPcode(conn, comp_cd, "C", contract_type, invDt);
		    
			DocumentBuilderFactory docFactory = xmlUtil.dcoumentBuilderFactory();
		    DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

		    Document doc = docBuilder.newDocument();
		    
		    //root fmsng
		    Element fmsng = doc.createElement("EmsSAPArMessage");
		    doc.appendChild(fmsng);

		    //root elements
		    Element Header = doc.createElement("Header");
		    fmsng.appendChild(Header);
		    Element Invoice = doc.createElement("Invoice");
		    fmsng.appendChild(Invoice);
		    
		    //Header elements
		    Element MessageId = doc.createElement("MessageId");
		    Element Scope = doc.createElement("Scope");
		    Element DateTimeStamp = doc.createElement("DateTimeStamp");
		    Element DataSource = doc.createElement("DataSource");
		    
		    Header.appendChild(MessageId);
		    Header.appendChild(Scope);
		    Header.appendChild(DateTimeStamp);
		    Header.appendChild(DataSource);
		    
		    MessageId.appendChild(doc.createTextNode(fms_MessageId));
		    Scope.appendChild(doc.createTextNode(utilBean.getCompanySAPcode(conn, comp_cd)+"Accounting"));
		    DateTimeStamp.appendChild(doc.createTextNode(date_timestamp));
		    DataSource.appendChild(doc.createTextNode(CommonVariable.app_name));
		    
		    //Invoice elements
		    Element InvoiceHeader = doc.createElement("InvoiceHeader");
		    Invoice.appendChild(InvoiceHeader);
		    
		    Element BusinessActivity = doc.createElement("BusinessActivity");
		    Element DocumentType = doc.createElement("DocumentType");
		    Element DocumentDate = doc.createElement("DocumentDate");
		    Element PostingDate = doc.createElement("PostingDate");
		    Element AccountingPeriodMonth = doc.createElement("AccountingPeriodMonth");
		    Element AccountingPeriodYear = doc.createElement("AccountingPeriodYear");
		    Element InternalLegalEntity = doc.createElement("InternalLegalEntity");
		    Element DocHeaderText = doc.createElement("DocHeaderText");
		    Element RefNum = doc.createElement("RefNum");
		    Element EmsRefNum = doc.createElement("EmsRefNum");
		    Element Currency = doc.createElement("Currency");
		    Element LocalCurrency = doc.createElement("LocalCurrency");
		    Element ExchangeRate = doc.createElement("ExchangeRate");
		    Element CalculateTax = doc.createElement("CalculateTax");
		    Element TranslationDate = doc.createElement("TranslationDate");
		    Element TradingPartnerBusinessArea = doc.createElement("TradingPartnerBusinessArea");
		    Element AddressLine1 = doc.createElement("AddressLine");
		    Element AddressLine2 = doc.createElement("AddressLine");
		    Element AddressLine3 = doc.createElement("AddressLine");
		    Element AddressLine4 = doc.createElement("AddressLine");
		    Element AddressLine5 = doc.createElement("AddressLine");
		    Element AddressLine6 = doc.createElement("AddressLine");
		    Element AddressLine7 = doc.createElement("AddressLine");
		    Element AddressLine8 = doc.createElement("AddressLine");
		    Element UserName = doc.createElement("UserName");
		    
		    //InvoiceHeader element
		    InvoiceHeader.appendChild(BusinessActivity);
		    InvoiceHeader.appendChild(DocumentType);
		    InvoiceHeader.appendChild(DocumentDate);
		    InvoiceHeader.appendChild(PostingDate);
		    InvoiceHeader.appendChild(AccountingPeriodMonth);
		    InvoiceHeader.appendChild(AccountingPeriodYear);
		    InvoiceHeader.appendChild(InternalLegalEntity);
		    InvoiceHeader.appendChild(DocHeaderText);
		    InvoiceHeader.appendChild(RefNum);
		    InvoiceHeader.appendChild(EmsRefNum);
		    InvoiceHeader.appendChild(Currency);
		    InvoiceHeader.appendChild(LocalCurrency);
		    InvoiceHeader.appendChild(ExchangeRate);
		    InvoiceHeader.appendChild(CalculateTax);
		    InvoiceHeader.appendChild(TranslationDate);
		    InvoiceHeader.appendChild(TradingPartnerBusinessArea);
		    InvoiceHeader.appendChild(AddressLine1);
		    InvoiceHeader.appendChild(AddressLine2);
		    InvoiceHeader.appendChild(AddressLine3);
		    InvoiceHeader.appendChild(AddressLine4);
		    InvoiceHeader.appendChild(AddressLine5);
		    InvoiceHeader.appendChild(AddressLine6);
		    InvoiceHeader.appendChild(AddressLine7);
		    InvoiceHeader.appendChild(AddressLine8);
		    InvoiceHeader.appendChild(UserName);
		    
		    BusinessActivity.appendChild(doc.createTextNode("RFBU")); //FIXED VALUE AS INSTRUCTED BY MAHESH MOHAN
		    DocumentType.appendChild(doc.createTextNode("X2"));
		    //DocumentDate.appendChild(doc.createTextNode(xml_sysdate));
		    //PostingDate.appendChild(doc.createTextNode(xml_sysdate));
		    DocumentDate.appendChild(doc.createTextNode(documentDate));
		    PostingDate.appendChild(doc.createTextNode(postingDate));
		    AccountingPeriodMonth.appendChild(doc.createTextNode(accountingPeriodMonth));
		    AccountingPeriodYear.appendChild(doc.createTextNode(accountingPeriodYear));
		    InternalLegalEntity.appendChild(doc.createTextNode(utilBean.getCompanySAPcode(conn, comp_cd))); //NEED TO CHEACK FOR COMPANY BASE LOGIN JD-20230728
		    DocHeaderText.appendChild(doc.createTextNode(docHeaderText));
		    RefNum.appendChild(doc.createTextNode(refNum));
		    //EmsRefNum.appendChild(doc.createTextNode(refNum));
		    EmsRefNum.appendChild(doc.createTextNode(refNum));
		    Currency.appendChild(doc.createTextNode("INR")); //NO NEED TO SEND OTHER TYPE OF CURRENCY - JD
		    
		    AddressLine1.appendChild(doc.createTextNode(plantNm));
		    AddressLine2.appendChild(doc.createTextNode(plantAddress));
		    AddressLine3.appendChild(doc.createTextNode(plantState));
		    AddressLine4.appendChild(doc.createTextNode(plantCity));
		    AddressLine5.appendChild(doc.createTextNode(plantPin));
		    
		    UserName.appendChild(doc.createTextNode(UserID));
		    
		    int i=0;
		    if(!netPayable.equals(""))
		    {
		    	//since tds is not deducted from net_payable
		    	//as per vijay's mail 20230904
		    	/*if(tcs_tds.equals("TDS") && !tds_amt.equals("")) //AS PER VIJAY MAIL ON 19-10-2023 TO ADDRESS SAP LIMITATION FOR TDS
		    	{
		    		netPayable=nf.format(Double.parseDouble(netPayable) - Double.parseDouble(tds_amt));
		    	}*/
		    	
		    	String sign = "";
		    	String pk = "01";
		    	if(invoice_type.equals("CR") || invoice_type.equals("CCR"))
		    	{
		    		pk = "11";
		    		sign = "-";
		    	}
		    	////
		    	
		    	i+=1;
		    	Element InvoiceDetail = doc.createElement("InvoiceDetail");
		    	Invoice.appendChild(InvoiceDetail);
		    	
		    	Element VendorId  = doc.createElement("CustomerId");
		    	Element LineSeqNo = doc.createElement("LineSeqNo");
			    Element PostingKey = doc.createElement("PostingKey");
			   // Element Account = doc.createElement("Account");
			    Element TransactionType = doc.createElement("TransactionType");
			    Element CurrencyAmount = doc.createElement("CurrencyAmount");
			    Element LocalCurrencyAmount = doc.createElement("LocalCurrencyAmount");
			    Element TaxCode = doc.createElement("TaxCode");
			    Element BusinessArea = doc.createElement("BusinessArea");
			    Element ItemText = doc.createElement("ItemText");
			    Element Volume = doc.createElement("Volume");
			    Element VolumeUnit = doc.createElement("VolumeUnit");
			    Element ReferenceKey1 = doc.createElement("ReferenceKey1");
			    Element ReferenceKey2 = doc.createElement("ReferenceKey2");
			    Element ProductionPeriod = doc.createElement("ProductionPeriod");
			    Element AssignmentNumber = doc.createElement("AssignmentNumber");
			    Element PaymentTerms = doc.createElement("PaymentTerms");
			    Element PaymentDueDate = doc.createElement("PaymentDueDate");
			    Element Material = doc.createElement("Material");
			    
		    	// InvoiceDetail elements
			    InvoiceDetail.appendChild(VendorId);
			    InvoiceDetail.appendChild(LineSeqNo);
			    InvoiceDetail.appendChild(PostingKey);
			    //InvoiceDetail.appendChild(Account);
			    InvoiceDetail.appendChild(TransactionType);
			    InvoiceDetail.appendChild(CurrencyAmount);
			    InvoiceDetail.appendChild(LocalCurrencyAmount);
			    InvoiceDetail.appendChild(TaxCode);
			    InvoiceDetail.appendChild(BusinessArea);
			    InvoiceDetail.appendChild(ItemText);
			    InvoiceDetail.appendChild(Volume);
			    InvoiceDetail.appendChild(VolumeUnit);
			    InvoiceDetail.appendChild(ReferenceKey1);
			    InvoiceDetail.appendChild(ReferenceKey2);
			    InvoiceDetail.appendChild(ProductionPeriod);
			    InvoiceDetail.appendChild(AssignmentNumber);
			    InvoiceDetail.appendChild(PaymentTerms);
			    InvoiceDetail.appendChild(PaymentDueDate);
			    InvoiceDetail.appendChild(Material);
			    
			    VendorId.appendChild(doc.createTextNode(account));
		    	LineSeqNo.appendChild(doc.createTextNode(""+i));
		    	PostingKey.appendChild(doc.createTextNode(pk));
		    	//Account.appendChild(doc.createTextNode(account)); // Will use VendorId to Send SAP Code
		    	CurrencyAmount.appendChild(doc.createTextNode(sign+""+netPayable));
		    	TaxCode.appendChild(doc.createTextNode(taxCode));
		    	BusinessArea.appendChild(doc.createTextNode(businessAreaCode));
		    	Volume.appendChild(doc.createTextNode(qty));
		    	VolumeUnit.appendChild(doc.createTextNode("MMB"));
		    	
		    	ItemText.appendChild(doc.createTextNode(refNum));

		    	//ReferenceKey1.appendChild(doc.createTextNode(counterparty_abbr+"-"+contract_type+cont_no));
		    	ReferenceKey1.appendChild(doc.createTextNode(assignmentNo));
		    	ReferenceKey2.appendChild(doc.createTextNode(UserID));
		    	
		    	ProductionPeriod.appendChild(doc.createTextNode(productionPeriodYear+""+productionPeriodMonth));
		    	AssignmentNumber.appendChild(doc.createTextNode(refNum));
		    	PaymentTerms.appendChild(doc.createTextNode("ZB00")); //FIXED VALUE AS INSTRUCTED BY MAHESH MOHAN
		    	PaymentDueDate.appendChild(doc.createTextNode(paymentDueDt)); //AS PER SUNIDHI MAIL 16/08/2023
		    	
		    	Material.appendChild(doc.createTextNode(utilBean.PrePaddingZero(material_code, 18))); //it was not added erlier
		    }
		    
		    if(!gross_amt.equals(""))
		    {
		    	String sign = "-";
		    	String pk = "50";
		    	if(invoice_type.equals("CR") || invoice_type.equals("CCR"))
		    	{
		    		pk = "40";
		    		sign = "";
		    	}
		    	////
		    	i+=1;
		    	Element InvoiceDetail = doc.createElement("InvoiceDetail");
		    	Invoice.appendChild(InvoiceDetail);
		    	
		    	Element LineSeqNo = doc.createElement("LineSeqNo");
			    Element PostingKey = doc.createElement("PostingKey");
			    Element Account = doc.createElement("Account");
			    Element TransactionType = doc.createElement("TransactionType");
			    Element CurrencyAmount = doc.createElement("CurrencyAmount");
			    Element LocalCurrencyAmount = doc.createElement("LocalCurrencyAmount");
			    Element TaxCode = doc.createElement("TaxCode");
			    Element BusinessArea = doc.createElement("BusinessArea");
			    Element ItemText = doc.createElement("ItemText");
			    Element Volume = doc.createElement("Volume");
			    Element VolumeUnit = doc.createElement("VolumeUnit");
			    Element ReferenceKey1 = doc.createElement("ReferenceKey1");
			    Element ReferenceKey2 = doc.createElement("ReferenceKey2");
			    Element ProductionPeriod = doc.createElement("ProductionPeriod");
			    Element AssignmentNumber = doc.createElement("AssignmentNumber");
			    Element PaymentTerms = doc.createElement("PaymentTerms");
			    Element PaymentDueDate = doc.createElement("PaymentDueDate");
			    Element Material = doc.createElement("Material");
			    
		    	// InvoiceDetail elements
			    InvoiceDetail.appendChild(LineSeqNo);
			    InvoiceDetail.appendChild(PostingKey);
			    InvoiceDetail.appendChild(Account);
			    InvoiceDetail.appendChild(TransactionType);
			    InvoiceDetail.appendChild(CurrencyAmount);
			    InvoiceDetail.appendChild(LocalCurrencyAmount);
			    InvoiceDetail.appendChild(TaxCode);
			    InvoiceDetail.appendChild(BusinessArea);
			    InvoiceDetail.appendChild(ItemText);
			    InvoiceDetail.appendChild(Volume);
			    InvoiceDetail.appendChild(VolumeUnit);
			    InvoiceDetail.appendChild(ReferenceKey1);
			    InvoiceDetail.appendChild(ReferenceKey2);
			    InvoiceDetail.appendChild(ProductionPeriod);
			    InvoiceDetail.appendChild(AssignmentNumber);
			    InvoiceDetail.appendChild(PaymentTerms);
			    InvoiceDetail.appendChild(PaymentDueDate);
			    InvoiceDetail.appendChild(Material);
			    
		    	LineSeqNo.appendChild(doc.createTextNode(""+i));
		    	PostingKey.appendChild(doc.createTextNode(pk));
		    	
		    	String countpty_category=""+utilBean.getCounterpartyCategory(conn,counterparty_cd);
		    	
		    	String tempAccount="";
		    	String itemText="";
		    	if(invoice_type.equals("LP"))
		    	{
		    		tempAccount="8240050";
		    		itemText="Interest";
		    	}
		    	else 
		    	{
			    	/*if(invoice_type.equals("CR") || invoice_type.equals("CCR"))
			    	{
			    		//tempAccount="7220300";
			    		//tempAccount="6000400";
			    		//itemText="Brokerage/Commission";
			    		itemText="Commodity";
			    	}
			    	else
			    	{	
			    		itemText=cash_flow;
			    	}*/
			    	
			    	if(sub_inv_type.equals("IMB"))
			    	{
			    		tempAccount="6318400";
			    		itemText=cash_flow;
			    	}
			    	else if(inv_flag.equals("ST")) //FOR STORAGE
			    	{
			    		//tempAccount="6320405";
			    		
			    		//AS PER VIJAY'S MAIL ON 25/06/2025
			    		if(countpty_category.equals("Group"))
				    	{
				    		tempAccount="6851550";
				    	}
				    	else
				    	{
				    		tempAccount="6850550";
				    	}
				    	itemText="LNG Storage Charge";
			    	}
			    	else if(contract_type.equals("O") || contract_type.equals("Q"))
			    	{
			    		if(countpty_category.equals("Group"))
				    	{
				    		tempAccount="6000450";
				    	}
				    	else
				    	{
				    		tempAccount="6000500";
				    	}
			    		itemText=cash_flow;
			    	}
			    	else if(invoice_type.equals("CR") || invoice_type.equals("CCR"))
			    	{
			    		//tempAccount="7220300";
			    		//tempAccount="6000400";
			    		//itemText="Brokerage/Commission";
			    		if(countpty_category.equals("Group"))
				    	{
				    		tempAccount="6001400";
				    	}
				    	else
				    	{
				    		tempAccount="6000400";
				    	}
			    		itemText="Commodity";
			    	}
			    	else 
			    	{
			    		if(countpty_category.equals("Group"))
				    	{
				    		tempAccount="6001400";
				    		itemText=cash_flow;
				    	}
				    	else
				    	{
				    		tempAccount="6000400";
				    		itemText=cash_flow;
				    	}
			    	}
		    	}
		    	Account.appendChild(doc.createTextNode(utilBean.PrePaddingZero(tempAccount, 10))); //IG OR NG
		    	//
		    	CurrencyAmount.appendChild(doc.createTextNode(sign+""+gross_amt));
		    	TaxCode.appendChild(doc.createTextNode(taxCode));
		    	BusinessArea.appendChild(doc.createTextNode(businessAreaCode));
		    	
		    	ItemText.appendChild(doc.createTextNode(itemText+" "+monthNm+" "+productionPeriodYear));
		    	
		    	Volume.appendChild(doc.createTextNode(qty));
		    	VolumeUnit.appendChild(doc.createTextNode("MMB"));
		    	//ReferenceKey1.appendChild(doc.createTextNode(counterparty_abbr+"-"+contract_type+cont_no));
		    	ReferenceKey1.appendChild(doc.createTextNode(assignmentNo));
		    	ReferenceKey2.appendChild(doc.createTextNode(UserID));
		    	
		    	ProductionPeriod.appendChild(doc.createTextNode(productionPeriodYear+""+productionPeriodMonth));
		    	//AssignmentNumber.appendChild(doc.createTextNode(itemText+" "+monthNm+"-"+productionPeriodYear));
		    	AssignmentNumber.appendChild(doc.createTextNode(refNum));
		    	PaymentTerms.appendChild(doc.createTextNode("ZB00")); //FIXED VALUE AS INSTRUCTED BY MAHESH MOHAN
		    	PaymentDueDate.appendChild(doc.createTextNode(paymentDueDt)); //AS PER SUNIDHI MAIL 16/08/2023
		    	//Material.appendChild(doc.createTextNode(utilBean.PrePaddingZero("1168001", 18))); //NATURAL GAS MATERIAL CODE
		    	Material.appendChild(doc.createTextNode(utilBean.PrePaddingZero(material_code, 18)));
		    }
		    
		    int stcount=0;
		    if(type_flag.equals("FFLOW"))
	    	{
	    		queryString="SELECT TAX_CODE,TAX_STRUCT_CD,TAX_AMT,TAX_BASE_AMT "
						+ "FROM FMS_DLNG_FFLOW_INV_TAX_DTL "
						+ "WHERE COMPANY_CD=? AND FINANCIAL_YEAR=? "
						+ "AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
						+ "AND INVOICE_TYPE=?";
	    	}
	    	else
	    	{
		    	queryString="SELECT TAX_CODE,TAX_STRUCT_CD,TAX_AMT,TAX_BASE_AMT "
						+ "FROM FMS_DLNG_INV_TAX_DTL "
						+ "WHERE COMPANY_CD=? AND FINANCIAL_YEAR=? "
						+ "AND INVOICE_SEQ=? AND BU_STATE_TIN=?";
	    	}
		    stmt1 = conn.prepareStatement(queryString);
		    if(type_flag.equals("FFLOW"))
	    	{
		    	stmt1.setString(++stcount, comp_cd);
				stmt1.setString(++stcount, financial_year);
				stmt1.setString(++stcount, invoice_seq);
				stmt1.setString(++stcount, bu_state_tin);
				stmt1.setString(++stcount, invoice_type);
	    	}
		    else
		    {
		    	stmt1.setString(++stcount, comp_cd);
				stmt1.setString(++stcount, financial_year);
				stmt1.setString(++stcount, invoice_seq);
				stmt1.setString(++stcount, bu_state_tin);
		    }
			rset1=stmt1.executeQuery();
			while(rset1.next())
			{
				String tax_code=rset1.getString(1)==null?"":rset1.getString(1);
				String taxStrctCd=rset1.getString(2)==null?"":rset1.getString(2);
				String taxAmt=rset1.getString(3)==null?"":nf.format(rset1.getDouble(3));
				String taxBaseAmt=rset1.getString(4)==null?"":nf.format(rset1.getDouble(4));
				if(!taxAmt.equals(""))
				{
					String pk="50";
			    	String sign="-";
		    		if(invoice_type.equals("CR") || invoice_type.equals("CCR"))
			    	{
			    		pk = "40";
			    		sign = "";
			    	}
		    		///
			    	i+=1;
			    	
			    	String gl_code="";
			    	String tax_sap_code="";
			    	String amt=taxAmt;
			    	gl_code=utilBean.getTaxGLcode(conn,taxStructCd, tax_code);
			    	tax_sap_code=utilBean.getTaxSAPcode(conn,taxStructCd, tax_code);
			    	if(Double.parseDouble(amt) > 0)
			    	{
				    	Element InvoiceDetail = doc.createElement("InvoiceDetail");
				    	Invoice.appendChild(InvoiceDetail);
				    	
				    	Element LineSeqNo = doc.createElement("LineSeqNo");
					    Element PostingKey = doc.createElement("PostingKey");
					    Element Account = doc.createElement("Account");
					    Element LineInd = doc.createElement("LineInd");
					    Element TaxAmount = doc.createElement("TaxAmount");
					    Element TaxAmountLocal = doc.createElement("TaxAmountLocal");
					    Element TaxCode = doc.createElement("TaxCode");
					    Element BusinessArea = doc.createElement("BusinessArea");
					    Element TaxType = doc.createElement("TaxType");	
					    Element TaxBase = doc.createElement("TaxBase");
					    
				    	// InvoiceDetail elements
					    InvoiceDetail.appendChild(LineSeqNo);
					    InvoiceDetail.appendChild(PostingKey);
					    InvoiceDetail.appendChild(Account);
					    InvoiceDetail.appendChild(LineInd);
					    InvoiceDetail.appendChild(TaxAmount);
					    InvoiceDetail.appendChild(TaxAmountLocal);
					    InvoiceDetail.appendChild(TaxCode);
					    InvoiceDetail.appendChild(BusinessArea);
					    InvoiceDetail.appendChild(TaxType);
					    InvoiceDetail.appendChild(TaxBase); //AS PER SUNIDHI MAIL 16/08/2023
					    				    
				    	LineSeqNo.appendChild(doc.createTextNode(""+i));
				    	PostingKey.appendChild(doc.createTextNode(pk));
				    	Account.appendChild(doc.createTextNode(utilBean.PrePaddingZero(gl_code, 10)));
				    	LineInd.appendChild(doc.createTextNode("T")); //FIXED VALUE AS INSTRUCTED BY MAHESH MOHAN
				    	TaxAmount.appendChild(doc.createTextNode(sign+""+amt));
				    	TaxCode.appendChild(doc.createTextNode(tax_sap_code));
				    	BusinessArea.appendChild(doc.createTextNode(businessAreaCode));
				    	TaxType.appendChild(doc.createTextNode("A")); //FIXED VALUE AS INSTRUCTED BY MAHESH MOHAN
				    	TaxBase.appendChild(doc.createTextNode(taxBaseAmt)); //AS PER SUNIDHI MAIL 16/08/2023
			    	}
				}
			}
			rset1.close();
			stmt1.close();
		    
		    if(!tcs_tds.equals("") && !tcs_tds.equals("NA"))
		    {
		    	i+=1;
		    	
		    	String gl_code="";
		    	String TcsTdscode="";
		    	String amt="";
		    	String pk="";
		    	String taxBase="";
		    	String sign="";
		    	if(tcs_tds.equals("TCS"))
		    	{
		    		gl_code=utilBean.getTaxGLcode(conn,tcsStructCd);
		    		TcsTdscode=utilBean.getTaxSAPcode(conn,tcsStructCd);
		    		amt=tcs_amt;
		    		pk="50";
		    		//taxBase=invoiceAmt;
		    		
		    		if(!tcs_amt.equals("") && !tcs_factor.equals(""))
		    		{
		    			taxBase=nf.format((Double.parseDouble(tcs_amt)*100)/Double.parseDouble(tcs_factor));
		    		}
		    		
		    		sign="-";
		    		if(invoice_type.equals("CR") || invoice_type.equals("CCR"))
			    	{
			    		pk = "40";
			    		sign = "";
			    	}
		    	}
		    	else if(tcs_tds.equals("TDS"))
		    	{
		    		gl_code=utilBean.getTaxGLcode(conn,tdsStructCd);
		    		TcsTdscode=utilBean.getTaxSAPcode(conn,tdsStructCd);
		    		amt=tds_amt;
		    		pk="40";
		    		//taxBase=gross_amt; //THIS WILL BE INCORRECT WHEN TRANSACTION ABOUT TO CROSS 50L
		    		
		    		if(!tds_amt.equals("") && !tds_factor.equals(""))
		    		{
		    			taxBase=nf.format((Double.parseDouble(tds_amt)*100)/Double.parseDouble(tds_factor));
		    		}
		    		
		    		if(invoice_type.equals("CR") || invoice_type.equals("CCR"))
			    	{
			    		pk = "50";
			    		sign = "-";
			    	}
		    	}
		    	
		    	Element InvoiceDetail = doc.createElement("InvoiceDetail");
		    	Invoice.appendChild(InvoiceDetail);
		    	
		    	
		    	Element LineSeqNo = doc.createElement("LineSeqNo");
			    Element PostingKey = doc.createElement("PostingKey");
			    Element Account = doc.createElement("Account");
			    Element LineInd = doc.createElement("LineInd");
			    Element TaxAmount = doc.createElement("TaxAmount");
			    Element TaxAmountLocal = doc.createElement("TaxAmountLocal");
			    Element TaxCode = doc.createElement("TaxCode");
			    Element BusinessArea = doc.createElement("BusinessArea");
			    Element TaxType = doc.createElement("TaxType");	
			    Element TaxBase = doc.createElement("TaxBase");
			    
		    	// InvoiceDetail elements
			    InvoiceDetail.appendChild(LineSeqNo);
			    InvoiceDetail.appendChild(PostingKey);
			    InvoiceDetail.appendChild(Account);
			    InvoiceDetail.appendChild(LineInd);
			    InvoiceDetail.appendChild(TaxAmount);
			    InvoiceDetail.appendChild(TaxAmountLocal);
			    InvoiceDetail.appendChild(TaxCode);
			    InvoiceDetail.appendChild(BusinessArea);
			    InvoiceDetail.appendChild(TaxType);
			    InvoiceDetail.appendChild(TaxBase); //AS PER SUNIDHI MAIL 16/08/2023
			    				    
		    	LineSeqNo.appendChild(doc.createTextNode(""+i));
		    	PostingKey.appendChild(doc.createTextNode(pk));
		    	Account.appendChild(doc.createTextNode(utilBean.PrePaddingZero(gl_code, 10)));
		    	LineInd.appendChild(doc.createTextNode(tcs_tds)); //TCS TDS XML block reference not found. Using Tax XML block
		    	TaxAmount.appendChild(doc.createTextNode(sign+""+amt));
		    	TaxCode.appendChild(doc.createTextNode(TcsTdscode));
		    	BusinessArea.appendChild(doc.createTextNode(businessAreaCode));
		    	TaxType.appendChild(doc.createTextNode("A")); //FIXED VALUE AS INSTRUCTED BY MAHESH MOHAN 	
		    	TaxBase.appendChild(doc.createTextNode(taxBase)); //AS PER SUNIDHI MAIL 16/08/2023
		    }
		    
		    TransformerFactory transformerFactory = TransformerFactory.newInstance();
			transformerFactory.setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD","");
			transformerFactory.setAttribute("http://javax.xml.XMLConstants/property/accessExternalStylesheet","");
			
		    Transformer transformer = transformerFactory.newTransformer();
		    DOMSource source = new DOMSource(doc);
		    
		    String xmlFileNm="";
		    String datetime="";
		    datetime=splitSys[0].replaceAll("/", "")+""+splitSys[1].replaceAll(":", "");
		    
		    if(!fms_MessageId.equals(""))
		    {
		    	if(sap_approval_flag.equals("Y"))
		        {
		    		xmlFileNm="AR_"+fms_MessageId+"_"+datetime+".xml";
		        }
		    	else
		    	{
		    		xmlFileNm="AR_"+fms_MessageId+".xml";
		    	}
		    }
		    else //ADDED WHEN INVOICE NUMBER IS NOT GENERATED
	    	{
	    		xmlFileNm="AR_"+fms_MessageId+".xml";
	    	}
			
		    if(!xmlFileNm.equals(""))
		    {
		    	String appPath = request.getServletContext().getRealPath("");
	        	
	        	String main_folder="";
				if(!comp_cd.equals(""))
				{
					main_folder=CommonVariable.work_dir+comp_cd;
				}
				File MainDir = new File(appPath+File.separator+main_folder);
		        if(!MainDir.exists()) 
		        {
		        	MainDir.mkdir();
		        }
		        String sub_folder=""+CommonVariable.sap_xml;
		        if(!sap_approval_flag.equals("Y"))
		        {
		        	sub_folder=""+CommonVariable.temp_sap_xml;
		        }
				File SubDir = new File(appPath+File.separator+main_folder+File.separator+sub_folder);
		        if(!SubDir.exists()) 
		        {
		        	SubDir.mkdir();
		        }
		        
			    StreamResult result =  new StreamResult(new File(appPath+File.separator+main_folder+File.separator+sub_folder+""+File.separator+""+xmlFileNm));
			    transformer.transform(source, result);
			    
			    xmlfile_name=xmlFileNm;
			    
			    if(sap_approval_flag.equals("Y"))
		        {
			    	File fileExi = new File(appPath+File.separator+main_folder+File.separator+sub_folder+File.separator+xmlFileNm);
			    	if(fileExi.exists()) 
			        {
			        	if(type_flag.equals("FFLOW"))
			        	{
			        		int count=0;
			    	        queryString="SELECT COUNT(*) "
			    	        		+ "FROM FMS_DLNG_FFLOW_INV_FILE_DTL "
			    	        		+"WHERE COMPANY_CD=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
			    					+ "AND INVOICE_TYPE=? AND FINANCIAL_YEAR=? "
			    	        		+ "AND PDF_TYPE=?";
			    	        stmt2 = conn.prepareStatement(queryString);
			    	        stmt2.setString(1, comp_cd);
			    	        stmt2.setString(2, invoice_seq);
			    	        stmt2.setString(3, bu_state_tin);
			    	        stmt2.setString(4, invoice_type);
			    	        stmt2.setString(5, financial_year);
			    	        stmt2.setString(6, "X");
			    	        rset2=stmt2.executeQuery();
			    	        if(rset2.next())
			    	        {
			    	        	count=rset2.getInt(1);
			    	        }
			    	        rset2.close();
			    	        stmt2.close();
	
			    	        if(count > 0)
			    	        {
			    	        	queryString="UPDATE FMS_DLNG_FFLOW_INV_FILE_DTL SET FILE_NAME=?,MODIFY_BY=?,MODIFY_DT=SYSDATE "
			    	        			+"WHERE COMPANY_CD=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
			    						+ "AND INVOICE_TYPE=? AND FINANCIAL_YEAR=? "
			    		        		+ "AND PDF_TYPE=?";
			    	            stmt3 = conn.prepareStatement(queryString);
				    	        stmt3.setString(1, xmlFileNm);
				    	        stmt3.setString(2, emp_cd);
				    	        stmt3.setString(3, comp_cd);
				    	        stmt3.setString(4, invoice_seq);
				    	        stmt3.setString(5, bu_state_tin);
				    	        stmt3.setString(6, invoice_type);
				    	        stmt3.setString(7, financial_year);
				    	        stmt3.setString(8, "X");
			    	        	stmt3.executeUpdate();
			    	        	
			    	        	stmt3.close();
			    	        }
			    	        else
			    	        {
			    	        	queryString="INSERT INTO FMS_DLNG_FFLOW_INV_FILE_DTL(COMPANY_CD,BU_STATE_TIN,INVOICE_SEQ,FINANCIAL_YEAR,PDF_TYPE,"
			    	        			+ "FILE_NAME,ENT_BY,ENT_DT,INVOICE_TYPE) "
			    	        			+ "VALUES(?,?,?,?,?,"
			    	        			+ "?,?,SYSDATE,?)";
			    	        	stmt3 = conn.prepareStatement(queryString);
				    	        stmt3.setString(1, comp_cd);
				    	        stmt3.setString(2, bu_state_tin);
				    	        stmt3.setString(3, invoice_seq);
				    	        stmt3.setString(4, financial_year);
				    	        stmt3.setString(5, "X");
				    	        stmt3.setString(6, xmlFileNm);
				    	        stmt3.setString(7, emp_cd);
				    	        stmt3.setString(8, invoice_type);
			    	        	stmt3.executeUpdate();
			    	        	
			    	        	stmt3.close();
			    	        }
			
			    	        conn.commit();
			        	}
			        	else
			        	{
						    int count=0;
					        queryString="SELECT COUNT(*) "
					        		+ "FROM FMS_DLNG_INV_FILE_DTL "
					        		+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
					        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE=?";
					        stmt2 = conn.prepareStatement(queryString);
			    	        stmt2.setString(1, comp_cd);
			    	        stmt2.setString(2, bu_state_tin);
			    	        stmt2.setString(3, invoice_seq);
			    	        stmt2.setString(4, financial_year);
			    	        stmt2.setString(5, "X");
			    	        rset2=stmt2.executeQuery();
					        if(rset2.next())
					        {
					        	count=rset2.getInt(1);
					        }
					        rset2.close();
					        stmt2.close();
				
					        if(count > 0)
					        {
					        	queryString="UPDATE FMS_DLNG_INV_FILE_DTL SET FILE_NAME=?,MODIFY_BY=?,MODIFY_DT=SYSDATE "
					        			+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
						        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE=?";
					        	stmt3 = conn.prepareStatement(queryString);
				    	        stmt3.setString(1, xmlFileNm);
				    	        stmt3.setString(2, emp_cd);
				    	        stmt3.setString(3, comp_cd);
				    	        stmt3.setString(4, bu_state_tin);
				    	        stmt3.setString(5, invoice_seq);
				    	        stmt3.setString(6, financial_year);
				    	        stmt3.setString(7, "X");
			    	        	stmt3.executeUpdate();
			    	        	
			    	        	stmt3.close();
					        }
					        else
					        {
					        	queryString="INSERT INTO FMS_DLNG_INV_FILE_DTL(COMPANY_CD,BU_STATE_TIN,INVOICE_SEQ,FINANCIAL_YEAR,PDF_TYPE,"
					        			+ "FILE_NAME,ENT_BY,ENT_DT) "
					        			+ "VALUES(?,?,?,?,?,"
					        			+ "?,?,SYSDATE)";
					        	stmt3 = conn.prepareStatement(queryString);
				    	        stmt3.setString(1, comp_cd);
				    	        stmt3.setString(2, bu_state_tin);
				    	        stmt3.setString(3, invoice_seq);
				    	        stmt3.setString(4, financial_year);
				    	        stmt3.setString(5, "X");
				    	        stmt3.setString(6, xmlFileNm);
				    	        stmt3.setString(7, emp_cd);
			    	        	stmt3.executeUpdate();
			    	        	
			    	        	stmt3.close();
					        }
		    	
					        conn.commit();
						}
			        }
		        }
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
				
	public void parseSAP_XMLfile()
	{
		String function_nm="parseSAP_XMLfile()";
		try
		{
			counterparty_nm=utilBean.getCounterpartyName(conn,counterparty_cd);
			counterparty_abbr=utilBean.getCounterpartyABBR(conn,counterparty_cd);
			    
			if(xmlfile_name.equals(""))
			{
	        	if(type_flag.equals("FFLOW"))
				{
	    	        queryString="SELECT FILE_NAME "
	    	        		+ "FROM FMS_DLNG_FFLOW_INV_FILE_DTL "
	    	        		+"WHERE COMPANY_CD=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
	    					+ "AND INVOICE_TYPE=? AND FINANCIAL_YEAR=? "
	    	        		+ "AND PDF_TYPE=?";
	    	        stmt = conn.prepareStatement(queryString);
	    	        stmt.setString(1, comp_cd);
	    	        stmt.setString(2, invoice_seq);
	    	        stmt.setString(3, bu_state_tin);
	    	        stmt.setString(4, invoice_type);
	    	        stmt.setString(5, financial_year);
	    	        stmt.setString(6, "X");
	    	        rset=stmt.executeQuery();
	    	        if(rset.next())
					{
	    	        	xmlfile_name=rset.getString(1)==null?"":rset.getString(1);
					}
	    	        rset.close();
	    	        stmt.close();
				}
	        	else
	        	{
	        		queryString="SELECT FILE_NAME "
			        		+ "FROM FMS_DLNG_INV_FILE_DTL "
			        		+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
			        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? AND PDF_TYPE=?";
	        		stmt = conn.prepareStatement(queryString);
	    	        stmt.setString(1, comp_cd);
	    	        stmt.setString(2, bu_state_tin);
	    	        stmt.setString(3, invoice_seq);
	    	        stmt.setString(4, financial_year);
	    	        stmt.setString(5, "X");
	    	        rset=stmt.executeQuery();
			        if(rset.next())
			        {
			        	xmlfile_name=rset.getString(1)==null?"":rset.getString(1);
					}
			        rset.close();
	    	        stmt.close();
				}
			}
			
			if(!xmlfile_name.equals(""))
			{
				String final_path=file_path+File.separator+xmlfile_name;
				
				if(sap_approval_flag.equals("Y"))
				{
					File fXmlFile = new File(file_path+File.separator+xmlfile_name);
					if(fXmlFile.exists())
					{
						final_path=file_path+File.separator+xmlfile_name;
					}
					else
					{
						String new_path=file_path+File.separator+CommonVariable.sap_xml_success+File.separator+xmlfile_name;
						final_path=new_path;
					}
				}
				
				File file = new File(final_path);
				if(file.exists())
				{
					//System.out.println("Created file is in folder");
					
				    DocumentBuilderFactory dbFactory = xmlUtil.dcoumentBuilderFactory();
				    DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				    Document doc = dBuilder.parse(file);
				    
				    doc.getDocumentElement().normalize();
				    
				    zeroTotal="0.00";
				    
					NodeList nList = doc.getElementsByTagName("EmsSAPArMessage");
					for (int temp = 0; temp < nList.getLength(); temp++) 
					{
						Node nNode = nList.item(temp);
						Element eElement = (Element) nNode;
						
						NodeList nodes = eElement.getChildNodes();
						for(int i=0; i<nodes.getLength(); i++)
						{
							Node node = nodes.item(i);
							String childTag = node.getNodeName();
							//System.out.println(childTag);
							if(childTag.equalsIgnoreCase("Header"))
							{
								Element ele = (Element) node;
								NodeList nodes1 = ele.getChildNodes();
								for(int j=0; j<nodes1.getLength(); j++)
								{
									Node node1 = nodes1.item(j);
									String childTag1 = node1.getNodeName();
									if(childTag1.equalsIgnoreCase("MessageId"))
									{
										documentNo=nodes1.item(j).getTextContent();
									}
								}
							}
							else if(childTag.equalsIgnoreCase("Invoice"))
							{
								Element ele = (Element) node;
								NodeList nodes1 = ele.getChildNodes();
								for(int j=0; j<nodes1.getLength(); j++)
								{
									Node node1 = nodes1.item(j);
									String childTag1 = node1.getNodeName();
									//System.out.println("childTag1="+childTag1);
									if(childTag1.equalsIgnoreCase("InvoiceHeader"))
									{
										Element ele1 = (Element) node1;
										NodeList nodes2 = ele1.getChildNodes();
										
										for(int k=0; k<nodes2.getLength(); k++)
										{
											Node node2 = nodes2.item(k);
											String childTag2 = node2.getNodeName();
											
											//System.out.println("childTag2="+childTag2);
											if(childTag2.equals("DocumentType"))
											{
												//System.out.println(k+""+nodes2.item(k).getTextContent());
												documentType=nodes2.item(k).getTextContent();
											}
											else if(childTag2.equals("DocumentDate")){
												documentDate=nodes2.item(k).getTextContent();											
											}
											else if(childTag2.equals("DocumentNo")){
												//documentNo=nodes2.item(k).getTextContent();											
											}
											else if(childTag2.equals("PostingDate")) 
											{
												postingDate=nodes2.item(k).getTextContent();
											}
											else if(childTag2.equals("AccountingPeriodMonth")) 
											{
												accountingPeriodMonth=nodes2.item(k).getTextContent();
											}	
											else if(childTag2.equals("AccountingPeriodYear")) 
											{
												accountingPeriodYear=nodes2.item(k).getTextContent();
											}	
											else if(childTag2.equals("InternalLegalEntity")) 
											{
												headerCompanyCode=nodes2.item(k).getTextContent();
											}	
											else if(childTag2.equals("DocHeaderText")) 
											{
												docHeaderText=nodes2.item(k).getTextContent();
											}	
											else if(childTag2.equals("RefNum"))
											{
												refNum=nodes2.item(k).getTextContent();
											}
											else if(childTag2.equals("Currency")) 
											{
												currency=nodes2.item(k).getTextContent();
											}
											else if(childTag2.equals("LocalCurrency")) {}
											else if(childTag2.equals("ExchangeRate")) {}
											else if(childTag2.equals("CalculateTax")) {}
											else if(childTag2.equals("TranslationDate")) {}
											else if(childTag2.equals("TradingPartnerBusinessArea")) {}
										}
									}	
									else if(childTag1.equalsIgnoreCase("InvoiceDetail"))
									{
										Element ele1 = (Element) node1;
										NodeList nodes2 = ele1.getChildNodes();
										
										String lineseqno= "";
										String postingkey= "";
										String account= "";
										String currencyamount= "";
										String businessarea= "";
										String itemtext= "";
										String taxCode= "";
										
										for(int k=0; k<nodes2.getLength(); k++)
										{
											Node node2 = nodes2.item(k);
											String childTag2 = node2.getNodeName();
											
											//System.out.println("childTag2="+childTag2);
											if(childTag2.equals("LineSeqNo")) 
											{
												lineseqno=nodes2.item(k).getTextContent();
											}
											else if(childTag2.equals("PostingKey")) 
											{
												postingkey=nodes2.item(k).getTextContent();
											}
											else if(childTag2.equals("Account") || childTag2.equals("CustomerId")) 
											{
												account=nodes2.item(k).getTextContent();
											}
											else if(childTag2.equals("TransactionType")) {}
											else if(childTag2.equals("CurrencyAmount") || childTag2.equals("TaxAmount")) 
											{
												currencyamount=nodes2.item(k).getTextContent();
											}
											else if(childTag2.equals("LocalCurrencyAmount")) {}
											else if(childTag2.equals("BusinessArea")) 
											{
												businessarea=nodes2.item(k).getTextContent();
											}
											else if(childTag2.equals("ItemText") || childTag2.equals("LineInd")) 
											{
												itemtext=nodes2.item(k).getTextContent();
											}
											else if(childTag2.equals("TaxCode")) 
											{
												taxCode=nodes2.item(k).getTextContent();
											}
											else if(childTag2.equals("Volume")) {}
											else if(childTag2.equals("VolumeUnit")) {}
											else if(childTag2.equals("ReferenceKey1")) {}
											else if(childTag2.equals("ReferenceKey2")) {}
											else if(childTag2.equals("ProductionPeriod")) {}
											else if(childTag2.equals("AssignmentNumber")) {}
										}
										
										if(!itemtext.equals("TDS")) //AS PER VIJAY MAIL ON 19-10-2023 TO ADDRESS SAP LIMITATION FOR TDS
										{
											if(!currencyamount.equals(""))
											{
												zeroTotal=nf.format(Double.parseDouble(zeroTotal)+Double.parseDouble(currencyamount));
											}
										}
										
										if(itemtext.equals("T") || itemtext.equals("TDS") || itemtext.equals("TCS"))
										{
											itemtext=itemtext+" ["+taxCode+"]";
										}
										
										VLINESEQNO.add(lineseqno);
										VPOSTINGKEY.add(postingkey);
										VACCOUNT.add(account);
										VCURRENCYAMOUNT.add(currencyamount);
										VBUSINESSAREA.add(businessarea);
										VITEMTEXT.add(itemtext);
										VSHORTTEXT.add(utilBean.getGLdesc(conn, ""+utilBean.RemovePrePaddingZero(account)));
									}	
								}	
							}
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}

	public void getSapInvoiceApprovalDetail()
	{
		String function_nm="getSapInvoiceApprovalDetail()";
		try
		{
			if(type_flag.equals("SG"))
			{
				queryString ="SELECT SAP_APPROVAL,SAP_APPROVED_BY,TO_CHAR(SAP_APPROVED_DT,'DD/MM/YYYY') "
						+ "FROM FMS_DLNG_INVOICE_MST "
						+ "WHERE COMPANY_CD=? AND FINANCIAL_YEAR=? "
						+ "AND INVOICE_SEQ=? AND BU_STATE_TIN=? ";
			}
			else
			{
				queryString ="SELECT SAP_APPROVAL,SAP_APPROVED_BY,TO_CHAR(SAP_APPROVED_DT,'DD/MM/YYYY') "
						+ "FROM FMS_DLNG_FFLOW_INV_MST "
						+ "WHERE COMPANY_CD=? AND FINANCIAL_YEAR=? "
						+ "AND INVOICE_SEQ=? AND BU_STATE_TIN=? AND INVOICE_TYPE=?";
			}
			stmt = conn.prepareStatement(queryString);
			if(type_flag.equals("SG"))
			{
				stmt.setString(1, comp_cd);
	 	        stmt.setString(2, financial_year);
	 	        stmt.setString(3, invoice_seq);
	 	        stmt.setString(4, bu_state_tin);
			}
			else
			{
				stmt.setString(1, comp_cd);
	 	        stmt.setString(2, financial_year);
	 	        stmt.setString(3, invoice_seq);
	 	        stmt.setString(4, bu_state_tin);
	 	        stmt.setString(5, invoice_type);
			}
 	        rset=stmt.executeQuery();
			if(rset.next())
			{
				String sap_app_by=rset.getString(2)==null?"":rset.getString(2);
				sap_approved_by=utilBean.getEmpName(conn,sap_app_by);
				sap_approved_dt=rset.getString(3)==null?"":rset.getString(3);
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getPostingDetail()
	{
		String function_nm="getPostingDetail()";
		try
		{
			queryString="SELECT MSG_STATUS,DOC_NO,STATUS_MSG,TO_CHAR(TO_DATE(TO_CHAR(POST_DT)||' '||POST_TIME,'DD-MM-YYYY HH24:MI:SS'),'DD-MM-YYYY HH24:MI:SS') "
					+ "FROM FMS_SAP_ACK_DTL A "
					+ "WHERE COMPANY_CD=? AND FMS_REF=? "
					+ "AND TO_DATE(TO_CHAR(POST_DT)||' '||POST_TIME,'DD-MM-YYYY HH24:MI:SS')=(SELECT MAX(TO_DATE(TO_CHAR(POST_DT)||' '||POST_TIME,'DD-MM-YYYY HH24:MI:SS')) "
					+ "FROM FMS_SAP_ACK_DTL B WHERE A.COMPANY_CD=B.COMPANY_CD AND A.FMS_REF=B.FMS_REF) ";
			stmt = conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, invoice_no);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				sap_msg_status=rset.getString(1)==null?"":rset.getString(1);
				sap_doc_no=rset.getString(2)==null?"":rset.getString(2);
				sap_ack_msg=rset.getString(3)==null?"":rset.getString(3);
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getSendInvoiceMailDetail()
	{
		String function_nm="getSendInvoiceMailDetail()";
		try
		{
			String ownAddress="";
			String ownCity="";
			String ownState="";
			String ownPin="";
			String ownCountry="";
			String ownPhone="";
			String ownEmail="";
			
			queryString="SELECT ADDR,CITY,STATE,PIN,COUNTRY,PHONE,EMAIL "
					+ "FROM FMS_COMPANY_OWNER_ADDR_MST A "
					+ "WHERE COMPANY_CD=? AND ADDRESS_TYPE=? "
					+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_COMPANY_OWNER_ADDR_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.ADDRESS_TYPE=B.ADDRESS_TYPE "
					+ "AND B.EFF_DT<=TO_DATE(TO_CHAR(SYSDATE,'DD/MM/YYYY'),'DD/MM/YYYY'))";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, "C");
			rset=stmt.executeQuery();
			if(rset.next())
			{
				ownAddress  = rset.getString(1)==null?"":rset.getString(1);
				ownCity  = rset.getString(2)==null?"":rset.getString(2);
				ownState  = rset.getString(3)==null?"":rset.getString(3);
				ownPin  = rset.getString(4)==null?"":rset.getString(4);
				ownCountry  = rset.getString(5)==null?"":rset.getString(5);
				ownPhone  = rset.getString(6)==null?"":rset.getString(6);
				ownEmail  = rset.getString(7)==null?"":rset.getString(7);
			}
			rset.close();
			stmt.close();
			
			String bu_contact_person_cd="";
			String contact_person_cd="";
			String invoiceNo="";
			String invoiceDt="";
			String dueDate="";
			String other_inv_str="";
			String truckNo="";
			
			if(mail_inv_type.equals("F"))
			{
				queryString1="SELECT BU_CONTACT_PERSON_CD,CONTACT_PERSON_CD,INVOICE_NO,TO_CHAR(DUE_DT,'DD/MM/YYYY'),"
						+ "TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),OTHER_INV_STR "
						+ "FROM FMS_DLNG_FFLOW_INV_MST "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
						+ "AND BU_STATE_TIN=? AND FINANCIAL_YEAR=? "
						+ "AND INVOICE_SEQ=? AND INVOICE_TYPE=?";
				stmt1=conn.prepareStatement(queryString1);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, counterparty_cd);
				stmt1.setString(3, bu_state_tin);
				stmt1.setString(4, financial_year);
				stmt1.setString(5, invoice_seq);
				stmt1.setString(6, invoice_type);
				rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					bu_contact_person_cd=rset1.getString(1)==null?"0":rset1.getString(1);
					contact_person_cd=rset1.getString(2)==null?"0":rset1.getString(2);
					invoiceNo=rset1.getString(3)==null?"":rset1.getString(3);
					dueDate=rset1.getString(4)==null?"":rset1.getString(4);
					invoiceDt=rset1.getString(5)==null?"":rset1.getString(5);
					other_inv_str=rset1.getString(6)==null?"":rset1.getString(6);
				}
				rset1.close();
				stmt1.close();
			}
			else
			{
				queryString1="SELECT BU_CONTACT_PERSON_CD,CONTACT_PERSON_CD,INVOICE_NO,TO_CHAR(DUE_DT,'DD/MM/YYYY'),TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),TRUCK_CD "
						+ "FROM FMS_DLNG_INVOICE_MST "
						+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
						+ "AND BU_STATE_TIN=? AND FINANCIAL_YEAR=? "
						+ "AND INVOICE_SEQ=?";
				stmt1=conn.prepareStatement(queryString1);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, counterparty_cd);
				stmt1.setString(3, bu_state_tin);
				stmt1.setString(4, financial_year);
				stmt1.setString(5, invoice_seq);
				rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					bu_contact_person_cd=rset1.getString(1)==null?"0":rset1.getString(1);
					contact_person_cd=rset1.getString(2)==null?"0":rset1.getString(2);
					invoiceNo=rset1.getString(3)==null?"":rset1.getString(3);
					dueDate=rset1.getString(4)==null?"":rset1.getString(4);
					invoiceDt=rset1.getString(5)==null?"":rset1.getString(5);
					truckNo=dlng_util.getTruckRegNo(conn, (rset1.getString(6)==null?"":rset1.getString(6)));
				}
				rset1.close();
				stmt1.close();
			}
			
			
			String[] pdf_type=mail_pdf_type.split(",");
			
			for(int i=0; i<pdf_type.length; i++)
			{
				String temp_pdf_type=""+pdf_type[i];
				
				VMAIL_PDF_TYPE.add(temp_pdf_type);
				
				String temp_pdf_type_nm="";
				if(temp_pdf_type.equals("O"))
				{
					temp_pdf_type_nm="Original";
					VMAIL_PDF_TYPE_NM.add("Original Invoice");
				}
				else if(temp_pdf_type.equals("D"))
				{
					temp_pdf_type_nm="Duplicate";
					VMAIL_PDF_TYPE_NM.add("Duplicate Invoice");
				}
				else if(temp_pdf_type.equals("T"))
				{
					temp_pdf_type_nm="Triplicate";
					VMAIL_PDF_TYPE_NM.add("Triplicate Invoice");
				}
				else if(temp_pdf_type.equals("402"))
				{
					temp_pdf_type_nm="Form 402";
					VMAIL_PDF_TYPE_NM.add("Form 402");
				}
				else
				{
					temp_pdf_type_nm="Triplicate";
					VMAIL_PDF_TYPE_NM.add("");
				}
				
				String companyAbbr=utilBean.getCompanyAbbr(conn,comp_cd);
				String customerNm=utilBean.getCounterpartyName(conn,counterparty_cd);
				String subject="";
				String type="";
				if(invoice_type.equals("DR"))
				{
					//type="DEBIT NOTE";
					type=other_inv_str;
				}
				else if(invoice_type.equals("CR"))
				{
					//type="CREDIT NOTE";
					type=other_inv_str;
				}
				else if(invoice_type.equals("CDR"))
				{
					//type="DEBIT NOTE";
					type=other_inv_str;
				}
				else if(invoice_type.equals("CCR"))
				{
					//type="CREDIT NOTE";
					type=other_inv_str;
				}
				else if(invoice_type.equals("LP"))
				{
					//type="LATE PAYMENT INVOICE";
					type=other_inv_str;
				}
				else if(invoice_type.equals("OR"))
				{
					//type="OTHER";
					type=other_inv_str;
				}
				else if(invoice_type.equals("S"))
				{
					//type="OTHER";
					type=other_inv_str;
				}
				else
				{
					type="DLNG SALES";
				}
				
				String to_list="";
				String cc_list="";
				String bcc_list="";
				
				String attachment="";
				Vector VTEMP_MAIL_ATTACHMENT = new Vector(); 
				Vector VTEMP_MAIL_ANNEXURE_ATTACHMENT_FLAG = new Vector();
				
				String companyNm=utilBean.getCompanyName(conn,comp_cd);
				String mail_body="";
				
				if(temp_pdf_type.equals("402"))
				{
					subject=companyAbbr+"/"+invoiceNo+"/Form-402";
					
					to_list=utilBean.getEntityContactPersonEmailList(conn, comp_cd, comp_cd, "B", "P"+bu_unit, "F402", "DLNG","Y");
					cc_list=utilBean.getEntityContactPersonEmailList(conn, comp_cd, comp_cd, "B", "P"+bu_unit, "F402", "DLNG","N");
					bcc_list=utilBean.getEntityContactPersonEmailList(conn, comp_cd, comp_cd, "B", "P"+bu_unit, "F402", "DLNG","B");
					
					VTEMP_MAIL_ATTACHMENT.add(invoiceNo.replace("/", "-")+"_"+truckNo+".xlsx");
					VTEMP_MAIL_ANNEXURE_ATTACHMENT_FLAG.add("");
					
					mail_body="Dear Sir/Madam,"
							+ "\n\nPlease find enclosed Form-402.";
					mail_body+= "\n\n\nThank You,"
							+ "\n\n"+companyNm+""
							+ "\n"+ownAddress+", "
							+ "\n"+ownCity+", "+ownState+" - "+ownPin+""
							+ "\nEmail: "+ownEmail+""
							+ "\nPh: "+ownPhone+""
							+ "\n\nThis is an auto-generated email from the system, please do not reply to this email.";
					
					VMAIL_FROM_LIST.add(utilBean.getFromMailId(conn));
					VMAIL_TO_LIST.add(to_list);
					VMAIL_CC_LIST.add(cc_list);
					VMAIL_BCC_LIST.add(bcc_list);
					VMAIL_SUBJECT.add(subject);
					//VMAIL_ATTACHMENT.add(attachment);
					VMAIL_ATTACHMENT.add(VTEMP_MAIL_ATTACHMENT);
					VMAIL_ANNEXURE_ATTACHMENT_FLAG.add(VTEMP_MAIL_ANNEXURE_ATTACHMENT_FLAG);
					VMAIL_ATTACHMENT_PATH.add(File.separator+CommonVariable.form_402_dir+File.separator);
					VMAIL_ANNEXURE_ATTACHMENT_PATH.add("");
					VMAIL_BODY.add(mail_body);	
				}
				else
				{
					subject=companyAbbr+"/"+customerNm+"/"+type+"/"+temp_pdf_type_nm+"/"+dueDate.replaceAll("/", "-")+"/"+invoiceNo;
					
					if(temp_pdf_type.equals("T"))
					{
						to_list=utilBean.getEntityContactPersonEmailList(conn, comp_cd, comp_cd, "B", "P"+bu_unit, "INV", "DLNG","Y");
					}
					else
					{
						if(mail_inv_type.equals("F"))
						{
							to_list=utilBean.getEntityContactPersonEmailList(conn, comp_cd, counterparty_cd, "C", plant_seq, "INV", "DLNG","Y");
							cc_list=utilBean.getEntityContactPersonEmailList(conn, comp_cd, counterparty_cd, "C", plant_seq, "INV", "DLNG","N");
						}
						else
						{
							to_list=utilBean.getEntityContactPersonEmailList(conn, comp_cd, counterparty_cd, "C", "P"+plant_seq, "INV", "DLNG","Y");
							cc_list=utilBean.getEntityContactPersonEmailList(conn, comp_cd, counterparty_cd, "C", "P"+plant_seq, "INV", "DLNG","N");
						}
					}
					
					String tmpCcList=utilBean.getEntityContactPersonEmailList(conn, comp_cd, comp_cd, "B", "P"+bu_unit, "INV", "DLNG","N");
					cc_list+=cc_list.equals("")?tmpCcList:","+tmpCcList;
					
					//get BCc list
					bcc_list=utilBean.getEntityContactPersonEmailList(conn, comp_cd, comp_cd, "B", "P"+bu_unit, "INV", "DLNG","B");
		
					if(!temp_pdf_type.equals("T"))
					{
						if(contract_type.equals("W")) //ADDITIONAL EMAIL IDs FOR IGX ONLY
						{
							queryString3="SELECT AGMT_REV,CONT_REV "
									+ "FROM FMS_SUPPLY_CONT_MST A "
									+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
									+ "AND CONT_NO=? AND AGMT_NO=? AND CONTRACT_TYPE=? "
									+ "AND CONT_REV=(SELECT MAX(CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
									+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_NO=B.AGMT_NO AND A.CONT_NO=B.CONT_NO "
									+ "AND A.AGMT_REV=B.AGMT_REV AND A.CONTRACT_TYPE=B.CONTRACT_TYPE)";
							stmt3=conn.prepareStatement(queryString3);
							stmt3.setString(1, comp_cd);
							stmt3.setString(2, counterparty_cd);
							stmt3.setString(3, cont_no);
							stmt3.setString(4, agmt_no);
							stmt3.setString(5, contract_type);
							rset3=stmt3.executeQuery();
							if(rset3.next())
							{
								String agmtRev=rset3.getString(1)==null?"":rset3.getString(1);
								String contRev=rset3.getString(2)==null?"":rset3.getString(2);
								
								queryString4="SELECT GX_COUNTERPARTY_CD,GX_BU_SEQ_NO "
										+ "FROM FMS_SUPPLY_CONT_GX_BU "
										+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? "
										+ "AND CONT_REV=? AND AGMT_NO=? AND AGMT_REV=? "
										+ "AND CONTRACT_TYPE=?";
								stmt4=conn.prepareStatement(queryString4);
								stmt4.setString(1, comp_cd);
								stmt4.setString(2, counterparty_cd);
								stmt4.setString(3, cont_no);
								stmt4.setString(4, contRev);
								stmt4.setString(5, agmt_no);
								stmt4.setString(6, agmtRev);
								stmt4.setString(7, contract_type);
								rset4=stmt4.executeQuery();
								while(rset4.next())
								{
									String gx_cd=rset4.getString(1)==null?"":rset4.getString(1);
									String gx_bu_cd=rset4.getString(2)==null?"":rset4.getString(2);
									
									String tmpToList=utilBean.getEntityContactPersonEmailList(conn, comp_cd, gx_cd, "G", "B"+gx_bu_cd, "INV", "DLNG","Y");
									to_list+=to_list.equals("")?tmpToList:","+tmpToList;
									
									tmpCcList=utilBean.getEntityContactPersonEmailList(conn, comp_cd, gx_cd, "G", "B"+gx_bu_cd, "INV", "DLNG","N");
									cc_list+=cc_list.equals("")?tmpCcList:","+tmpCcList;	
								}
								rset4.close();
								stmt4.close();
							}
							rset3.close();
							stmt3.close();
						}
					}
					
					int st_count=0;
					if(mail_inv_type.equals("F"))
					{
						queryString3="SELECT FILE_NAME "
								+ "FROM FMS_DLNG_FFLOW_INV_FILE_DTL "
								+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
			 	        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
			 	        		+ "AND PDF_TYPE=? AND PDF_SIGNED=? "
			 	        		+ "AND INVOICE_TYPE=?";
					}
					else
					{
						queryString3="SELECT FILE_NAME "
								+ "FROM FMS_DLNG_INV_FILE_DTL "
								+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
			 	        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
			 	        		+ "AND PDF_TYPE=? AND PDF_SIGNED=?";
					}
					stmt3=conn.prepareStatement(queryString3);
					stmt3.setString(++st_count, comp_cd);
					stmt3.setString(++st_count, bu_state_tin);
					stmt3.setString(++st_count, invoice_seq);
					stmt3.setString(++st_count, financial_year);
					stmt3.setString(++st_count, temp_pdf_type);
					stmt3.setString(++st_count, "Y");
					if(mail_inv_type.equals("F"))
					{
						stmt3.setString(++st_count, invoice_type);
					}
					rset3=stmt3.executeQuery();
					if(rset3.next())
					{
						//attachment=rset.getString(1)==null?"":rset.getString(1);
						VTEMP_MAIL_ATTACHMENT.add(rset3.getString(1)==null?"":rset3.getString(1));
						VTEMP_MAIL_ANNEXURE_ATTACHMENT_FLAG.add("");
					}
					rset3.close();
					stmt3.close();
					
					if(mail_inv_type.equals("F"))
					{
						/*queryString4="SELECT FILE_NAME "
								+ "FROM FMS_DLNG_FFLOW_INV_ANXRE "
								+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
								+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
								+ "AND INVOICE_TYPE=?";
						stmt4=conn.prepareStatement(queryString4);
						stmt4.setString(1, comp_cd);
						stmt4.setString(2, bu_state_tin);
						stmt4.setString(3, invoice_seq);
						stmt4.setString(4, financial_year);
						stmt4.setString(5, invoice_type);
						rset4=stmt4.executeQuery();
						while(rset4.next())
						{
							//attachment=rset.getString(1)==null?"":rset.getString(1);
							VTEMP_MAIL_ATTACHMENT.add(rset4.getString(1)==null?"":rset4.getString(1));
							VTEMP_MAIL_ANNEXURE_ATTACHMENT_FLAG.add("Y");
						}
						rset4.close();
						stmt4.close();*/
					}
					
					mail_body="Dear Sir/Madam,"
							+ "\n\nPlease find enclosed Invoice# "+invoiceNo+" dated "+invoiceDt.replaceAll("/", "-")+".";
					if(!invoice_type.equals("CR") && !invoice_type.equals("CCR"))
					{
						mail_body+= "\n\nYou are requested to pay on or before the due date "+dueDate+". If already paid or no amount is due kindly ignore this message.";
					}		
					mail_body+= "\n\nIn case of any query, please contact us at "+ownEmail+""				
							+ "\n\nNOTE : Bank Account changes should not be made without re-confirmation with your usual SHELL Contact."
							+ "\nUnless communicated by your usual Shell Contact/Authorized Representative, Bank Account changes should not be made. Any proposed change should always be confirmed initially by Phone and then Electronically (Email) with your usual SHELL Contact. Most Importantly check for valid Domain Name (@SHELL.COM) in the E-mail Address."
							+ "\n\n\nThank You,"
							+ "\n\n"+companyNm+""
							+ "\n"+ownAddress+", "
							+ "\n"+ownCity+", "+ownState+" - "+ownPin+""
							+ "\nEmail: "+ownEmail+""
							+ "\nPh: "+ownPhone+""
							+ "\n\nThis is an auto-generated email from the system, please do not reply to this email.";
					
					VMAIL_FROM_LIST.add(utilBean.getFromMailId(conn));
					VMAIL_TO_LIST.add(to_list);
					VMAIL_CC_LIST.add(cc_list);
					VMAIL_BCC_LIST.add(bcc_list);
					VMAIL_SUBJECT.add(subject);
					//VMAIL_ATTACHMENT.add(attachment);
					VMAIL_ATTACHMENT.add(VTEMP_MAIL_ATTACHMENT);
					VMAIL_ANNEXURE_ATTACHMENT_FLAG.add(VTEMP_MAIL_ANNEXURE_ATTACHMENT_FLAG);
					if(mail_inv_type.equals("F"))
					{
						VMAIL_ATTACHMENT_PATH.add(CommonVariable.signed_freeflow_inv_path);
					}
					else
					{
						VMAIL_ATTACHMENT_PATH.add(CommonVariable.signed_dlng_sales_inv_path);
					}
					
					String annexure_folder=invoice_type+"_"+financial_year+"_"+bu_state_tin+"_"+invoice_seq;
					VMAIL_ANNEXURE_ATTACHMENT_PATH.add(CommonVariable.freeflow_annexure_path+""+annexure_folder+"/");
					VMAIL_BODY.add(mail_body);	
				}
				
				
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getAllPdfFileName()
	{
		String function_nm="getAllPdfFileName()";
		try
		{
			if(flag.equals("FF"))
			{
				queryString3="SELECT FILE_NAME,PDF_SIGNED "
						+ "FROM FMS_DLNG_FFLOW_INV_FILE_DTL "
						+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
	 	        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
	 	        		+ "AND INVOICE_TYPE=? AND PDF_TYPE!=?";
				stmt3=conn.prepareStatement(queryString3);
				stmt3.setString(1, comp_cd);
				stmt3.setString(2, bu_state_tin);
				stmt3.setString(3, invoice_seq);
				stmt3.setString(4, financial_year);
				stmt3.setString(5, invoice_type);
				stmt3.setString(6, "X");
				rset3=stmt3.executeQuery();
				while(rset3.next())
				{
					VPDF_FILE_NAME.add(rset3.getString(1)==null?"":rset3.getString(1));
					String pdf_signed=rset3.getString(2)==null?"":rset3.getString(2);
					
					if(pdf_signed.equals("Y"))
					{
						VPDF_FILE_PATH.add(CommonVariable.signed_freeflow_inv_path);
					}
					else
					{
						VPDF_FILE_PATH.add(CommonVariable.freeflow_inv_path);
					}
				}
				rset3.close();
				stmt3.close();
			}
			else
			{
				queryString3="SELECT FILE_NAME,PDF_SIGNED "
						+ "FROM FMS_DLNG_INV_FILE_DTL "
						+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
	 	        		+ "AND INVOICE_SEQ=? AND FINANCIAL_YEAR=? "
	 	        		+ "AND PDF_TYPE!=?";
				stmt3=conn.prepareStatement(queryString3);
				stmt3.setString(1, comp_cd);
				stmt3.setString(2, bu_state_tin);
				stmt3.setString(3, invoice_seq);
				stmt3.setString(4, financial_year);
				stmt3.setString(5, "X");
				rset3=stmt3.executeQuery();
				while(rset3.next())
				{
					VPDF_FILE_NAME.add(rset3.getString(1)==null?"":rset3.getString(1));
					String pdf_signed=rset3.getString(2)==null?"":rset3.getString(2);
					
					if(pdf_signed.equals("Y"))
					{
						VPDF_FILE_PATH.add(CommonVariable.signed_dlng_sales_inv_path);
					}
					else
					{
						VPDF_FILE_PATH.add(CommonVariable.dlng_sales_inv_path);
					}
				}
				rset3.close();
				stmt3.close();
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getDriverDetailForForm402()
	{
		String function_nm="getDriverDetailForForm402()";
		try
		{
			queryString="SELECT DRIVER_NAME,DRIVER_ADDR,LICENCE_NO,LICENCE_ISSUE_STATE "
					+ "FROM FMS_TRUCK_DRIVER_MST "
					+ "WHERE DRIVER_CD=? ";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, driver_cd);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				driver_nm=rset.getString(1)==null?"":rset.getString(1);
				driver_addr=rset.getString(2)==null?"":rset.getString(2);
				licence_no=rset.getString(3)==null?"":rset.getString(3);
				licence_issue_state=rset.getString(4)==null?"": utilBean.getStateName(conn, rset.getString(4));
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getTransporterDetail()
	{
		String function_nm="getTransporterDetail()";
		try
		{
			check_post_nm=dlng_util.getCheckPostName(conn, check_post_cd);
			
			counterparty_nm=utilBean.getCounterpartyName(conn, counterparty_cd);
			truck_no=dlng_util.getTruckRegNo(conn, truck_cd);
			
			HashMap plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "C", counterparty_cd, plant_seq);
            plantAddress=""+plant_detail.get("plant_address");
			plantCity=""+plant_detail.get("plant_city");
			plantState=""+plant_detail.get("plant_state");
			plantPin=""+plant_detail.get("plant_pin");
			plantNm=""+plant_detail.get("plant_name");
			
			HashMap bu_plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "B", comp_cd, bu_unit);
            bu_plantAddress=""+bu_plant_detail.get("plant_address");
			bu_plantCity=""+bu_plant_detail.get("plant_city");
			bu_plantState=""+bu_plant_detail.get("plant_state");
			bu_plantPin=""+bu_plant_detail.get("plant_pin");
			bu_plantNm=""+bu_plant_detail.get("plant_name");
			
			queryString = "SELECT A.STAT_NO, TO_CHAR(A.EFF_DT,'DD/MM/YYYY'), B.STAT_CD "
					+ "FROM FMS_COUNTERPARTY_PLANT_TAX A, FMS_GOVT_STAT_TAX B "
					+ "WHERE A.COUNTERPARTY_CD=? AND A.ENTITY=? "
					+ "AND A.PLANT_SEQ_NO=? AND A.COMPANY_CD=? "
					+ "AND A.STAT_CD=B.STAT_CD AND A.STAT_NO IS NOT NULL AND B.STAT_CD IN ('1003','1004','1005')";
			stmt = conn.prepareStatement(queryString);
			stmt.setString(1, counterparty_cd);
			stmt.setString(2, "C");
			stmt.setString(3, plant_seq);
			stmt.setString(4, comp_cd);
			rset = stmt.executeQuery();
			while(rset.next())
			{
				String no = rset.getString(1)==null?"":rset.getString(1);
				String dt = rset.getString(2)==null?"":rset.getString(2);
				String cd = rset.getString(3)==null?"":rset.getString(3);
				
				if(cd.equals("1003"))
				{
					cust_gst_no=no;
					cust_gst_dt=dt;
				}
				else if(cd.equals("1004"))
				{
					cust_cst_no=no;
					cust_cst_dt=dt;
				}
				else if(cd.equals("1005"))
				{
					cust_vat_no=no;
					cust_vat_dt=dt;
				}
			}
			stmt.close();
			rset.close();
			
			queryString = "SELECT A.STAT_NO, TO_CHAR(A.EFF_DT,'DD/MM/YYYY'), B.STAT_CD "
					+ "FROM FMS_COUNTERPARTY_PLANT_TAX A, FMS_GOVT_STAT_TAX B "
					+ "WHERE A.COUNTERPARTY_CD=? AND A.ENTITY=? "
					+ "AND A.PLANT_SEQ_NO=? AND A.COMPANY_CD=? "
					+ "AND A.STAT_CD=B.STAT_CD AND A.STAT_NO IS NOT NULL AND B.STAT_CD IN ('1004')";
			stmt = conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, "B");
			stmt.setString(3, bu_unit);
			stmt.setString(4, comp_cd);
			rset = stmt.executeQuery();
			while(rset.next())
			{
				String no = rset.getString(1)==null?"":rset.getString(1);
				String dt = rset.getString(2)==null?"":rset.getString(2);
				String cd = rset.getString(3)==null?"":rset.getString(3);
				
				bu_cst_no=no;
				bu_cst_dt=dt;
			}
			stmt.close();
			rset.close();
			
		    if(plantState.contains("Gujarat")){
            	not = "Sale Within Gujarat";
            }else{
            	not = "Inter State Sale";
            }
			
			queryString = "SELECT TRUCK_TRANS_NAME,ADDR "
					+ "FROM FMS_TRUCK_TRANSPORTER_MST "
					+ "WHERE TRUCK_TRANS_CD=? ";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, truck_trans_cd);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				transporter_name=rset.getString(1)==null?"":rset.getString(1);
				transporter_addr=rset.getString(2)==null?"":rset.getString(2);
			}
			rset.close();
			stmt.close();
		
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void GenerateExcelForForm402() 
	{
		String function_nm="GenerateExcelForForm402()";
		String fileName="",sheetnm="";
		try
		{
			queryString="SELECT INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),ALLOC_QTY,GROSS_AMT,"
					+ "TAX_AMT,NET_PAYABLE_AMT,CHKPOST_CD,DRIVER_CD,TRUCK_CD,TRUCK_TRANS_CD "
					+ "FROM FMS_DLNG_INVOICE_MST "
					+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? AND FINANCIAL_YEAR=? "
					+ "AND INV_FLAG=? AND INVOICE_SEQ=? ";
			stmt = conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, bu_state_tin);
			stmt.setString(3, financial_year);
			stmt.setString(4, inv_flag);
			stmt.setString(5, inv_seq);
			rset = stmt.executeQuery();
			if(rset.next())
			{
				invoice_no=rset.getString(1)==null?"":rset.getString(1);
				invoice_dt=rset.getString(2)==null?"":rset.getString(2);
				qty_mmbtu=rset.getString(3)==null?"":nf.format(rset.getDouble(3));
				gross_amt=rset.getString(4)==null?"":nf.format(rset.getDouble(4));
				tax_amt=rset.getString(5)==null?"":nf.format(rset.getDouble(5));
				net_payable=rset.getString(6)==null?"":nf.format(rset.getDouble(6));
				check_post_cd=rset.getString(7)==null?"":rset.getString(7);
				driver_cd=rset.getString(8)==null?"":rset.getString(8);
				truck_cd=rset.getString(9)==null?"":rset.getString(9);
				truck_trans_cd=rset.getString(10)==null?"":rset.getString(10);
				
				if(!gross_amt.equals("") && !tax_amt.equals(""))
				{
					tax_factor=nf.format((Double.parseDouble(tax_amt)/Double.parseDouble(gross_amt))*100);
				}
			}
			rset.close();
			stmt.close();
			
			getDriverDetailForForm402();
			getTransporterDetail();
			
			if(!invoice_no.equals("") && !truck_no.equals(""))
			{
				fileName =invoice_no.replace("/", "-")+"_"+truck_no+".xlsx";
				sheetnm=invoice_no.replace("/", "-")+"_"+truck_no;
				
				String work_data=utilBean.getAutomationKeyDetail(conn, "WORK_DATA_"+comp_cd);
				
				String file_path=work_data+File.separator+CommonVariable.form_402_dir;
				
				if(!new File(file_path).exists())
				{
					new File(file_path).mkdirs();
				}
				
				file_path=file_path+File.separator+fileName;
				
				workbook402 = new XSSFWorkbook();
	            XSSFSheet sheet = workbook402.createSheet(sheetnm);
	            
	            XSSFCellStyle stringStyle1 = workbook402.createCellStyle();
	            XSSFCellStyle stringStyle2 = workbook402.createCellStyle();
	    		XSSFCellStyle stringStyle3 = workbook402.createCellStyle();
	    		
	    		XSSFColor grey = new XSSFColor(new Color(191, 191, 191), null);		// The second argument is for IndexedColorMap, null for direct RGB colors
	    		stringStyle1.setAlignment(HorizontalAlignment.CENTER);
	    		//stringStyle1.setFillBackgroundColor(grey);
	    		stringStyle1.setFillForegroundColor(grey);
	    		stringStyle1.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	    		
	    		//XSSFColor grey2 = new XSSFColor((IndexedColorMap) new Color(217, 217, 217));
	    		XSSFColor grey2 = new XSSFColor(new Color(217,217,217), null);
	    		stringStyle2.setAlignment(HorizontalAlignment.CENTER);
	    		//stringStyle2.setFillBackgroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
	    		//stringStyle2.setFillBackgroundColor(grey2);
	    		stringStyle2.setFillForegroundColor(grey2);
	    		stringStyle2.setFillPattern(FillPatternType.FINE_DOTS);
	    		
	    		stringStyle3.setAlignment(HorizontalAlignment.LEFT);
	    		
	    		Font font1 = workbook402.createFont();
	    		font1.setFontHeightInPoints((short)20); 
	    		
	    		Font font2 = workbook402.createFont();
	    		font2.setFontHeightInPoints((short)15); 
	    		
	    		Font font3 = workbook402.createFont();
	    		font3.setFontHeightInPoints((short)9);
	    		
	    		/*Row 1*/
	    		Row row = sheet.createRow(0);  
	            Cell cell = row.createCell(0);  
	            cell.setCellValue("Form-402");  
	            stringStyle1.setFont(font1); 
	            cell.setCellStyle(stringStyle1);
	            sheet.addMergedRegion(new CellRangeAddress(0,1,0,15));  
	            
	            /*Row 2*/
	            Row row1 = sheet.createRow(2);  
	            Cell cell1 = row1.createCell(0);  
	            cell1.setCellValue("Basic Info"); 
	            stringStyle2.setFont(font2);
	            cell1.setCellStyle(stringStyle2);
	            sheet.addMergedRegion(new CellRangeAddress(2,2,0,15)); 
	            
	            /*Row 3*/
	            Row row2 = sheet.createRow(3);  
	            Cell cell2 = row2.createCell(0);
	            cell2.setCellValue("Check Post Name"); 
	            stringStyle3.setFont(font3);
	            cell2.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(3,3,0,5));
	            
	            Cell cell3 = row2.createCell(6);
	            cell3.setCellValue(check_post_nm);
	            cell3.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(3,3,6,15));
	            
	            /*Row 4*/
	            Row row3 = sheet.createRow(4);  
	            Cell cell4 = row3.createCell(0);
	            cell4.setCellValue("Place from Which Goods are Dispatched"); 
	            stringStyle3.setFont(font3);
	            cell4.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(4,4,0,5));
	            
	            Cell cell5 = row3.createCell(6);
	            cell5.setCellValue("Gujarat");
	            cell5.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(4,4,6,15));
	            
	            /*Row 5*/
	            Row row5 = sheet.createRow(5);  
	            Cell cell6 = row5.createCell(0);
	            cell6.setCellValue("District from Which Goods are Dispatched"); 
	            stringStyle3.setFont(font3);
	            cell6.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(5,5,0,5));
	            
	            Cell cell7 = row5.createCell(6);
	            cell7.setCellValue("");
	            cell7.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(5,5,6,15));
	            
	            /*Row 6*/
	            Row row6 = sheet.createRow(6);  
	            Cell cell8 = row6.createCell(0);
	            cell8.setCellValue("Place to Which Goods are Dispatched");
	            stringStyle3.setFont(font3);
	            cell8.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(6,6,0,5));
	            
	            Cell cell9 = row6.createCell(6);
	            cell9.setCellValue(plantState);
	            cell9.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(6,6,6,15));
	            
	            /*Row 7*/
	            Row row7 = sheet.createRow(7);  
	            Cell cell10 = row7.createCell(0);
	            cell10.setCellValue("District to Which Goods are Dispatched");
	            stringStyle3.setFont(font3);
	            cell10.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(7,7,0,5));
	            
	            Cell cell11 = row7.createCell(6);
	            cell11.setCellValue("");
	            cell11.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(7,7,6,15));
	            
	            /*Row 8*/
	            Row row8 = sheet.createRow(8);  
	            Cell cell12 = row8.createCell(0);  
	            cell12.setCellValue("Consignor Details"); 
	            stringStyle2.setFont(font2);
	            cell12.setCellStyle(stringStyle2);
	            sheet.addMergedRegion(new CellRangeAddress(8,8,0,15)); 
	            
	            /*Row 9*/
	            Row row9 = sheet.createRow(9);  
	            Cell cell13 = row9.createCell(0);
	            cell13.setCellValue("CST Certificate Number");
	            stringStyle3.setFont(font3);
	            cell13.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(9,9,0,5));
	            
	            Cell cell14 = row9.createCell(6);
	            cell14.setCellValue(bu_cst_no);
	            cell14.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(9,9,6,15));
	            
	            /*Row 10*/            
	            Row row10 = sheet.createRow(10);  
	            Cell cell15 = row10.createCell(0);
	            cell15.setCellValue("Nature of Transactions");
	            stringStyle3.setFont(font3);
	            cell15.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(10,10,0,5));
	            
	            Cell cell16 = row10.createCell(6);
	            cell16.setCellValue(not);
	            cell16.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(10,10,6,15));
	            
	            
	            /*Row 11*/
	            Row row11 = sheet.createRow(11);  
	            Cell cell17 = row11.createCell(0);  
	            cell17.setCellValue("Consignee Details"); 
	            stringStyle2.setFont(font2);
	            cell17.setCellStyle(stringStyle2);
	            sheet.addMergedRegion(new CellRangeAddress(11,11,0,15)); 
	            
	            /*Row 12*/
	            Row row12 = sheet.createRow(12);  
	            Cell cell18 = row12.createCell(0);
	            cell18.setCellValue("Name");
	            stringStyle3.setFont(font3);
	            cell18.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(12,12,0,5));
	            
	            Cell cell19 = row12.createCell(6);
	            cell19.setCellValue(counterparty_nm);
	            cell19.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(12,12,6,15));
	            
	            /*Row 13*/
	            Row row13 = sheet.createRow(13);  
	            Cell cell20 = row13.createCell(0);
	            cell20.setCellValue("Address");
	            stringStyle3.setFont(font3);
	            cell20.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(13,13,0,5));
	            
	            Cell cell21 = row13.createCell(6);
	            cell21.setCellValue(plantAddress +","+plantCity+" - "+plantPin);
	            cell21.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(13,13,6,15));
	            
	            /*Row 16*/
	            String cst_no=cust_cst_no,cst_dt=cust_cst_dt;
	            String vat_no=cust_vat_no,vat_dt=cust_vat_dt;
	            String gstin_no=cust_gst_no,gstin_dt=cust_gst_dt;
	            
	        	/*Row 14*/
	            Row row14 = sheet.createRow(14);  
	            Cell cell22 = row14.createCell(0);
	            cell22.setCellValue("VAT Registration Certificate No.");
	            stringStyle3.setFont(font3);
	            cell22.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(14,14,0,5));
	            
	            Cell cell23 = row14.createCell(6);
	            cell23.setCellValue(vat_no);
	            cell23.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(14,14,6,15));
	            
	            /*Row 15*/
	            Row row15 = sheet.createRow(15);  
	            Cell cell24 = row15.createCell(0);
	            cell24.setCellValue("VAT Registration Effective Date");
	            stringStyle3.setFont(font3);
	            cell24.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(15,15,0,5));
	            
	            Cell cell25 = row15.createCell(6);
	            cell25.setCellValue(vat_dt);
	            cell25.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(15,15,6,15));
	            
	           
	            Row row16 = sheet.createRow(16);  
	            Cell cell26 = row16.createCell(0);
	            cell26.setCellValue("CST Registration No.");
	            stringStyle3.setFont(font3);
	            cell26.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(16,16,0,5));
	            
	            Cell cell27 = row16.createCell(6);
	            cell27.setCellValue(cst_no);
	            cell27.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(16,16,6,15));
	            
	            /*Row 17*/
	            Row row17 = sheet.createRow(17);  
	            Cell cell28 = row17.createCell(0);
	            cell28.setCellValue("CST Registration Effective Date");
	            stringStyle3.setFont(font3);
	            cell28.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(17,17,0,5));
	            
	            Cell cell29 = row17.createCell(6);
	            cell29.setCellValue(cst_dt);
	            cell29.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(17,17,6,15));
	            
	            /*Row 18*/
	            Row row18 = sheet.createRow(18);  
	            Cell cell82 = row18.createCell(0);
	            cell82.setCellValue("GSTIN Registration No.");
	            stringStyle3.setFont(font3);
	            cell82.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(18,18,0,5));
	            
	            Cell cell83 = row18.createCell(6);
	            cell83.setCellValue(gstin_no);
	            cell83.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(18,18,6,15));
	            
	            
	            /*Row 18*/
	            Row row19 = sheet.createRow(19);  
	            Cell cell84 = row19.createCell(0);
	            cell84.setCellValue("GSTIN Effective Date");
	            stringStyle3.setFont(font3);
	            cell84.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(19,19,0,5));
	            
	            Cell cell85 = row19.createCell(6);
	            cell85.setCellValue(gstin_dt);
	            cell85.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(19,19,6,15));
	            
	            
	            /*Row 18*/
	            Row row20 = sheet.createRow(20);  
	            Cell cell30 = row20.createCell(0);
	            cell30.setCellValue("Telephone No.");
	            stringStyle3.setFont(font3);
	            cell30.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(20,20,0,5));
	            
	            Cell cell31 = row20.createCell(6);
	            cell31.setCellValue("");
	            cell31.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(20,20,6,15));
	            
	            /*Row 19*/
	            Row row21 = sheet.createRow(21);  
	            Cell cell33 = row21.createCell(0);
	            cell33.setCellValue("Consignee Fax No.");
	            stringStyle3.setFont(font3);
	            cell33.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(21,21,0,5));
	            
	            Cell cell34 = row21.createCell(6);
	            cell34.setCellValue("");
	            cell34.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(21,21,6,15));
	            
	            /*Row 20*/
	            Row row22 = sheet.createRow(22);  
	            Cell cell35 = row22.createCell(0);
	            cell35.setCellValue("Consigned Value Rs. (Total Value of Invoice)");
	            stringStyle3.setFont(font3);
	            cell35.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(22,22,0,5));
	            
	            Cell cell36 = row22.createCell(6);
	            cell36.setCellValue(net_payable);
	            cell36.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(22,22,6,15));
	            
	            /*Row 23*/
	            Row row23 = sheet.createRow(23);  
	            Cell cell37 = row23.createCell(0);
	            cell37.setCellValue("Whether Shipping Address is within the state of Gujarat and shipping \nis to dealer other than consignee, as declared above ?");
	            stringStyle3.setFont(font3);
	            cell37.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(23,23,0,5));
	            
	            Cell cell38 = row23.createCell(6);
	            cell38.setCellValue("");
	            cell38.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(23,23,6,15));
	            
	            /*Row 22*/
	            Row row24 = sheet.createRow(24);  
	            Cell cell39 = row24.createCell(0);
	            cell39.setCellValue("If yes, give TIN of Local Register dealer to Goods are Shipped to");
	            stringStyle3.setFont(font3);
	            cell39.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(24,24,0,5));
	            
	            Cell cell40 = row24.createCell(6);
	            cell40.setCellValue("");
	            cell40.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(24,24,6,15));
	            
	            /*Row 23*/
	            Row row25 = sheet.createRow(25);  
	            Cell cell41 = row25.createCell(0);
	            cell41.setCellValue("Whether this is final shipping to original buyer outside the state of Gujarat");
	            stringStyle3.setFont(font3);
	            cell41.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(25,25,0,5));
	            
	            Cell cell42 = row25.createCell(6);
	            cell42.setCellValue("");
	            cell42.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(25,25,6,15));
	            
	            
	            /*Row 26*/
	            Row row26 = sheet.createRow(26);  
	            Cell cell43 = row26.createCell(0);
	            cell43.setCellValue("If yes, provide reference of previous Form-402 \r\n against which goods are received for Job work");
	            stringStyle3.setFont(font3);
	            cell43.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(26,26,0,5));
	            
	            Cell cell44 = row26.createCell(6);
	            cell44.setCellValue("");
	            cell44.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(26,26,6,15));
	            
	            /*Row 27*/
	            Row row27 = sheet.createRow(27);  
	            Cell cell47 = row27.createCell(0);  
	            cell47.setCellValue("Commodity Details"); 
	            stringStyle2.setFont(font2);
	            cell47.setCellStyle(stringStyle2);
	            sheet.addMergedRegion(new CellRangeAddress(27,27,0,15));
	            
	            /*Row 28*/
	            Row row28 = sheet.createRow(28);  
	            Cell cell45 = row28.createCell(0);
	            cell45.setCellValue("Invoice number");
	            stringStyle3.setFont(font3);
	            cell45.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(28,28,0,5));
	            
	            Cell cell46 = row28.createCell(6);
	            cell46.setCellValue(invoice_no);
	            cell46.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(28,28,6,15));
	            
	            /*Row 29*/
	            Row row29 = sheet.createRow(29);  
	            Cell cell48 = row29.createCell(0);
	            cell48.setCellValue("Invoice Date");
	            stringStyle3.setFont(font3);
	            cell48.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(29,29,0,5));
	            
	            Cell cell49 = row29.createCell(6);
	            cell49.setCellValue(invoice_dt);
	            cell49.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(29,29,6,15));
	            
	            /*Row 28*/
	            Row row30 = sheet.createRow(30);  
	            Cell cell50 = row30.createCell(0);
	            cell50.setCellValue("Commodity Name");
	            stringStyle3.setFont(font3);
	            cell50.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(30,30,0,5));
	            
	            Cell cell51 = row30.createCell(6);
	            cell51.setCellValue("Liquified Natural Gas (LNG)");
	            cell51.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(30,30,6,15));
	            
	            /*Row 31*/
	            Row row31 = sheet.createRow(31);  
	            Cell cell52 = row31.createCell(0);
	            cell52.setCellValue("Quantity");
	            stringStyle3.setFont(font3);
	            cell52.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(31,31,0,5));
	            
	            Cell cell53 = row31.createCell(6);
	            cell53.setCellValue(qty_mmbtu);
	            cell53.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(31,31,6,15));
	            
	            /*Row 32*/
	            Row row32 = sheet.createRow(32);  
	            Cell cell54 = row32.createCell(0);
	            cell54.setCellValue("Unit of Mesurement");
	            stringStyle3.setFont(font3);
	            cell54.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(32,32,0,5));
	            
	            Cell cell55 = row32.createCell(6);
	            cell55.setCellValue("Nos.");
	            cell55.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(32,32,6,15));
	            
	            /*Row 33*/
	            Row row33 = sheet.createRow(33);  
	            Cell cell56 = row33.createCell(0);
	            cell56.setCellValue("Rate of tax");
	            stringStyle3.setFont(font3);
	            cell56.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(33,33,0,5));
	            
	            Cell cell57 = row33.createCell(6);
	            cell57.setCellValue(tax_factor);
	            cell57.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(33,33,6,15));
	            
	            /*Row 34*/
	            Row row34 = sheet.createRow(34);  
	            Cell cell58 = row34.createCell(0);
	            cell58.setCellValue("Amount");
	            stringStyle3.setFont(font3);
	            cell58.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(34,34,0,5));
	            
	            Cell cell59 = row34.createCell(6);
	            cell59.setCellValue(net_payable);
	            cell59.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(34,34,6,15));
	            
	            /*Row 35*/
	            Row row35 = sheet.createRow(35);  
	            Cell cell60 = row35.createCell(0);  
	            cell60.setCellValue("Transporter Details"); 
	            stringStyle2.setFont(font2);
	            cell60.setCellStyle(stringStyle2);
	            sheet.addMergedRegion(new CellRangeAddress(35,35,0,15));
	            
	            
	            /*Row 36*/
	            Row row36 = sheet.createRow(36);  
	            Cell cell61 = row36.createCell(0);
	            cell61.setCellValue("Name");
	            stringStyle3.setFont(font3);
	            cell61.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(36,36,0,5));
	            
	            Cell cell62 = row36.createCell(6);
	            cell62.setCellValue(transporter_name);
	            cell62.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(36,36,6,15));
	            
	            /*Row 37*/
	            Row row37 = sheet.createRow(37);  
	            Cell cell63 = row37.createCell(0);
	            cell63.setCellValue("Address");
	            stringStyle3.setFont(font3);
	            cell63.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(37,37,0,5));
	            
	            Cell cell64 = row37.createCell(6);
	            cell64.setCellValue(transporter_addr);
	            cell64.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(37,37,6,15));
	            
	            /*Row 38*/
	            Row row38 = sheet.createRow(38);  
	            Cell cell65 = row38.createCell(0);
	            cell65.setCellValue("Owner / Partner Name");
	            stringStyle3.setFont(font3);
	            cell65.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(38,38,0,5));
	            
	            Cell cell66 = row38.createCell(6);
	            cell66.setCellValue("");
	            cell66.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(38,38,6,15));
	            
	            /*Row 39*/
	            Row row39 = sheet.createRow(39);  
	            Cell cell67 = row39.createCell(0);
	            cell67.setCellValue("Vehicle No.");
	            stringStyle3.setFont(font3);
	            cell67.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(39,39,0,5));
	            
	            Cell cell68 = row39.createCell(6);
	            cell68.setCellValue(truck_no);
	            cell68.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(39,39,6,15));
	            
	            
	            /*Row 40*/
	            Row row40 = sheet.createRow(40);  
	            Cell cell69 = row40.createCell(0);
	            cell69.setCellValue("LR No.");
	            stringStyle3.setFont(font3);
	            cell69.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(40,40,0,5));
	            
	            Cell cell70 = row40.createCell(6);
	            cell70.setCellValue("");
	            cell70.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(40,40,6,15));
	            
	            /*Row 41*/
	            Row row41 = sheet.createRow(41);  
	            Cell cell71 = row41.createCell(0);
	            cell71.setCellValue("LR Date");
	            stringStyle3.setFont(font3);
	            cell71.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(41,41,0,5));
	            
	            Cell cell72 = row41.createCell(6);
	            cell72.setCellValue("");
	            cell72.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(41,41,6,15));
	            
	            
	            /*Row 42*/
	            Row row42 = sheet.createRow(42);  
	            Cell cell75 = row42.createCell(0);  
	            cell75.setCellValue("Drivers Details"); 
	            stringStyle2.setFont(font2);
	            cell75.setCellStyle(stringStyle2);
	            sheet.addMergedRegion(new CellRangeAddress(42,42,0,15));
	            
	            /*Row 41*/
	            Row row43 = sheet.createRow(43);  
	            Cell cell73 = row43.createCell(0);
	            cell73.setCellValue("Name");
	            stringStyle3.setFont(font3);
	            cell73.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(43,43,0,5));
	            
	            Cell cell74 = row43.createCell(6);
	            cell74.setCellValue(driver_nm);
	            cell74.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(43,43,6,15));
	            
	            /*Row 44*/
	            Row row44 = sheet.createRow(44);  
	            Cell cell77 = row44.createCell(0);
	            cell77.setCellValue("Address");
	            stringStyle3.setFont(font3);
	            cell77.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(44,44,0,5));
	            
	            Cell cell76 = row44.createCell(6);
	            cell76.setCellValue(driver_addr);
	            cell76.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(44,44,6,15));
	            
	            /*Row 45*/
	            Row row45 = sheet.createRow(45);  
	            Cell cell78 = row45.createCell(0);
	            cell78.setCellValue("Driving Licence No.");
	            stringStyle3.setFont(font3);
	            cell78.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(45,45,0,5));
	            
	            Cell cell79 = row45.createCell(6);
	            cell79.setCellValue(licence_no);
	            cell79.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(45,45,6,15));
	            
	            /*Row 46*/
	            Row row46 = sheet.createRow(46);  
	            Cell cell80 = row46.createCell(0);
	            cell80.setCellValue("Licence Issueing State");
	            stringStyle3.setFont(font3);
	            cell80.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(46,46,0,5));
	            
	            Cell cell81 = row46.createCell(6);
	            cell81.setCellValue(licence_issue_state);
	            cell81.setCellStyle(stringStyle3);
	            sheet.addMergedRegion(new CellRangeAddress(46,46,6,15));
	            
	            String realPath = request.getServletContext().getRealPath("");
	            String canonicalPath_files = new File(file_path).getCanonicalPath();
	            
	            //System.out.println("realPath = "+realPath);
	            //System.out.println("canonicalPath_files = "+canonicalPath_files);
		        if(!canonicalPath_files.startsWith(realPath))
		        {
		        	throw new IOException("Entry is outside of the target directory!");
		        }
		        else
		        {
		            try (FileOutputStream fileOut = new FileOutputStream(file_path))
		            {
		            	workbook402.write(fileOut);
		            	fileOut.close();
		            	workbook402.close();
		            }
		        }
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}

	public void getCFormMst() 
	{
		String function_nm="getCFormMst()";
		try
		{
			queryString="SELECT COMPANY_CD,CFORM_NO,TO_CHAR(CFORM_DT,'DD/MM/YYYY'),COUNTERPARTY_CD,FINANCIAL_YEAR,ISSUING_STATE,"
					+ "TO_CHAR(PERIOD_FROM,'DD/MM/YYYY'),TO_CHAR(PERIOD_TO,'DD/MM/YYYY'),"
					+ "CFORM_AMOUNT,CFORM_FILE,NO_OF_INVOICES,CFORM_CD "
					+ "FROM FMS_CFORM_MST "
					+ "WHERE COMPANY_CD=? AND FINANCIAL_YEAR=? AND COUNTERPARTY_CD=? AND ISSUING_STATE=?";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, financial_year);
			stmt.setString(3, counterparty_cd);
			stmt.setString(4, state);
			rset=stmt.executeQuery();
			while(rset.next())
			{
				VCFORM_NO.add(rset.getString(2)==null?"":rset.getString(2));
				VCFORM_DT.add(rset.getString(3)==null?"":rset.getString(3));
				VCOUNTERPARTY_CD.add(rset.getString(4)==null?"":rset.getString(4));
				VCFORM_FINANCIAL_YEAR.add(rset.getString(5)==null?"":rset.getString(5));
				VISSUING_STATE.add(rset.getString(6)==null?"":rset.getString(6));
				VPERIOD_FROM.add(rset.getString(7)==null?"":rset.getString(7));
				VPERIOD_TO.add(rset.getString(8)==null?"":rset.getString(8));
				VCFORM_AMOUNT.add(rset.getString(9)==null?"":rset.getString(9));
				VCFORM_FILE.add(rset.getString(10)==null?"":rset.getString(10));
				VNO_OF_INVOICES.add(rset.getString(11)==null?"":rset.getString(11));
				VCFORM_CD.add(rset.getString(12)==null?"":rset.getString(12));
			}

			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getCFormDtl() 
	{
		String function_nm="getCFormDtl()";
		try
		{
			int secCnt =0;
			int noofInvoice =0;
			
			String queryString="SELECT INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),"
					+ "GROSS_AMT,TAX_AMT,INVOICE_AMT,PLANT_SEQ,NULL,'DLNG' AS COMMODITY,INVOICE_SEQ,BU_STATE_TIN,HOLD_AMT "
					+ "FROM FMS_DLNG_INVOICE_MST A "
					+ "WHERE A.COMPANY_CD=? AND A.COUNTERPARTY_CD=? AND A.FINANCIAL_YEAR=? AND APPROVED_FLAG=? "
					+ "AND A.TAX_STRUCT_CD IN ("
						+ "SELECT TAX_STR_CD "
						+ "FROM FMS_TAX_STRUCTURE_DTL "
						+ "WHERE TAX_CODE IN ("
							+ "SELECT TAX_CODE FROM FMS_TAX_MST "
							+ "WHERE TAX_ALIAS_CODE = ?) AND FACTOR=? GROUP BY TAX_STR_CD HAVING COUNT(*) = 1 ) ";
			if(cform_cd.equals(""))
			{
				queryString+="AND A.INVOICE_NO NOT IN (SELECT INVOICE_NO FROM FMS_CFORM_DTL) ";
			}
			else
			{
				queryString+="AND A.INVOICE_NO IN (SELECT INVOICE_NO FROM FMS_CFORM_DTL WHERE CFORM_CD = ? "
						+ "UNION SELECT INVOICE_NO "
						+ "FROM FMS_DLNG_INVOICE_MST "
						+ "WHERE INVOICE_NO NOT IN (SELECT INVOICE_NO FROM FMS_CFORM_DTL)) ";
			}
			if(!period_start_dt.equals("") && !period_end_dt.equals("")) 
			{
				queryString+="AND A.INVOICE_DT<=TO_DATE(?,'DD/MM/YYYY') AND A.INVOICE_DT>=TO_DATE(?,'DD/MM/YYYY')";
			}
			
			queryString+="UNION ALL ";
			queryString+="SELECT INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),"
					+ "NVL(GROSS_AMT_INR,GROSS_AMT_USD),TAX_AMT,INVOICE_AMT,NULL,ADDR_FLAG,'RLNG' AS COMMODITY,INVOICE_SEQ,BU_STATE_TIN,HOLD_AMT "
					+ "FROM FMS_DLNG_FFLOW_INV_MST D "
					+ "WHERE D.COMPANY_CD=? AND D.COUNTERPARTY_CD=? AND D.FINANCIAL_YEAR=? AND APPROVED_FLAG=? "
					+ "AND INVOICE_TYPE IN ('S','DR','CDR') "
					+ "AND D.TAX_STRUCT_CD IN ("
					+ "SELECT TAX_STR_CD "
					+ "FROM FMS_TAX_STRUCTURE_DTL "
					+ "WHERE TAX_CODE IN ("
						+ "SELECT TAX_CODE FROM FMS_TAX_MST "
						+ "WHERE TAX_ALIAS_CODE = ?) AND FACTOR=? GROUP BY TAX_STR_CD HAVING COUNT(*) = 1 ) ";
			if(cform_cd.equals(""))
			{
				queryString+="AND D.INVOICE_NO NOT IN (SELECT INVOICE_NO FROM FMS_CFORM_DTL) ";
			}
			else
			{
				queryString+="AND D.INVOICE_NO IN (SELECT INVOICE_NO FROM FMS_CFORM_DTL WHERE CFORM_CD = ? "
						+ "UNION SELECT INVOICE_NO "
						+ "FROM FMS_FFLOW_INV_MST "
						+ "WHERE INVOICE_NO NOT IN (SELECT INVOICE_NO FROM FMS_CFORM_DTL)) ";
			}
			if(!period_start_dt.equals("") && !period_end_dt.equals("")) 
			{
				queryString+="AND D.INVOICE_DT<=TO_DATE(?,'DD/MM/YYYY') AND D.INVOICE_DT>=TO_DATE(?,'DD/MM/YYYY')";
			}
			queryString+="UNION ALL ";
			queryString+="SELECT INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),"
					+ "GROSS_AMT,TAX_AMT,INVOICE_AMT,PLANT_SEQ,NULL,'RLNG' AS COMMODITY,INVOICE_SEQ,BU_STATE_TIN,HOLD_AMT "
					+ "FROM FMS_INVOICE_MST B "
					+ "WHERE B.COMPANY_CD=? AND B.COUNTERPARTY_CD=? AND B.FINANCIAL_YEAR=? AND APPROVED_FLAG=? "
					+ "AND B.TAX_STRUCT_CD IN ("
					+ "SELECT TAX_STR_CD "
					+ "FROM FMS_TAX_STRUCTURE_DTL "
					+ "WHERE TAX_CODE IN ("
						+ "SELECT TAX_CODE FROM FMS_TAX_MST "
						+ "WHERE TAX_ALIAS_CODE = ?) AND FACTOR=? GROUP BY TAX_STR_CD HAVING COUNT(*) = 1 ) ";
			if(cform_cd.equals(""))
			{
				queryString+="AND B.INVOICE_NO NOT IN (SELECT INVOICE_NO FROM FMS_CFORM_DTL) ";
			}
			else
			{
				queryString+="AND B.INVOICE_NO IN (SELECT INVOICE_NO FROM FMS_CFORM_DTL WHERE CFORM_CD = ? "
						+ "UNION SELECT INVOICE_NO "
						+ "FROM FMS_INVOICE_MST "
						+ "WHERE INVOICE_NO NOT IN (SELECT INVOICE_NO FROM FMS_CFORM_DTL)) ";
			}
			if(!period_start_dt.equals("") && !period_end_dt.equals("")) 
			{
				queryString+="AND B.INVOICE_DT<=TO_DATE(?,'DD/MM/YYYY') AND B.INVOICE_DT>=TO_DATE(?,'DD/MM/YYYY')";
			}
			queryString+="UNION ALL ";
			queryString+="SELECT INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),"
					+ "NVL(GROSS_AMT_INR,GROSS_AMT_USD),TAX_AMT,INVOICE_AMT,NULL,ADDR_FLAG,'RLNG' AS COMMODITY,INVOICE_SEQ,BU_STATE_TIN,HOLD_AMT "
					+ "FROM FMS_FFLOW_INV_MST C "
					+ "WHERE C.COMPANY_CD=? AND C.COUNTERPARTY_CD=? AND C.FINANCIAL_YEAR=? AND APPROVED_FLAG=? "
					+ "AND INVOICE_TYPE IN ('S','DR','CDR') "
					+ "AND C.TAX_STRUCT_CD IN ("
					+ "SELECT TAX_STR_CD "
					+ "FROM FMS_TAX_STRUCTURE_DTL "
					+ "WHERE TAX_CODE IN ("
						+ "SELECT TAX_CODE FROM FMS_TAX_MST "
						+ "WHERE TAX_ALIAS_CODE = ?) AND FACTOR=? GROUP BY TAX_STR_CD HAVING COUNT(*) = 1 ) ";
			if(cform_cd.equals(""))
			{
				queryString+="AND C.INVOICE_NO NOT IN (SELECT INVOICE_NO FROM FMS_CFORM_DTL) ";
			}
			else
			{
				queryString+="AND C.INVOICE_NO IN (SELECT INVOICE_NO FROM FMS_CFORM_DTL WHERE CFORM_CD = ? "
						+ "UNION SELECT INVOICE_NO "
						+ "FROM FMS_FFLOW_INV_MST "
						+ "WHERE INVOICE_NO NOT IN (SELECT INVOICE_NO FROM FMS_CFORM_DTL)) ";
			}
			if(!period_start_dt.equals("") && !period_end_dt.equals("")) 
			{
				queryString+="AND C.INVOICE_DT<=TO_DATE(?,'DD/MM/YYYY') AND C.INVOICE_DT>=TO_DATE(?,'DD/MM/YYYY')";
			}
			stmt=conn.prepareStatement(queryString);
			stmt.setString(++secCnt, comp_cd);
			stmt.setString(++secCnt, counterparty_cd);
			stmt.setString(++secCnt, financial_year);
			stmt.setString(++secCnt, "Y");
			stmt.setString(++secCnt, "CST");
			stmt.setString(++secCnt, "2");
			if(!cform_cd.equals(""))
			{
				stmt.setString(++secCnt, cform_cd);
			}
			if(!period_start_dt.equals("") && !period_end_dt.equals("")) 
			{
				stmt.setString(++secCnt, period_end_dt);
				stmt.setString(++secCnt, period_start_dt);
			}
			stmt.setString(++secCnt, comp_cd);
			stmt.setString(++secCnt, counterparty_cd);
			stmt.setString(++secCnt, financial_year);
			stmt.setString(++secCnt, "Y");
			stmt.setString(++secCnt, "CST");
			stmt.setString(++secCnt, "2");
			if(!cform_cd.equals(""))
			{
				stmt.setString(++secCnt, cform_cd);
			}
			if(!period_start_dt.equals("") && !period_end_dt.equals("")) 
			{
				stmt.setString(++secCnt, period_end_dt);
				stmt.setString(++secCnt, period_start_dt);
			}
			stmt.setString(++secCnt, comp_cd);
			stmt.setString(++secCnt, counterparty_cd);
			stmt.setString(++secCnt, financial_year);
			stmt.setString(++secCnt, "Y");
			stmt.setString(++secCnt, "CST");
			stmt.setString(++secCnt, "2");
			if(!cform_cd.equals(""))
			{
				stmt.setString(++secCnt, cform_cd);
			}
			if(!period_start_dt.equals("") && !period_end_dt.equals("")) 
			{
				stmt.setString(++secCnt, period_end_dt);
				stmt.setString(++secCnt, period_start_dt);
			}
			stmt.setString(++secCnt, comp_cd);
			stmt.setString(++secCnt, counterparty_cd);
			stmt.setString(++secCnt, financial_year);
			stmt.setString(++secCnt, "Y");
			stmt.setString(++secCnt, "CST");
			stmt.setString(++secCnt, "2");
			if(!cform_cd.equals(""))
			{
				stmt.setString(++secCnt, cform_cd);
			}
			if(!period_start_dt.equals("") && !period_end_dt.equals("")) 
			{
				stmt.setString(++secCnt, period_end_dt);
				stmt.setString(++secCnt, period_start_dt);
			}
			rset=stmt.executeQuery();
			while(rset.next())
			{
				String plantSeq=rset.getString(6)==null?"":rset.getString(6);
				String invoice_no=rset.getString(1)==null?"":rset.getString(1);
				
				HashMap<String, String> plant_detail  = null;
				String plantState = "";
				
				if(plantSeq.equals("")) 
				{
					String address_type=rset.getString(7)==null?"":rset.getString(7);
					
					if(!address_type.equals("R") && !address_type.equals("B") && !address_type.equals("C"))
					{
						String addrSeq=address_type.substring(1,address_type.length());
						
						plant_detail  = utilBean.getCounterpartyPlantDetail(conn, comp_cd, "C", counterparty_cd, addrSeq);
						plantState = ""+plant_detail.get("plant_state");
					}
					else if(address_type.equals("R"))
					{
						queryString3="SELECT STATE "
								+ "FROM FMS_COUNTERPARTY_ADDR_MST A "
								+ "WHERE COUNTERPARTY_CD=? AND ADDRESS_TYPE=? "
								+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_COUNTERPARTY_ADDR_MST B WHERE A.COUNTERPARTY_CD=B.COUNTERPARTY_CD "
								+ "AND A.ADDRESS_TYPE=B.ADDRESS_TYPE)";
						stmt3=conn.prepareStatement(queryString3);
						stmt3.setString(1, counterparty_cd);
						stmt3.setString(2, address_type);
						rset3=stmt3.executeQuery();
						while(rset.next())
						{
							String addrState = rset3.getString(1)==null?"":rset3.getString(1);
							
							plantState = utilBean.getStateName(conn, addrState);
						}
						rset3.close();
						stmt3.close();
					}
					else if(address_type.equals("B") || address_type.equals("C"))
					{
						queryString3="SELECT STATE "
								+ "FROM FMS_ENTITY_ADDR_MST A "
								+ "WHERE COUNTERPARTY_CD=? AND COMPANY_CD=? AND ADDRESS_TYPE=? AND ENTITY=? "
								+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_ADDR_MST B WHERE A.COUNTERPARTY_CD=B.COUNTERPARTY_CD "
								+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.ADDRESS_TYPE=B.ADDRESS_TYPE AND A.ENTITY=B.ENTITY)";
						stmt3=conn.prepareStatement(queryString3);
						stmt3.setString(1, counterparty_cd);
						stmt3.setString(2, comp_cd);
						stmt3.setString(3, address_type);
						stmt3.setString(4, "C");
						rset3=stmt3.executeQuery();
						while(rset.next())
						{
							String addrState = rset3.getString(1)==null?"":rset3.getString(1);
							
							plantState = utilBean.getStateName(conn, addrState);
						}
						rset3.close();
						stmt3.close();
					}
				}
				else
				{
					plant_detail  = utilBean.getCounterpartyPlantDetail(conn, comp_cd, "C", counterparty_cd, plantSeq);
					plantState = ""+plant_detail.get("plant_state");
				}
				
				String stateName = utilBean.getStateName(conn, state);
				
				if(plantState.equals(stateName))
				{
					String invoice_dt=rset.getString(2)==null?"":rset.getString(2);
					String commodity=rset.getString(8)==null?"":rset.getString(8);
					String invoice_seq=rset.getString(9)==null?"":rset.getString(9);
					String bu_state=rset.getString(10)==null?"":rset.getString(10);
					double gross_amt=rset.getDouble(3);
					double tax_amt=rset.getDouble(4);
					double invoice_amt=rset.getDouble(5);
					double hold_amt=rset.getDouble(11);
					
					String cformEntryExist = "N";
					
					queryString2="SELECT CFORM_NO,TO_CHAR(CFORM_DT,'DD/MM/YYYY'),"
							+ "TO_CHAR(PERIOD_FROM,'DD/MM/YYYY'),TO_CHAR(PERIOD_TO,'DD/MM/YYYY'),"
							+ "CFORM_AMOUNT,CFORM_FILE "
							+ "FROM FMS_CFORM_MST "
							+ "WHERE COMPANY_CD=? AND CFORM_CD=? ";
					stmt2=conn.prepareStatement(queryString2);
					stmt2.setString(1, comp_cd);
					stmt2.setString(2, cform_cd);
					rset2=stmt2.executeQuery();
					if(rset2.next())
					{
						cform_serial_no=rset2.getString(1)==null?"":rset2.getString(1);
						cform_dt=rset2.getString(2)==null?"":rset2.getString(2);
						period_from=rset2.getString(3)==null?"":rset2.getString(3);
						period_to=rset2.getString(4)==null?"":rset2.getString(4);
						cform_amount=rset2.getString(5)==null?"":rset2.getString(5);
						cform_file=rset2.getString(6)==null?"":rset2.getString(6);
					}
					rset2.close();
					stmt2.close();
					
					queryString1="SELECT INVOICE_AMOUNT,TO_CHAR(INVOICE_DT,'DD/MM/YYYY') "
							+ "FROM FMS_CFORM_DTL "
							+ "WHERE COMPANY_CD=? AND CFORM_CD=? "
							+ "AND INVOICE_NO=? AND INVOICE_DT=TO_DATE(?,'DD/MM/YYYY') ";
					stmt1=conn.prepareStatement(queryString1);
					stmt1.setString(1, comp_cd);
					stmt1.setString(2, cform_cd);
					stmt1.setString(3, invoice_no);
					stmt1.setString(4, invoice_dt);
					rset1=stmt1.executeQuery();
					if(rset1.next())
					{
						cformEntryExist = "Y";
					}
					rset1.close();
					stmt1.close();
					
					noofInvoice++;
					
					VINVOICE_NO.add(invoice_no);
					VINVOICE_DT.add(invoice_dt);
					VGROSS_AMT.add(nf.format(gross_amt));
					VTAX_AMT.add(nf.format(tax_amt));
					VINVOICE_AMT.add(nf.format(invoice_amt));
					VCFORM_ENTRY_EXIST.add(cformEntryExist);
					VINVOICE_COMMODITY.add(commodity);
					VBU_STATE_TIN.add(bu_state);
					VINVOICE_SEQ.add(invoice_seq);
					VINVOICE_HOLD_AMT.add(nf.format(hold_amt));
				}
			}
			rset.close();
			stmt.close();
			
			noOfInvoice = ""+noofInvoice;
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getCustomerList() 
	{
		String function_nm="getCustomerList()";
		try 
		{
			utilBean.getEffectiveEntityCounterpartyList(conn,comp_cd,"C");
			VMST_COUNTERPARTY_CD= utilBean.getCOUNTERPARTY_CD();
			VMST_COUNTERPARTY_NM = utilBean.getCOUNTERPARTY_NM();
			VMST_COUNTERPARTY_ABBR = utilBean.getCOUNTERPARTY_ABBR();
		} 
		catch (Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getStateMst()
	{
		String function_nm="getStateMst()";
		try
		{
			utilBean.getStateMaster(conn);
			VSTATE_CD = utilBean.getTIN();
			VSTATE_NM = utilBean.getSTATE_NM();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getFinancialYearList()
	{
		String function_nm="getFinancialYearList()";

		try
		{	
			int currentYear=utilDate.getCurrentYear();
			
			String sysdate=utilDate.getSysdate();
			String firstDtofFinYr="16/03/"+currentYear;
			
			int count = utilDate.getDays(sysdate, firstDtofFinYr);
			
			for(int i=currentYear;i>=currentYear-5;i--)
			{
				String tmp_dt="01/04/"+i;
				
				VFINANCIAL_YEAR.add(""+utilDate.getFinancialYear(tmp_dt));
			}
			
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getReceivableTracking()
	{
		String function_nm="getReceivableTracking()";
		
		try
		{
			start_dt = "01/"+month+"/"+year;
			end_dt = ""+utilDate.getLastDateOfMonth(month_to, year_to);
			
			queryString="SELECT COMPANY_CD,COUNTERPARTY_CD,AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,CONTRACT_TYPE,FINANCIAL_YEAR, "
					+ "BU_STATE_TIN,INVOICE_SEQ,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),TO_CHAR(PERIOD_START_DT,'DD/MM/YYYY'),"
					+ "TO_CHAR(PERIOD_END_DT,'DD/MM/YYYY'),TO_CHAR(DUE_DT,'DD/MM/YYYY'),SALE_PRICE,SALE_PRICE_UNIT,"
					+ "SALE_AMT,GROSS_AMT,TAX_AMT,TAX_STRUCT_CD,TO_CHAR(TAX_EFF_DT,'DD/MM/YYYY'),INVOICE_AMT,NET_PAYABLE_AMT,"
					+ "TCS_TDS,TCS_AMT,TCS_FACTOR,TDS_GROSS_AMT,TDS_GROSS_PERCENT,TDS_TAX_AMT,TDS_TAX_PERCENT,"
					+ "PAY_RECV_AMT,TO_CHAR(PAY_RECV_DT,'DD/MM/YYYY'),PLANT_SEQ,INVOICE_RAISED_IN,BU_UNIT,HOLD_AMT "
					+ "FROM FMS_DLNG_INVOICE_MST "
					+ "WHERE COMPANY_CD=? "
					+ "AND INVOICE_DT>=TO_DATE(?,'DD/MM/YYYY') AND INVOICE_DT<=TO_DATE(?,'DD/MM/YYYY') "
					+ "AND APPROVED_FLAG=? AND INVOICE_ID_SEQ IS NOT NULL AND INVOICE_AMT IS NOT NULL "
					+ "AND PDF_INV_DTL IS NOT NULL ";
			if(paid_status.equals("F"))
			{
				queryString+= " AND PAY_RECV_AMT IS NOT NULL AND PAY_RECV_DT IS NOT NULL "
						+ "AND ((NVL(NET_PAYABLE_AMT,0)-NVL(TDS_GROSS_AMT,0)-NVL(TDS_TAX_AMT,0)) - NVL(PAY_RECV_AMT,0)) = 0 ";
			}
			else if(paid_status.equals("U"))
			{
				queryString+= " AND PAY_RECV_AMT IS NULL AND PAY_RECV_DT IS NULL ";
			}
			else if(paid_status.equals("P"))
			{
				queryString+= " AND PAY_RECV_AMT IS NOT NULL AND PAY_RECV_DT IS NOT NULL "
						+ "AND ((NVL(NET_PAYABLE_AMT,0)-NVL(TDS_GROSS_AMT,0)-NVL(TDS_TAX_AMT,0)) - NVL(PAY_RECV_AMT,0)) > 0 ";
			}
			queryString+= "ORDER BY INVOICE_DT ";
			stmt = conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, start_dt);
			stmt.setString(3, end_dt);
			stmt.setString(4, "Y");
			rset=stmt.executeQuery();
			while(rset.next())
			{
				String companyCd = rset.getString(1)==null?"":rset.getString(1);
				String countpty_cd = rset.getString(2)==null?"":rset.getString(2);
				String agmt = rset.getString(3)==null?"":rset.getString(3);
				String agmt_rev = rset.getString(4)==null?"":rset.getString(4);
				String cont = rset.getString(5)==null?"":rset.getString(5);
				String cont_rev = rset.getString(6)==null?"":rset.getString(6);
				String cont_type = rset.getString(7)==null?"":rset.getString(7);
				String finan_yr = rset.getString(8)==null?"":rset.getString(8);
				String bu_state_tin = rset.getString(9)==null?"":rset.getString(9);
				String inv_seq = rset.getString(10)==null?"":rset.getString(10);
				String inv_no = rset.getString(11)==null?"":rset.getString(11);
				String inv_dt = rset.getString(12)==null?"":rset.getString(12);
				String period_st_dt = rset.getString(13)==null?"":rset.getString(13);
				String period_end_dt = rset.getString(14)==null?"":rset.getString(14);
				String inv_due_dt = rset.getString(15)==null?"":rset.getString(15);
				double sales_price=rset.getDouble(16);
				String sales_price_cd = rset.getString(17)==null?"":rset.getString(17);
				
				//18
				double gross_amt = rset.getDouble(19);
				double tax_amt = rset.getDouble(20);
				String tax_struct_cd = rset.getString(21)==null?"":rset.getString(21);
				String tax_struct_dt = rset.getString(22)==null?"":rset.getString(22);
				
				double invoice_amt = rset.getDouble(23);
				double net_payable = rset.getDouble(24);
				String tds_tcs_flag = rset.getString(25)==null?"":rset.getString(25);
				double tcs_amt = rset.getDouble(26);
				//27
				String temp_tds_gross_amt = rset.getString(28)==null?"":rset.getString(28);
				double tds_gross_amt = rset.getDouble(28);
				String temp_tds_gross_per = rset.getString(29)==null?"":rset.getString(29);
				double tds_gross_per = rset.getDouble(29);
				String temp_tds_tax_amt = rset.getString(30)==null?"":rset.getString(30);
				double tds_tax_amt = rset.getDouble(30);
				String temp_tds_tax_per = rset.getString(31)==null?"":rset.getString(31);
				double tds_tax_per = rset.getDouble(31);
				
				String temp_pay_recv_amt = rset.getString(32)==null?"":rset.getString(32);
				double pay_recv_amt = rset.getDouble(32);
				String temp_pay_recv_dt = rset.getString(33)==null?"":rset.getString(33);
				
				String plant_seq = rset.getString(34)==null?"":rset.getString(34);
				//35
				String bu_unit=rset.getString(36)==null?"":rset.getString(36);
				double holdAmt=rset.getDouble(37);
				
				if(!temp_tds_gross_amt.equals("")){
					VTDS_GROSS_AMT.add(nf.format(tds_gross_amt));
				}else{
					VTDS_GROSS_AMT.add("");
				}
				
				if(!temp_tds_gross_per.equals("")){
					VTDS_GROSS_PERCENT.add(nf.format(tds_gross_per));
				}else{
					VTDS_GROSS_PERCENT.add("");
				}
				
				if(!temp_tds_tax_amt.equals("")){
					VTDS_TAX_AMT.add(nf.format(tds_tax_amt));
				}else{
					VTDS_TAX_AMT.add("");
				}

				if(!temp_tds_tax_per.equals("")){
					VTDS_TAX_PERCENT.add(nf.format(tds_tax_per));
				}else{
					VTDS_TAX_PERCENT.add("");
				}
				
				if(!temp_pay_recv_amt.equals("")){
					VPAY_RECV_AMT.add(nf.format(pay_recv_amt));
				}else{
					VPAY_RECV_AMT.add("");
				}
				VPAY_RECV_DT.add(temp_pay_recv_dt);
				
				VCOUNTERPARTY_CD.add(countpty_cd);
				VCOUNTERPARTY_NM.add(""+utilBean.getCounterpartyName(conn,countpty_cd));
				VCOUNTERPARTY_ABBR.add(""+utilBean.getCounterpartyABBR(conn,countpty_cd));
				VAGMT_NO.add(agmt);
				VAGMT_REV_NO.add(agmt_rev);
				VCONT_NO.add(cont);
				VCONT_REV_NO.add(cont_rev);
				VCONTRACT_TYPE.add(cont_type);
				VCARGO_NO.add(cargo_no);
				VCONTRACT_TYPE_NM.add(""+utilBean.getContractTypeName(cont_type));
				VFINANCIAL_YEAR.add(finan_yr);
				VBU_STATE_TIN.add(bu_state_tin);
				VINVOICE_SEQ.add(inv_seq);
				VINVOICE_NO.add(inv_no);
				VINVOICE_DT.add(inv_dt);
				VPERIOD_START_DT.add(period_st_dt);
				VPERIOD_END_DT.add(period_end_dt);
				VINVOICE_DUE_DT.add(inv_due_dt);
				VSALES_PRICE.add(""+utilBean.RateNumberFormat(sales_price, sales_price_cd));
				VSALES_PRICE_CD.add(sales_price_cd);
				VSALES_PRICE_NM.add(""+utilBean.getRateUnitNm(conn,sales_price_cd));
				VGROSS_AMT.add(nf.format(gross_amt));
				VTAX_AMT.add(nf.format(tax_amt));
				VINVOICE_AMT.add(nf.format(invoice_amt));
				
				net_payable=net_payable-tds_gross_amt-tds_tax_amt;
				VNET_PAYABLE_AMT.add(nf.format(net_payable));
				
				double short_received = net_payable - pay_recv_amt;
				VSHORT_RECEIVED.add(nf.format(short_received));
				
				String tax_struct_dtl=utilBean.getTaxDescr(conn, tax_struct_cd);
				double tot_Adv_amt=0;
				String advContMapping=companyCd+"-"+countpty_cd+"-"+cont_type+"-"+agmt+"-"+cont;
				if(Double.parseDouble(nf.format(short_received))>0 && !cont_type.equals("W"))
				{
					tot_Adv_amt=utilBean.getAdvanceAmount(conn,companyCd, countpty_cd, agmt, cont, cont_type, "K", utilDate.getSysdate());
					
					if(tot_Adv_amt > 0)
					{
						contWiseAdvAmt.put(advContMapping, nf.format(tot_Adv_amt));
					}
				}
				VCONT_MAP.add(advContMapping);
				VTOTAL_ADV_AMT.add(nf.format(tot_Adv_amt));
				
				if(paid_status.equals("U") && !cont_type.equals("W"))
				{
					int count_hold_release=0;
					queryString3="SELECT COUNT(*) "
							+ "FROM FMS_DLNG_INVOICE_MST A, FMS_CFORM_MST C, FMS_CFORM_DTL D "
							+ "WHERE A.COMPANY_CD=? AND A.COUNTERPARTY_CD=? AND A.CONT_NO=? AND A.AGMT_NO=? AND A.CONTRACT_TYPE=? "
							+ "AND A.INVOICE_NO=? "
							+ "AND C.COMPANY_CD=D.COMPANY_CD AND C.CFORM_CD=D.CFORM_CD AND D.INVOICE_NO=A.INVOICE_NO "
							+ "AND A.COMPANY_CD=C.COMPANY_CD ";
					stmt3 = conn.prepareStatement(queryString3);
					stmt3.setString(1, companyCd);
					stmt3.setString(2, countpty_cd);
					stmt3.setString(3, cont);
					stmt3.setString(4, agmt);
					stmt3.setString(5, cont_type);
					stmt3.setString(6, inv_no);
					rset3=stmt3.executeQuery();
					if(rset3.next())
					{
						count_hold_release=rset3.getInt(1);
					}
					rset3.close();
					stmt3.close();
					
					if(count_hold_release > 0)
					{
						VCFORM_FLAG.add("");
						VHOLD_AMT.add("");
					}
					else
					{
						VCFORM_FLAG.add(holdAmt>0?"Y":"N");
						VHOLD_AMT.add(holdAmt>0?nf.format(holdAmt):"");
					}
				}
				else
				{
					VCFORM_FLAG.add("");
					VHOLD_AMT.add("");
				}
				
				VTDS_TCS_FLAG.add(tds_tcs_flag);
				VTCS_AMT.add(rset.getString(26)==null?"":nf3.format(rset.getDouble(26)));
				VTCS_FACTOR.add(rset.getString(27)==null?"":nf3.format(rset.getDouble(27)));
				
				String dis_cont_mapping=""+utilBean.NewDealMappingId(companyCd, countpty_cd, agmt, agmt_rev, cont, cont_rev, cont_type, cargo_no);

				queryString1="SELECT CONT_REF_NO,TRADE_REF_NO,AGMT_BASE "
						+ "FROM FMS_SUPPLY_CONT_MST A "
						+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE=? "
						+ "AND COUNTERPARTY_CD=? AND AGMT_NO=? AND CONT_NO=? "
						+ "AND CONT_REV=(SELECT MAX(CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_NO=B.AGMT_NO AND A.CONT_NO=B.CONT_NO AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) ";
				stmt1 = conn.prepareStatement(queryString1);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, cont_type);
				stmt1.setString(3, countpty_cd);
				stmt1.setString(4, agmt);
				stmt1.setString(5, cont);
				rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					String cont_ref=rset1.getString(1)==null?"":rset1.getString(1);
					if(cont_type.equals("W"))
					{
						cont_ref=rset1.getString(2)==null?"":rset1.getString(2);
					}
					String agmt_base=rset1.getString(3)==null?"":rset1.getString(3);
					
					if(agmt_base.equals("D"))
					{
						dis_cont_mapping+="<font style='background: #a6ff4d;'>[DLV]</font>";
					}
					if(!cont_ref.equals(""))
					{
						dis_cont_mapping+="<br>["+cont_ref+"]";
					}
				}
				rset1.close();
				stmt1.close();
			
				VDIS_CONT_MAPPING.add(dis_cont_mapping);
				
				VTAX_STRUCT_DTL.add(tax_struct_dtl);
				
				String pay_recv_history="";
				queryString1="SELECT TO_CHAR(PAY_RECV_DT,'DD/MM/YYYY'),PAY_RECV_AMT,ENT_BY "
						+ "FROM FMS_DLNG_INV_PAY_RECV_DTL "
						+ "WHERE COMPANY_CD=? AND INVOICE_SEQ=? "
						+ "AND BU_STATE_TIN=? AND FINANCIAL_YEAR=?";
				stmt3 = conn.prepareStatement(queryString1);
				stmt3.setString(1, comp_cd);
				stmt3.setString(2, inv_seq);
				stmt3.setString(3, bu_state_tin);
				stmt3.setString(4, finan_yr);
				rset3=stmt3.executeQuery();
				while(rset3.next())
				{
					String Paydt=rset3.getString(1)==null?"":rset3.getString(1);
					String PayAmt=rset3.getString(2)==null?"":nf.format(rset3.getDouble(2));
					String empNm=utilBean.getEmpName(conn,rset3.getString(3)==null?"":rset3.getString(3));
					
					if(pay_recv_history.equals(""))
					{
						pay_recv_history=""+PayAmt+"   "+Paydt+"    "+empNm;
					}
					else
					{
						pay_recv_history+="\n"+PayAmt+"   "+Paydt+"    "+empNm;
					}
				}
				VPAY_RECV_HISTORY.add(pay_recv_history);
				rset3.close();
				stmt3.close();
				
				VINVOICE_RAISED_IN.add(""+utilBean.getRateUnitNm(conn,rset.getString(35)==null?"":rset.getString(35)));
				VPAYMENT_DONE_IN.add("INR");
				
				VINVOICE_TYPE.add("");
				VTYPE_FLAG.add("S");
			}
			rset.close();
			stmt.close();
			
			
			//DLNG FFLow when available;
			queryString="SELECT COMPANY_CD,COUNTERPARTY_CD,AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,CONTRACT_TYPE,FINANCIAL_YEAR, "
					+ "BU_STATE_TIN,INVOICE_SEQ,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),TO_CHAR(PERIOD_START_DT,'DD/MM/YYYY'),"
					+ "TO_CHAR(PERIOD_END_DT,'DD/MM/YYYY'),TO_CHAR(DUE_DT,'DD/MM/YYYY'),GROSS_AMT_INR,GROSS_AMT_INR,"
					+ "GROSS_AMT_INR,GROSS_AMT_INR,TAX_AMT,TAX_STRUCT_CD,TO_CHAR(TAX_EFF_DT,'DD/MM/YYYY'),INVOICE_AMT,NET_PAYABLE_AMT,"
					+ "TCS_TDS,TCS_AMT,TCS_FACTOR,TDS_GROSS_AMT,TDS_GROSS_PERCENT,TDS_TAX_AMT,TDS_TAX_PERCENT,"
					+ "PAY_RECV_AMT,TO_CHAR(PAY_RECV_DT,'DD/MM/YYYY'),ADDR_FLAG,INVOICE_RAISED_IN,INVOICE_TYPE,CARGO_NO,HOLD_AMT "
					+ "FROM FMS_DLNG_FFLOW_INV_MST "
					+ "WHERE COMPANY_CD=? "
					+ "AND INVOICE_DT>=TO_DATE(?,'DD/MM/YYYY') AND INVOICE_DT<=TO_DATE(?,'DD/MM/YYYY') "
					+ "AND APPROVED_FLAG=? AND INVOICE_ID_SEQ IS NOT NULL AND INVOICE_AMT IS NOT NULL "
					+ "AND PDF_INV_DTL IS NOT NULL ";
			if(paid_status.equals("F"))
			{
				queryString+= " AND PAY_RECV_AMT IS NOT NULL AND PAY_RECV_DT IS NOT NULL "
						+ "AND ((NVL(NET_PAYABLE_AMT,0)-NVL(TDS_GROSS_AMT,0)-NVL(TDS_TAX_AMT,0)) - NVL(PAY_RECV_AMT,0)) = 0 ";
			}
			else if(paid_status.equals("U"))
			{
				queryString+= " AND PAY_RECV_AMT IS NULL AND PAY_RECV_DT IS NULL ";
			}
			else if(paid_status.equals("P"))
			{
				queryString+= " AND PAY_RECV_AMT IS NOT NULL AND PAY_RECV_DT IS NOT NULL "
						+ "AND ((NVL(NET_PAYABLE_AMT,0)-NVL(TDS_GROSS_AMT,0)-NVL(TDS_TAX_AMT,0)) - NVL(PAY_RECV_AMT,0)) > 0 ";
			}
			queryString+= "ORDER BY INVOICE_DT ";
			stmt1 = conn.prepareStatement(queryString);
			stmt1.setString(1, comp_cd);
			stmt1.setString(2, start_dt);
			stmt1.setString(3, end_dt);
			stmt1.setString(4, "Y");
			rset1=stmt1.executeQuery();
			while(rset1.next())
			{
				String companyCd = rset1.getString(1)==null?"":rset1.getString(1);
				String countpty_cd = rset1.getString(2)==null?"":rset1.getString(2);
				String agmt = rset1.getString(3)==null?"":rset1.getString(3);
				String agmt_rev = rset1.getString(4)==null?"":rset1.getString(4);
				String cont = rset1.getString(5)==null?"":rset1.getString(5);
				String cont_rev = rset1.getString(6)==null?"":rset1.getString(6);
				String cont_type = rset1.getString(7)==null?"":rset1.getString(7);
				String finan_yr = rset1.getString(8)==null?"":rset1.getString(8);
				String bu_state_tin = rset1.getString(9)==null?"":rset1.getString(9);
				String inv_seq = rset1.getString(10)==null?"":rset1.getString(10);
				String inv_no = rset1.getString(11)==null?"":rset1.getString(11);
				String inv_dt = rset1.getString(12)==null?"":rset1.getString(12);
				String period_st_dt = rset1.getString(13)==null?"":rset1.getString(13);
				String period_end_dt = rset1.getString(14)==null?"":rset1.getString(14);
				String inv_due_dt = rset1.getString(15)==null?"":rset1.getString(15);
				double sales_price=0;//rset1.getDouble(16);
				String sales_price_cd ="";// rset1.getString(17)==null?"":rset1.getString(17);
				String cargo_no = rset1.getString(37)==null?"":rset1.getString(37);
				double holdAmt=rset1.getDouble(38);
				
				//18
				double gross_amt = rset1.getDouble(19);
				double tax_amt = rset1.getDouble(20);
				String tax_struct_cd = rset1.getString(21)==null?"":rset1.getString(21);
				String tax_struct_dt = rset1.getString(22)==null?"":rset1.getString(22);
				
				double invoice_amt = rset1.getDouble(23);
				double net_payable = rset1.getDouble(24);
				String tds_tcs_flag = rset1.getString(25)==null?"":rset1.getString(25);
				double tcs_amt = rset1.getDouble(26);
				//27
				String temp_tds_gross_amt = rset1.getString(28)==null?"":rset1.getString(28);
				double tds_gross_amt = rset1.getDouble(28);
				String temp_tds_gross_per = rset1.getString(29)==null?"":rset1.getString(29);
				double tds_gross_per = rset1.getDouble(29);
				String temp_tds_tax_amt = rset1.getString(30)==null?"":rset1.getString(30);
				double tds_tax_amt = rset1.getDouble(30);
				String temp_tds_tax_per = rset1.getString(31)==null?"":rset1.getString(31);
				double tds_tax_per = rset1.getDouble(31);
				
				String temp_pay_recv_amt = rset1.getString(32)==null?"":rset1.getString(32);
				double pay_recv_amt = rset1.getDouble(32);
				String temp_pay_recv_dt = rset1.getString(33)==null?"":rset1.getString(33);
				
				String plant_seq = rset1.getString(34)==null?"":rset1.getString(34);
				
				if(!temp_tds_gross_amt.equals("")){
					VTDS_GROSS_AMT.add(nf.format(tds_gross_amt));
				}else{
					VTDS_GROSS_AMT.add("");
				}
				
				if(!temp_tds_gross_per.equals("")){
					VTDS_GROSS_PERCENT.add(nf.format(tds_gross_per));
				}else{
					VTDS_GROSS_PERCENT.add("");
				}
				
				if(!temp_tds_tax_amt.equals("")){
					VTDS_TAX_AMT.add(nf.format(tds_tax_amt));
				}else{
					VTDS_TAX_AMT.add("");
				}

				if(!temp_tds_tax_per.equals("")){
					VTDS_TAX_PERCENT.add(nf.format(tds_tax_per));
				}else{
					VTDS_TAX_PERCENT.add("");
				}
				
				if(!temp_pay_recv_amt.equals("")){
					VPAY_RECV_AMT.add(nf.format(pay_recv_amt));
				}else{
					VPAY_RECV_AMT.add("");
				}
				VPAY_RECV_DT.add(temp_pay_recv_dt);
				
				VCOUNTERPARTY_CD.add(countpty_cd);
				VCOUNTERPARTY_NM.add(""+utilBean.getCounterpartyName(conn, countpty_cd));
				VCOUNTERPARTY_ABBR.add(""+utilBean.getCounterpartyABBR(conn,countpty_cd));
				VAGMT_NO.add(agmt);
				VAGMT_REV_NO.add(agmt_rev);
				VCONT_NO.add(cont);
				VCONT_REV_NO.add(cont_rev);
				VCARGO_NO.add(cargo_no);
				VCONTRACT_TYPE.add(cont_type);
				VCONTRACT_TYPE_NM.add(""+utilBean.getContractTypeName(cont_type));
				VFINANCIAL_YEAR.add(finan_yr);
				VBU_STATE_TIN.add(bu_state_tin);
				VINVOICE_SEQ.add(inv_seq);
				VINVOICE_NO.add(inv_no);
				VINVOICE_DT.add(inv_dt);
				VPERIOD_START_DT.add(period_st_dt);
				VPERIOD_END_DT.add(period_end_dt);
				VINVOICE_DUE_DT.add(inv_due_dt);
				if(sales_price>0)
				{
					VSALES_PRICE.add(""+utilBean.RateNumberFormat(sales_price, sales_price_cd));
				}
				else
				{
					VSALES_PRICE.add("");
				}
				VSALES_PRICE_CD.add(sales_price_cd);
				VSALES_PRICE_NM.add(""+utilBean.getRateUnitNm(conn,sales_price_cd));
				VGROSS_AMT.add(nf.format(gross_amt));
				if(tax_amt>0)
				{
					VTAX_AMT.add(nf.format(tax_amt));
				}
				else
				{
					VTAX_AMT.add("");
				}
				VINVOICE_AMT.add(nf.format(invoice_amt));
				
				net_payable=net_payable-tds_gross_amt-tds_tax_amt;
				VNET_PAYABLE_AMT.add(nf.format(net_payable));
				
				double short_received = net_payable - pay_recv_amt;
				VSHORT_RECEIVED.add(nf.format(short_received));
				
				String tax_struct_dtl=utilBean.getTaxDescr(conn, tax_struct_cd);
				String advContMapping=companyCd+"-"+countpty_cd+"-"+cont_type+"-"+agmt+"-"+cont;
				VCONT_MAP.add(advContMapping);
				VTOTAL_ADV_AMT.add(nf.format(0));
				
				VTDS_TCS_FLAG.add(tds_tcs_flag);
				if(tcs_amt>0)
				{
					VTCS_AMT.add(nf.format(tcs_amt));
				}
				else
				{
					VTCS_AMT.add("");
				}
				VTCS_FACTOR.add("");
				
				//String dis_cont_mapping=""+utilBean.getDisplayDealMapping(agmt, agmt_rev, cont, cont_rev, cont_type);
				String dis_cont_mapping=""+utilBean.NewDealMappingId(companyCd, countpty_cd, agmt, agmt_rev, cont, cont_rev, cont_type,cargo_no);
				if(cont_type.equals("O") || cont_type.equals("Q"))
				{
					queryString1="SELECT A.CONT_REF_NO "
							+ "FROM FMS_LTCORA_CONT_MST A,"
								+ "FMS_LTCORA_CONT_CARGO_DTL B "
							+ "WHERE A.COMPANY_CD=? AND A.COUNTERPARTY_CD=? AND A.BUY_SALE=? "
							+ "AND A.AGMT_NO=? AND A.AGMT_REV=? AND A.AGMT_TYPE=? AND A.CONT_NO=? AND A.CONTRACT_TYPE=? AND B.CARGO_NO=? "
							+ "AND A.CONT_REV = (SELECT MAX(B.CONT_REV) FROM FMS_LTCORA_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
							+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
							+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE AND A.BUY_SALE=B.BUY_SALE AND A.AGMT_TYPE=B.AGMT_TYPE) "
							+ ""
							+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO "
							+ "AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV AND A.CONTRACT_TYPE=B.CONTRACT_TYPE AND A.BUY_SALE=B.BUY_SALE AND A.AGMT_TYPE=B.AGMT_TYPE ";
					stmt2=conn.prepareStatement(queryString1);
					stmt2.setString(1, companyCd);
					stmt2.setString(2, countpty_cd);
					stmt2.setString(3, "C");
					stmt2.setString(4, agmt);
					stmt2.setString(5, agmt_rev);
					stmt2.setString(6, "A");
					stmt2.setString(7, cont);
					stmt2.setString(8, cont_type);
					stmt2.setString(9, cargo_no);
					rset2=stmt2.executeQuery();
					if(rset2.next())
					{
						String cont_ref=rset2.getString(1)==null?"":rset2.getString(1);
						if(!cont_ref.equals(""))
						{
							dis_cont_mapping+="<br>["+cont_ref+"]";
						}
						
					}
					rset2.close();
					stmt2.close();
					
					VCFORM_FLAG.add("");
					VHOLD_AMT.add("");
				}
				else
				{	
					queryString1="SELECT CONT_REF_NO,TRADE_REF_NO,AGMT_BASE "
							+ "FROM FMS_SUPPLY_CONT_MST A "
							+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE=? "
							+ "AND COUNTERPARTY_CD=? AND AGMT_NO=? AND CONT_NO=? "
							+ "AND CONT_REV=(SELECT MAX(CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
							+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_NO=B.AGMT_NO AND A.CONT_NO=B.CONT_NO AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) ";
					stmt2 = conn.prepareStatement(queryString1);
					stmt2.setString(1, comp_cd);
					stmt2.setString(2, cont_type);
					stmt2.setString(3, countpty_cd);
					stmt2.setString(4, agmt);
					stmt2.setString(5, cont);
					rset2=stmt2.executeQuery();
					if(rset2.next())
					{
						String cont_ref=rset2.getString(1)==null?"":rset2.getString(1);
						if(cont_type.equals("W"))
						{
							cont_ref=rset2.getString(2)==null?"":rset2.getString(2);
						}
						String agmt_base=rset2.getString(3)==null?"":rset2.getString(3);
						
						if(agmt_base.equals("D"))
						{
							dis_cont_mapping+="<font style='background: #a6ff4d;'>[DLV]</font>";
						}
						if(!cont_ref.equals(""))
						{
							dis_cont_mapping+="<br>["+cont_ref+"]";
						}
					}
					rset2.close();
					stmt2.close();
					
					if(paid_status.equals("U") && !cont_type.equals("W"))
					{
						int count_hold_release=0;
						queryString3="SELECT COUNT(*) "
								+ "FROM FMS_DLNG_INVOICE_MST A, FMS_CFORM_MST C, FMS_CFORM_DTL D "
								+ "WHERE A.COMPANY_CD=? AND A.COUNTERPARTY_CD=? AND A.CONT_NO=? AND A.AGMT_NO=? AND A.CONTRACT_TYPE=? "
								+ "AND A.INVOICE_NO=? "
								+ "AND C.COMPANY_CD=D.COMPANY_CD AND C.CFORM_CD=D.CFORM_CD AND D.INVOICE_NO=A.INVOICE_NO "
								+ "AND A.COMPANY_CD=C.COMPANY_CD ";
						stmt3 = conn.prepareStatement(queryString3);
						stmt3.setString(1, companyCd);
						stmt3.setString(2, countpty_cd);
						stmt3.setString(3, cont);
						stmt3.setString(4, agmt);
						stmt3.setString(5, cont_type);
						stmt3.setString(6, inv_no);
						rset3=stmt3.executeQuery();
						if(rset3.next())
						{
							count_hold_release=rset3.getInt(1);
						}
						rset3.close();
						stmt3.close();
						
						if(count_hold_release > 0)
						{
							VCFORM_FLAG.add("");
							VHOLD_AMT.add("");
						}
						else
						{
							VCFORM_FLAG.add(holdAmt>0?"Y":"N");
							VHOLD_AMT.add(holdAmt>0?nf.format(holdAmt):"");
						}
					}
					else
					{
						VCFORM_FLAG.add("");
						VHOLD_AMT.add("");
					}
				}
				VDIS_CONT_MAPPING.add(dis_cont_mapping);
				VTAX_STRUCT_DTL.add(utilBean.getTaxDescr(conn, tax_struct_cd));	
					
				String inv_type=rset1.getString(36)==null?"":rset1.getString(36);
				String pay_recv_history="";
				queryString1="SELECT TO_CHAR(PAY_RECV_DT,'DD/MM/YYYY'),PAY_RECV_AMT,ENT_BY "
						+ "FROM FMS_DLNG_FFLOW_PAY_RECV_DTL "
						+ "WHERE COMPANY_CD=? AND INVOICE_SEQ=? "
						+ "AND BU_STATE_TIN=? AND FINANCIAL_YEAR=? AND INVOICE_TYPE=?";
				stmt3 = conn.prepareStatement(queryString1);
				stmt3.setString(1, comp_cd);
				stmt3.setString(2, inv_seq);
				stmt3.setString(3, bu_state_tin);
				stmt3.setString(4, finan_yr);
				stmt3.setString(5, inv_type);
				rset3=stmt3.executeQuery();
				while(rset3.next())
				{
					String Paydt=rset3.getString(1)==null?"":rset3.getString(1);
					String PayAmt=rset3.getString(2)==null?"":nf.format(rset3.getDouble(2));
					String empNm=utilBean.getEmpName(conn,rset3.getString(3)==null?"":rset3.getString(3));
					
					if(pay_recv_history.equals(""))
					{
						pay_recv_history=""+PayAmt+"   "+Paydt+"    "+empNm;
					}
					else
					{
						pay_recv_history+="\n"+PayAmt+"   "+Paydt+"    "+empNm;
					}
				}
				VPAY_RECV_HISTORY.add(pay_recv_history);
				rset3.close();
				stmt3.close();
				
				VINVOICE_RAISED_IN.add(""+utilBean.getRateUnitNm(conn,rset1.getString(35)==null?"":rset1.getString(35)));
				VPAYMENT_DONE_IN.add("INR");
				
				VINVOICE_TYPE.add(inv_type);
				VTYPE_FLAG.add("FF");
			}
			rset1.close();;
			stmt1.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getFilterContractList()
	{
		String function_nm="getFilterContractList()";
		try
		{
			VFILTER_CONT_TYPE.add("F");
			VFILTER_CONT_NAME.add(utilBean.getContractTypeName("F"));
			
			VFILTER_CONT_TYPE.add("E");
			VFILTER_CONT_NAME.add(utilBean.getContractTypeName("E"));
			
			VFILTER_CONT_TYPE.add("W");
			VFILTER_CONT_NAME.add(utilBean.getContractTypeName("W"));

			VFILTER_CONT_TYPE.add("O");
			VFILTER_CONT_NAME.add(utilBean.getContractTypeName("O"));

			VFILTER_CONT_TYPE.add("Q");
			VFILTER_CONT_NAME.add(utilBean.getContractTypeName("Q"));
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getCustomerCounterpartyList()
	{
		String function_nm="getCustomerCounterpartyList()";
		try
		{
			//utilBean.getEffectiveCustomerCounterpartyList(comp_cd);
			utilBean.getEffectiveEntityCounterpartyList(conn,comp_cd,"C");
			VCOUNTERPARTY_CD= utilBean.getCOUNTERPARTY_CD();
			VCOUNTERPARTY_NM = utilBean.getCOUNTERPARTY_NM();
			VCOUNTERPARTY_ABBR = utilBean.getCOUNTERPARTY_ABBR();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getContractList()
	{
		String function_nm="getContractList()";
		try
		{
			VMAPPING_ID.clear();
			
			queryString="SELECT COMPANY_CD,COUNTERPARTY_CD,AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,"
					+ "TO_CHAR(START_DT,'DD/MM/YYYY'),TO_CHAR(END_DT,'DD/MM/YYYY'),CONT_NAME,CONT_REF_NO,CONTRACT_TYPE,"
					+ "TRADE_REF_NO,NULL "
					+ "FROM FMS_SUPPLY_CONT_MST A "
					+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE IN ('F','E','W') "
					+ "AND START_DT<=TO_DATE(?,'DD/MM/YYYY') AND END_DT>=TO_DATE(?,'DD/MM/YYYY') "
					+ "AND COUNTERPARTY_CD=? "
					+ "AND CONT_REV = (SELECT MAX(B.CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
					+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) ";
			if(!filter_cont_type.equals("")) {
				queryString+="AND CONTRACT_TYPE=? ";
			}
			queryString+= " UNION ";
			queryString+="SELECT A.COMPANY_CD,A.COUNTERPARTY_CD,A.AGMT_NO,A.AGMT_REV,A.CONT_NO,A.CONT_REV,"
					+ "TO_CHAR(B.ACTUAL_RECPT_DT,'DD/MM/YYYY'),TO_CHAR(TO_DATE(B.ACTUAL_RECPT_DT,'DD/MM/YY')+NVL(STORAGE_DAYS-1,0)+NVL(STORAGE_EXT_DAYS,0),'DD/MM/YYYY'),"
					+ "A.CONT_NAME,B.CARGO_REF,A.CONTRACT_TYPE,NULL,B.CARGO_NO "
					+ "FROM FMS_LTCORA_CONT_MST A,"
						+ "FMS_LTCORA_CONT_CARGO_DTL B "
					+ "WHERE A.COMPANY_CD=? AND A.COUNTERPARTY_CD=? AND A.BUY_SALE=? AND B.CARGO_STATUS=? AND A.AGMT_TYPE=? "
					+ "AND TO_DATE(TO_CHAR(B.ACTUAL_RECPT_DT,'DD/MM/YYYY'),'DD/MM/YYYY')<=TO_DATE(?,'DD/MM/YYYY') AND TO_DATE(TO_CHAR(B.ACTUAL_RECPT_DT,'DD/MM/YYYY'),'DD/MM/YYYY')+NVL(STORAGE_DAYS-1,0)+NVL(STORAGE_EXT_DAYS,0) >=TO_DATE(?,'DD/MM/YYYY') "
					+ "AND TLU_FLAG=? "
					+ "AND A.CONT_REV = (SELECT MAX(B.CONT_REV) FROM FMS_LTCORA_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
					+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE AND A.BUY_SALE=B.BUY_SALE AND A.AGMT_TYPE=B.AGMT_TYPE) "
					+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO "
					+ "AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV AND A.CONTRACT_TYPE=B.CONTRACT_TYPE AND A.BUY_SALE=B.BUY_SALE AND A.AGMT_TYPE=B.AGMT_TYPE ";
			if(!filter_cont_type.equals("")) {
				queryString+="AND A.CONTRACT_TYPE=? ";
			}
			int cnt=0;
			stmt=conn.prepareStatement(queryString);
			stmt.setString(++cnt, comp_cd);
			stmt.setString(++cnt, period_end_dt);
			stmt.setString(++cnt, period_start_dt);
			stmt.setString(++cnt, counterparty_cd);
			if(!filter_cont_type.equals("")) {
				stmt.setString(++cnt, filter_cont_type);
			}
			stmt.setString(++cnt, comp_cd);
			stmt.setString(++cnt, counterparty_cd);
			stmt.setString(++cnt, "C");
			stmt.setString(++cnt, "Y");
			stmt.setString(++cnt, "A");
			stmt.setString(++cnt, period_end_dt);
			stmt.setString(++cnt, period_start_dt);
			stmt.setString(++cnt, "Y");
			if(!filter_cont_type.equals("")) {
				stmt.setString(++cnt, filter_cont_type);
			}
			rset=stmt.executeQuery();
			while(rset.next())
			{
				String own_cd=rset.getString(1)==null?"":rset.getString(1);
				String countpty_cd=rset.getString(2)==null?"":rset.getString(2);
				String agmtno=rset.getString(3)==null?"0":rset.getString(3);
				String agmtrev=rset.getString(4)==null?"0":rset.getString(4);
				String contno=rset.getString(5)==null?"0":rset.getString(5);
				String contrev=rset.getString(6)==null?"0":rset.getString(6);
				String cont_st_dt=rset.getString(7)==null?"":rset.getString(7);
				String cont_end_dt=rset.getString(8)==null?"":rset.getString(8);
				String cont_ref=rset.getString(10)==null?"":rset.getString(10);
				String cont_type=rset.getString(11)==null?"":rset.getString(11);
				String trade_ref=rset.getString(12)==null?"":rset.getString(12);
				String cargono=rset.getString(13)==null?"":rset.getString(13);
				
				if(cont_type.equals("W"))
				{
					cont_ref=trade_ref;
				}
				
				String deal_no = utilBean.NewDealMappingId(own_cd, countpty_cd, agmtno, agmtrev, contno, contrev, cont_type, cargono);
				if(!cont_ref.equals(""))
				{
					deal_no+=" ["+cont_ref+"]";
				}
				deal_no+=" ["+cont_st_dt+"-"+cont_end_dt+"]";

				String mapping_id=cont_type+"-"+agmtno+"-"+agmtrev+"-"+contno+"-"+contrev;
				if(cont_type.equals("O") || cont_type.equals("Q")) {
					mapping_id+="-"+cargono;
				}

				VDEAL_NO.add(deal_no);
				VMAPPING_ID.add(mapping_id);
			}
			rset.close();
			stmt.close();
			
			if(!contract_type.equals(""))
			{
				queryString="SELECT COMPANY_CD,COUNTERPARTY_CD,AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,"
						+ "TO_CHAR(START_DT,'DD/MM/YYYY'),TO_CHAR(END_DT,'DD/MM/YYYY'),CONT_NAME,CONT_REF_NO,CONTRACT_TYPE,"
						+ "TRADE_REF_NO,NULL "
						+ "FROM FMS_SUPPLY_CONT_MST A "
						+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE=? "
						+ "AND CONT_NO=? AND AGMT_NO=? AND COUNTERPARTY_CD=? "
						+ "AND CONT_REV = (SELECT MAX(B.CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
						+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) ";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, contract_type);
				stmt.setString(3, cont_no);
				stmt.setString(4, agmt_no);
				stmt.setString(5, counterparty_cd);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					String own_cd=rset.getString(1)==null?"":rset.getString(1);
					String countpty_cd=rset.getString(2)==null?"":rset.getString(2);
					String agmtno=rset.getString(3)==null?"0":rset.getString(3);
					String agmtrev=rset.getString(4)==null?"0":rset.getString(4);
					String contno=rset.getString(5)==null?"0":rset.getString(5);
					String contrev=rset.getString(6)==null?"0":rset.getString(6);
					String cont_st_dt=rset.getString(7)==null?"":rset.getString(7);
					String cont_end_dt=rset.getString(8)==null?"":rset.getString(8);
					String cont_ref=rset.getString(10)==null?"":rset.getString(10);
					String cont_type=rset.getString(11)==null?"":rset.getString(11);
					String trade_ref=rset.getString(12)==null?"":rset.getString(12);
					String cargono=rset.getString(13)==null?"":rset.getString(13);
					
					if(cont_type.equals("W"))
					{
						cont_ref=trade_ref;
					}
					
					contRef=cont_ref;
					
					String deal_no = utilBean.NewDealMappingId(own_cd, countpty_cd, agmtno, agmtrev, contno, contrev, cont_type, cargono);
					if(!cont_ref.equals(""))
					{
						deal_no+=" ["+cont_ref+"]";
					}
					deal_no+=" ["+cont_st_dt+"-"+cont_end_dt+"]";

					String mapping_id=cont_type+"-"+agmtno+"-"+agmtrev+"-"+contno+"-"+contrev;

					if(!VMAPPING_ID.contains(mapping_id))
					{
						VDEAL_NO.add(deal_no);
						VMAPPING_ID.add(mapping_id);
					}
				}
				rset.close();
				stmt.close();
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	

	public void getPlantDetail()
	{
		String function_nm="getPlantDetail()";
		try
		{
			utilBean.getEffectiveCounterpartyPlantList(conn,counterparty_cd, "C", comp_cd);
			VPLANT_SEQ = utilBean.getPLANT_SEQ_NO();
			VPLANT_ABBR = utilBean.getPLANT_ABBR();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getAddressType()
	{
		String function_nm="getAddressType()";
		try
		{
			queryString="SELECT DISTINCT ADDRESS_TYPE "
					+ "FROM FMS_COUNTERPARTY_ADDR_MST A "
					+ "WHERE COUNTERPARTY_CD=? ";
			queryString+="UNION ";
			queryString+="SELECT DISTINCT ADDRESS_TYPE "
					+ "FROM FMS_ENTITY_ADDR_MST A "
					+ "WHERE COUNTERPARTY_CD=? AND COMPANY_CD=? ";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, counterparty_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, comp_cd);
			rset=stmt.executeQuery();
			while(rset.next())
			{
				String add_type = rset.getString(1)==null?"":rset.getString(1);
				if(add_type.equals("R"))
				{
					VADDRESS_TYPE.add(add_type);
					VADDRESS_NAME.add("Registered");
				}
				else if(add_type.equals("C"))
				{
					VADDRESS_TYPE.add(add_type);
					VADDRESS_NAME.add("Correspondence");
				}
				else if(add_type.equals("B"))
				{
					VADDRESS_TYPE.add(add_type);
					VADDRESS_NAME.add("Billing");
				}
			}
			rset.close();
			stmt.close();

			for(int i=0; i<VPLANT_SEQ.size(); i++)
			{
				VADDRESS_TYPE.add("P"+VPLANT_SEQ.elementAt(i));
				VADDRESS_NAME.add(VPLANT_ABBR.elementAt(i));
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getOtherInvoiceContactPerson()
	{
		String function_nm="getOtherInvoiceContactPerson()";
		try
		{
			queryString="SELECT CONTACT_PERSON, SEQ_NO "
					+ "FROM FMS_ENTITY_CONTACT_MST A "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND ENTITY=? AND ADDR_FLAG=? AND INV_FLAG=? "
					+ "AND ACTIVE_FLAG=? AND ADDR_IS_ACTIVE=? AND TYPE=? "
					+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO AND A.TYPE=B.TYPE "
					+ "AND EFF_DT <= TO_DATE(TO_CHAR(SYSDATE,'DD/MM/YYYY'),'DD/MM/YYYY'))";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, "C");
			stmt.setString(4, address_type);
			stmt.setString(5, "Y");
			stmt.setString(6, "Y");
			stmt.setString(7, "Y");
			stmt.setString(8, "DLNG");
			rset=stmt.executeQuery();
			while(rset.next())
			{
				VCONTACT_PERSON.add(rset.getString(1)==null?"":rset.getString(1));
				VCONTACT_PERSON_CD.add(rset.getString(2)==null?"":rset.getString(2));
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getBuUnit()
	{
		String function_nm="getBuUnit()";
		try
		{
			queryString="SELECT COMPANY_CD,PLANT_SEQ_NO "
					+ "FROM FMS_SUPPLY_CONT_BU "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? AND CONT_NO=? "
					+ "AND CONT_REV=? AND AGMT_NO=? AND AGMT_REV=? "
					+ "AND CONTRACT_TYPE=? ";
			queryString+="UNION ";
			queryString+="SELECT COMPANY_CD,PLANT_SEQ_NO "
					+ "FROM FMS_LTCORA_CONT_BU "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND BUY_SALE=? AND AGMT_TYPE=? AND CONT_NO=? "
					+ "AND CONT_REV=? AND AGMT_NO=? AND AGMT_REV=? "
					+ "AND CONTRACT_TYPE=? ";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, cont_no);
			stmt.setString(4, cont_rev_no);
			stmt.setString(5, agmt_no);
			stmt.setString(6, agmt_rev_no);
			stmt.setString(7, contract_type);
			stmt.setString(8, comp_cd);
			stmt.setString(9, counterparty_cd);
			stmt.setString(10, "C");
			stmt.setString(11, "A");
			stmt.setString(12, cont_no);
			stmt.setString(13, cont_rev_no);
			stmt.setString(14, agmt_no);
			stmt.setString(15, agmt_rev_no);
			stmt.setString(16, contract_type);
			rset=stmt.executeQuery();
			while(rset.next())
			{
				String buCd = rset.getString(1)==null?"":rset.getString(1);
				String bu_plant_seq = rset.getString(2)==null?"":rset.getString(2);
				String bu_plant_abbr=utilBean.getCounterpartyPlantABBR(conn,buCd, comp_cd, bu_plant_seq, "B");

				VSEL_BU_CD.add(buCd);
				VSEL_BU_PLANT_SEQ_NO.add(bu_plant_seq);
				VSEL_BU_PLANT_ABBR.add(bu_plant_abbr);
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getSacCodeDtl()
	{
		String function_nm="getSacCodeDtl()";
		try
		{
			queryString = "SELECT SAC_CD,SAC_CODE,SAC_DESC,REMARKS,SAC_FLAG "
					+ "FROM FMS_SAC_MST "
					+ "WHERE SAC_FLAG=? ";
			stmt = conn.prepareStatement(queryString);
			stmt.setString(1, "Y");
			rset = stmt.executeQuery();
			while(rset.next())
			{
				 String sac_cd = rset.getString(1)==null?"":rset.getString(1);
				 String sac_code = rset.getString(2)==null?"":rset.getString(2);
				 
				 VMST_SAC_CD.add(sac_cd);
				 VMST_SAC_CODE.add(sac_code);
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getF_FlowInvoice()
	{
		String function_nm="getF_FlowInvoice()";
		try
		{
			String temp_contact_person_cd=utilBean.getEntityContactPersonCd(conn,comp_cd,counterparty_cd,"C",address_type, "INV", "DLNG","Y");
			contact_person_cd=temp_contact_person_cd.equals("")?"0":temp_contact_person_cd;
			
			String temp_bu_contact_person_cd=utilBean.getEntityContactPersonCd(conn,comp_cd,comp_cd,"B","P"+bu_unit, "INV", "DLNG","Y");
			bu_contact_person_cd=temp_bu_contact_person_cd.equals("")?"0":temp_bu_contact_person_cd;
			
			String state_code=utilBean.getState_TIN(conn, comp_cd, comp_cd, "B", bu_unit);
			bu_state_tin=state_code;

			sac_no = "0";
			
			String bank_formula="";
			queryString2="SELECT COUNTERPARTY_CD,ENTITY,TO_CHAR(EFF_DT,'DD/MM/YYYY'),BANK_NAME,ACCOUNT_ID,IFSC_CODE,BRANCH_NAME,"
					+ "STATE_NM  "
					+ "FROM FMS_ENTITY_BANK_MST A "
					+ "WHERE ENTITY=? AND COUNTERPARTY_CD=? AND COMPANY_CD=? AND CATEGORY=? "
					+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_BANK_MST B WHERE A.COUNTERPARTY_CD=B.COUNTERPARTY_CD "
					+ "AND A.ENTITY=B.ENTITY AND A.COMPANY_CD=B.COMPANY_CD AND B.EFF_DT<=TO_DATE(TO_CHAR(SYSDATE,'DD/MM/YYYY'),'DD/MM/YYYY') AND A.CATEGORY=B.CATEGORY)";
			stmt2=conn.prepareStatement(queryString2);
			stmt2.setString(1, "B");
			stmt2.setString(2, comp_cd);
			stmt2.setString(3, comp_cd);
			stmt2.setString(4, "DLNG");
			rset2=stmt2.executeQuery();
			if(rset2.next())
			{
				String bank_eff_dt = rset2.getString(3)==null?"":rset2.getString(3);
				String bank_name=rset2.getString(4)==null?"":rset2.getString(4);
				String bank_account_no=rset2.getString(5)==null?"":rset2.getString(5);
				String ifsc_code=rset2.getString(6)==null?"":rset2.getString(6);
				String bank_branch=rset2.getString(7)==null?"":rset2.getString(7);
				String bank_state=rset2.getString(8)==null?"":rset2.getString(8);
				
				bank_formula=bank_name+", "+bank_branch+", "+bank_state+", A/C No : "+bank_account_no+", IFSC Code : "+ifsc_code;
			}
			rset2.close();
			stmt2.close();
			
			if(invoice_type.equals("CR")) //As per vijay's feedback - 'Credit Note bank detail printing not required.'
			{
				note ="";
			}
			else
			{
				note ="Please pay the invoiced amount by wire transfer at our Bank Account : "+bank_formula;
			}

			VLINE_NO.add("1");
			VLINE_DESC.add("");
			VUNIT.add("");
			VQTY.add("");
			VRATE.add("");
			VAMOUNT.add("");
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getExixtingF_FLowInvoice()
	{
		String function_nm="getExixtingF_FLowInvoice()";
		try
		{
			queryString="SELECT INVOICE_SEQ, INVOICE_NO, INVOICE_NO, TO_CHAR(INVOICE_DT,'DD/MM/YYYY'), TO_CHAR(DUE_DT,'DD/MM/YYYY'),"
					+ "INVOICE_CATEGORY, INVOICE_TYPE, "
					+ "FINANCIAL_YEAR, NUM_LINE, LINKED_INVOICE, NOTE, "
					+ "CONTACT_PERSON_CD,BU_CONTACT_PERSON_CD, "
					+ "CHECKED_FLAG, CHECKED_BY, TO_CHAR(CHECKED_DT,'DD/MM/YYYY HH24:MI:SS'), "
					+ "APPROVED_FLAG, APPROVED_BY, TO_CHAR(APPROVED_DT,'DD/MM/YYYY HH24:MI:SS'),"
					+ "OTHER_INV_STR,GROSS_AMT_USD,EXCHG_RATE_VALUE,GROSS_AMT_INR,TAX_AMT,INVOICE_AMT,ADJUST_AMT,NET_PAYABLE_AMT,"
					+ "INVOICE_RAISED_IN,AMT_WORD,TAX_STRUCT_CD,TO_CHAR(TAX_EFF_DT,'DD/MM/YYYY'),"
					+ "TDS_GROSS_AMT,TDS_STRUCT_CD,TO_CHAR(TDS_EFF_DT,'DD/MM/YYYY'),"
					+ "TCS_AMT,TCS_STRUCT_CD,TO_CHAR(TCS_EFF_DT,'DD/MM/YYYY'),"
					+ "TCS_TDS,ALLOC_QTY,SUB_INV_TYPE,SAC_CD "
					+ "FROM FMS_DLNG_FFLOW_INV_MST "
					+ "WHERE COMPANY_CD=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
					+ "AND FINANCIAL_YEAR=? AND INVOICE_TYPE=?";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, inv_seq);
			stmt.setString(3, bu_state_tin);
			stmt.setString(4, financial);
			stmt.setString(5, invoice_type);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				submission_chk=true;

				invoice_seq=rset.getString(1)==null?"":rset.getString(1);
				invoice_no=rset.getString(2)==null?"":rset.getString(2);
				//invoice_ref=rset.getString(3)==null?"":rset.getString(3);
				invoice_dt=rset.getString(4)==null?"":rset.getString(4);
				invoice_due_dt=rset.getString(5)==null?"":rset.getString(5);
				invoice_category=rset.getString(6)==null?"":rset.getString(6);
				invoice_type=rset.getString(7)==null?"":rset.getString(7);
				financial_year=rset.getString(8)==null?"":rset.getString(8);
				num_line=rset.getString(9)==null?"":rset.getString(9);
				linked_invoice=rset.getString(10)==null?"":rset.getString(10);
				note=rset.getString(11)==null?"":rset.getString(11);
				contact_person_cd=rset.getString(12)==null?"0":rset.getString(12);
				bu_contact_person_cd=rset.getString(13)==null?"0":rset.getString(13);

				invoice_check_flag=rset.getString(14)==null?"":rset.getString(14);
				String chk_by=rset.getString(15)==null?"":rset.getString(15);
				invoice_check_by=utilBean.getEmpName(conn,chk_by);
				invoice_check_dt=rset.getString(16)==null?"":rset.getString(16);
				if(invoice_check_flag.equals("Y"))
				{
					invoice_check_nm="Checked";
				}
				else if(invoice_check_flag.equals("N"))
				{
					invoice_check_nm="Rejected";
				}
				invoice_aprv_flag=rset.getString(17)==null?"":rset.getString(17);
				String aprv_by=rset.getString(18)==null?"":rset.getString(18);
				invoice_aprv_by=utilBean.getEmpName(conn,aprv_by);
				invoice_aprv_dt=rset.getString(19)==null?"":rset.getString(19);
				if(invoice_aprv_flag.equals("A"))
				{
					invoice_aprv_nm="Approved";
				}
				else if(invoice_aprv_flag.equals("R"))
				{
					invoice_aprv_nm="Rejected";
				}

				other_inv_str =rset.getString(20)==null?"":rset.getString(20);

				gross_amt =rset.getString(21)==null?"":rset.getString(21);
				exchang_rate =rset.getString(22)==null?"":rset.getString(22);
				gross_amt1 =rset.getString(23)==null?"":rset.getString(23);
				tax_amt =rset.getString(24)==null?"":rset.getString(24);
				invoice_amt =rset.getString(25)==null?"":rset.getString(25);
				invoice_adj_amt =rset.getString(26)==null?"":rset.getString(26);
				net_payable =rset.getString(27)==null?"":rset.getString(27);
				invoice_raised_in =rset.getString(28)==null?"":rset.getString(28);
				amount_in_word =rset.getString(29)==null?"":rset.getString(29);
				tax_struct_cd =rset.getString(30)==null?"":rset.getString(30);
				tax_struct_dt =rset.getString(31)==null?"":rset.getString(31);
				
				tds_amt =rset.getString(32)==null?"":nf.format(rset.getDouble(32));
				tds_struct_cd =rset.getString(33)==null?"":rset.getString(33);
				tds_struct_dt =rset.getString(34)==null?"":rset.getString(34);
				
				applicable_amt =rset.getString(35)==null?"":nf.format(rset.getDouble(35));
				tcs_struct_cd =rset.getString(36)==null?"":rset.getString(36);
				tcs_struct_dt =rset.getString(37)==null?"":rset.getString(37);
				
				applicable_abbr =rset.getString(38)==null?"":rset.getString(38);
				qty_mmbtu =rset.getString(39)==null?"":nf.format(rset.getDouble(39));
				sub_inv_type =rset.getString(40)==null?"":rset.getString(40);
				
				sac_no = rset.getString(41)==null?"0":rset.getString(41);
				
				tax_struct_info=utilBean.getTaxDescr(conn,tax_struct_cd);
				tcs_struct_info=utilBean.getTaxDescr(conn,tcs_struct_cd);
				tds_struct_info=utilBean.getTaxDescr(conn,tds_struct_cd);
				
				Vector VTAX_CODE = new Vector();
				Vector VTAX_DESCR = new Vector();
				Vector VTAX_AMT = new Vector();
				Vector VTAX_BASE_AMT = new Vector();
				queryString4="SELECT TAX_CODE,TAX_DESCR,TAX_AMT,TAX_BASE_AMT "
						+ "FROM FMS_DLNG_FFLOW_INV_TAX_DTL "
						+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
						+ "AND INVOICE_TYPE=? "
						+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? ";
				stmt4=conn.prepareStatement(queryString4);
				stmt4.setString(1, comp_cd);
				stmt4.setString(2, bu_state_tin);
				stmt4.setString(3, invoice_type);
				stmt4.setString(4, financial_year);
				stmt4.setString(5, invoice_seq);
				rset4=stmt4.executeQuery();
				while(rset4.next())
				{
					VTAX_CODE.add(rset4.getString(1)==null?"":rset4.getString(1));
					VTAX_DESCR.add(rset4.getString(2)==null?"":rset4.getString(2));
					VTAX_AMT.add(rset4.getString(3)==null?"":nf.format(rset4.getDouble(3)));
					VTAX_BASE_AMT.add(rset4.getString(4)==null?"":nf.format(rset4.getDouble(4)));
				}
				rset4.close();
				stmt4.close();
				
				Vector VTEMP_TAX_DTL = new Vector();
				
				VTEMP_TAX_DTL.add(VTAX_CODE);
				VTEMP_TAX_DTL.add(VTAX_DESCR);
				VTEMP_TAX_DTL.add(VTAX_AMT);
				VTEMP_TAX_DTL.add(VTAX_BASE_AMT);
				
				VMULTI_TAX_STRUCT.add(VTEMP_TAX_DTL);
			}
			rset.close();
			stmt.close();


			queryString1="SELECT LINE_NO,LINE_DESC,UNIT,QTY,RATE,AMOUNT "
					+ "FROM FMS_DLNG_FFLOW_INV_DTL "
					+ "WHERE COMPANY_CD=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
					+ "AND FINANCIAL_YEAR=? AND INVOICE_TYPE=?";
			stmt1=conn.prepareStatement(queryString1);
			stmt1.setString(1, comp_cd);
			stmt1.setString(2, inv_seq);
			stmt1.setString(3, bu_state_tin);
			stmt1.setString(4, financial);
			stmt1.setString(5, invoice_type);
			rset1=stmt1.executeQuery();
			while(rset1.next())
			{
				VLINE_NO.add(rset1.getString(1)==null?"":rset1.getString(1));
				VLINE_DESC.add(rset1.getString(2)==null?"":rset1.getString(2));
				VUNIT.add(rset1.getString(3)==null?"":rset1.getString(3));
				VQTY.add(rset1.getString(4)==null?"":rset1.getString(4));
				VRATE.add(rset1.getString(5)==null?"":rset1.getString(5));
				VAMOUNT.add(rset1.getString(6)==null?"":rset1.getString(6));
			}
			rset1.close();
			stmt1.close();

			if(VLINE_NO.size()==0)
			{
				VLINE_NO.add("1");
				VLINE_DESC.add("");
				VUNIT.add("");
				VQTY.add("");
				VRATE.add("");
				VAMOUNT.add("");
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getF_FlowAnnexureDetail()
	{
		String function_nm="getF_FlowAnnexureDetail()";
		try
		{
			queryString="SELECT ANNEXURE_SEQ,FILE_NAME "
					+ "FROM FMS_DLNG_FFLOW_INV_ANXRE "
					+ "WHERE COMPANY_CD=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
					+ "AND FINANCIAL_YEAR=? AND INVOICE_TYPE=?";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, inv_seq);
			stmt.setString(3, bu_state_tin);
			stmt.setString(4, financial);
			stmt.setString(5, invoice_type);
			rset=stmt.executeQuery();
			while(rset.next())
			{
				VANNEXURE_SEQ.add(rset.getString(1)==null?"":rset.getString(1));
				VANNEXURE_FILE_NM.add(rset.getString(2)==null?"":rset.getString(2));
				VANNEXURE_FOLDER.add(invoice_type+"_"+financial+"_"+bu_state_tin+"_"+inv_seq);
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getInvoiceNo()
	{
		String function_nm="getInvoiceNo()";
		try
		{
			queryString="SELECT INVOICE_NO "
					+ "FROM FMS_DLNG_INVOICE_MST "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND AGMT_NO=? AND CONT_NO=? AND CONTRACT_TYPE=? "
					+ "AND BU_UNIT=? "
					//+ "AND TO_DATE(TO_CHAR(PERIOD_START_DT,'MM/YYYY'),'MM/YYYY')=TO_DATE(?,'MM/YYYY') "
					//+ "AND TO_DATE(TO_CHAR(PERIOD_END_DT,'MM/YYYY'),'MM/YYYY')=TO_DATE(?,'MM/YYYY') "
					+ "AND APPROVED_FLAG=? AND PDF_INV_DTL IS NOT NULL";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, agmt_no);
			stmt.setString(4, cont_no);
			stmt.setString(5, contract_type);
			stmt.setString(6, bu_unit);
			//stmt.setString(7, month+"/"+year);
			//stmt.setString(8, month+"/"+year);
			stmt.setString(7, "Y");
			rset=stmt.executeQuery();
			while(rset.next())
			{
				VLINK_INVOICE_NO.add(rset.getString(1)==null?"":rset.getString(1));
			}
			rset.close();
			stmt.close();

			queryString="SELECT INVOICE_NO "
					+ "FROM FMS_DLNG_FFLOW_INV_MST "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND AGMT_NO=? AND CONT_NO=? AND CONTRACT_TYPE=? "
					+ "AND BU_UNIT=? "
					//+ "AND TO_DATE(TO_CHAR(PERIOD_START_DT,'MM/YYYY'),'MM/YYYY')=TO_DATE('"+month+"/"+year+"','MM/YYYY') "
					//+ "AND TO_DATE(TO_CHAR(PERIOD_END_DT,'MM/YYYY'),'MM/YYYY')=TO_DATE('"+month+"/"+year+"','MM/YYYY') "
					+ "AND APPROVED_FLAG=? AND PDF_INV_DTL IS NOT NULL";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, counterparty_cd);
			stmt.setString(3, agmt_no);
			stmt.setString(4, cont_no);
			stmt.setString(5, contract_type);
			stmt.setString(6, bu_unit);
			//stmt.setString(7, month+"/"+year);
			//stmt.setString(8, month+"/"+year);
			stmt.setString(7, "Y");
			rset=stmt.executeQuery();
			while(rset.next())
			{
				VLINK_INVOICE_NO.add(rset.getString(1)==null?"":rset.getString(1));
			}
			rset.close();
			stmt.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getF_FlowInvoiceDetail()
	{
		String function_nm="getF_FlowInvoiceDetail()";
		try
		{
			queryString="SELECT INVOICE_SEQ, INVOICE_NO, INVOICE_NO, TO_CHAR(INVOICE_DT,'DD-MON-YY'), TO_CHAR(DUE_DT,'DD-MON-YY'),"
					+ "INVOICE_CATEGORY, INVOICE_TYPE, "
					+ "FINANCIAL_YEAR, NUM_LINE, LINKED_INVOICE, NOTE, "
					+ "CONTACT_PERSON_CD,BU_CONTACT_PERSON_CD, "
					+ "CHECKED_FLAG, CHECKED_BY, TO_CHAR(CHECKED_DT,'DD/MM/YYYY HH24:MI:SS'), "
					+ "APPROVED_FLAG, APPROVED_BY, TO_CHAR(APPROVED_DT,'DD/MM/YYYY HH24:MI:SS'),"
					+ "OTHER_INV_STR,GROSS_AMT_USD,EXCHG_RATE_VALUE,GROSS_AMT_INR,TAX_AMT,INVOICE_AMT,ADJUST_AMT,NET_PAYABLE_AMT,"
					+ "INVOICE_RAISED_IN,AMT_WORD,TAX_STRUCT_CD,TO_CHAR(TAX_EFF_DT,'DD/MM/YYYY'),"
					+ "TO_CHAR(PERIOD_START_DT,'DD-MON-YY'),TO_CHAR(PERIOD_END_DT,'DD-MON-YY'),INVOICE_ID_SEQ,"
					+ "TCS_TDS,TCS_AMT,TCS_STRUCT_CD,TO_CHAR(TCS_EFF_DT,'DD/MM/YYYY'),SAC_CD "
					+ "FROM FMS_DLNG_FFLOW_INV_MST "
					+ "WHERE COMPANY_CD=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
					+ "AND FINANCIAL_YEAR=? AND INVOICE_TYPE=?";
			stmt=conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, invoice_seq);
			stmt.setString(3, bu_state_tin);
			stmt.setString(4, financial_year);
			stmt.setString(5, invoice_type);
			rset=stmt.executeQuery();
			if(rset.next())
			{
				invoice_no=rset.getString(2)==null?"":rset.getString(2);
				//invoice_ref=rset.getString(3)==null?"":rset.getString(3);
				invoice_dt=rset.getString(4)==null?"":rset.getString(4);
				invoice_due_dt=rset.getString(5)==null?"":rset.getString(5);
				invoice_category=rset.getString(6)==null?"":rset.getString(6);
				invoice_type=rset.getString(7)==null?"":rset.getString(7);
				num_line=rset.getString(9)==null?"":rset.getString(9);
				linked_invoice=rset.getString(10)==null?"":rset.getString(10);
				note=rset.getString(11)==null?"":rset.getString(11);
				contact_person_cd=rset.getString(12)==null?"0":rset.getString(12);
				bu_contact_person_cd=rset.getString(13)==null?"0":rset.getString(13);

				other_inv_str =rset.getString(20)==null?"":rset.getString(20);

				gross_amt =rset.getString(21)==null?"":rset.getString(21);
				exchang_rate =rset.getString(22)==null?"":rset.getString(22);
				gross_amt1 =rset.getString(23)==null?"":rset.getString(23);
				tax_amt =rset.getString(24)==null?"":rset.getString(24);
				invoice_amt =rset.getString(25)==null?"":rset.getString(25);
				invoice_adj_amt =rset.getString(26)==null?"":rset.getString(26);
				net_payable =rset.getString(27)==null?"":rset.getString(27);
				invoice_raised_in =rset.getString(28)==null?"":rset.getString(28);
				amount_in_word =rset.getString(29)==null?"":rset.getString(29);
				tax_struct_cd =rset.getString(30)==null?"":rset.getString(30);
				tax_struct_dt =rset.getString(31)==null?"":rset.getString(31);
				
				inv_period_start_dt=rset.getString(32)==null?"":rset.getString(32);
				inv_period_end_dt=rset.getString(33)==null?"":rset.getString(33);
				invoice_id_seq=rset.getString(34)==null?"":rset.getString(34);
				
				applicable_abbr=rset.getString(35)==null?"":rset.getString(35);
				applicable_amt=rset.getString(36)==null?"":nf.format(rset.getDouble(36));
				tcs_struct_cd=rset.getString(37)==null?"":rset.getString(37);
				tcs_struct_dt=rset.getString(38)==null?"":rset.getString(38);
				sac_no=rset.getString(39)==null?"":rset.getString(39);
				
				if(activityFlag.equals("CHECK")) {
					activity_value=rset.getString(14)==null?"":rset.getString(14);
				}else if(activityFlag.equals("APPROVE")) {
					activity_value=rset.getString(17)==null?"":rset.getString(17);
				}
				
				tax_struct_info=utilBean.getTaxDescr(conn,tax_struct_cd);
				tcs_struct_info=utilBean.getTaxDescr(conn,tcs_struct_cd);
			}
			rset.close();
			stmt.close();
			
			if(!address_type.equals("R") && !address_type.equals("B") && !address_type.equals("C"))
			{
				plant_seq=address_type.substring(1,address_type.length());
			}
			
			if(contract_type.equals("O") || contract_type.equals("Q"))
			{
				queryString="SELECT B.CARGO_REF,TO_CHAR(A.DDA_DT,'DD-MON-YY'),A.CONT_REF_NO,B.SHIP_CD,B.BOE_NO,TO_CHAR(B.BOE_DT,'DD-MON-YY'),TO_CHAR(SIGNING_DT,'DD-MON-YY'),"
						+ "B.CSOC_QTY,A.MDCQ_PERCENTAGE "
						+ "FROM FMS_LTCORA_CONT_MST A,"
							+ "FMS_LTCORA_CONT_CARGO_DTL B "
						+ "WHERE A.COMPANY_CD=? AND A.COUNTERPARTY_CD=? AND A.BUY_SALE=? "
						+ "AND A.AGMT_NO=? AND A.AGMT_REV=? AND A.AGMT_TYPE=? AND A.CONT_NO=? AND A.CONTRACT_TYPE=? AND B.CARGO_NO=? "
						+ "AND A.CONT_REV = (SELECT MAX(B.CONT_REV) FROM FMS_LTCORA_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
						+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE AND A.BUY_SALE=B.BUY_SALE AND A.AGMT_TYPE=B.AGMT_TYPE) "
						+ ""
						+ "AND A.COMPANY_CD=B.COMPANY_CD AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO "
						+ "AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV AND A.CONTRACT_TYPE=B.CONTRACT_TYPE AND A.BUY_SALE=B.BUY_SALE AND A.AGMT_TYPE=B.AGMT_TYPE ";
				stmt=conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, counterparty_cd);
				stmt.setString(3, "C");
				stmt.setString(4, agmt_no);
				stmt.setString(5, agmt_rev_no);
				stmt.setString(6, "A");
				stmt.setString(7, cont_no);
				stmt.setString(8, contract_type);
				stmt.setString(9, cargo_no);
				rset=stmt.executeQuery();
				if(rset.next())
				{
					contRef=rset.getString(1)==null?"":rset.getString(1);
					dda_dt=rset.getString(2)==null?"":rset.getString(2);
					//cargoRef=rset.getString(3)==null?"":rset.getString(3);
					
					String ship_cd=rset.getString(4)==null?"":rset.getString(4);
					//ship_nm=utilBean.getShipName(conn,ship_cd);
					//boe_number = rset.getString(5)==null?"":rset.getString(5);
					//boe_date=rset.getString(6)==null?"":rset.getString(6);
					
					signingDt=rset.getString(7)==null?"":rset.getString(7);
					dcq=rset.getString(8)==null?"":rset.getString(8);
					mdcq_percentage=rset.getDouble(9);
					if(mdcq_percentage==0)
					{
						mdcq_percentage=100;
					}
				}
				rset.close();
				stmt.close();
				
				queryString1="SELECT TO_CHAR(SIGNING_DT,'DD-MON-YY')  "
						+ "FROM FMS_LTCORA_AGMT_MST A "
						+ "WHERE COMPANY_CD=? AND AGMT_TYPE=? "
						+ "AND AGMT_NO=? AND COUNTERPARTY_CD=? AND BUY_SALE=? "
						+ "AND AGMT_REV = (SELECT MAX(AGMT_REV) FROM FMS_LTCORA_AGMT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_TYPE=B.AGMT_TYPE AND A.BUY_SALE=B.BUY_SALE) ";
				stmt1=conn.prepareStatement(queryString1);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, "A");
				stmt1.setString(3, agmt_no);
				stmt1.setString(4, counterparty_cd);
				stmt1.setString(5, "C");
				rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					agmtSigningDt=rset1.getString(1)==null?"":rset1.getString(1);
				}
				rset1.close();
				stmt1.close();
			}
			else
			{
				queryString1="SELECT CONT_REF_NO,TO_CHAR(DDA_DT,'DD-MON-YY'),TRADE_REF_NO,TO_CHAR(SIGNING_DT,'DD-MON-YY')  "
						+ "FROM FMS_SUPPLY_CONT_MST A "
						+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE=? "
						+ "AND CONT_NO=? AND AGMT_NO=? AND COUNTERPARTY_CD=? "
						+ "AND CONT_REV = (SELECT MAX(CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.CONT_NO=B.CONT_NO AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_REV=B.AGMT_REV "
						+ "AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) ";
				stmt1=conn.prepareStatement(queryString1);
				stmt1.setString(1, comp_cd);
				stmt1.setString(2, contract_type);
				stmt1.setString(3, cont_no);
				stmt1.setString(4, agmt_no);
				stmt1.setString(5, counterparty_cd);
				rset1=stmt1.executeQuery();
				if(rset1.next())
				{
					contRef=rset1.getString(1)==null?"":rset1.getString(1);
					dda_dt=rset1.getString(2)==null?"":rset1.getString(2);
					String tradeRef=rset1.getString(3)==null?"":rset1.getString(3);
					signingDt=rset1.getString(4)==null?"":rset1.getString(4);
					
					if(contract_type.equals("W"))
					{
						contRef=tradeRef;
					}
				}
				rset1.close();
				stmt1.close();
				
				if(contract_type.equals("F"))
				{
					queryString2="SELECT TO_CHAR(SIGNING_DT,'DD-MON-YY')  "
							+ "FROM FMS_AGMT_MST A "
							+ "WHERE COMPANY_CD=? AND AGMT_TYPE=? "
							+ "AND AGMT_NO=? AND COUNTERPARTY_CD=? "
							+ "AND AGMT_REV = (SELECT MAX(AGMT_REV) FROM FMS_AGMT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
							+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_NO=B.AGMT_NO AND A.AGMT_TYPE=B.AGMT_TYPE) ";
					stmt2=conn.prepareStatement(queryString2);
					stmt2.setString(1, comp_cd);
					stmt2.setString(2, "D");
					stmt2.setString(3, agmt_no);
					stmt2.setString(4, counterparty_cd);
					rset2=stmt2.executeQuery();
					if(rset2.next())
					{
						agmtSigningDt=rset2.getString(1)==null?"":rset2.getString(1);
					}
					rset2.close();
					stmt2.close();
				}
			}
			
			queryString2="SELECT CONTACT_PERSON "
					+ "FROM FMS_ENTITY_CONTACT_MST A "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND ENTITY=? AND SEQ_NO=? AND ADDR_FLAG=? AND TYPE=? "
					+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO AND A.TYPE=B.TYPE "
					+ "AND EFF_DT <= TO_DATE(?,'DD-MON-YY'))";
			stmt2=conn.prepareStatement(queryString2);
			stmt2.setString(1, comp_cd);
			stmt2.setString(2, counterparty_cd);
			stmt2.setString(3, "C");
			stmt2.setString(4, contact_person_cd);
			stmt2.setString(5, address_type);
			stmt2.setString(6, "DLNG");
			stmt2.setString(7, invoice_dt);
			rset2=stmt2.executeQuery();
			if(rset2.next())
			{
				contact_person_nm=rset2.getString(1)==null?"":rset2.getString(1);
			}
			rset2.close();
			stmt2.close();
			
			queryString3="SELECT CONTACT_PERSON "
					+ "FROM FMS_ENTITY_CONTACT_MST A "
					+ "WHERE COMPANY_CD=? AND COUNTERPARTY_CD=? "
					+ "AND ENTITY=? AND SEQ_NO=? AND ADDR_FLAG=? AND TYPE=? "
					+ "AND EFF_DT=(SELECT MAX(B.EFF_DT) FROM FMS_ENTITY_CONTACT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
					+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.ENTITY=B.ENTITY AND A.SEQ_NO=B.SEQ_NO AND A.TYPE=B.TYPE "
					+ "AND EFF_DT <= TO_DATE(?,'DD-MON-YY'))";
			stmt3=conn.prepareStatement(queryString3);
			stmt3.setString(1, comp_cd);
			stmt3.setString(2, comp_cd);
			stmt3.setString(3, "B");
			stmt3.setString(4, bu_contact_person_cd);
			stmt3.setString(5, "P"+bu_unit);
			stmt3.setString(6, "DLNG");
			stmt3.setString(7, invoice_dt);
			rset3=stmt3.executeQuery();
			if(rset3.next())
			{
				bu_contact_person_nm=rset3.getString(1)==null?"":rset3.getString(1);
			}
			rset3.close();
			stmt3.close();
			
			HashMap bu_plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "B", comp_cd, bu_unit);
            bu_plantAddress=""+bu_plant_detail.get("plant_address");
			bu_plantCity=""+bu_plant_detail.get("plant_city");
			bu_plantState=""+bu_plant_detail.get("plant_state");
			bu_plantPin=""+bu_plant_detail.get("plant_pin");
			bu_plantNm=""+bu_plant_detail.get("plant_name");
			
			HashMap plant_detail=utilBean.getCounterpartyPlantDetail(conn,comp_cd, "C", counterparty_cd, plant_seq);
            plantAddress=""+plant_detail.get("plant_address");
			plantCity=""+plant_detail.get("plant_city");
			plantState=""+plant_detail.get("plant_state");
			plantPin=""+plant_detail.get("plant_pin");
			plantNm=""+plant_detail.get("plant_name");
			
			if(contract_type.equals("O") || contract_type.equals("Q"))
			{
				tax_info="State : "+plantState;
				tax_info+="<br>State Code : "+utilBean.getState_TIN(conn, comp_cd, counterparty_cd, "C", plant_seq);
				//String temp_tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "C", counterparty_cd, plant_seq);
				//tax_info+=temp_tax_info.replaceAll("\n", "<br>");
				
				queryString = "SELECT A.STAT_NO, TO_CHAR(A.EFF_DT,'DD/MM/YYYY'), B.STAT_NM "
						+ "FROM FMS_COUNTERPARTY_PLANT_TAX A, FMS_GOVT_STAT_TAX B "
						+ "WHERE A.COUNTERPARTY_CD=? AND A.ENTITY=? "
						+ "AND A.PLANT_SEQ_NO=? AND A.COMPANY_CD=? "
						+ "AND A.STAT_CD=B.STAT_CD AND A.STAT_NO IS NOT NULL AND B.STAT_CD IN ('1003','1001')";
				stmt = conn.prepareStatement(queryString);
				stmt.setString(1, counterparty_cd);
				stmt.setString(2, "C");
				stmt.setString(3, plant_seq);
				stmt.setString(4, comp_cd);
				rset = stmt.executeQuery();
				while(rset.next())
				{
					String no = rset.getString(1)==null?"":rset.getString(1);
					String nm = rset.getString(3)==null?"":rset.getString(3);
	
					tax_info+="<br>"+nm+" : "+no;
				}
				stmt.close();
				rset.close();
				
				bu_tax_info="State : "+bu_plantState;
				bu_tax_info+="<br>State Code : "+utilBean.getState_TIN(conn, comp_cd, comp_cd, "B", bu_unit);
				//String temp_bu_tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "B", comp_cd, bu_unit);
				//bu_tax_info+=temp_bu_tax_info.replaceAll("\n", "<br>");
				
				queryString = "SELECT A.STAT_NO, TO_CHAR(A.EFF_DT,'DD/MM/YYYY'), B.STAT_NM "
						+ "FROM FMS_COUNTERPARTY_PLANT_TAX A, FMS_GOVT_STAT_TAX B "
						+ "WHERE A.COUNTERPARTY_CD=? AND A.ENTITY=? "
						+ "AND A.PLANT_SEQ_NO=? AND A.COMPANY_CD=? "
						+ "AND A.STAT_CD=B.STAT_CD AND A.STAT_NO IS NOT NULL AND B.STAT_CD IN ('1003','1001')";
				stmt = conn.prepareStatement(queryString);
				stmt.setString(1, comp_cd);
				stmt.setString(2, "B");
				stmt.setString(3, bu_unit);
				stmt.setString(4, comp_cd);
				rset = stmt.executeQuery();
				while(rset.next())
				{
					String no = rset.getString(1)==null?"":rset.getString(1);
					String nm = rset.getString(3)==null?"":rset.getString(3);
	
					bu_tax_info+="<br>"+nm+" : "+no;
				}
				stmt.close();
				rset.close();

				queryString = "SELECT SAC_CODE,SAC_DESC,REMARKS,SAC_FLAG "
						+ "FROM FMS_SAC_MST "
						+ "WHERE SAC_FLAG=? AND SAC_CD=? ";
				stmt = conn.prepareStatement(queryString);
				stmt.setString(1, "Y");
				stmt.setString(2, sac_no);
				rset = stmt.executeQuery();
				while(rset.next())
				{
					String no = rset.getString(1)==null?"":rset.getString(1);
					
					bu_tax_info+="<br>SAC : "+no;
				}
				stmt.close();
				rset.close();
			}
			else
			{
				tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "C", counterparty_cd, plant_seq);
				tax_info=tax_info.replaceAll("\n", "<br>");
				
				bu_tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "B", comp_cd, bu_unit);
				bu_tax_info=bu_tax_info.replaceAll("\n", "<br>");
			}
			
			//tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "C", counterparty_cd, plant_seq);
			//tax_info=tax_info.replaceAll("\n", "<br>");
			
			//bu_tax_info=utilBean.getCounterpartyPlantTaxInfo(conn,comp_cd, "B", comp_cd, bu_unit);
			//bu_tax_info=bu_tax_info.replaceAll("\n", "<br>");
			
			couterpty_nm=""+utilBean.getCounterpartyName(conn,counterparty_cd);
			int srno=0;
			
			queryString0="SELECT LINE_NO,LINE_DESC,UNIT,QTY,RATE,AMOUNT "
					+ "FROM FMS_DLNG_FFLOW_INV_DTL "
					+ "WHERE COMPANY_CD=? AND INVOICE_SEQ=? AND BU_STATE_TIN=? "
					+ "AND FINANCIAL_YEAR=? AND INVOICE_TYPE=? "
					+ "ORDER BY LINE_NO";
			stmt0=conn.prepareStatement(queryString0);
			stmt0.setString(1, comp_cd);
			stmt0.setString(2, invoice_seq);
			stmt0.setString(3, bu_state_tin);
			stmt0.setString(4, financial_year);
			stmt0.setString(5, invoice_type);
			rset0=stmt0.executeQuery();
			while(rset0.next())
			{
				srno+=1;
				VPDF_COL1.add(rset0.getString(1)==null?"":rset0.getString(1));
				VPDF_COL2.add(rset0.getString(2)==null?"":rset0.getString(2));
				VPDF_COL3.add("");
				VPDF_COL4.add(rset0.getString(3)==null?"":rset0.getString(3));
				VPDF_COL5.add(rset0.getString(4)==null?"":rset0.getString(4));
				VPDF_COL6.add(rset0.getString(5)==null?"":rset0.getString(5));
				VPDF_COL7.add(rset0.getString(6)==null?"":rset0.getString(6));
			}
			rset0.close();
			stmt0.close();
			
			if(!gross_amt.equals(""))
			{
				srno+=1;
				VPDF_COL1.add(srno);
				VPDF_COL2.add("Gross Amount");
				VPDF_COL3.add("");
				VPDF_COL4.add("USD");
				VPDF_COL5.add("");
				VPDF_COL6.add("");
				VPDF_COL7.add(gross_amt);
			}	
			
			if(!exchang_rate.equals(""))
			{
				srno+=1;
				VPDF_COL1.add(srno);
				VPDF_COL2.add("Exchange Rate");
				VPDF_COL3.add("Att2");
				VPDF_COL4.add("INR/USD");
				VPDF_COL5.add("");
				VPDF_COL6.add(exchang_rate);
				VPDF_COL7.add("");
			}
			
			if(!gross_amt1.equals(""))
			{
				srno+=1;
				VPDF_COL1.add(srno);
				VPDF_COL2.add("Gross Amount");
				VPDF_COL3.add("");
				VPDF_COL4.add("INR");
				VPDF_COL5.add("");
				VPDF_COL6.add("");
				VPDF_COL7.add(gross_amt1);
			}
			
			if(!tax_amt.equals(""))
			{
				srno+=1;
				VPDF_COL1.add(srno);
				VPDF_COL2.add("Tax ("+tax_struct_info+")");
				VPDF_COL3.add("");
				VPDF_COL4.add("INR");
				VPDF_COL5.add("");
				VPDF_COL6.add("");
				VPDF_COL7.add(tax_amt);
			}
			
			double temp_srno=srno;
			queryString1="SELECT COUNT(*) "
					+ "FROM FMS_DLNG_FFLOW_INV_TAX_DTL "
					+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
					+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? "
					+ "AND INVOICE_TYPE=?";
			stmt1=conn.prepareStatement(queryString1);
			stmt1.setString(1, comp_cd);
			stmt1.setString(2, bu_state_tin);
			stmt1.setString(3, financial_year);
			stmt1.setString(4, invoice_seq);
			stmt1.setString(5, invoice_type);
			rset1=stmt1.executeQuery();
			if(rset1.next())
			{
				if(rset1.getInt(1)>1)
				{
					queryString="SELECT TAX_CODE,TAX_DESCR,TAX_AMT,TAX_BASE_AMT "
							+ "FROM FMS_DLNG_FFLOW_INV_TAX_DTL "
							+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
							+ "AND FINANCIAL_YEAR=? AND INVOICE_SEQ=? "
							+ "AND INVOICE_TYPE=?";
					stmt=conn.prepareStatement(queryString);
					stmt.setString(1, comp_cd);
					stmt.setString(2, bu_state_tin);
					stmt.setString(3, financial_year);
					stmt.setString(4, invoice_seq);
					stmt.setString(5, invoice_type);
					rset=stmt.executeQuery();
					while(rset.next())
					{
						temp_srno=temp_srno+0.1;
						VPDF_COL1.add(nf0.format(temp_srno));
						VPDF_COL2.add(rset.getString(2)==null?"":rset.getString(2));
						VPDF_COL3.add("");
						VPDF_COL4.add("INR");
						VPDF_COL5.add("");
						VPDF_COL6.add("");
						VPDF_COL7.add(rset.getString(3)==null?"":nf.format(rset.getDouble(3)));
					}
					rset.close();
					stmt.close();
				}
			}
			rset1.close();
			stmt1.close();
			
			if(!invoice_amt.equals(""))
			{
				srno+=1;
				VPDF_COL1.add(srno);
				VPDF_COL2.add("Invoice Amount");
				VPDF_COL3.add("");
				VPDF_COL4.add("INR");
				VPDF_COL5.add("");
				VPDF_COL6.add("");
				VPDF_COL7.add(invoice_amt);
			}
			
			if(applicable_abbr.equals("TCS"))
			{
				srno+=1;
				VPDF_COL1.add(srno);
				VPDF_COL2.add("TCS("+tcs_struct_info+")");
				VPDF_COL3.add("");
				VPDF_COL4.add("INR");
				VPDF_COL5.add("");
				VPDF_COL6.add("");
				VPDF_COL7.add(applicable_amt);
			}
			
			if(!invoice_adj_amt.equals(""))
			{
				srno+=1;
				VPDF_COL1.add(srno);
				VPDF_COL2.add("Adjustment Amount");
				VPDF_COL3.add("");
				VPDF_COL4.add("INR");
				VPDF_COL5.add("");
				VPDF_COL6.add("");
				VPDF_COL7.add(invoice_adj_amt);
			}
			
			if(!net_payable.equals(""))
			{
				srno+=1;
				VPDF_COL1.add(srno);
				VPDF_COL2.add("Net Amount Payable");
				VPDF_COL3.add("");
				VPDF_COL4.add("INR");
				VPDF_COL5.add("");
				VPDF_COL6.add("");
				VPDF_COL7.add(net_payable);
			}	
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getF_FlowInvoiceNumber()
	{
		String function_nm="getF_FlowInvoiceNumber()";
		try
		{
			String invoice_prefix=utilBean.getInvoicePrefix(conn,comp_cd);
			
			String fin_yr="";
			if(!financial_year.equals(""))
			{
				String[] temp = financial_year.split("-");
				fin_yr=temp[0].substring(2,temp[0].length())+"-"+temp[1].substring(2,temp[1].length());
			}
			
			String state_abbr="";
			String state_code=bu_state_tin;
			if(state_code.length()<=1)
			{
				state_code="0"+state_code;
			}

			if(!invoice_id_seq.equals(""))
			{
				VINVOICE_ID_SEQ.add(invoice_id_seq);
				VINVOICE_NO.add(invoice_no);
			}
			
			if(!invoice_prefix.equals(""))
			{
				int no_inv_no=10;
				for(int i=1;i<=no_inv_no;i++)
				{
					String contType="";
					String invSeries="";
					String inv_type="";
					
					if(contract_type.equals("Q") || contract_type.equals("O"))
					{
						contType="'Q','O'";
						if(invoice_type.equals("SI") 
								|| invoice_type.equals("UG") 
								|| invoice_type.equals("ST") 
								|| invoice_type.equals("DI"))
						{
							invSeries="L";
							inv_type="'SI','UG','ST','DI'";
						}
						else if(!invoice_type.equals("CCR") && !invoice_type.equals("CDR"))
						{
							invSeries="L"+invoice_type;
							inv_type="'"+invoice_type+"'";
						}
						else
						{
							inv_type="'"+invoice_type+"'";
							invSeries=invoice_type;	
						}
						
					}
					else
					{
						contType="'F','E','W'";
						invSeries=invoice_type;
						inv_type="'"+invoice_type+"'";
					}
					
					String invoice_id_seq=""+i;
					int count=0;
					int selCount=0;
					
					queryString="SELECT COUNT(*) "
							+ "FROM FMS_DLNG_FFLOW_INV_MST "
							+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
							+ "AND FINANCIAL_YEAR=? AND INVOICE_TYPE IN ("+inv_type+") "
							+ "AND INVOICE_ID_SEQ=? AND CONTRACT_TYPE IN ("+contType+") ";
					if(contract_type.equals("Q") || contract_type.equals("O"))
					{
						queryString+="UNION ";
						queryString+="SELECT COUNT(*) "
								+ "FROM FMS_FFLOW_INV_MST "
								+ "WHERE COMPANY_CD=? AND BU_STATE_TIN=? "
								+ "AND FINANCIAL_YEAR=? AND INVOICE_TYPE IN ("+inv_type+") "
								+ "AND INVOICE_ID_SEQ=? AND CONTRACT_TYPE IN ("+contType+") ";
					}
					stmt=conn.prepareStatement(queryString);
					stmt.setString(++selCount, comp_cd);
					stmt.setString(++selCount, bu_state_tin);
					stmt.setString(++selCount, financial_year);
					stmt.setString(++selCount, invoice_id_seq);
					if(contract_type.equals("Q") || contract_type.equals("O"))
					{
						stmt.setString(++selCount, comp_cd);
						stmt.setString(++selCount, bu_state_tin);
						stmt.setString(++selCount, financial_year);
						stmt.setString(++selCount, invoice_id_seq);
					}
					rset=stmt.executeQuery();
					while(rset.next())
					{
						count += rset.getInt(1);
					}
					rset.close();
					stmt.close();
					
					if(invoice_type.equals("S") 
							|| invoice_type.equals("SI") 
							|| invoice_type.equals("UG") 
							|| invoice_type.equals("ST") 
							|| invoice_type.equals("DI")
							|| invoice_type.equals("TLU")
							)
					{
						queryString1="SELECT COUNT(*) "
								+ "FROM FMS_DLNG_INVOICE_MST "
								+ "WHERE COMPANY_CD=? AND FINANCIAL_YEAR=? "
								+ "AND BU_STATE_TIN=? AND INVOICE_ID_SEQ=? AND CONTRACT_TYPE IN ("+contType+")";
						if(contract_type.equals("Q") || contract_type.equals("O"))
						{
							queryString1+="UNION ALL ";
							queryString1+="SELECT COUNT(*) "
									+ "FROM FMS_INVOICE_MST "
									+ "WHERE COMPANY_CD=? AND FINANCIAL_YEAR=? "
									+ "AND BU_STATE_TIN=? AND INVOICE_ID_SEQ=? AND CONTRACT_TYPE IN ("+contType+")";
						}
						stmt1=conn.prepareStatement(queryString1);
						stmt1.setString(1, comp_cd);
						stmt1.setString(2, financial_year);
						stmt1.setString(3, bu_state_tin);
						stmt1.setString(4, invoice_id_seq);
						if(contract_type.equals("Q") || contract_type.equals("O"))
						{
							stmt1.setString(5, comp_cd);
							stmt1.setString(6, financial_year);
							stmt1.setString(7, bu_state_tin);
							stmt1.setString(8, invoice_id_seq);
						}
						rset1=stmt1.executeQuery();
						while(rset1.next())
						{
							count += rset1.getInt(1);
						}
						rset1.close();
						stmt1.close();
					}
					
					if(count==0)
					{	
						queryString1="SELECT STATE_CODE "
								+ "FROM FMS_STATE_MST "
								+ "WHERE TIN=?";
						stmt1=conn.prepareStatement(queryString1);
						stmt1.setString(1, state_code);
						rset1=stmt1.executeQuery();
						if(rset1.next())
						{
							state_abbr=rset1.getString(1)==null?"":rset1.getString(1);
						}
						rset1.close();
						stmt1.close();
						
						String invoice_no="";
						//invoice_no=invoice_prefix+""+invSeries+""+invoice_type+state_abbr+""+utilBean.PrePaddingZero(invoice_id_seq, 4)+"/"+fin_yr;
						invoice_no=invoice_prefix+""+invSeries+""+state_abbr+""+utilBean.PrePaddingZero(invoice_id_seq, 4)+"/"+fin_yr;
						
						VINVOICE_ID_SEQ.add(invoice_id_seq);
						VINVOICE_NO.add(invoice_no);
					}
					else
					{
						no_inv_no+=1;
					}
				}
			}
			
			if(invoice_id_seq.equals(""))
			{
				if(VINVOICE_ID_SEQ.size()>0)
				{
					invoice_id_seq=""+VINVOICE_ID_SEQ.elementAt(0);
				}
			}
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getSegment()
	{
		String function_nm="getSegment()";
		try
		{
			VSEGMENT.add("Supply Notice");
			VSEGMENT.add("Letter of Agreement");
			VSEGMENT.add("IGX");
			
			VSEGMENT_TYPE.add("F");
			VSEGMENT_TYPE.add("E");
			VSEGMENT_TYPE.add("W");
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public void getDlngInvoiceActualRptDtl()
	{
		String function_nm="getDlngInvoiceActualRptDtl()";
		
		try
		{
			queryString="SELECT COMPANY_CD,COUNTERPARTY_CD,AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,CONTRACT_TYPE,FINANCIAL_YEAR, "
					+ "BU_STATE_TIN,INVOICE_SEQ,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),TO_CHAR(PERIOD_START_DT,'DD/MM/YYYY'),"
					+ "TO_CHAR(PERIOD_END_DT,'DD/MM/YYYY'),TO_CHAR(DUE_DT,'DD/MM/YYYY'),SALE_PRICE,SALE_PRICE_UNIT,"
					+ "SALE_AMT,GROSS_AMT,TAX_AMT,TAX_STRUCT_CD,TO_CHAR(TAX_EFF_DT,'DD/MM/YYYY'),INVOICE_AMT,NET_PAYABLE_AMT,"
					+ "TCS_TDS,TCS_AMT,TCS_FACTOR,TDS_GROSS_AMT,TDS_GROSS_PERCENT,TDS_TAX_AMT,TDS_TAX_PERCENT,"
					+ "PAY_RECV_AMT,TO_CHAR(PAY_RECV_DT,'DD/MM/YYYY'),PLANT_SEQ,BU_UNIT,ALLOC_QTY,INVOICE_RAISED_IN,TCS_TDS,"
					+ "TCS_AMT,TCS_FACTOR,'',SAP_APPROVAL,"
					+ "'','','',INV_FLAG,FIN_SYS,TRUCK_CD,TRUCK_TRANS_CD "
					+ "FROM FMS_DLNG_INVOICE_MST "
					+ "WHERE COMPANY_CD=? "
					+ "AND INVOICE_DT>=TO_DATE(?,'DD/MM/YYYY') AND INVOICE_DT<=TO_DATE(?,'DD/MM/YYYY') "
					+ "AND APPROVED_FLAG=? AND INVOICE_ID_SEQ IS NOT NULL AND INVOICE_AMT IS NOT NULL "
					+ "AND SAP_APPROVAL=? ";
			if(!segment.equals("0") && !segment.equals(""))
			{
				queryString+="AND CONTRACT_TYPE=? ";
			}
			queryString+= "ORDER BY INVOICE_DT";
			stmt = conn.prepareStatement(queryString);
			stmt.setString(1, comp_cd);
			stmt.setString(2, from_dt);
			stmt.setString(3, to_dt);
			stmt.setString(4, "Y");
			stmt.setString(5, "Y");
			if(!segment.equals("0") && !segment.equals(""))
			{
				stmt.setString(6, segment);
			}
			rset=stmt.executeQuery();
			while(rset.next())
			{
				String companyCd = rset.getString(1)==null?"":rset.getString(1);
				String countpty_cd = rset.getString(2)==null?"":rset.getString(2);
				String agmt = rset.getString(3)==null?"":rset.getString(3);
				String agmt_rev = rset.getString(4)==null?"":rset.getString(4);
				String cont = rset.getString(5)==null?"":rset.getString(5);
				String cont_rev = rset.getString(6)==null?"":rset.getString(6);
				String cont_type = rset.getString(7)==null?"":rset.getString(7);
				String finan_yr = rset.getString(8)==null?"":rset.getString(8);
				String bu_state_tin = rset.getString(9)==null?"":rset.getString(9);
				String inv_seq = rset.getString(10)==null?"":rset.getString(10);
				String inv_no = rset.getString(11)==null?"":rset.getString(11);
				String inv_dt = rset.getString(12)==null?"":rset.getString(12);
				String period_st_dt = rset.getString(13)==null?"":rset.getString(13);
				String period_end_dt = rset.getString(14)==null?"":rset.getString(14);
				String inv_due_dt = rset.getString(15)==null?"":rset.getString(15);
				double sales_price=rset.getDouble(16);
				String sales_price_cd = rset.getString(17)==null?"":rset.getString(17);
				String cargo_no = "0";
				String invFlag = rset.getString(46)==null?"":rset.getString(46);
				String fin_sys = rset.getString(47)==null?"":rset.getString(47);		//PB 20250627: for Sun
				String truckCd = rset.getString(48)==null?"":rset.getString(48);
				String transCd = rset.getString(49)==null?"":rset.getString(49);
				
				String truckNo=dlng_util.getTruckRegNo(conn, truckCd);
				
				double sales_amt = rset.getDouble(18);
				double gross_amt = rset.getDouble(19);
				double tax_amt = rset.getDouble(20);
				String tax_struct_cd = rset.getString(21)==null?"":rset.getString(21);
				String tax_struct_dt = rset.getString(22)==null?"":rset.getString(22);
				
				double invoice_amt = rset.getDouble(23);
				double net_payable = rset.getDouble(24);
				String tds_tcs_flag = rset.getString(25)==null?"":rset.getString(25);
				double tcs_amt = rset.getDouble(26);
				//27
				String temp_tds_gross_amt = rset.getString(28)==null?"":rset.getString(28);
				double tds_gross_amt = rset.getDouble(28);
				String temp_tds_gross_per = rset.getString(29)==null?"":rset.getString(29);
				double tds_gross_per = rset.getDouble(29);
				String temp_tds_tax_amt = rset.getString(30)==null?"":rset.getString(30);
				double tds_tax_amt = rset.getDouble(30);
				String temp_tds_tax_per = rset.getString(31)==null?"":rset.getString(31);
				double tds_tax_per = rset.getDouble(31);
				
				String temp_pay_recv_amt = rset.getString(32)==null?"":rset.getString(32);
				double pay_recv_amt = rset.getDouble(32);
				String temp_pay_recv_dt = rset.getString(33)==null?"":rset.getString(33);
				
				String plant_seq = rset.getString(34)==null?"":rset.getString(34);
				
				if(!temp_tds_tax_amt.equals("")){
					VTDS_TAX_AMT.add(nf.format(tds_tax_amt));
				}else{
					VTDS_TAX_AMT.add("");
				}

				if(!temp_tds_tax_per.equals("")){
					VTDS_TAX_PERCENT.add(nf.format(tds_tax_per));
				}else{
					VTDS_TAX_PERCENT.add("");
				}
				
				if(!temp_pay_recv_amt.equals("")){
					VPAY_RECV_AMT.add(nf.format(pay_recv_amt));
				}else{
					VPAY_RECV_AMT.add("");
				}
				VPAY_RECV_DT.add(temp_pay_recv_dt);
				
				VTRUCK_CD.add(truckCd);
				VTRUCK_NO.add(truckNo);
				VCOUNTERPARTY_CD.add(countpty_cd);
				VCOUNTERPARTY_ABBR.add(""+utilBean.getCounterpartyABBR(conn,countpty_cd));
				VAGMT_NO.add(agmt);
				VAGMT_REV_NO.add(agmt_rev);
				VCONT_NO.add(cont);
				VCONT_REV_NO.add(cont_rev);
				VCONTRACT_TYPE.add(cont_type);
				VDIS_CONT_MAPPING.add(""+utilBean.NewDealMappingId(companyCd, countpty_cd, agmt, agmt_rev, cont, cont_rev, cont_type, cargo_no));
				VFINANCIAL_YEAR.add(finan_yr);
				VBU_STATE_TIN.add(bu_state_tin);
				VINVOICE_SEQ.add(inv_seq);
				VINVOICE_NO.add(inv_no);
				VINVOICE_DT.add(inv_dt);
				VPERIOD_START_DT.add(period_st_dt);
				VPERIOD_END_DT.add(period_end_dt);
				VINVOICE_DUE_DT.add(inv_due_dt);
				VSALES_PRICE.add(""+utilBean.RateNumberFormat(sales_price, sales_price_cd));
				VSALES_PRICE_CD.add(sales_price_cd);
				VSALES_PRICE_NM.add(""+utilBean.getRateUnitNm(conn,sales_price_cd));
				VGROSS_AMT.add(nf.format(gross_amt));
				VTAX_AMT.add(nf.format(tax_amt));
				VINVOICE_AMT.add(nf.format(invoice_amt));
				
				net_payable=net_payable-tds_gross_amt-tds_tax_amt;
				VNET_PAYABLE_AMT.add(nf.format(net_payable));
				
				double short_received = net_payable - pay_recv_amt;
				VSHORT_RECEIVED.add(nf.format(short_received));
				
				VTDS_TCS_FLAG.add(tds_tcs_flag);
				VTCS_AMT.add(nf.format(tcs_amt));
				
				VFIN_SYS.add(fin_sys);
				
				VTAX_STRUCT_DTL.add(utilBean.getTaxDescr(conn, tax_struct_cd));
				
				String bu_plant_seq=rset.getString(35)==null?"":rset.getString(35);
				VBU_NM.add(""+utilBean.getCounterpartyPlantABBR(conn,comp_cd, comp_cd, bu_plant_seq, "B"));
				VSAP_APPROVAL_FLAG.add(rset.getString(42)==null?"":rset.getString(42));
				VTYPE_FLAG.add("SG");
				VALLOC_QTY.add(rset.getString(36)==null?"":nf.format(rset.getDouble(36)));
				VINVOICE_RAISED_IN.add(""+utilBean.getRateUnitNm(conn,rset.getString(37)==null?"":rset.getString(37)));
				VPAYMENT_DONE_IN.add("INR");
				String tcs_tds=rset.getString(38)==null?"":rset.getString(38);
				VTCS_TDS.add(tcs_tds);
				
				if(tcs_tds.equals("TCS"))
				{
					VTDS_GROSS_AMT.add(rset.getString(39)==null?"":nf.format(rset.getDouble(39)));
					VTDS_GROSS_PERCENT.add(rset.getString(40)==null?"":nf.format(rset.getDouble(40)));
				}
				else
				{
					if(!temp_tds_gross_amt.equals("")){
						VTDS_GROSS_AMT.add(nf.format(tds_gross_amt));
					}else{
						VTDS_GROSS_AMT.add("");
					}
					
					if(!temp_tds_gross_per.equals("")){
						VTDS_GROSS_PERCENT.add(nf.format(tds_gross_per));
					}else{
						VTDS_GROSS_PERCENT.add("");
					}
				}
				
				VSALES_AMT.add(nf.format(sales_amt));
				
				VINVOICE_TYPE.add("");
				
				String contRef="";

				queryString1="SELECT CONT_REF_NO,TRADE_REF_NO,AGMT_BASE "
						+ "FROM FMS_SUPPLY_CONT_MST A "
						+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE=? "
						+ "AND COUNTERPARTY_CD=? AND AGMT_NO=? AND CONT_NO=? "
						+ "AND CONT_REV=(SELECT MAX(CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_NO=B.AGMT_NO AND A.CONT_NO=B.CONT_NO AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) ";
				stmt2 = conn.prepareStatement(queryString1);
				stmt2.setString(1, comp_cd);
				stmt2.setString(2, cont_type);
				stmt2.setString(3, countpty_cd);
				stmt2.setString(4, agmt);
				stmt2.setString(5, cont);
				rset2=stmt2.executeQuery();
				if(rset2.next())
				{
					contRef=rset2.getString(1)==null?"":rset2.getString(1);
					if(cont_type.equals("W"))
					{
						contRef=rset2.getString(2)==null?"":rset2.getString(2);
					}
				}
				rset2.close();
				stmt2.close();
				
				VCONT_REF_NO.add(contRef);
				
				/*if(invFlag.equals("ST"))
				{
					VCASH_FLOW.add("LNG Storage Charge");
				}
				else if(cont_type.equals("O") || cont_type.equals("Q"))
				{
					VCASH_FLOW.add("Re-Gas Capacity");
				}
				else*/
				{
					VCASH_FLOW.add("Commodity");
				}
			}
			rset.close();
			stmt.close();
			
			queryString="SELECT COMPANY_CD,COUNTERPARTY_CD,AGMT_NO,AGMT_REV,CONT_NO,CONT_REV,CONTRACT_TYPE,FINANCIAL_YEAR, "
					+ "BU_STATE_TIN,INVOICE_SEQ,INVOICE_NO,TO_CHAR(INVOICE_DT,'DD/MM/YYYY'),TO_CHAR(PERIOD_START_DT,'DD/MM/YYYY'),"
					+ "TO_CHAR(PERIOD_END_DT,'DD/MM/YYYY'),TO_CHAR(DUE_DT,'DD/MM/YYYY'),GROSS_AMT_INR,GROSS_AMT_INR,"
					+ "GROSS_AMT_INR,GROSS_AMT_INR,TAX_AMT,TAX_STRUCT_CD,TO_CHAR(TAX_EFF_DT,'DD/MM/YYYY'),INVOICE_AMT,NET_PAYABLE_AMT,"
					+ "TCS_TDS,TCS_AMT,TCS_FACTOR,TDS_GROSS_AMT,TDS_GROSS_PERCENT,TDS_TAX_AMT,TDS_TAX_PERCENT,"
					+ "PAY_RECV_AMT,TO_CHAR(PAY_RECV_DT,'DD/MM/YYYY'),ADDR_FLAG,BU_UNIT,INVOICE_RAISED_IN,INVOICE_TYPE,SAP_APPROVAL,"
					+ "INVOICE_CATEGORY,ALLOC_QTY,'',FIN_SYS "
					+ "FROM FMS_DLNG_FFLOW_INV_MST "
					+ "WHERE COMPANY_CD=? "
					+ "AND INVOICE_DT>=TO_DATE(?,'DD/MM/YYYY') AND INVOICE_DT<=TO_DATE(?,'DD/MM/YYYY') "
					+ "AND APPROVED_FLAG=? AND INVOICE_ID_SEQ IS NOT NULL AND INVOICE_AMT IS NOT NULL "
					+ "AND SAP_APPROVAL=? ";
			if(!segment.equals("0") && !segment.equals(""))
			{
				queryString+="AND CONTRACT_TYPE=? ";
			}
			queryString+= "ORDER BY INVOICE_DT";
			stmt1 = conn.prepareStatement(queryString);
			stmt1.setString(1, comp_cd);
			stmt1.setString(2, from_dt);
			stmt1.setString(3, to_dt);
			stmt1.setString(4, "Y");
			stmt1.setString(5, "Y");
			if(!segment.equals("0") && !segment.equals(""))
			{
				stmt1.setString(6, segment);
			}
			rset1=stmt1.executeQuery();
			while(rset1.next())
			{
				String companyCd = rset1.getString(1)==null?"":rset1.getString(1);
				String countpty_cd = rset1.getString(2)==null?"":rset1.getString(2);
				String agmt = rset1.getString(3)==null?"":rset1.getString(3);
				String agmt_rev = rset1.getString(4)==null?"":rset1.getString(4);
				String cont = rset1.getString(5)==null?"":rset1.getString(5);
				String cont_rev = rset1.getString(6)==null?"":rset1.getString(6);
				String cont_type = rset1.getString(7)==null?"":rset1.getString(7);
				String finan_yr = rset1.getString(8)==null?"":rset1.getString(8);
				String bu_state_tin = rset1.getString(9)==null?"":rset1.getString(9);
				String inv_seq = rset1.getString(10)==null?"":rset1.getString(10);
				String inv_no = rset1.getString(11)==null?"":rset1.getString(11);
				String inv_dt = rset1.getString(12)==null?"":rset1.getString(12);
				String period_st_dt = rset1.getString(13)==null?"":rset1.getString(13);
				String period_end_dt = rset1.getString(14)==null?"":rset1.getString(14);
				String inv_due_dt = rset1.getString(15)==null?"":rset1.getString(15);
				double sales_price=0;//rset1.getDouble(16);
				String sales_price_cd ="";// rset1.getString(17)==null?"":rset1.getString(17);
				String cargo_no = "0";//rset1.getString(41)==null?"":rset1.getString(41);
				String fin_sys = rset1.getString(42)==null?"":rset1.getString(42);
				
				//18
				double gross_amt = rset1.getDouble(19);
				double tax_amt = rset1.getDouble(20);
				String tax_struct_cd = rset1.getString(21)==null?"":rset1.getString(21);
				String tax_struct_dt = rset1.getString(22)==null?"":rset1.getString(22);
				
				double invoice_amt = rset1.getDouble(23);
				double net_payable = rset1.getDouble(24);
				String tds_tcs_flag = rset1.getString(25)==null?"":rset1.getString(25);
				double tcs_amt = rset1.getDouble(26);
				//27
				String temp_tds_gross_amt = rset1.getString(28)==null?"":rset1.getString(28);
				double tds_gross_amt = rset1.getDouble(28);
				String temp_tds_gross_per = rset1.getString(29)==null?"":rset1.getString(29);
				double tds_gross_per = rset1.getDouble(29);
				String temp_tds_tax_amt = rset1.getString(30)==null?"":rset1.getString(30);
				double tds_tax_amt = rset1.getDouble(30);
				String temp_tds_tax_per = rset1.getString(31)==null?"":rset1.getString(31);
				double tds_tax_per = rset1.getDouble(31);
				
				String temp_pay_recv_amt = rset1.getString(32)==null?"":rset1.getString(32);
				double pay_recv_amt = rset1.getDouble(32);
				String temp_pay_recv_dt = rset1.getString(33)==null?"":rset1.getString(33);
				
				String plant_seq = rset1.getString(34)==null?"":rset1.getString(34);
				
				if(!temp_tds_tax_amt.equals("")){
					VTDS_TAX_AMT.add(nf.format(tds_tax_amt));
				}else{
					VTDS_TAX_AMT.add("");
				}

				if(!temp_tds_tax_per.equals("")){
					VTDS_TAX_PERCENT.add(nf.format(tds_tax_per));
				}else{
					VTDS_TAX_PERCENT.add("");
				}
				
				if(!temp_pay_recv_amt.equals("")){
					VPAY_RECV_AMT.add(nf.format(pay_recv_amt));
				}else{
					VPAY_RECV_AMT.add("");
				}
				VPAY_RECV_DT.add(temp_pay_recv_dt);
				
				VTRUCK_CD.add("");
				VTRUCK_NO.add("");
				VCOUNTERPARTY_CD.add(countpty_cd);
				VCOUNTERPARTY_ABBR.add(""+utilBean.getCounterpartyABBR(conn,countpty_cd));
				VAGMT_NO.add(agmt);
				VAGMT_REV_NO.add(agmt_rev);
				VCONT_NO.add(cont);
				VCONT_REV_NO.add(cont_rev);
				VCONTRACT_TYPE.add(cont_type);
				VDIS_CONT_MAPPING.add(""+utilBean.NewDealMappingId(companyCd, countpty_cd, agmt, agmt_rev, cont, cont_rev, cont_type, cargo_no));
				VFINANCIAL_YEAR.add(finan_yr);
				VBU_STATE_TIN.add(bu_state_tin);
				VINVOICE_SEQ.add(inv_seq);
				VINVOICE_NO.add(inv_no);
				VINVOICE_DT.add(inv_dt);
				VPERIOD_START_DT.add(period_st_dt);
				VPERIOD_END_DT.add(period_end_dt);
				VINVOICE_DUE_DT.add(inv_due_dt);
				if(sales_price>0)
				{
					VSALES_PRICE.add(""+utilBean.RateNumberFormat(sales_price, sales_price_cd));
				}
				else
				{
					VSALES_PRICE.add("");
				}
				VSALES_PRICE_CD.add(sales_price_cd);
				VSALES_PRICE_NM.add(""+utilBean.getRateUnitNm(conn,sales_price_cd));
				VGROSS_AMT.add(nf.format(gross_amt));
				if(tax_amt>0)
				{
					VTAX_AMT.add(nf.format(tax_amt));
				}
				else
				{
					VTAX_AMT.add("");
				}
				VINVOICE_AMT.add(nf.format(invoice_amt));
				
				net_payable=net_payable-tds_gross_amt-tds_tax_amt;
				VNET_PAYABLE_AMT.add(nf.format(net_payable));
				
				double short_received = net_payable - pay_recv_amt;
				VSHORT_RECEIVED.add(nf.format(short_received));
				
				VTDS_TCS_FLAG.add(tds_tcs_flag);
				if(tcs_amt>0)
				{
					VTCS_AMT.add(nf.format(tcs_amt));
				}
				else
				{
					VTCS_AMT.add("");
				}
				
				VFIN_SYS.add(fin_sys);
				
				VTAX_STRUCT_DTL.add(utilBean.getTaxDescr(conn, tax_struct_cd));
				
				String bu_plant_seq=rset1.getString(35)==null?"":rset1.getString(35);
				VBU_NM.add(""+utilBean.getCounterpartyPlantABBR(conn,comp_cd, comp_cd, bu_plant_seq, "B"));
				VSAP_APPROVAL_FLAG.add(rset1.getString(38)==null?"":rset1.getString(38));
				VTYPE_FLAG.add("FFLOW");
				VALLOC_QTY.add(rset1.getString(40)==null?"":nf.format(rset1.getDouble(40)));
				VINVOICE_RAISED_IN.add(""+utilBean.getRateUnitNm(conn,rset1.getString(36)==null?"":rset1.getString(36)));
				VPAYMENT_DONE_IN.add("INR");
				VTCS_TDS.add(tds_tcs_flag);
				
				if(tds_tcs_flag.equals("TCS"))
				{
					VTDS_GROSS_AMT.add(rset1.getString(26)==null?"":nf.format(rset1.getDouble(26)));
					VTDS_GROSS_PERCENT.add(rset1.getString(27)==null?"":nf.format(rset1.getDouble(27)));
				}
				else
				{
					if(!temp_tds_gross_amt.equals("")){
						VTDS_GROSS_AMT.add(nf.format(tds_gross_amt));
					}else{
						VTDS_GROSS_AMT.add("");
					}
					
					if(!temp_tds_gross_per.equals("")){
						VTDS_GROSS_PERCENT.add(nf.format(tds_gross_per));
					}else{
						VTDS_GROSS_PERCENT.add("");
					}
				}
				
				VSALES_AMT.add("");
				String inv_type = rset1.getString(37)==null?"":rset1.getString(37);
				VINVOICE_TYPE.add(inv_type);
				
				String contRef="";

				queryString1="SELECT CONT_REF_NO,TRADE_REF_NO,AGMT_BASE "
						+ "FROM FMS_SUPPLY_CONT_MST A "
						+ "WHERE COMPANY_CD=? AND CONTRACT_TYPE=? "
						+ "AND COUNTERPARTY_CD=? AND AGMT_NO=? AND CONT_NO=? "
						+ "AND CONT_REV=(SELECT MAX(CONT_REV) FROM FMS_SUPPLY_CONT_MST B WHERE A.COMPANY_CD=B.COMPANY_CD "
						+ "AND A.COUNTERPARTY_CD=B.COUNTERPARTY_CD AND A.AGMT_NO=B.AGMT_NO AND A.CONT_NO=B.CONT_NO AND A.CONTRACT_TYPE=B.CONTRACT_TYPE) ";
				stmt2 = conn.prepareStatement(queryString1);
				stmt2.setString(1, comp_cd);
				stmt2.setString(2, cont_type);
				stmt2.setString(3, countpty_cd);
				stmt2.setString(4, agmt);
				stmt2.setString(5, cont);
				rset2=stmt2.executeQuery();
				if(rset2.next())
				{
					contRef=rset2.getString(1)==null?"":rset2.getString(1);
					if(cont_type.equals("W"))
					{
						contRef=rset2.getString(2)==null?"":rset2.getString(2);
					}
				}
				rset2.close();
				stmt2.close();
				
				VCONT_REF_NO.add(contRef);
				
				String inv_cetegory=rset1.getString(39)==null?"":rset1.getString(39);
				String cash_flow="";
				if(inv_type.equals("LP"))
		    	{
					cash_flow="Interest";
		    	}
		    	else if(inv_type.equals("CR") || inv_type.equals("CCR"))
		    	{
		    		//cash_flow="Brokerage/Commission";
		    		cash_flow="Commodity";
		    	}
		    	else if(inv_cetegory.equals("P"))
				{
					cash_flow="Commodity";
				}
				else if(inv_cetegory.equals("S"))
				{
					cash_flow="Service";
				}
				VCASH_FLOW.add(cash_flow);
			}
			rset1.close();
			stmt1.close();
		}
		catch(Exception e)
		{
			new SystemErrorLogger().InsertErrorLogger(db_src_file_name, function_nm, e);
		}
	}
	
	public HttpServletRequest request = null;
	public void setRequest(HttpServletRequest request) {this.request = request;}
	
	String callFlag = "";
	public void setCallFlag(String callFlag) {this.callFlag = callFlag;}
	String comp_cd = "";
	public void setComp_cd(String comp_cd) {this.comp_cd = comp_cd;}
	String operation = "";
	public void setOperation(String operation) {this.operation = operation;}
	String opration = "";
	public void setOpration(String opration) {this.opration = opration;}
	
	String from_dt = "";
	String to_dt="";
	String segment = "";
	String gas_dt = "";
	String month = "";
	String year = "";
	String billing_cycle = "";
	String billing_freq="";
	String billing_flag = "";
	String period_start_dt="";
	String period_end_dt="";
	String temp_period_start_dt="";
	String temp_period_end_dt="";
	String counterparty_cd = "";
	String cont_no = "";
	String cont_rev_no = "";
	String agmt_no = "";
	String agmt_rev_no = "";
	String cargo_no = "";
	String contract_type = "";
	String plant_seq = "";
	String bu_unit = "";
	String inv_type = "";
	String address_type = "";
	String invoice_type = "";
	String refresh_flg = "";
	String inv_seq="";
	String inv_no="";
	String inv_dt="";
	String user_defined_dt="";
	String financial="";
	String sel_exchng_cd="";
	String activityFlag="";
	String financial_year="";
	String exist_financial_year="";
	String bu_state_tin="";
	String file_nm="";
	String emp_cd="";
	String print_pdf_type="";
	String view_pdf_type="";
	String mail_pdf_type="";
	String ff_print_pdf_type="";
	String ff_view_pdf_type="";
	String ff_mail_pdf_type="";
	String flag="";
	String is_attachment="";
	String mail_inv_type="";
	String exchange_rate_mapping="";
	String filter_cont_type="";
	String inv_flag="";
	String allocQty="";
	String temp_price="";
	String mapping_id="";
	String truck_trans_cd="";
	String truck_cd="";
	String xmlfile_name="";
	String sap_approval_flag="";
	String file_path="";
	String type_flag="";
	String driver_cd="";
	String check_post_cd="";
	String state="";
	String month_to = "";
	String year_to = "";
	String start_dt = "";
	String end_dt="";
	String paid_status="";
	
	public void setGas_dt(String gas_dt) {this.gas_dt = gas_dt;}
	public void setMonth(String month) {this.month = month;}
	public void setYear(String year) {this.year = year;}
	public void setBilling_cycle(String billing_cycle) {this.billing_cycle = billing_cycle;}
	public void setPeriod_start_dt(String period_start_dt) {this.period_start_dt = period_start_dt;}
	public void setPeriod_end_dt(String period_end_dt) {this.period_end_dt = period_end_dt;}
	public void setTemp_period_start_dt(String temp_period_start_dt) {this.temp_period_start_dt = temp_period_start_dt;}
	public void setTemp_period_end_dt(String temp_period_end_dt) {this.temp_period_end_dt = temp_period_end_dt;}
	public void setCounterparty_cd(String counterparty_cd) {this.counterparty_cd = counterparty_cd;}
	public void setCont_no(String cont_no) {this.cont_no = cont_no;}
	public void setCont_rev_no(String cont_rev_no) {this.cont_rev_no = cont_rev_no;}
	public void setAgmt_no(String agmt_no) {this.agmt_no = agmt_no;}
	public void setAgmt_rev_no(String agmt_rev_no) {this.agmt_rev_no = agmt_rev_no;}
	public void setCargo_no(String cargo_no) {this.cargo_no = cargo_no;}
	public void setContract_type(String contract_type) {this.contract_type = contract_type;}
	public void setPlant_seq(String plant_seq) {this.plant_seq = plant_seq;}
	public void setBu_unit(String bu_unit) {this.bu_unit = bu_unit;}
	public void setInv_type(String inv_type) {this.inv_type = inv_type;}
	public void setAddress_type(String address_type) {this.address_type = address_type;}
	public void setInvoice_type(String invoice_type) {this.invoice_type = invoice_type;}
	public void setRefresh_flg(String refresh_flg) {this.refresh_flg = refresh_flg;}
	public void setInv_seq(String inv_seq) {this.inv_seq = inv_seq;}
	public void setInv_no(String inv_no) {this.inv_no = inv_no;}
	public void setInv_dt(String inv_dt) {this.inv_dt = inv_dt;}
	public void setUser_defined_dt(String user_defined_dt) {this.user_defined_dt = user_defined_dt;}
	public void setFinancial(String financial) {this.financial = financial;}
	public void setSel_exchng_cd(String sel_exchng_cd) {this.sel_exchng_cd = sel_exchng_cd;}
	public void setActivityFlag(String activityFlag) {this.activityFlag = activityFlag;}
	public void setFinancial_year(String financial_year) {this.financial_year = financial_year;}
	public void setExist_financial_year(String exist_financial_year) {this.exist_financial_year = exist_financial_year;}
	public void setBu_state_tin(String bu_state_tin) {this.bu_state_tin = bu_state_tin;}
	public void setInvoice_seq(String invoice_seq) {this.invoice_seq = invoice_seq;}
	public void setFlag(String flag) {this.flag = flag;}
	public void setFilter_cont_type(String filter_cont_type) {this.filter_cont_type = filter_cont_type;}
	public void setInv_flag(String inv_flag) {this.inv_flag = inv_flag;}
	public void setAllocQty(String allocQty) {this.allocQty = allocQty;}
	public void setTemp_price(String temp_price) {this.temp_price = temp_price;}
	public void setMapping_id(String mapping_id) {this.mapping_id = mapping_id;}
	public void setTruck_trans_cd(String truck_trans_cd) {this.truck_trans_cd = truck_trans_cd;}
	public void setTruck_cd(String truck_cd) {this.truck_cd = truck_cd;}
	public void setXmlfile_name(String xmlfile_name) {this.xmlfile_name = xmlfile_name;}
	public void setSap_approval_flag(String sap_approval_flag) {this.sap_approval_flag = sap_approval_flag;}
	public void setInvoice_no(String invoice_no) {this.invoice_no = invoice_no;}
	public void setFile_path(String file_path) {this.file_path = file_path;}
	public void setType_flag(String type_flag) {this.type_flag = type_flag;}
	public void setDriver_cd(String driver_cd) {this.driver_cd = driver_cd;}
	public void setCheck_post_cd(String check_post_cd) {this.check_post_cd = check_post_cd;}
	public void setPaid_status(String paid_status) {this.paid_status = paid_status;}
	
	public String getPeriod_start_dt() {return period_start_dt;}
	public String getPeriod_end_dt() {return period_end_dt;}
	public String getTemp_period_start_dt() {return temp_period_start_dt;}
	public String getTemp_period_end_dt() {return temp_period_end_dt;}
	public String getUser_defined_dt() {return user_defined_dt;}
	public String getFinancial_year() {return financial_year;}
	public String getBu_state_tin() {return bu_state_tin;}
	
	public void setContact_person_cd(String contact_person_cd) {this.contact_person_cd = contact_person_cd;}
	public void setBu_contact_person_cd(String bu_contact_person_cd) {this.bu_contact_person_cd = bu_contact_person_cd;}
	public void setPrice_cd(String price_cd) {this.price_cd = price_cd;}
	public void setInvoice_raised_in(String invoice_raised_in) {this.invoice_raised_in = invoice_raised_in;}
	public void setInvoice_dt(String invoice_dt) {this.invoice_dt = invoice_dt;}
	
	public void setFile_nm(String file_nm) {this.file_nm = file_nm;}
	public void setEmp_cd(String emp_cd) {this.emp_cd = emp_cd;}
	public void setPrint_pdf_type(String print_pdf_type) {this.print_pdf_type = print_pdf_type;}
	public void setView_pdf_type(String view_pdf_type) {this.view_pdf_type = view_pdf_type;}
	public void setMail_pdf_type(String mail_pdf_type) {this.mail_pdf_type = mail_pdf_type;}
	public void setFf_print_pdf_type(String ff_print_pdf_type) {this.ff_print_pdf_type = ff_print_pdf_type;}
	public void setFf_view_pdf_type(String ff_view_pdf_type) {this.ff_view_pdf_type = ff_view_pdf_type;}
	public void setFf_mail_pdf_type(String ff_mail_pdf_type) {this.ff_mail_pdf_type = ff_mail_pdf_type;}
	public void setIs_attachment(String is_attachment) {this.is_attachment = is_attachment;}
	public void setMail_inv_type(String mail_inv_type) {this.mail_inv_type = mail_inv_type;}
	
	public void setExchange_rate_mapping(String exchange_rate_mapping) {this.exchange_rate_mapping = exchange_rate_mapping;}
	
	public String getExchange_rate_mapping() {return exchange_rate_mapping;}
	
	public void setMonth_to(String month_to) {this.month_to = month_to;}
	public void setYear_to(String year_to) {this.year_to = year_to;}
	
	public void setFrom_dt(String from_dt) {this.from_dt = from_dt;}
	public void setTo_dt(String to_dt) {this.to_dt = to_dt;}
	public void setSegment(String segment) {this.segment = segment;}
	
	String cform_cd = "";
	public void setCform_cd(String cform_cd) {this.cform_cd = cform_cd;}
	public void setState(String state) {this.state = state;}
	
	Vector VCOUNTERPTY_CD = new Vector();
	Vector VCOUNTERPTY_ABBR = new Vector();
	Vector VCOUNTERPTY_NM = new Vector();
	Vector VCONT_NO = new Vector();
	Vector VCONT_REV_NO = new Vector();
	Vector VAGMT_NO = new Vector();
	Vector VAGMT_REV_NO = new Vector();
	Vector VCARGO_NO = new Vector();
	Vector VSTART_DT = new Vector();
	Vector VEND_DT = new Vector();
	Vector VCONT_REF_NO = new Vector();
	Vector VCONTRACT_TYPE = new Vector();
	Vector VPLANT_SEQ = new Vector();
	Vector VPLANT_ABBR = new Vector();
	Vector VBU_PLANT_SEQ = new Vector();
	Vector VBU_PLANT_ABBR = new Vector();
	Vector VDEAL_NO = new Vector();
	Vector VAGMT_BASE = new Vector();
	Vector VTRUCK_CD = new Vector();
	Vector VTRUCK_NO = new Vector();
	Vector VBU_STATE_TIN = new Vector();
	Vector VFINANCIAL_YEAR = new Vector();
	Vector VINVOICE_SEQ = new Vector();
	Vector VINV_CHECKED_FLAG = new Vector();
	Vector VINV_APPROVED_FLAG = new Vector();
	Vector VINVOICE_EXIST = new Vector();
	Vector VTRUCK_TRANS_CD = new Vector();
	Vector VCOUNTERPARTY_CD = new Vector();
	Vector VCOUNTERPARTY_NM = new Vector();
	Vector VCOUNTERPARTY_ABBR = new Vector();
	Vector VCONT_NAME = new Vector();
	Vector VPERIOD_START_DT = new Vector();
	Vector VPERIOD_END_DT = new Vector();
	Vector VTEMP_PERIOD_START_DT = new Vector();
	Vector VTEMP_PERIOD_END_DT = new Vector();
	Vector VSEL_BU_CD = new Vector();
	Vector VSEL_BU_PLANT_SEQ_NO = new Vector();
	Vector VSEL_BU_PLANT_ABBR = new Vector();
	Vector VCONTACT_PERSON = new Vector();
	Vector VCONTACT_PERSON_CD = new Vector();
	Vector VBU_CONTACT_PERSON = new Vector();
	Vector VBU_CONTACT_PERSON_CD = new Vector();
	Vector VINVOICE_DT = new Vector();
	Vector VINVOICE_DUE_DT = new Vector();
	Vector VINVOICE_NO = new Vector();
	Vector VFREQ = new Vector();
	Vector VFREQ_NM = new Vector();
	Vector VALLOC_QTY = new Vector();
	Vector VEXCHNAGE_RATE = new Vector();
	Vector VSALES_PRICE = new Vector();
	Vector VSALES_PRICE_CD = new Vector();
	Vector VSALES_PRICE_NM = new Vector();
	Vector VSALES_PRICE_UNIT = new Vector();
	Vector VRATE_NM = new Vector();
	Vector VGROSS_AMT = new Vector();
	Vector VTAX_AMT = new Vector();
	Vector VINVOICE_AMT = new Vector();
	Vector VINVOICE_HOLD_AMT = new Vector();
	Vector VADJ_SIGN = new Vector();
	Vector VADJ_AMT = new Vector();
	Vector VNET_PAYABLE = new Vector();
	Vector VSALES_PRICE_USD = new Vector();
	Vector VSALES_PRICE_UNIT_USD = new Vector();
	Vector VRATE_NM_USD = new Vector();
	Vector VGROSS_AMT_USD = new Vector();
	Vector VTAX_AMT_USD = new Vector();
	Vector VINVOICE_AMT_USD = new Vector();
	Vector VADJ_SIGN_USD = new Vector();
	Vector VADJ_AMT_USD = new Vector();
	Vector VNET_PAYABLE_USD = new Vector();
	Vector VMAPPING_ID = new Vector();
	Vector VADDRESS_TYPE = new Vector();
	Vector VADDRESS_NAME = new Vector();
	Vector VLINK_INVOICE_NO = new Vector();
	Vector VSTATUS = new Vector();
	Vector VINVOICE_TYPE = new Vector();
	Vector VINVOICE_TYPE_NM = new Vector();
	Vector VINVOICE_CATEGORY = new Vector();
	Vector VINVOICE_REF = new Vector();
	Vector VLINE_NO = new Vector();
	Vector VLINE_DESC = new Vector();
	Vector VUNIT = new Vector();
	Vector VQTY = new Vector();
	Vector VRATE = new Vector();
	Vector VAMOUNT = new Vector();
	Vector VBILLING_FREQ_FLAG = new Vector();
	Vector VBILLING_FREQ_NM = new Vector();
	Vector VEXCHNG_RATE_CD = new Vector();
	Vector VEXCHNG_RATE_NM = new Vector();
	Vector VEXCHNG_RATE_FLAG = new Vector();
	Vector VMULTI_TAX_STRUCT = new Vector();
	
	Vector VP_EXCHNG_RATE_CD = new Vector();
	Vector VP_EXCHNG_RATE_VALUE = new Vector();
	Vector VP_BG_COLOR = new Vector();
	Vector VB_EXCHNG_RATE_CD = new Vector();
	Vector VB_EXCHNG_RATE_VALUE = new Vector();
	Vector VB_BG_COLOR = new Vector();
	Vector VU_EXCHNG_RATE_CD = new Vector();
	Vector VU_EXCHNG_RATE_VALUE = new Vector();
	Vector VU_BG_COLOR = new Vector();
	Vector VEXCHNG_RATE_CAL_CD = new Vector();
	Vector VEXCHNG_RATE_CAL_VAL = new Vector();
	Vector VEXCHNG_RATE_CAL_COLOR = new Vector();
	
	Vector VALLOCATION_DT = new Vector();
	Vector VPRICE = new Vector();
	Vector VALLOCATION_QTY = new Vector();
	Vector VAMOUNT_USD = new Vector();
	Vector VAMOUNT_INR = new Vector();
	
	Vector VPDF_COL1 = new Vector();
	Vector VPDF_COL2 = new Vector();
	Vector VPDF_COL3 = new Vector();
	Vector VPDF_COL4 = new Vector();
	Vector VPDF_COL5 = new Vector();
	Vector VPDF_COL6 = new Vector();
	Vector VPDF_COL7 = new Vector();
	
	Vector VINVOICE_ID_SEQ = new Vector();
	Vector VDIFF_COLOR = new Vector();
	Vector VPDF_INV_FLAG = new Vector();
	Vector VPDF_TYPE = new Vector();
	Vector VPDF_FILE_NAME=new Vector();
	Vector VPDF_FILE_PATH=new Vector();
	Vector VPDF_SIGNED_FLAG=new Vector();
	Vector VSIGN_PDF_TYPE = new Vector();

	Vector VMAIL_PDF_TYPE = new Vector();
	Vector VMAIL_PDF_TYPE_NM = new Vector();
	Vector VMAIL_FROM_LIST = new Vector();
	Vector VMAIL_TO_LIST = new Vector();
	Vector VMAIL_CC_LIST = new Vector();
	Vector VMAIL_BCC_LIST = new Vector();
	Vector VMAIL_SUBJECT = new Vector();
	Vector VMAIL_ATTACHMENT = new Vector();
	Vector VMAIL_ANNEXURE_ATTACHMENT_FLAG = new Vector();
	Vector VMAIL_ATTACHMENT_PATH = new Vector();
	Vector VMAIL_ANNEXURE_ATTACHMENT_PATH = new Vector();
	Vector VMAIL_BODY = new Vector();
	
	Vector VSAP_APPROVAL_FLAG = new Vector();
	Vector VOTH_SAP_APPROVAL_FLAG = new Vector();
	Vector VFILTER_CONT_TYPE = new Vector();
	Vector VFILTER_CONT_NAME = new Vector();
	
	Vector VINVOICE_LIST_ABBR = new Vector();
	Vector VINVOICE_LIST_NAME = new Vector();
	Vector VINDEX = new Vector();
	Vector VIS_IRN_GENERATED = new Vector();
	Vector VINV_FLAG = new Vector();
	Vector VBOE_ENTRY = new Vector();
	Vector VCARGO_NM = new Vector();
	Vector VATT_INVOICE_NO = new Vector();
	
	// For SAP XML
	Vector VLINESEQNO = new Vector();
	Vector VPOSTINGKEY = new Vector();
	Vector VACCOUNT = new Vector();
	Vector VCURRENCYAMOUNT = new Vector();
	Vector VBUSINESSAREA = new Vector();
	Vector VITEMTEXT = new Vector();
	Vector VSHORTTEXT = new Vector();
	
	Vector VDRIVER_CD = new Vector();
	Vector VDRIVER_NM = new Vector();
	Vector VCHECKPOST_CD = new Vector();
	Vector VCHECKPOST_NAME = new Vector();
	Vector VGENERATED_FORM_402_PATH = new Vector();

	Vector VCFORM_CD = new Vector();
	Vector VCFORM_NO = new Vector();
	Vector VCFORM_DT = new Vector();
	Vector VISSUING_STATE = new Vector();
	Vector VPERIOD_FROM = new Vector();
	Vector VPERIOD_TO = new Vector();
	Vector VCFORM_AMOUNT = new Vector();
	Vector VCFORM_FILE = new Vector();
	Vector VNO_OF_INVOICES = new Vector();
	Vector VCFORM_FINANCIAL_YEAR = new Vector();
	
	Vector VINVOICE_COMMODITY = new Vector();
	Vector VCFORM_ENTRY_EXIST = new Vector();
	Vector VSTATE_CD = new Vector();
	Vector VSTATE_NM = new Vector();
	
	Vector VMST_COUNTERPARTY_CD = new Vector();
	Vector VMST_COUNTERPARTY_NM = new Vector();
	Vector VMST_COUNTERPARTY_ABBR = new Vector();
	
	Vector VSEGMENT = new Vector();
	Vector VSEGMENT_TYPE = new Vector();
	Vector VTEMP_SEGMENT = new Vector();
	Vector VTEMP_SEGMENT_TYPE = new Vector();
	
	Vector VDIS_CONT_MAPPING = new Vector();
	Vector VCONTRACT_TYPE_NM = new Vector();
	Vector VNET_PAYABLE_AMT = new Vector();
	Vector VTDS_TCS_FLAG = new Vector();
	Vector VTCS_AMT = new Vector();
	Vector VTCS_FACTOR = new Vector();
	Vector VTDS_GROSS_PERCENT = new Vector();
	Vector VTDS_GROSS_AMT = new Vector();
	Vector VTDS_TAX_PERCENT = new Vector();
	Vector VTDS_TAX_AMT = new Vector();
	Vector VPAY_RECV_AMT = new Vector();
	Vector VPAY_RECV_DT = new Vector();
	Vector VTAX_STRUCT_DTL = new Vector();
	Vector VSHORT_RECEIVED = new Vector();
	Vector VPAY_RECV_HISTORY = new Vector();
	Vector VPAYMENT_DONE_IN = new Vector();
	Vector VSALES_AMT = new Vector();
	Vector VTYPE_FLAG = new Vector();
	Vector VINVOICE_RAISED_IN = new Vector();
	
	Vector VTOTAL_ADV_AMT = new Vector();
	Vector VCONT_MAP = new Vector();
	Vector VCFORM_FLAG = new Vector();
	Vector VHOLD_AMT = new Vector();
	
	Vector VOTH_TRUCK_CD = new Vector();
	Vector VOTH_TRUCK_REG_NO = new Vector();
	Vector VOTH_COUNTERPTY_CD = new Vector();
	Vector VOTH_COUNTERPTY_NM = new Vector();
	Vector VOTH_COUNTERPTY_ABBR = new Vector();
	Vector VOTH_CONT_NO = new Vector();
	Vector VOTH_CONT_REV_NO = new Vector();
	Vector VOTH_AGMT_NO = new Vector();
	Vector VOTH_AGMT_REV_NO = new Vector();
	Vector VOTH_CONTRACT_TYPE = new Vector();
	Vector VOTH_DEAL_NO = new Vector();
	Vector VOTH_PLANT_SEQ = new Vector();
	Vector VOTH_PLANT_ABBR = new Vector();
	Vector VOTH_BU_PLANT_SEQ = new Vector();
	Vector VOTH_BU_PLANT_ABBR = new Vector();
	Vector VOTH_START_DT = new Vector();
	Vector VOTH_END_DT = new Vector();
	Vector VOTH_CONT_NAME = new Vector();
	Vector VOTH_CONT_REF_NO = new Vector();
	Vector VOTH_PERIOD_START_DT = new Vector();
	Vector VOTH_PERIOD_END_DT = new Vector();
	Vector VOTH_INVOICE_NO = new Vector();
	Vector VOTH_DIS_INVOICE_NO = new Vector();
	Vector VOTH_STATUS = new Vector();
	Vector VOTH_BILLING_FREQ_FLAG = new Vector();
	Vector VOTH_BILLING_FREQ_NM = new Vector();
	Vector VOTH_INVOICE_SEQ = new Vector();
	Vector VOTH_INVOICE_EXIST = new Vector();
	Vector VOTH_INV_CHECKED_FLAG = new Vector();
	Vector VOTH_INV_APPROVED_FLAG = new Vector();
	Vector VOTH_PDF_INV_FLAG = new Vector();
	Vector VOTH_PDF_TYPE = new Vector();
	Vector VOTH_PDF_FILE_NAME = new Vector();
	Vector VOTH_PDF_FILE_PATH=new Vector();
	Vector VOTH_PDF_SIGNED_FLAG=new Vector();
	Vector VOTH_SIGN_PDF_TYPE = new Vector();
	Vector VOTH_FINANCIAL_YEAR = new Vector();
	Vector VOTH_INVOICE_TYPE = new Vector();
	Vector VOTH_BU_STATE_TIN = new Vector();
	Vector VOTH_IS_IRN_GENERATED = new Vector();
	
	Vector VANNEXURE_SEQ = new Vector();
	Vector VANNEXURE_FILE_NM = new Vector();
	Vector VANNEXURE_FOLDER = new Vector();

	Vector VMST_SAC_CD = new Vector();
	Vector VMST_SAC_CODE = new Vector();
	
	Vector VBU_NM = new Vector();
	Vector VTCS_TDS = new Vector();
	Vector VCASH_FLOW = new Vector();
	Vector VFIN_SYS = new Vector();
	
	public Vector getVFIN_SYS() {return VFIN_SYS;}
	public Vector getVBU_NM() {return VBU_NM;}
	public Vector getVTCS_TDS() {return VTCS_TDS;}
	public Vector getVCASH_FLOW() {return VCASH_FLOW;}
	
	public Vector getVCOUNTERPTY_CD() {return VCOUNTERPTY_CD;}
	public Vector getVCOUNTERPTY_ABBR() {return VCOUNTERPTY_ABBR;}
	public Vector getVCOUNTERPTY_NM() {return VCOUNTERPTY_NM;}
	public Vector getVCONT_NO() {return VCONT_NO;}
	public Vector getVCONT_REV_NO() {return VCONT_REV_NO;}
	public Vector getVAGMT_NO() {return VAGMT_NO;}
	public Vector getVAGMT_REV_NO() {return VAGMT_REV_NO;}
	public Vector getVCARGO_NO() {return VCARGO_NO;}
	public Vector getVSTART_DT() {return VSTART_DT;}
	public Vector getVEND_DT() {return VEND_DT;}
	public Vector getVCONT_REF_NO() {return VCONT_REF_NO;}
	public Vector getVCONTRACT_TYPE() {return VCONTRACT_TYPE;}
	public Vector getVPLANT_SEQ() {return VPLANT_SEQ;}
	public Vector getVPLANT_ABBR() {return VPLANT_ABBR;}
	public Vector getVBU_PLANT_SEQ() {return VBU_PLANT_SEQ;}
	public Vector getVBU_PLANT_ABBR() {return VBU_PLANT_ABBR;}
	public Vector getVDEAL_NO() {return VDEAL_NO;}
	public Vector getVAGMT_BASE() {return VAGMT_BASE;}
	public Vector getVTRUCK_CD() {return VTRUCK_CD;}
	public Vector getVTRUCK_NO() {return VTRUCK_NO;}
	public Vector getVBU_STATE_TIN() {return VBU_STATE_TIN;}
	public Vector getVFINANCIAL_YEAR() {return VFINANCIAL_YEAR;}
	public Vector getVINVOICE_SEQ() {return VINVOICE_SEQ;}
	public Vector getVINV_CHECKED_FLAG() {return VINV_CHECKED_FLAG;}
	public Vector getVINV_APPROVED_FLAG() {return VINV_APPROVED_FLAG;}
	public Vector getVINVOICE_EXIST() {return VINVOICE_EXIST;}
	public Vector getVTRUCK_TRANS_CD() {return VTRUCK_TRANS_CD;}
	public Vector getVCOUNTERPARTY_CD() {return VCOUNTERPARTY_CD;}
	public Vector getVCOUNTERPARTY_NM() {return VCOUNTERPARTY_NM;}
	public Vector getVCOUNTERPARTY_ABBR() {return VCOUNTERPARTY_ABBR;}
	public Vector getVPERIOD_START_DT() {return VPERIOD_START_DT;}
	public Vector getVPERIOD_END_DT() {return VPERIOD_END_DT;}
	public Vector getVTEMP_PERIOD_START_DT() {return VTEMP_PERIOD_START_DT;}
	public Vector getVTEMP_PERIOD_END_DT() {return VTEMP_PERIOD_END_DT;}
	public Vector getVSEL_BU_CD() {return VSEL_BU_CD;}
	public Vector getVSEL_BU_PLANT_SEQ_NO() {return VSEL_BU_PLANT_SEQ_NO;}
	public Vector getVSEL_BU_PLANT_ABBR() {return VSEL_BU_PLANT_ABBR;}
	public Vector getVCONTACT_PERSON() {return VCONTACT_PERSON;}
	public Vector getVCONTACT_PERSON_CD() {return VCONTACT_PERSON_CD;}
	public Vector getVBU_CONTACT_PERSON() {return VBU_CONTACT_PERSON;}
	public Vector getVBU_CONTACT_PERSON_CD() {return VBU_CONTACT_PERSON_CD;}
	public Vector getVINVOICE_DT() {return VINVOICE_DT;}
	public Vector getVINVOICE_DUE_DT() {return VINVOICE_DUE_DT;}
	public Vector getVINVOICE_NO() {return VINVOICE_NO;}
	public Vector getVFREQ() {return VFREQ;}
	public Vector getVFREQ_NM() {return VFREQ_NM;}
	public Vector getVALLOC_QTY() {return VALLOC_QTY;}
	public Vector getVEXCHNAGE_RATE() {return VEXCHNAGE_RATE;}
	public Vector getVSALES_PRICE() {return VSALES_PRICE;}
	public Vector getVSALES_PRICE_CD() {return VSALES_PRICE_CD;}
	public Vector getVSALES_PRICE_NM() {return VSALES_PRICE_NM;}
	public Vector getVSALES_PRICE_UNIT() {return VSALES_PRICE_UNIT;}
	public Vector getVRATE_NM() {return VRATE_NM;}
	public Vector getVGROSS_AMT() {return VGROSS_AMT;}
	public Vector getVTAX_AMT() {return VTAX_AMT;}
	public Vector getVINVOICE_AMT() {return VINVOICE_AMT;}
	public Vector getVINVOICE_HOLD_AMT() {return VINVOICE_HOLD_AMT;}
	public Vector getVADJ_SIGN() {return VADJ_SIGN;}
	public Vector getVADJ_AMT() {return VADJ_AMT;}
	public Vector getVNET_PAYABLE() {return VNET_PAYABLE;}
	public Vector getVSALES_PRICE_USD() {return VSALES_PRICE_USD;}
	public Vector getVSALES_PRICE_UNIT_USD() {return VSALES_PRICE_UNIT_USD;}
	public Vector getVRATE_NM_USD() {return VRATE_NM_USD;}
	public Vector getVGROSS_AMT_USD() {return VGROSS_AMT_USD;}
	public Vector getVTAX_AMT_USD() {return VTAX_AMT_USD;}
	public Vector getVINVOICE_AMT_USD() {return VINVOICE_AMT_USD;}
	public Vector getVADJ_SIGN_USD() {return VADJ_SIGN_USD;}
	public Vector getVADJ_AMT_USD() {return VADJ_AMT_USD;}
	public Vector getVNET_PAYABLE_USD() {return VNET_PAYABLE_USD;}
	public Vector getVMAPPING_ID() {return VMAPPING_ID;}
	public Vector getVADDRESS_TYPE() {return VADDRESS_TYPE;}
	public Vector getVADDRESS_NAME() {return VADDRESS_NAME;}
	public Vector getVLINK_INVOICE_NO() {return VLINK_INVOICE_NO;}
	public Vector getVSTATUS() {return VSTATUS;}
	public Vector getVINVOICE_TYPE() {return VINVOICE_TYPE;}
	public Vector getVINVOICE_TYPE_NM() {return VINVOICE_TYPE_NM;}
	public Vector getVINVOICE_CATEGORY() {return VINVOICE_CATEGORY;}
	public Vector getVINVOICE_REF() {return VINVOICE_REF;}
	public Vector getVLINE_NO() {return VLINE_NO;}
	public Vector getVLINE_DESC() {return VLINE_DESC;}
	public Vector getVUNIT() {return VUNIT;}
	public Vector getVQTY() {return VQTY;}
	public Vector getVRATE() {return VRATE;}
	public Vector getVAMOUNT() {return VAMOUNT;}
	public Vector getVBILLING_FREQ_FLAG() {return VBILLING_FREQ_FLAG;}
	public Vector getVBILLING_FREQ_NM() {return VBILLING_FREQ_NM;}
	public Vector getVEXCHNG_RATE_CD() {return VEXCHNG_RATE_CD;}
	public Vector getVEXCHNG_RATE_NM() {return VEXCHNG_RATE_NM;}
	public Vector getVEXCHNG_RATE_FLAG() {return VEXCHNG_RATE_FLAG;}
	public Vector getVMULTI_TAX_STRUCT() {return VMULTI_TAX_STRUCT;}
	
	public Vector getVP_EXCHNG_RATE_CD() {return VP_EXCHNG_RATE_CD;}
	public Vector getVP_EXCHNG_RATE_VALUE() {return VP_EXCHNG_RATE_VALUE;}
	public Vector getVP_BG_COLOR() {return VP_BG_COLOR;}
	public Vector getVB_EXCHNG_RATE_CD() {return VB_EXCHNG_RATE_CD;}
	public Vector getVB_EXCHNG_RATE_VALUE() {return VB_EXCHNG_RATE_VALUE;}
	public Vector getVB_BG_COLOR() {return VB_BG_COLOR;}
	public Vector getVU_EXCHNG_RATE_CD() {return VU_EXCHNG_RATE_CD;}
	public Vector getVU_EXCHNG_RATE_VALUE() {return VU_EXCHNG_RATE_VALUE;}
	public Vector getVU_BG_COLOR() {return VU_BG_COLOR;}
	public Vector getVEXCHNG_RATE_CAL_CD() {return VEXCHNG_RATE_CAL_CD;}
	public Vector getVEXCHNG_RATE_CAL_VAL() {return VEXCHNG_RATE_CAL_VAL;}
	public Vector getVEXCHNG_RATE_CAL_COLOR() {return VEXCHNG_RATE_CAL_COLOR;}
	
	public Vector getVALLOCATION_DT() {return VALLOCATION_DT;}
	public Vector getVPRICE() {return VPRICE;}
	public Vector getVALLOCATION_QTY() {return VALLOCATION_QTY;}
	public Vector getVAMOUNT_USD() {return VAMOUNT_USD;}
	public Vector getVAMOUNT_INR() {return VAMOUNT_INR;}
	
	public Vector getVPDF_COL1() {return VPDF_COL1;}
	public Vector getVPDF_COL2() {return VPDF_COL2;}
	public Vector getVPDF_COL3() {return VPDF_COL3;}
	public Vector getVPDF_COL4() {return VPDF_COL4;}
	public Vector getVPDF_COL5() {return VPDF_COL5;}
	public Vector getVPDF_COL6() {return VPDF_COL6;}
	public Vector getVPDF_COL7() {return VPDF_COL7;}
	
	public Vector getVINVOICE_ID_SEQ() {return VINVOICE_ID_SEQ;}
	public Vector getVDIFF_COLOR() {return VDIFF_COLOR;}
	public Vector getVPDF_INV_FLAG() {return VPDF_INV_FLAG;}
	public Vector getVPDF_TYPE() {return VPDF_TYPE;}
	public Vector getVPDF_FILE_NAME() {return VPDF_FILE_NAME;}
	public Vector getVPDF_FILE_PATH() {return VPDF_FILE_PATH;}
	public Vector getVPDF_SIGNED_FLAG() {return VPDF_SIGNED_FLAG;}
	public Vector getVSIGN_PDF_TYPE() {return VSIGN_PDF_TYPE;}
	
	public Vector getVMAIL_PDF_TYPE() {return VMAIL_PDF_TYPE;}
	public Vector getVMAIL_PDF_TYPE_NM() {return VMAIL_PDF_TYPE_NM;}
	public Vector getVMAIL_FROM_LIST() {return VMAIL_FROM_LIST;}
	public Vector getVMAIL_TO_LIST() {return VMAIL_TO_LIST;}
	public Vector getVMAIL_CC_LIST() {return VMAIL_CC_LIST;}
	public Vector getVMAIL_BCC_LIST() {return VMAIL_BCC_LIST;}
	public Vector getVMAIL_SUBJECT() {return VMAIL_SUBJECT;}
	public Vector getVMAIL_ATTACHMENT() {return VMAIL_ATTACHMENT;}
	public Vector getVMAIL_ANNEXURE_ATTACHMENT_FLAG() {return VMAIL_ANNEXURE_ATTACHMENT_FLAG;}
	public Vector getVMAIL_ATTACHMENT_PATH() {return VMAIL_ATTACHMENT_PATH;}
	public Vector getVMAIL_ANNEXURE_ATTACHMENT_PATH() {return VMAIL_ANNEXURE_ATTACHMENT_PATH;}
	public Vector getVMAIL_BODY() {return VMAIL_BODY;}
	
	public Vector getVSAP_APPROVAL_FLAG() {return VSAP_APPROVAL_FLAG;}
	public Vector getVOTH_SAP_APPROVAL_FLAG() {return VOTH_SAP_APPROVAL_FLAG;}
	public Vector getVFILTER_CONT_TYPE() {return VFILTER_CONT_TYPE;}
	public Vector getVFILTER_CONT_NAME() {return VFILTER_CONT_NAME;}
	
	public Vector getVINVOICE_LIST_ABBR() {return VINVOICE_LIST_ABBR;}
	public Vector getVINVOICE_LIST_NAME() {return VINVOICE_LIST_NAME;}
	public Vector getVINDEX() {return VINDEX;}
	public Vector getVIS_IRN_GENERATED() {return VIS_IRN_GENERATED;}
	public Vector getVINV_FLAG() {return VINV_FLAG;}
	public Vector getVBOE_ENTRY() {return VBOE_ENTRY;}
	public Vector getVCARGO_NM() {return VCARGO_NM;}
	public Vector getVATT_INVOICE_NO() {return VATT_INVOICE_NO;}
	
	public Vector getVLINESEQNO() {return VLINESEQNO;}
	public Vector getVPOSTINGKEY() {return VPOSTINGKEY;}
	public Vector getVACCOUNT() {return VACCOUNT;}
	public Vector getVCURRENCYAMOUNT() {return VCURRENCYAMOUNT;}
	public Vector getVBUSINESSAREA() {return VBUSINESSAREA;}
	public Vector getVITEMTEXT() {return VITEMTEXT;}
	public Vector getVSHORTTEXT() {return VSHORTTEXT;}
	
	public Vector getVDRIVER_CD() {return VDRIVER_CD;}
	public Vector getVDRIVER_NM() {return VDRIVER_NM;}
	public Vector getVCHECKPOST_CD() {return VCHECKPOST_CD;}
	public Vector getVCHECKPOST_NAME() {return VCHECKPOST_NAME;}
	public Vector getVGENERATED_FORM_402_PATH() {return VGENERATED_FORM_402_PATH;}
	
	public Vector getVCFORM_CD() {return VCFORM_CD;}
	public Vector getVCFORM_NO() {return VCFORM_NO;}
	public Vector getVCFORM_DT() {return VCFORM_DT;}
	public Vector getVISSUING_STATE() {return VISSUING_STATE;}
	public Vector getVPERIOD_FROM() {return VPERIOD_FROM;}
	public Vector getVPERIOD_TO() {return VPERIOD_TO;}
	public Vector getVCFORM_AMOUNT() {return VCFORM_AMOUNT;}
	public Vector getVCFORM_FILE() {return VCFORM_FILE;}
	public Vector getVNO_OF_INVOICES() {return VNO_OF_INVOICES;}
	public Vector getVCFORM_FINANCIAL_YEAR() {return VCFORM_FINANCIAL_YEAR;}
	
	public Vector getVINVOICE_COMMODITY() {return VINVOICE_COMMODITY;}
	public Vector getVCFORM_ENTRY_EXIST() {return VCFORM_ENTRY_EXIST;}
	public Vector getVSTATE_CD() {return VSTATE_CD;}
	public Vector getVSTATE_NM() {return VSTATE_NM;}
	
	public Vector getVMST_COUNTERPARTY_CD() {return VMST_COUNTERPARTY_CD;}
	public Vector getVMST_COUNTERPARTY_NM() {return VMST_COUNTERPARTY_NM;}
	public Vector getVMST_COUNTERPARTY_ABBR() {return VMST_COUNTERPARTY_ABBR;}
	
	public Vector getVSEGMENT() {return VSEGMENT;}
	public Vector getVSEGMENT_TYPE() {return VSEGMENT_TYPE;}
	public Vector getVTEMP_SEGMENT() {return VTEMP_SEGMENT;}
	public Vector getVTEMP_SEGMENT_TYPE() {return VTEMP_SEGMENT_TYPE;}
	
	public Vector getVDIS_CONT_MAPPING() {return VDIS_CONT_MAPPING;}
	public Vector getVCONTRACT_TYPE_NM() {return VCONTRACT_TYPE_NM;}
	public Vector getVNET_PAYABLE_AMT() {return VNET_PAYABLE_AMT;}
	public Vector getVTDS_TCS_FLAG() {return VTDS_TCS_FLAG;}
	public Vector getVTCS_AMT() {return VTCS_AMT;}
	public Vector getVTCS_FACTOR() {return VTCS_FACTOR;}
	public Vector getVTDS_GROSS_PERCENT() {return VTDS_GROSS_PERCENT;}
	public Vector getVTDS_GROSS_AMT() {return VTDS_GROSS_AMT;}
	public Vector getVTDS_TAX_PERCENT() {return VTDS_TAX_PERCENT;}
	public Vector getVTDS_TAX_AMT() {return VTDS_TAX_AMT;}
	public Vector getVPAY_RECV_AMT() {return VPAY_RECV_AMT;}
	public Vector getVPAY_RECV_DT() {return VPAY_RECV_DT;}
	public Vector getVTAX_STRUCT_DTL() {return VTAX_STRUCT_DTL;}
	public Vector getVSHORT_RECEIVED() {return VSHORT_RECEIVED;}
	public Vector getVPAY_RECV_HISTORY() {return VPAY_RECV_HISTORY;}
	public Vector getVPAYMENT_DONE_IN() {return VPAYMENT_DONE_IN;}
	public Vector getVSALES_AMT() {return VSALES_AMT;}
	public Vector getVTYPE_FLAG() {return VTYPE_FLAG;}
	public Vector getVINVOICE_RAISED_IN() {return VINVOICE_RAISED_IN;}
	
	public Vector getVTOTAL_ADV_AMT() {return VTOTAL_ADV_AMT;}
	public Vector getVCONT_MAP() {return VCONT_MAP;}
	public Vector getVCFORM_FLAG() {return VCFORM_FLAG;}
	public Vector getVHOLD_AMT() {return VHOLD_AMT;}
	
	public Vector getVOTH_TRUCK_CD() {return VOTH_TRUCK_CD;}
	public Vector getVOTH_TRUCK_REG_NO() {return VOTH_TRUCK_REG_NO;}
	public Vector getVOTH_COUNTERPTY_CD() {return VOTH_COUNTERPTY_CD;}
	public Vector getVOTH_COUNTERPTY_NM() {return VOTH_COUNTERPTY_NM;}
	public Vector getVOTH_COUNTERPTY_ABBR() {return VOTH_COUNTERPTY_ABBR;}
	public Vector getVOTH_CONT_NO() {return VOTH_CONT_NO;}
	public Vector getVOTH_CONT_REV_NO() {return VOTH_CONT_REV_NO;}
	public Vector getVOTH_AGMT_NO() {return VOTH_AGMT_NO;}
	public Vector getVOTH_AGMT_REV_NO() {return VOTH_AGMT_REV_NO;}
	public Vector getVOTH_CONTRACT_TYPE() {return VOTH_CONTRACT_TYPE;}
	public Vector getVOTH_DEAL_NO() {return VOTH_DEAL_NO;}
	public Vector getVOTH_PLANT_SEQ() {return VOTH_PLANT_SEQ;}
	public Vector getVOTH_PLANT_ABBR() {return VOTH_PLANT_ABBR;}
	public Vector getVOTH_BU_PLANT_SEQ() {return VOTH_BU_PLANT_SEQ;}
	public Vector getVOTH_BU_PLANT_ABBR() {return VOTH_BU_PLANT_ABBR;}
	public Vector getVOTH_START_DT() {return VOTH_START_DT;}
	public Vector getVOTH_END_DT() {return VOTH_END_DT;}
	public Vector getVOTH_CONT_NAME() {return VOTH_CONT_NAME;}
	public Vector getVOTH_CONT_REF_NO() {return VOTH_CONT_REF_NO;}
	public Vector getVOTH_PERIOD_START_DT() {return VOTH_PERIOD_START_DT;}
	public Vector getVOTH_PERIOD_END_DT() {return VOTH_PERIOD_END_DT;}
	public Vector getVOTH_INVOICE_NO() {return VOTH_INVOICE_NO;}
	public Vector getVOTH_DIS_INVOICE_NO() {return VOTH_DIS_INVOICE_NO;}
	public Vector getVOTH_STATUS() {return VOTH_STATUS;}
	public Vector getVOTH_BILLING_FREQ_FLAG() {return VOTH_BILLING_FREQ_FLAG;}
	public Vector getVOTH_BILLING_FREQ_NM() {return VOTH_BILLING_FREQ_NM;}
	public Vector getVOTH_INVOICE_SEQ() {return VOTH_INVOICE_SEQ;}
	public Vector getVOTH_INVOICE_EXIST() {return VOTH_INVOICE_EXIST;}
	public Vector getVOTH_INV_CHECKED_FLAG() {return VOTH_INV_CHECKED_FLAG;}
	public Vector getVOTH_INV_APPROVED_FLAG() {return VOTH_INV_APPROVED_FLAG;}
	public Vector getVOTH_PDF_INV_FLAG() {return VOTH_PDF_INV_FLAG;}
	public Vector getVOTH_PDF_TYPE() {return VOTH_PDF_TYPE;}
	public Vector getVOTH_PDF_FILE_NAME() {return VOTH_PDF_FILE_NAME;}
	public Vector getVOTH_PDF_FILE_PATH() {return VOTH_PDF_FILE_PATH;}
	public Vector getVOTH_PDF_SIGNED_FLAG() {return VOTH_PDF_SIGNED_FLAG;}
	public Vector getVOTH_SIGN_PDF_TYPE() {return VOTH_SIGN_PDF_TYPE;}
	public Vector getVOTH_INVOICE_TYPE() {return VOTH_INVOICE_TYPE;}
	public Vector getVOTH_FINANCIAL_YEAR() {return VOTH_FINANCIAL_YEAR;}
	public Vector getVOTH_BU_STATE_TIN() {return VOTH_BU_STATE_TIN;}
	public Vector getVOTH_IS_IRN_GENERATED() {return VOTH_IS_IRN_GENERATED;}
	
	public Vector getVANNEXURE_SEQ() {return VANNEXURE_SEQ;}
	public Vector getVANNEXURE_FILE_NM() {return VANNEXURE_FILE_NM;}
	public Vector getVANNEXURE_FOLDER() {return VANNEXURE_FOLDER;}

	public Vector getVMST_SAC_CD() {return VMST_SAC_CD;}
	public Vector getVMST_SAC_CODE() {return VMST_SAC_CODE;}
	
	String billing_freq_nm="";
	String couterpty_abbr="";
	String couterpty_nm="";
	String deal_no="";
	String plant_abbr="";
	String bu_plant_abbr="";
	String qty_mmbtu="";
	String sac_no="";
	String price="";
	String price_cd="";
	String price_cd_nm="";
	String cont_start_dt="";
	String contact_person_cd="0";
	String contact_person_nm="";
	String bu_contact_person_cd="0";
	String bu_contact_person_nm="";
	String invoice_raised_in="";
	String invoice_raised_in_nm="";
	String payment_done_in="";
	String payment_done_in_nm="";
	String due_days="";
	String exchng_rate_cd="";
	String exchng_rate_cal="";
	String exchang_rate="";
	String exchang_rate_dt="";
	String exchang_rate_type="";
	String exchang_criteria="";
	String invoice_seq="";
	String invoice_no="";
	String invoice_ref="";
	String invoice_dt = "";
	String invoice_due_dt = "";
	String consider_due_dt_in="";
	String exclude_sat="";
	String holiday_state="";
	String gross_amt="";
	String gross_amt1="";
	String remark_1="";
	String remark_2="";
	String last_avlb_exchng_dt="";
	String lable_inv_criteria="";
	String lable_inv_date="";
	String correction_msg="";
	String daily_tot_amt_inr="";
	String daily_tot_amt_usd="";
	String daily_tot_qty="";
	String tax_amt="";
	String tax_struct_cd="";
	String tax_struct_dt="";
	String tax_struct_dtl="";
	String tax_info="";
	String tax_factor="";
	String invoice_amt="";
	String net_payable="";
	String previousFinancialYear="";
	String total_transaction_amt="";
	String applicable_flag="";
	String applicable_amt="";
	String applicable_abbr="";
	String sellerTurnoverFlag="";
	String buyerTurnoverFlag="";
	String TCS_factor="";
	String total_InvoiceAmt="";
	String inv_period_start_dt="";
	String inv_period_end_dt="";
	String signingDt="";
	String agmtSigningDt="";
	String contract_ref="";
	String tcs_struct_cd="";
	String tcs_struct_dt="";
	String tcs_struct_info="";
	String tds_amt="";
	String tds_factor="";
	String tds_struct_cd="";
	String tds_struct_dt="";
	String tds_struct_info="";
	
	String plantAddress="";
	String plantCity="";
	String plantState="";
	String plantPin="";
	String plantNm="";
	
	String bu_plantAddress="";
	String bu_plantCity="";
	String bu_plantState="";
	String bu_plantPin="";
	String bu_plantNm="";
	
	String bu_tax_info="";
	String activity_value="";
	String contRef="";
	String dda_dt="";
	
	String invoice_id_seq="";
	String fixed_exchng_val="";
	
	String invoice_check_flag = "";
	String invoice_check_dt = "";
	String invoice_check_by = "";
	String invoice_check_nm = "";
	String invoice_auth_flag = "";
	String invoice_auth_dt = "";
	String invoice_auth_by = "";
	String invoice_auth_nm = "";
	String invoice_aprv_flag = "";
	String invoice_aprv_dt = "";
	String invoice_aprv_by = "";
	String invoice_aprv_nm = "";
	String invoice_category="";
	String num_line="1";
	String linked_invoice="";
	String note="";
	String other_inv_str="";
	String amount_in_word="";
	String tax_struct_info="";
	String invoice_adj_amt = "";
	
	String agmt_base = "";
	String transportation_charges = "";
	String transportation_amount = "";
	String gross_include_transport_tariff = "";
	String marketing_margin = "";
	String marketing_margin_amount = "";
	String other_charges = "";
	String other_charges_amount = "";
	
	String dcq = "";
	
	String total_exchng_label = "";
	String total_exchng_label_rate = "";
	String source = "";
	
	String inv_entered_on="";
	String inv_approved_on="";
	
	String sub_inv_type="";
	
	String plant_gstin_no="";
	String bu_gstin_no="";
	String sug_percentage="";
	String sug_qty="";
	String discount_days="";
	String storage_start_dt="";
	String storage_end_dt="";
	String arrivalDt="";
	
	String documentType="";
	String documentDate="";
	String documentNo="";
	String postingDate="";
	String accountingPeriodMonth="";
	String accountingPeriodYear="";
	String headerCompanyCode="";
	String docHeaderText="";
	String refNum ="";
	String currency="";
	
	String counterparty_nm="";
	String counterparty_abbr="";
	
	String sap_approved_by="";
	String sap_approved_dt="";
	
	String zeroTotal ="";
	String isFreezed="";
	String eodProcessDoneOn = "";
	
	String gen_type="";
	String sap_msg_status="";
	String sap_doc_no="";
	String sap_ack_msg="";
	String billing_days="";
	String driver_nm="";
	String driver_addr="";
	String licence_no="";
	String licence_issue_state="";
	String truck_no="";
	String transporter_name="";
	String transporter_addr="";
	String cust_vat_no="";
	String cust_cst_no="";
	String cust_gst_no="";
	String cust_vat_dt="";
	String cust_cst_dt="";
	String cust_gst_dt="";
	String check_post_nm="";
	String bu_cst_no="";
	String bu_cst_dt="";
	String not="";
	
	String linked_driver_cd="";
	String linked_checkpost_cd="";
	
	String noOfInvoice="";
	String cform_serial_no="";
	String cform_dt="";
	String period_from="";
	String period_to="";
	String cform_amount="";
	String cform_file="";
	
	public String getBilling_freq_nm() {return billing_freq_nm;}
	public String getCouterpty_abbr() {return couterpty_abbr;}
	public String getCouterpty_nm() {return couterpty_nm;}
	public String getDeal_no() {return deal_no;}
	public String getPlant_abbr() {return plant_abbr;}
	public String getBu_plant_abbr() {return bu_plant_abbr;}
	public String getQty_mmbtu() {return qty_mmbtu;}
	public String getSac_no() {return sac_no;}
	public String getPrice() {return price;}
	public String getPrice_cd() {return price_cd;}
	public String getPrice_cd_nm() {return price_cd_nm;}
	public String getCont_start_dt() {return cont_start_dt;}
	public String getContact_person_cd() {return contact_person_cd;}
	public String getContact_person_nm() {return contact_person_nm;}
	public String getBu_contact_person_cd() {return bu_contact_person_cd;}
	public String getBu_contact_person_nm() {return bu_contact_person_nm;}
	public String getInvoice_raised_in() {return invoice_raised_in;}
	public String getInvoice_raised_in_nm() {return invoice_raised_in_nm;}
	public String getPayment_done_in() {return payment_done_in;}
	public String getPayment_done_in_nm() {return payment_done_in_nm;}
	public String getDue_days() {return due_days;}
	public String getExchng_rate_cd() {return exchng_rate_cd;}
	public String getExchng_rate_cal() {return exchng_rate_cal;}
	public String getExchang_rate() {return exchang_rate;}
	public String getExchang_rate_dt() {return exchang_rate_dt;}
	public String getExchang_rate_type() {return exchang_rate_type;}
	public String getExchang_criteria() {return exchang_criteria;}
	public String getInvoice_seq() {return invoice_seq;}
	public String getInvoice_no() {return invoice_no;}
	public String getInvoice_ref() {return invoice_ref;}
	public String getInvoice_dt() {return invoice_dt;}
	public String getInvoice_due_dt() {return invoice_due_dt;}
	public String getConsider_due_dt_in() {return consider_due_dt_in;}
	public String getExclude_sat() {return exclude_sat;}
	public String getHoliday_state() {return holiday_state;}
	public String getGross_amt() {return gross_amt;}
	public String getGross_amt1() {return gross_amt1;}
	public String getRemark_1() {return remark_1;}
	public String getRemark_2() {return remark_2;}
	public String getLast_avlb_exchng_dt() {return last_avlb_exchng_dt;}
	public String getLable_inv_criteria() {return lable_inv_criteria;}
	public String getLable_inv_date() {return lable_inv_date;}
	public String getCorrection_msg() {return correction_msg;}
	public String getDaily_tot_amt_inr() {return daily_tot_amt_inr;}
	public String getDaily_tot_amt_usd() {return daily_tot_amt_usd;}
	public String getDaily_tot_qty() {return daily_tot_qty;}
	public String getTax_amt() {return tax_amt;}
	public String getTax_struct_cd() {return tax_struct_cd;}
	public String getTax_struct_dt() {return tax_struct_dt;}
	public String getTax_struct_dtl() {return tax_struct_dtl;}
	public String getTax_info() {return tax_info;}
	public String getTax_factor() {return tax_factor;}
	public String getInvoice_amt() {return invoice_amt;}
	public String getNet_payable() {return net_payable;}
	public String getPreviousFinancialYear() {return previousFinancialYear;}
	public String getTotal_transaction_amt() {return total_transaction_amt;}
	public String getApplicable_flag() {return applicable_flag;}
	public String getApplicable_amt() {return applicable_amt;}
	public String getApplicable_abbr() {return applicable_abbr;}
	public String getSellerTurnoverFlag() {return sellerTurnoverFlag;}
	public String getBuyerTurnoverFlag() {return buyerTurnoverFlag;}
	public String getTCS_factor() {return TCS_factor;}
	public String getTotal_InvoiceAmt() {return total_InvoiceAmt;}
	public String getInv_period_start_dt() {return inv_period_start_dt;}
	public String getInv_period_end_dt() {return inv_period_end_dt;}
	public String getSigningDt() {return signingDt;}
	public String getAgmtSigningDt() {return agmtSigningDt;}
	public String getContract_ref() {return contract_ref;}
	public String getTcs_struct_cd() {return tcs_struct_cd;}
	public String getTcs_struct_dt() {return tcs_struct_dt;}
	public String getTcs_struct_info() {return tcs_struct_info;}
	public String getTds_amt() {return tds_amt;}
	public String getTds_factor() {return tds_factor;}
	public String getTds_struct_cd() {return tds_struct_cd;}
	public String getTds_struct_dt() {return tds_struct_dt;}
	public String getTds_struct_info() {return tds_struct_info;}
	
	public String getPlantAddress() {return plantAddress;}
	public String getPlantCity() {return plantCity;}
	public String getPlantState() {return plantState;}
	public String getPlantPin() {return plantPin;}
	public String getPlantNm() {return plantNm;}
	
	public String getBu_plantAddress() {return bu_plantAddress;}
	public String getBu_plantCity() {return bu_plantCity;}
	public String getBu_plantState() {return bu_plantState;}
	public String getBu_plantPin() {return bu_plantPin;}
	public String getBu_plantNm() {return bu_plantNm;}
	
	public String getBu_tax_info() {return bu_tax_info;}
	public String getActivity_value() {return activity_value;}
	
	public String getContRef() {return contRef;}
	public String getDda_dt() {return dda_dt;}
	
	public String getInvoice_id_seq() {return invoice_id_seq;}
	
	public String getInvoice_check_flag() {return invoice_check_flag;}
	public String getInvoice_check_dt() {return invoice_check_dt;}
	public String getInvoice_check_by() {return invoice_check_by;}
	public String getInvoice_check_nm() {return invoice_check_nm;}
	public String getInvoice_auth_flag() {return invoice_auth_flag;}
	public String getInvoice_auth_dt() {return invoice_auth_dt;}
	public String getInvoice_auth_by() {return invoice_auth_by;}
	public String getInvoice_auth_nm() {return invoice_auth_nm;}
	public String getInvoice_aprv_flag() {return invoice_aprv_flag;}
	public String getInvoice_aprv_dt() {return invoice_aprv_dt;}
	public String getInvoice_aprv_by() {return invoice_aprv_by;}
	public String getInvoice_aprv_nm() {return invoice_aprv_nm;}
	public String getInvoice_category() {return invoice_category;}
	public String getNum_line() {return num_line;}
	public String getLinked_invoice() {return linked_invoice;}
	public String getNote() {return note;}
	public String getOther_inv_str() {return other_inv_str;}
	public String getAmount_in_word() {return amount_in_word;}
	public String getTax_struct_info() {return tax_struct_info;}
	public String getInvoice_adj_amt() {return invoice_adj_amt;}
	
	public String getAgmt_base() {return agmt_base;}
	public String getTransportation_charges() {return transportation_charges;}
	public String getTransportation_amount() {return transportation_amount;}
	public String getGross_include_transport_tariff() {return gross_include_transport_tariff;}
	public String getMarketing_margin() {return marketing_margin;}
	public String getMarketing_margin_amount() {return marketing_margin_amount;}
	public String getOther_charges() {return other_charges;}
	public String getOther_charges_amount() {return other_charges_amount;}
	
	public String getDcq() {return dcq;}
	
	public String getTotal_exchng_label() {return total_exchng_label;}
	public String getTotal_exchng_label_rate() {return total_exchng_label_rate;}
	public String getSource() {return source;}
	
	public String getInv_entered_on() {return inv_entered_on;}
	public String getInv_approved_on() {return inv_approved_on;}
	
	public String getSub_inv_type() {return sub_inv_type;}
	public String getPlant_gstin_no() {return plant_gstin_no;}
	public String getBu_gstin_no() {return bu_gstin_no;}
	public String getSug_percentage() {return sug_percentage;}
	public String getSug_qty() {return sug_qty;}
	public String getDiscount_days() {return discount_days;}
	public String getStorage_start_dt() {return storage_start_dt;}
	public String getStorage_end_dt() {return storage_end_dt;}
	public String getArrivalDt() {return arrivalDt;}
	
	public String getGen_type() {return gen_type;}
	
	public String getDocumentType() {return documentType;}
	public String getDocumentDate() {return documentDate;}
	public String getDocumentNo() {return documentNo;}
	public String getPostingDate() {return postingDate;}
	public String getAccountingPeriodMonth() {return accountingPeriodMonth;}
	public String getAccountingPeriodYear() {return accountingPeriodYear;}
	public String getHeaderCompanyCode() {return headerCompanyCode;}
	public String getDocHeaderText() {return docHeaderText;}
	public String getRefNum() {return refNum;}
	public String getCurrency() {return currency;}
	
	public String getCounterparty_nm() {return counterparty_nm;}
	public String getCounterparty_abbr() {return counterparty_abbr;}
	
	public String getXmlfile_name() {return xmlfile_name;}
	
	public String getSap_approved_by() {return sap_approved_by;}
	public String getSap_approved_dt() {return sap_approved_dt;}
	
	public String getZeroTotal() {return zeroTotal;}
	public String getIsFreezed() {return isFreezed;}
	public String getEodProcessDoneOn() {return eodProcessDoneOn;}
	
	public String getSap_doc_no() {return sap_doc_no;}
	public String getSap_msg_status() {return sap_msg_status;}
	public String geSap_ack_msg() {return sap_ack_msg;}
	public String getBilling_days() {return billing_days;}
	
	public String getDriver_nm() {return driver_nm;}
	public String getDriver_addr() {return driver_addr;}
	public String getLicence_no() {return licence_no;}
	public String getLicence_issue_state() {return licence_issue_state;}
	public String getTruck_no() {return truck_no;}
	public String getTransporter_name() {return transporter_name;}
	public String getTransporter_addr() {return transporter_addr;}
	public String getCust_vat_no() {return cust_vat_no;}
	public String getCust_cst_no() {return cust_cst_no;}
	public String getCust_gst_no() {return cust_gst_no;}
	public String getCust_vat_dt() {return cust_vat_dt;}
	public String getCust_cst_dt() {return cust_cst_dt;}
	public String getCust_gst_dt() {return cust_gst_dt;}
	public String getCheck_post_nm() {return check_post_nm;}
	public String getBu_cst_no() {return bu_cst_no;}
	public String getBu_cst_dt() {return bu_cst_dt;}
	public String getNot() {return not;}
	
	public String getLinked_driver_cd() {return linked_driver_cd;}
	public String getLinked_checkpost_cd() {return linked_checkpost_cd;}
	
	public String getNoOfInvoice() {return noOfInvoice;}
	public String getCform_serial_no() {return cform_serial_no;}
	public String getCform_dt() {return cform_dt;}
	public String getPeriod_from() {return period_from;}
	public String getPeriod_to() {return period_to;}
	public String getCform_amount() {return cform_amount;}
	public String getCform_file() {return cform_file;}
	
	boolean submission_chk = false;
	boolean correction_needed = false;
	double mdcq_percentage=100;
	
	public boolean getSubmission_chk() {return submission_chk;}
	public boolean getCorrection_needed() {return correction_needed;}
	
	HashMap contWiseAdvAmt = new HashMap();
	
	public HashMap getContWiseAdvAmt() {return contWiseAdvAmt;}
}
