<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<%@ include file="../util/common_js.jsp"%>
<script>
function refresh(clearance)
{
	var prev_clearance = document.forms[0].prev_clearance.value;
	var counterparty_cd = document.forms[0].counterparty_cd.value;
	
	if(prev_clearance != clearance)
	{
		counterparty_cd="";
	}
	
	var u = document.forms[0].u.value;
		
	var url = "frm_cash_collateral.jsp?counterparty_cd="+counterparty_cd+"&clearance="+clearance+"&u="+u;
			
	document.getElementById("loading").style.visibility = "visible";
	location.replace(url);
}

var newWindow;
function openTcsTdsStructMst(tax_app)
{
	var type="P";
		
	var newWindow;
	if(!newWindow || newWindow.closed)
	{
		newWindow = window.open("frm_tcs_tds_tax_structure_list.jsp?type="+type+"&tax_app="+tax_app,"Tax Structure List","top=10,left=10,width=1100,height=600,scrollbars=1");
	}
	else
	{
		newWindow.close();
		newWindow = window.open("frm_tcs_tds_tax_structure_list.jsp?type="+type+"&tax_app="+tax_app,"Tax Structure List","top=10,left=10,width=1100,height=600,scrollbars=1");
	}
}

function setTcsTdsStructDetail(tax_struct_cd,tax_struct_nm,tax_struct_eff_dt,tax_app)
{
	if(tax_app=="TCS")
	{
		var info = "TCS ("+tax_struct_nm+")";
		document.forms[0].tcs_struct_info.value=info
		document.forms[0].tcs_cd.value=tax_struct_cd
		document.forms[0].tcs_dt.value=tax_struct_eff_dt
	}
	else
	{
		var info = "TDS ("+tax_struct_nm+")";
		document.forms[0].tds_struct_info.value=info
		document.forms[0].tds_cd.value=tax_struct_cd
		document.forms[0].tds_dt.value=tax_struct_eff_dt
	}
}

function doGenXML(couterpty_cd,clearance,seq_no, seq_rev_no, sap_approval_flag,sec_ref_no,isReversal, isPrintPdf)
{
	var u = document.forms[0].u.value;
	
	var url = "rpt_view_advance_sap_approval.jsp?&counterparty_cd="+couterpty_cd+
			"&clearance="+clearance+"&seq_no="+seq_no+"&seq_rev_no="+seq_rev_no+"&sap_approval_flag="+sap_approval_flag+
			"&sec_ref_no="+sec_ref_no+"&isReversal="+isReversal+"&isPrintPdf="+isPrintPdf+"&u="+u;
			

	if(!newWindow || newWindow.closed)
	{
		newWindow = window.open(url,"Advance SAP Approval","top=10,left=10,width=1100,height=900,scrollbars=1");
	}
	else
	{
		newWindow.close();
		newWindow = window.open(url,"Advance SAP Approval","top=10,left=10,width=1100,height=900,scrollbars=1");
	}
}

function printPDF(counterparty_cd,seq_no, seq_rev_no, clearance, isReversal)
{
	//JD: We we need to change file name here?
	var url = "view_advance_remittance.jsp?counterparty_cd="+counterparty_cd+"&seq_no="+seq_no+
		"&seq_rev_no="+seq_rev_no+"&gx="+clearance+"&isReversal="+isReversal;
	
	if(!newWindow || newWindow.closed)
	{
		newWindow = window.open(url,"Generate Advance Remittance PDF","top=10,left=10,width=1200,height=600,scrollbars=1");
	}
	else
	{
		newWindow.close();
		newWindow = window.open(url,"Generate Advance Remittance PDF","top=10,left=10,width=1200,height=600,scrollbars=1");
	}
}

function openPdfFile(url)
{
	window.open(url);
}

function validateCP()
{
	var counterparty_cd = document.forms[0].counterparty_cd.value;
	if(trim(counterparty_cd)=="")
	{
		alert("Select Counterparty!");
	}
	else
	{
		doClear();
		document.forms[0].counterparty.value=counterparty_cd;
		document.forms[0].counterparty.style.pointerEvents='none';
		$("#AddNewSecurity").modal("show");
	}
}

function doSubmitDealNo()
{
	var chk_deal = document.forms[0].chk_deal;
	var deal_dtl = document.forms[0].deal_dtl;
	var display_deal_dtl = document.forms[0].display_deal_dtl;
	var cont_deal_type = document.forms[0].cont_deal_type;
	
	var display ="";
	if(chk_deal!=null && chk_deal.length!=undefined)
 	{
  		for(var i=0;i<chk_deal.length;i++)
  		{
   			if(chk_deal[i].checked)
   			{
   				deal_dtl[i].disabled=false;
   				document.forms[0].deal_type.value=cont_deal_type[i].value;
   				if(display!="")
   				{
   					display+=", "+display_deal_dtl[i].value;
   				}
   				else
   				{
   					display+=display_deal_dtl[i].value;
   				}
   			}
   			else
   			{
   				deal_dtl[i].disabled=true;
			}
  		} 
 	}
 	else if(chk_deal!=null)
 	{
   		if(chk_deal.checked)
     	{	
   			deal_dtl.disabled=false;
   			document.forms[0].deal_type.value=cont_deal_type.value;
   			if(display!="")
			{
				display+=", "+display_deal_dtl.value;
			}
			else
			{
				display+=display_deal_dtl.value;
			}
   		}
   		else
   		{
   			deal_dtl.disabled=true;
		}
 	}
	
	document.getElementById("DealNoDisplay").innerHTML=display;
	if(display != "")
	{
		document.getElementById("DealNoDisplay").style.display="inline";
	}
	$("#DealNoModel").modal("hide");
}

function doClear()
{
	document.forms[0].counterparty.value="";
	document.forms[0].ref_no.value="";
	document.forms[0].seq_no.value="";
	document.forms[0].seq_rev_no.value="";
	document.forms[0].sec_type.value="";
	document.forms[0].crdr.value="";
	document.forms[0].value.value="";
	document.forms[0].tds_cd.value="";
	document.forms[0].tds_dt.value="";
	document.forms[0].tds_struct_info.value="";
	document.forms[0].tds_amt.value="";
	document.forms[0].received_dt.value="";
	document.forms[0].pg_ref.value="";
	document.forms[0].deal_type.value="";
	document.forms[0].status.value="";
	document.forms[0].remark.value="";
	
	document.getElementById("model_hder_nm").innerHTML="Add Cash Collateral";
	document.getElementById("DealNoDisplay").style.display="none";
	
	document.getElementById("modelBodyParam").style.pointerEvents='auto'
	document.getElementById("attch_cont_btn").style.pointerEvents='auto';
	document.forms[0].status.style.pointerEvents='auto';
	document.forms[0].remark.style.pointerEvents='auto';
	document.getElementById("div_id_btn").style.display="";
	
	document.getElementById("opt1").style.display='none';
	document.getElementById("opt2").style.display='block';
	document.getElementById("opt3").style.display='none';
	
	var chk_deal = document.forms[0].chk_deal;
	var deal_dtl = document.forms[0].deal_dtl;
	var deal_exp = document.forms[0].deal_exp;
	if(chk_deal!=null && chk_deal.length!=undefined)
 	{
  		for(var i=0;i<chk_deal.length;i++)
  		{
   			chk_deal[i].checked=false
   			deal_dtl[i].disabled=true;
   			
   			if(deal_exp[i].value=="Y")
   			{
   				document.getElementById("tbtr_"+i).style.display="none";
			}
   		} 
 	}
 	else if(chk_deal!=null)
 	{
   		chk_deal.checked=false
   		deal_dtl.disabled=true;
   		
   		if(deal_exp.value=="Y")
		{
			document.getElementById("tbtr_0").style.display="none";
		}
 	}
	
	doSubmitDealNo();
	
	document.forms[0].opration.value="INSERT";
}

function doModify(counterparty,ref_no,seq_no,seq_rev_no,sec_type,deal_no,crdr,value,currency,tds_cd,tds_dt,tds_struct_info,tds_amt,received_dt,pg_ref,deal_type,status,remark,operation)
{
	doClear()
	
	document.forms[0].counterparty.value=counterparty;
	document.forms[0].counterparty.style.pointerEvents='none';
	document.forms[0].ref_no.value=ref_no;
	document.forms[0].seq_no.value=seq_no;
	document.forms[0].seq_rev_no.value=seq_rev_no;
	document.forms[0].sec_type.value=sec_type;
	document.forms[0].crdr.value=crdr;
	document.forms[0].value.value=value;
	document.forms[0].currency.value=currency;
	document.forms[0].tds_cd.value=tds_cd;
	document.forms[0].tds_dt.value=tds_dt;
	document.forms[0].tds_struct_info.value=tds_struct_info;
	document.forms[0].tds_amt.value=tds_amt;
	document.forms[0].received_dt.value=received_dt;
	document.forms[0].pg_ref.value=pg_ref;
	document.forms[0].deal_type.value=deal_type;
	document.forms[0].status.value=status;
	document.forms[0].remark.value=remark;
	
	if(operation=="MODIFY")
	{
		document.getElementById("model_hder_nm").innerHTML="Modify Cash Collateral";
		document.getElementById("modelBodyParam").style.pointerEvents='auto';
		document.getElementById("attch_cont_btn").style.pointerEvents='auto';
		document.forms[0].status.style.pointerEvents='auto';
		document.forms[0].remark.style.pointerEvents='auto';
		document.getElementById("div_id_btn").style.display="";
		
		document.getElementById("opt1").style.display='none';
		document.getElementById("opt2").style.display='block';
		document.getElementById("opt3").style.display='block';
	}
	else if(operation=="CHECK")
	{
		document.getElementById("model_hder_nm").innerHTML="Check(Deal) Cash Collateral";
		document.getElementById("modelBodyParam").style.pointerEvents='none';
		document.getElementById("attch_cont_btn").style.pointerEvents='auto';
		document.forms[0].status.style.pointerEvents='none';
		document.forms[0].remark.style.pointerEvents='auto';
		document.getElementById("div_id_btn").style.display="";
		
		document.getElementById("opt1").style.display='block';
		document.getElementById("opt2").style.display='block';
		document.getElementById("opt3").style.display='block';
	}
	else if(operation=="APPROVE")
	{
		document.getElementById("model_hder_nm").innerHTML="Approve Cash Collateral";
		document.getElementById("modelBodyParam").style.pointerEvents='none';
		document.getElementById("attch_cont_btn").style.pointerEvents='none';
		document.forms[0].status.style.pointerEvents='auto';
		document.forms[0].remark.style.pointerEvents='auto';
		document.getElementById("div_id_btn").style.display="";
		
		document.getElementById("opt1").style.display='block';
		document.getElementById("opt2").style.display='none';
		document.getElementById("opt3").style.display='none';
	}
	else
	{
		document.getElementById("model_hder_nm").innerHTML="View Cash Collateral";
		document.getElementById("modelBodyParam").style.pointerEvents='none'
		document.getElementById("attch_cont_btn").style.pointerEvents='none';
		document.forms[0].status.style.pointerEvents='none';
		document.forms[0].remark.style.pointerEvents='none';
		document.getElementById("div_id_btn").style.display="none";
		
		document.getElementById("opt1").style.display='block';
		document.getElementById("opt2").style.display='block';
		document.getElementById("opt3").style.display='block';
	}
	
	var chk_deal = document.forms[0].chk_deal;
	var deal_dtl = document.forms[0].deal_dtl;
	var deal_exp = document.forms[0].deal_exp;
	if(chk_deal!=null && chk_deal.length!=undefined)
 	{
  		for(var i=0;i<chk_deal.length;i++)
  		{
			if(deal_no==deal_dtl[i].value)
			{
				chk_deal[i].checked=true
   				deal_dtl[i].disabled=false;
				
				if(deal_exp[i].value=="Y")
	   			{
	   				document.getElementById("tbtr_"+i).style.display="";
				}
			}
			else
			{
   				chk_deal[i].checked=false
   				deal_dtl[i].disabled=true;
   				
   				if(deal_exp[i].value=="Y")
   	   			{
   	   				document.getElementById("tbtr_"+i).style.display="none";
   				}
			}
   		} 
 	}
 	else if(chk_deal!=null)
 	{
 		if(deal_no==deal_dtl.value)
		{
			chk_deal.checked=true
			deal_dtl.disabled=false;
			
			if(deal_exp.value=="Y")
   			{
   				document.getElementById("tbtr_0").style.display="";
			}
		}
		else
		{
			chk_deal.checked=false
			deal_dtl.disabled=true;
			
			if(deal_exp.value=="Y")
   			{
   				document.getElementById("tbtr_0").style.display="none";
			}
		}
 	}
 	
	doSubmitDealNo()
	
	document.forms[0].opration.value="MODIFY";
}

function doSubmit()
{
	var counterparty = document.forms[0].counterparty.value;
	var sec_type = document.forms[0].sec_type.value;
	var received_dt = document.forms[0].received_dt.value;
	var currency = document.forms[0].currency.value;
	var value = document.forms[0].value.value;
	var remark = document.forms[0].remark.value;
	var pg_ref = document.forms[0].pg_ref.value;
	var status = document.forms[0].status.value;
	var crdr = document.forms[0].crdr.value;
	var tds_cd = document.forms[0].tds_cd.value;
	var tds_dt = document.forms[0].tds_dt.value;
	var tds_amt = document.forms[0].tds_amt.value;
	
	var chk_deal = document.forms[0].chk_deal;
	
	var opration = document.forms[0].opration.value;
	var msg="";
	var flag=true;
	
	if(trim(counterparty)=="")
	{
		msg+="Please Select Counterparty!\n";
		flag=false;
	}
	if(trim(sec_type)=="")
	{
		msg+="Please Select Cash Collateral Type!\n";
		flag=false;
	}
	if(trim(crdr)=="")
	{
		msg+="Please Select Credit | Debit!\n";
		flag=false;
	}
	if(trim(value)=="")
	{
		msg+="Please Enter Amount!\n";
		flag=false;
	}
	if(trim(currency)=="")
	{
		msg+="Please Select Currency!\n";
		flag=false;
	}
	if(trim(tds_amt)!="")
	{
		if(parseFloat(tds_amt) > 0)
		{
			var cnt=0;
			if(trim(tds_cd)=="")
			{
				cnt++;
			}
			if(trim(tds_dt)=="")
			{
				cnt++;
			}
			
			if(parseInt(cnt) > 0)
			{
				msg+="Please Config TDS Structure Detail!\n";
				flag=false;
			}
		}
	}
	else
	{
		msg+="Please Enter TDS Amount!\n";
		flag=false;
	}
	if(trim(received_dt)=="")
	{
		msg+="Please Enter Pay/Received Date!\n";
		flag=false;
	}
	if(trim(status)=="O")
	{
		var cnt=0;
		if(chk_deal!=null && chk_deal.length!=undefined)
	 	{
	  		for(var i=0;i<chk_deal.length;i++)
	  		{
	   			if(chk_deal[i].checked)
	   			{
					cnt++;
				}
	   		} 
	 	}
	 	else if(chk_deal!=null)
	 	{
	 		if(chk_deal.checked)
   			{
				cnt++;
			}
	 	}
		
		if(parseInt(cnt) == 0)
		{
			msg+="Please Select atleast one Contract!\n";
			flag=false;
		}
	}
	if(trim(pg_ref)=="")
	{
		msg+="Please Enter Transaction Ref!\n";
		flag=false;
	}
	if(trim(status)=="")
	{
		msg+="Please Select Status!\n";
		flag=false;
	}
	
	if(flag)
	{
		var a = confirm("Do you want to "+opration+" the Cash Collateral Details?");
		if(a)
		{
			document.getElementById("loading").style.visibility = "visible";
			document.forms[0].submit();
		}
	}
	else
	{
		alert(msg);
	}
}

function doDealEnabled(obj,index)
{
	if(obj.checked)
	{
		document.getElementById("deal_dtl_"+index).disabled=false;
	}
	else
	{
		document.getElementById("deal_dtl_"+index).disabled=true;
	}
}
</script>
</head>
<jsp:useBean class="com.etrm.fms.credit_risk.DataBean_Advance" id="advance" scope="request"></jsp:useBean>
<jsp:useBean class="com.etrm.fms.util.MessageUtil" id="utilmsg" scope="request"></jsp:useBean>
<%
String counterparty_cd=request.getParameter("counterparty_cd")==null?"":request.getParameter("counterparty_cd");
String clearance = request.getParameter("clearance")==null?"K":request.getParameter("clearance");

advance.setCallFlag("CASH_COLLATERAL_MANAGEMENT");
advance.setCounterparty_cd(counterparty_cd);
advance.setClearance(clearance);
advance.setComp_cd(owner_cd);
advance.init();

if(counterparty_cd.equals(""))
{
	counterparty_cd=advance.getCounterparty_cd();
}

Vector VMST_COUNTERPARTY_CD = advance.getVMST_COUNTERPARTY_CD();
Vector VMST_COUNTERPARTY_NM = advance.getVMST_COUNTERPARTY_NM();
Vector VMST_COUNTERPARTY_ABBR = advance.getVMST_COUNTERPARTY_ABBR();

Vector VCOUNTERPARTY_CD = advance.getVCOUNTERPARTY_CD();
Vector VCOUNTERPARTY_NAME = advance.getVCOUNTERPARTY_NAME();
Vector VCOUNTERPARTY_ABBR = advance.getVCOUNTERPARTY_ABBR();
Vector VSEC_TYPE = advance.getVSEC_TYPE();
Vector VSEC_REF_NO = advance.getVSEC_REF_NO();
Vector VSTATUS = advance.getVSTATUS();
Vector VCURRENCY = advance.getVCURRENCY();
Vector VCURRENCY_NM = advance.getVCURRENCY_NM();
Vector VCRDR = advance.getVCRDR();
Vector VCRDR_NM = advance.getVCRDR_NM();
Vector VVALUE = advance.getVVALUE();
Vector VTOTAL_VALUE = advance.getVTOTAL_VALUE();
Vector VRECEIVED_DATE = advance.getVRECEIVED_DATE();
Vector VSEQ_NO = advance.getVSEQ_NO();
Vector VSEQ_REV_NO = advance.getVSEQ_REV_NO();
Vector VADV_PG_REF = advance.getVADV_PG_REF();
Vector VDEAL_TYPE = advance.getVDEAL_TYPE();
Vector VDEAL_NO = advance.getVDEAL_NO();
Vector VREMARK = advance.getVREMARK();
Vector VPDF_GENERATED = advance.getVPDF_GENERATED();
Vector VPDF_FILE_NAME = advance.getVPDF_FILE_NAME();
Vector VSAP_APPROVAL_FLAG = advance.getVSAP_APPROVAL_FLAG();
Vector VTDS_AMT = advance.getVTDS_AMT();
Vector VTDS_STRUCT_CD = advance.getVTDS_STRUCT_CD();
Vector VTDS_STRUCT_INFO = advance.getVTDS_STRUCT_INFO();
Vector VTDS_EFF_DT = advance.getVTDS_EFF_DT();
Vector VTEMP_SEC_REF_NO = advance.getVTEMP_SEC_REF_NO();
Vector VDEAL_MAPPING = advance.getVDEAL_MAPPING();

Vector VAGMT_NO = advance.getVAGMT_NO();
Vector VAGMT_REV_NO = advance.getVAGMT_REV_NO();
Vector VCONT_NO = advance.getVCONT_NO();
Vector VCONT_REV_NO = advance.getVCONT_REV_NO();
Vector VCONTRACT_TYPE = advance.getVCONTRACT_TYPE();
Vector VCONTRACT_MAPPING = advance.getVCONTRACT_MAPPING();
Vector VCONTRACT_MAPPING_DIS = advance.getVCONTRACT_MAPPING_DIS();
Vector VCONTRACT_MAPPING_DIS_1 = advance.getVCONTRACT_MAPPING_DIS_1();
Vector VCONTRACT_EXPIRED = advance.getVCONTRACT_EXPIRED();
Vector VCONTRACT_DEAL_TYPE = advance.getVCONTRACT_DEAL_TYPE();


String context_nm = request.getContextPath();
String server_nm = request.getServerName();
String server_port = ""+request.getServerPort();
String url=CommonVariable.app_protocol+"://"+server_nm+":"+server_port+context_nm+"//";
String file_url = CommonVariable.app_protocol+"://"+server_nm+":"+server_port+context_nm+"//"+CommonVariable.work_dir+owner_cd+"//security//adv//";
//System.out.println("VPDF_GENERATED...."+VPDF_GENERATED+"...VPDF_REV_GENERATED..."+VPDF_REV_GENERATED);

%>
<body>
<%@ include file="../home/header.jsp"%>

<form method="post" action="../servlet/Frm_Advance">
<div class="box-body">
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
			<%if(!msg.equals("")){
				if(msg_type.equals("S")){%>
					<div class="fadealert"><%=utilmsg.successMessage(msg)%></div>
				<%}else if(msg_type.equals("E")){%>
					<div class="fadealert"><%= utilmsg.errorMessage(msg)%></div>
				<%}
			} %>
			<div class="card cardmain">
				<div class="card-header cdheader">
					 <div class="d-flex justify-content-between">
						<div class="topheader">
				    		Cash Collateral Management  
	   	 				</div>
				    </div>
				</div>
				<div class="card-body cdbody">
					<div class="row" >
						<div class="col-sm-12 col-xs-12 col-md-12">
							<div align="center">
								<div class="btn-group" >
									<label class="btn btn-outline-secondary subbtngrp1 <%if(clearance.equals("K")){%>btnactive<%}%>" onclick="refresh('K')">KYC</label>
									<label class="btn btn-outline-secondary subbtngrp1 <%if(clearance.equals("I")){%>btnactive<%}%>" onclick="refresh('I')">IGX</label>
								</div>
							</div>
						</div>
					</div>
					<div class="row">						
						<div class="col-sm-12 col-xs-12 col-md-12">
							<div class="d-flex justify-content-between">
								<div class="form-group row">
									<div class="col-auto">
										<label class="form-label"><b>Counterparty</b></label>
									</div>
									<div class="col-auto">
										<select class="form-select form-select-sm" name="counterparty_cd" onchange="refresh('<%=clearance%>')">
											<option value="">--Select--</option>
											<%for(int i=0;i<VMST_COUNTERPARTY_CD.size();i++){ %>
												<option value="<%=VMST_COUNTERPARTY_CD.elementAt(i)%>"><%=VMST_COUNTERPARTY_ABBR.elementAt(i)%> - <%=VMST_COUNTERPARTY_NM.elementAt(i) %></option>
											<%} %> 
										</select>
										<script>document.forms[0].counterparty_cd.value="<%=counterparty_cd%>"</script>
									</div> 
								</div>
								<div class="btn-group" align="right">
									<!-- <label class="btn btn-outline-secondary subbtngrp1" data-bs-toggle="modal" data-bs-target="#AddNewSecurity">Add New Advance</label> -->
									<label class="btn btn-outline-secondary subbtngrp1" onclick="validateCP();">Add New Cash Collateral</label>
								</div> 
							</div>
						</div>
					</div>
				</div>
				<div class="card-body cdbody">
					<div class="row">
						<div class="col-sm-12 col-xs-12 col-md-12">
						<%if(counterparty_cd.equals("")){ %>
							<div align="center"><%=utilmsg.infoMessage("<b>Please Select Counterparty!</b>") %></div>
						<%}else{ %>
							<div class="table-responsive">
								<table class="table table-bordered" id="filterbysearch">
									<thead>
										<tr>
											<th>SR#</th>
											<th>Counterparty</th>
											<th>Deal Type</th>
											<th>Buy | Sell</th>
											<th>Cash Collateral Ref.</th>
											<th>Transaction Ref.</th>
											<th>Cash Collateral Type</th>
											<th>Credit | Debit</th>
											<th>Value(Amount + TDS)</th>
											<th>Currency</th>
											<th>Pay | Received Date</th>
											<th>Status</th>
											<th>Linked Deal#</th>
											<th>View</th>
											<th>Modify</th>
											<th>Check (Deal)</th>
											<th>Approve</th>
											<th>View | Print PDF</th>
											<th>SAP Approval</th>
											<th>Generate Reversal</th>
										</tr>
									</thead>
								<% if(VSEC_REF_NO.size()>0){  %>
									<% for(int i=0; i<VCOUNTERPARTY_CD.size(); i++){ %>
									<tbody>
										<tr>
											<td align="right"><%=i+1%></td>
											<td><%=VCOUNTERPARTY_NAME.elementAt(i) %></td>
											<td align="center"><%=VDEAL_TYPE.elementAt(i) %></td>
											<td></td>
											<td align="center"><%=VSEC_REF_NO.elementAt(i) %></td>
											<td align="center"><%=VADV_PG_REF.elementAt(i) %></td>
											<td align="center">
												<span 
												<%if(VSEC_TYPE.elementAt(i).equals("ADV")){ %>
		    										class="alert alert-info"
		    									<%}else if(VSEC_TYPE.elementAt(i).equals("DPT")){ %>
		    										class="alert alert-warning" <%}%>><%=VSEC_TYPE.elementAt(i) %></span></td>
											<td align="center"><%=VCRDR_NM.elementAt(i) %></td>
											<td align="right"><%=VTOTAL_VALUE.elementAt(i) %></td>
											<td align="center"><%=VCURRENCY_NM.elementAt(i) %></td>
											<td align="center"><%=VRECEIVED_DATE.elementAt(i) %></td>
											<td align="center">
												<%if(VSTATUS.elementAt(i).equals("P")){ %>
													<span class="alert alert-primary">Pending</span>
												<%}else if(VSTATUS.elementAt(i).equals("O")){  %>
													<span class="alert alert-success">In Order</span>
												<%}else if(VSTATUS.elementAt(i).equals("C")){  %>
													<span class="alert alert-danger">Cancelled</span>
												<%}else if(VSTATUS.elementAt(i).equals("A")){  %>
													<span class="alert alert-secondary">Pending For Amendment</span>
												<%}else if(VSTATUS.elementAt(i).equals("R")){  %>
													<span class="alert alert-warning">Restated</span>
												<%} %>
											</td>
											<td align="center"><%=VDEAL_NO.elementAt(i) %></td>
											<td align="center">
												<i class="fa fa-eye fa-2x" data-bs-toggle="modal" data-bs-target="#AddNewSecurity" 
													onclick="doModify('<%=VCOUNTERPARTY_CD.elementAt(i) %>','<%=VTEMP_SEC_REF_NO.elementAt(i)%>','<%=VSEQ_NO.elementAt(i)%>','<%=VSEQ_REV_NO.elementAt(i)%>','<%=VSEC_TYPE.elementAt(i) %>',
													'<%=VDEAL_MAPPING.elementAt(i)%>','<%=VCRDR.elementAt(i)%>','<%=VVALUE.elementAt(i)%>','<%=VCURRENCY.elementAt(i)%>',
													'<%=VTDS_STRUCT_CD.elementAt(i)%>','<%=VTDS_EFF_DT.elementAt(i)%>','<%=VTDS_STRUCT_INFO.elementAt(i)%>','<%=VTDS_AMT.elementAt(i)%>',
													'<%=VRECEIVED_DATE.elementAt(i)%>','<%=VADV_PG_REF.elementAt(i) %>','<%=VDEAL_TYPE.elementAt(i)%>','<%=VSTATUS.elementAt(i)%>','<%=VREMARK.elementAt(i)%>','');">
												</i>
											</td>
											<td align="center">
												<i class="fa fa-pencil fa-2x" data-bs-toggle="modal" data-bs-target="#AddNewSecurity" 
													onclick="doModify('<%=VCOUNTERPARTY_CD.elementAt(i) %>','<%=VTEMP_SEC_REF_NO.elementAt(i)%>','<%=VSEQ_NO.elementAt(i)%>','<%=VSEQ_REV_NO.elementAt(i)%>','<%=VSEC_TYPE.elementAt(i) %>',
													'<%=VDEAL_MAPPING.elementAt(i)%>','<%=VCRDR.elementAt(i)%>','<%=VVALUE.elementAt(i)%>','<%=VCURRENCY.elementAt(i)%>',
													'<%=VTDS_STRUCT_CD.elementAt(i)%>','<%=VTDS_EFF_DT.elementAt(i)%>','<%=VTDS_STRUCT_INFO.elementAt(i)%>','<%=VTDS_AMT.elementAt(i)%>',
													'<%=VRECEIVED_DATE.elementAt(i)%>','<%=VADV_PG_REF.elementAt(i) %>','<%=VDEAL_TYPE.elementAt(i)%>','<%=VSTATUS.elementAt(i)%>','<%=VREMARK.elementAt(i)%>','MODIFY');"
													style="<%if(VSTATUS.elementAt(i).equals("C") || VSTATUS.elementAt(i).equals("O")){ %>
														pointer-events: none; opacity: .65; color: gray;
														<%} else {%>
															color:var(--header_color);
														<%}%>">
												</i>
											</td>
											<td align="center">
												<i class="fa fa-handshake-o fa-2x" data-bs-toggle="modal" data-bs-target="#AddNewSecurity" 
													onclick="doModify('<%=VCOUNTERPARTY_CD.elementAt(i) %>','<%=VTEMP_SEC_REF_NO.elementAt(i)%>','<%=VSEQ_NO.elementAt(i)%>','<%=VSEQ_REV_NO.elementAt(i)%>','<%=VSEC_TYPE.elementAt(i) %>',
													'<%=VDEAL_MAPPING.elementAt(i)%>','<%=VCRDR.elementAt(i)%>','<%=VVALUE.elementAt(i)%>','<%=VCURRENCY.elementAt(i)%>',
													'<%=VTDS_STRUCT_CD.elementAt(i)%>','<%=VTDS_EFF_DT.elementAt(i)%>','<%=VTDS_STRUCT_INFO.elementAt(i)%>','<%=VTDS_AMT.elementAt(i)%>',
													'<%=VRECEIVED_DATE.elementAt(i)%>','<%=VADV_PG_REF.elementAt(i) %>','<%=VDEAL_TYPE.elementAt(i)%>','<%=VSTATUS.elementAt(i)%>','<%=VREMARK.elementAt(i)%>','CHECK');"
													style="<%if(VSTATUS.elementAt(i).equals("C") || VSTATUS.elementAt(i).equals("O")){ %>
														pointer-events: none; opacity: .65; color: gray;
														<%} else {%>
															color:#ff3399;
														<%}%>">
												</i>
											</td>
											<td align="center">
												<i class="fa fa-flag fa-2x" data-bs-toggle="modal" data-bs-target="#AddNewSecurity" 
													onclick="doModify('<%=VCOUNTERPARTY_CD.elementAt(i) %>','<%=VTEMP_SEC_REF_NO.elementAt(i)%>','<%=VSEQ_NO.elementAt(i)%>','<%=VSEQ_REV_NO.elementAt(i)%>','<%=VSEC_TYPE.elementAt(i) %>',
													'<%=VDEAL_MAPPING.elementAt(i)%>','<%=VCRDR.elementAt(i)%>','<%=VVALUE.elementAt(i)%>','<%=VCURRENCY.elementAt(i)%>',
													'<%=VTDS_STRUCT_CD.elementAt(i)%>','<%=VTDS_EFF_DT.elementAt(i)%>','<%=VTDS_STRUCT_INFO.elementAt(i)%>','<%=VTDS_AMT.elementAt(i)%>',
													'<%=VRECEIVED_DATE.elementAt(i)%>','<%=VADV_PG_REF.elementAt(i) %>','<%=VDEAL_TYPE.elementAt(i)%>','<%=VSTATUS.elementAt(i)%>','<%=VREMARK.elementAt(i)%>','APPROVE');"
													style="<%if(VSTATUS.elementAt(i).equals("C") || VSTATUS.elementAt(i).equals("O")){ %>
														pointer-events: none; opacity: .65; color: gray;
														<%} else {%>
															color:#00cc00;
														<%}%>">
												</i>
											</td>
											<td align="center">
											<%if(!VSAP_APPROVAL_FLAG.elementAt(i).equals("X")){ %>
												<%if(!VPDF_GENERATED.elementAt(i).equals("Y")){ %>
													<i class="fa fa-print fa-2x"
														onclick="printPDF('<%=VCOUNTERPARTY_CD.elementAt(i)%>', '<%=VSEQ_NO.elementAt(i) %>', 
																			'<%=VSEQ_REV_NO.elementAt(i) %>', '<%=clearance%>','N');" 
														style="<%if(VSTATUS.elementAt(i).equals("O")){ %>
															color:#800000;
														<%} else {%>
															pointer-events: none; opacity: .65; color: gray;												
														<%}%>">											
													</i>		
												<%} else {%>
													<i class="fa fa-file-pdf-o fa-2x"
														onclick="openPdfFile('<%=file_url%><%=VPDF_FILE_NAME.elementAt(i)%>');" 
														style="color:red;">												
													</i>
												<%} %>												
											<%} %>	
											</td>
											<td align="center">		
											<%if(!VSAP_APPROVAL_FLAG.elementAt(i).equals("X")){ %>
												<i class="fa <%if(!VSAP_APPROVAL_FLAG.elementAt(i).equals("Y")){ %>fa-file-code-o<%}else{%>fa-eye<%} %> fa-2x" 
														onclick="doGenXML('<%=VCOUNTERPARTY_CD.elementAt(i)%>','<%=clearance%>',
													 '<%=VSEQ_NO.elementAt(i)%>',<%=VSEQ_REV_NO.elementAt(i) %>,'<%=VSAP_APPROVAL_FLAG.elementAt(i)%>',
													 '<%=VSEC_REF_NO.elementAt(i)%>','N', '<%=VPDF_GENERATED.elementAt(i)%>');"
													style="<%if(VSTATUS.elementAt(i).equals("O")){ %>
														color: orange;
													<%} else {%>
															pointer-events: none; opacity: .65; color: gray;
													<%}%>">
												</i>
											<%}%>
											</td>
											<td align="center">
											<%if(!VSAP_APPROVAL_FLAG.elementAt(i).equals("X")){ %>
												<i class="fa fa-retweet fa-2x" 
														onclick="doGenXML('<%=VCOUNTERPARTY_CD.elementAt(i)%>','<%=clearance%>',
													 '<%=VSEQ_NO.elementAt(i)%>',<%=VSEQ_REV_NO.elementAt(i) %>,'<%=VSAP_APPROVAL_FLAG.elementAt(i)%>',
													 '<%=VSEC_REF_NO.elementAt(i)%>','N', '<%=VPDF_GENERATED.elementAt(i)%>');"
													style="<%if(VSAP_APPROVAL_FLAG.elementAt(i).equals("Y")){ %>
														color: blue;
													<%} else {%>
															pointer-events: none; opacity: .65; color: gray;
													<%}%>">
												</i>
											<%}%>
											</td>
										</tr>
									</tbody>
									<%} %>
								<%}else{ %>
									<tr><td colspan="20" align="center"><%=utilmsg.infoMessage("<b>No Cash Collateral Available!</b>") %></td></tr>
								<%} %>
								</table>
							</div>
						<%} %>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="AddNewSecurity" data-bs-backdrop="static" data-bs-keyboard="false">
	<div class="modal-dialog modal-dialog-scrollable modal-xl">
    	<div class="modal-content">
    		<div class="modal-header cdheader">
        		<div class="topheader" id="model_hder_nm">
        			Add Cash Collateral
        		</div>
        		<input type="button" class="btn-close" data-bs-dismiss="modal">
        	</div>
        	<div class="modal-body mdbody">
      			<div class="cdbody" id="modelBodyParam">
      				<div class="row m-b-5">
      					<div class="col-sm-2 col-xs-2 col-md-2">  
							<div class="form-group row">
								<label class="form-label"><b>Counterparty<span class="s-red">*</span> </b></label>
							</div>
						</div>
						<div class="col-sm-10 col-xs-10 col-md-10">  
							<div class="form-group row">
				    			<div class="col-sm-12 col-xs-12 col-md-12">
									<select class="form-select form-select-sm" name="counterparty" >
										<option value="">--Select--</option>
										<%for(int i=0;i<VMST_COUNTERPARTY_CD.size();i++){ %>
											<option value="<%=VMST_COUNTERPARTY_CD.elementAt(i)%>"><%=VMST_COUNTERPARTY_ABBR.elementAt(i)%> - <%=VMST_COUNTERPARTY_NM.elementAt(i) %></option>
										<%} %>
									</select>
									<input type="hidden" name="ref_no" value="">
									<input type="hidden" name="seq_no" value="">
									<input type="hidden" name="seq_rev_no" value="">
								</div>
							</div>
						</div>
					</div>
					<div class="row m-b-5">
						<div class="col-sm-2 col-xs-2 col-md-2">  
							<div class="form-group row">
				    			<label class="form-label"><b>Cash Collateral Type<span class="s-red">*</span></b></label>
				  			</div>
						</div>
						<div class="col-sm-4 col-xs-4 col-md-4">  
							<div class="form-group row">
				    			<div class="col-sm-12 col-xs-12 col-md-12">
				      				<select class="form-select form-select-sm" name="sec_type">
				      					<option value="">--Select--</option>
				      					<option value="ADV">ADV - Advance Payment</option>
				      					<option value="DPT">DPT - Cash Deposit</option>
				      				</select>
				    			</div>
				  			</div>
						</div>
						<div class="col-sm-2 col-xs-2 col-md-2">  
							<div class="form-group row">
				    			<label class="form-label"><b>Credit | Debit<span class="s-red">*</span></b></label>
				  			</div>
						</div>
						<div class="col-sm-4 col-xs-4 col-md-4">  
							<div class="form-group row">
				    			<div class="col-sm-12 col-xs-12 col-md-12">
				      				<div class="input-group input-group-sm" >
			      						<select class="form-select form-select-sm" name="crdr">
			      							<option value="">--Select--</option>
					      					<option value="CR">Credit</option>
					      					<option value="DR">Debit</option>
				      					</select>
		      						</div>
				    			</div>
				  			</div>
						</div>
      				</div>
      				<div class="row m-b-5">
      					<div class="col-sm-2 col-xs-2 col-md-2"> 
							<div class="form-group row">
				    			<label class="form-label"><b>Amount<span class="s-red">*</span></b></label>
				  			</div>
						</div>
				  		<div class="col-sm-4 col-xs-4 col-md-4">
							<div class="form-group row">
								<div class="col-8">							
				      				<input type="text" class="form-control form-control-sm" name="value" onblur="negNumber(this);checkNumber1(this,10,2);">	
				      			</div>
				      			<div class="col-4">				    			
				      				<select class="form-select form-select-sm" name="currency">
				      					<option value="1">INR</option>
				      					<!-- <option value="2">USD</option> -->
				      				</select>
				    			</div>
				  			</div>
				  		</div>
				   		<div class="col-sm-2 col-xs-2 col-md-2" id="row_tds">  
			    			<input type="button" class="btn btn-sm config_btn" value="TDS Config" onclick="openTcsTdsStructMst('TDS');">
							<input type="hidden" name="tds_cd" value="">
							<input type="hidden" name="tds_dt" value="">
						</div>
						<div class="col-sm-4 col-xs-4 col-md-4" id="row_tds1">  
							<div class="form-group row">
								<div class="col-4">
									<textarea class="form-control form-control-sm" name="tds_struct_info" cols="75" rows="1" style="font-weight: bold;" readOnly></textarea>
				    			</div>
				    			<div class="col-5">				    				
			    					<input type="text" class="form-control form-control-sm" name="tds_amt" value="" onblur="negNumber(this);checkNumber1(this,8,2);">
				    			</div>
				    			<div class="col-3">	
			    					<select class="form-select form-select-sm" name="tds_amt_unit">
					  					<option value="1">INR</option>
										<!-- <option value="2">USD</option> -->
									</select>
								</div>
				    		</div>
				    	</div>			    	 	
				  	</div>
      				<div class="row m-b-5">	
				  		<div class="col-sm-2 col-xs-2 col-md-2">  
							<div class="form-group row">
				    			<label class="form-label"><b>Pay/Received Date<span class="s-red">*</span></b></label>
				  			</div>
						</div>
						<div class="col-sm-4 col-xs-4 col-md-4">  
							<div class="form-group row">
				    			<div class="col-sm-12 col-xs-12 col-md-12">
				      				<div class="input-group input-group-sm" >
			      						<input type="text" class="form-control form-control-sm date fmsdtpick" name="received_dt" value="" maxLength="10" 
			      						onblur="validateDate(this);" onchange="validateDate(this);" autocomplete="off">
			      						<span class="input-group-text"><i class="fa fa-calendar fa-lg"></i></span>
		      						</div>
				    			</div>
				  			</div>
						</div>
						<div class="col-sm-2 col-xs-2 col-md-2">  
							<div class="form-group row">
				    			<label class="form-label"><b>Transaction Ref#<span class="s-red">*</span></b></label>
				  			</div>
						</div>
						<div class="col-sm-4 col-xs-4 col-md-4">  
							<div class="form-group row">
				    			<div class="col-sm-12 col-xs-12 col-md-12">
		      						<input type="text" class="form-control form-control-sm" name="pg_ref" maxlength="12">
				    			</div>
				  			</div>
						</div>
					</div>	
					<div class="row m-b-5">	
						<div class="col-sm-2 col-xs-2 col-md-2">  
							<div class="form-group row">
								<div class="col-sm-12 col-xs-12 col-md-12">
									<input type="button" class="btn btn-sm config_btn" value="Attach Contract#" id="attch_cont_btn"; 
					    			data-bs-toggle="modal" data-bs-target="#DealNoModel">
					    			
					    			<select class="form-select form-select-sm" name="deal_type" style="display: none;">
				      					<option value="">--Select--</option>
				      					<option value="GAS" >GAS</option>
				      					<option value="LTCORA" >LTCORA</option>
				      				</select>
				  				</div>
				  			</div>
						</div>
						<div class="col-sm-4 col-xs-4 col-md-4">  
							<div class="form-group row">
				    			<div class="col-sm-12 col-xs-12 col-md-12">
				    				<label class="form-label" id="DealNoDisplay" style="display:none;"></label>
				      			</div>
				  			</div>
						</div>	
					</div>
      				<div class="row m-b-5">
      					<div class="col-sm-2 col-xs-2 col-md-2">  
							<div class="form-group row">
				    			<label class="form-label"><b>Status<span class="s-red">*</span></b></label>
				  			</div>
						</div>
						<div class="col-sm-4 col-xs-4 col-md-4">  
							<div class="form-group row">
				    			<div class="col-sm-12 col-xs-12 col-md-12">
				      				<select class="form-select form-select-sm" name="status">
				      					<option id="opt0" value="">--Select--</option>
				      					<option id="opt1" value="O" style="pointer-events: none;">In order</option>
				      					<option id="opt2" value="A">Pending for Amendment</option>
				      					<option id="opt3" value="C">Cancelled</option>
				      				</select>				      				
				      			</div>
				  			</div>
						</div>							
					</div>				
					<div class="row m-b-5">
						<div class="col-sm-2 col-xs-2 col-md-2">  
							<div class="form-group row">
				    			<label class="form-label"><b>Remark</b></label>
				  			</div>
						</div>
						<div class="col-sm-12 col-xs-12 col-md-10">  
							<div class="form-group row">
				    			<div class="col-sm-12 col-xs-12 col-md-12">
				    				<input type="text" class="form-control form-control-sm" name="remark">
				    			</div>
				  			</div>
						</div>
					</div>
      			</div>
      		</div>
      		<div class="modal-footer cdfooter">
        		<div align="right" id="div_id_btn">
        			<%if(write_access.equals("Y")){ %>
					<input type="button" class="btn btn-warning com-btn" value="Submit" onclick="doSubmit();">
					<%}else{ %>
					<input type="button" class="btn btn-warning com-btn" value="Submit" disabled>
					<%} %>
				</div>
      		</div>
        </div>
	</div>
</div>

<div class="modal fade" id="DealNoModel" data-bs-backdrop="static" data-bs-keyboard="false">
	<div class="modal-dialog modal-dialog-scrollable modal-xl">
    	<div class="modal-content">
    		<div class="modal-header cdheader">
        		<div class="topheader">
        			Deal No
        		</div>
        	</div>
        	<div class="modal-body mdbody">
        		<div class="cdbody">
        			<div class="row">
						<div class="col-sm-12 col-xs-12 col-md-12">
							<div class="table-responsive">
								<table class="table table-bordered">
									<tbody>
									<%if(VCONTRACT_MAPPING.size() > 0){ %>
				        				<%for(int i=0; i<VCONTRACT_MAPPING.size(); i++){%>
			        					<tr id="tbtr_<%=i%>" <%if(VCONTRACT_EXPIRED.elementAt(i).equals("Y")){ %>style="display: none"<%} %>>
			        						<td align="center">
			        							<input type="radio" class="form-check-input" name="chk_deal" value="<%=VCONTRACT_MAPPING.elementAt(i)%>" onclick="doDealEnabled(this,'<%=i%>')">
							    			</td>
							    			<td align="center"><%=VCONTRACT_DEAL_TYPE.elementAt(i)%></td>
				        					<td>
				        						<%=VCONTRACT_MAPPING_DIS.elementAt(i) %>
				        						<input type="hidden"  name="deal_dtl" id="deal_dtl_<%=i%>" value="<%=VCONTRACT_MAPPING.elementAt(i)%>" disabled>
				        						<input type="hidden"  name="deal_exp" id="deal_exp_<%=i%>" value="<%=VCONTRACT_EXPIRED.elementAt(i)%>">
				        						<input type="hidden"  name="cont_deal_type" id="cont_deal_exp_<%=i%>" value="<%=VCONTRACT_DEAL_TYPE.elementAt(i)%>">
							    				<input type="hidden"  name="display_deal_dtl" value="<%=VCONTRACT_MAPPING_DIS_1.elementAt(i)%>">
							    			</td>
				        				</tr>
			        					<%} %>
			        				<%}else{ %>
			        					<tr>
			        						<td colspan="2" align="center"><%=utilmsg.infoMessage("<b>No Active/Upcoming Contracts Detail are Avaliable!</b>") %></td>
			        					</tr>
			        				<%} %>
		        					</tbody>
	        					</table>
	        				</div>
	        			</div>
        			</div>
        			<div align="center" id="new_msg" style="display: none;"></div>
      			</div>
        	</div>
        	<div class="modal-footer cdfooter">
        		<div class="d-flex justify-content-between">
					<input type="button" class="btn btn-warning com-btn" value="Back" data-bs-target="#AddNewSecurity" data-bs-toggle="modal" data-bs-dismiss="modal">
					<input type="button" class="btn btn-warning com-btn" value="Submit" onclick="doSubmitDealNo()" 
					data-bs-target="#AddNewSecurity" data-bs-toggle="modal" data-bs-dismiss="modal">
				</div>
      		</div>
        </div>
    </div>
</div>

<input type="hidden" name="option" value="CASH_COLLATERAL_MST">
<input type="hidden" name="opration" value="INSERT">
<input type="hidden" name="prev_clearance" value="<%=clearance%>">
<input type="hidden" name="clearance" value="<%=clearance%>">

<input type="hidden" name="form_cd" value="<%=formCd%>">
<input type="hidden" name="form_nm" value="<%=formNm%>">
<input type="hidden" name="mod_cd" value="<%=mod_cd%>">
<input type="hidden" name="mod_nm" value="<%=mod_nm%>">	
<input type="hidden" name="u" value="<%=u%>">		

</form>

</body>
</html>